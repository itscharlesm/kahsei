<style>
    @media print {
        body {
            zoom: 100%;
        }

        .no-print {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }

        .print-hide {
            display: none !important;
        }
    }

    .table-responsive {
        overflow: visible !important;
    }

    #sectionB {
        overflow: visible !important;
    }

    #timelineTabs .nav-link {
        color: #28a745;
    }

    #timelineTabs .nav-link.active {
        color: #28a745;
        border-color: #28a745 #28a745 #fff;
    }

    #timelineTabs .nav-link:hover {
        color: #1e7e34;
        border-color: #1e7e34 #1e7e34 transparent;
    }

    body.layout-fixed .content-wrapper {
        height: auto !important;
        min-height: auto !important;
        overflow-y: visible !important;
    }
</style>

@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Ongoing Appointment</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointment</li>
                        <li class="breadcrumb-item">Ongoing</li>
                        <li class="breadcrumb-item active">View</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="text-center mb-2">
                        <h5 style="margin: 0; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
                        <p style="margin: 0;">{{ $display->branch_name }}</p>
                    </div>

                    <div class="mb-4 position-relative text-center">
                        <strong style="color: red;">SERVICE ORDER</strong>

                        <strong style="position: absolute; right: 0; top: 0;">
                            SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </strong>
                    </div>
                    <div class="row">

                        {{-- Appointment Information Display --}}
                        <div class="table-responsive overflow-auto" id="sectionA">
                            <table class="table table-bordered text-left align-middle">
                                <tbody>
                                    <tr>
                                        <th colspan="6" class="text-center table-light">CLIENT INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">CLIENT NAME</td>
                                        <td>{{ $display->usr_first_name }} {{ $display->usr_last_name }}</td>
                                        <td style="font-weight: bold;">EMAIL</td>
                                        <td>{{ $display->usr_email }}</td>
                                        <td style="font-weight: bold;">MOBILE</td>
                                        <td>{{ $display->usr_mobile }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">ADDRESS</td>
                                        <td colspan="3">
                                            {{ implode(
                                                ', ',
                                                array_filter([
                                                    $display->uadd_street,
                                                    $display->uadd_barangay,
                                                    $display->uadd_city,
                                                    $display->uadd_province,
                                                    $display->uadd_region,
                                                ]),
                                            ) }}
                                        </td>
                                        <td style="font-weight: bold;">ADDRESS TYPE</td>
                                        <td>{{ $display->add_name }}</td>
                                    </tr>

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SERVICE INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">BRANCH</td>
                                        <td>{{ $display->branch_name }}</td>
                                        <td style="font-weight: bold;">STATUS</td>
                                        <td>{{ $display->svc_status }}</td>
                                        <td style="font-weight: bold;">PAYMENT STATUS</td>
                                        <td>{{ $display->svc_payment_status }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">PROPERTY TYPE</td>
                                        <td>{{ $display->svc_property_type }}</td>
                                        <td style="font-weight: bold;">INFESTATION</td>
                                        <td>{{ $display->svc_infestation }}</td>
                                        <td style="font-weight: bold;">DISTANCE</td>
                                        <td>{{ $display->svc_km_distance }} KM</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">IS TERMITE</td>
                                        <td>{{ $display->svc_is_termite ? 'YES' : 'NO' }}</td>
                                        <td style="font-weight: bold;">IS PACKAGE</td>
                                        <td colspan="3">{{ $display->svc_is_package ? 'YES' : 'NO' }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">INITIAL SQM</td>
                                        <td>{{ $display->svc_sqm_initial ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">FINAL SQM</td>
                                        <td colspan="3">{{ $display->svc_sqm_final ?? 'N/A' }}</td>
                                    </tr>

                                    @if (!empty($display->svc_problem_description))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">PROBLEM DESCRIPTION / CLIENT REQUEST</th>
                                        </tr>

                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_problem_description }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">PRICING</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">INITIAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_initial_price, 2) }}</td>
                                        <td style="font-weight: bold;">LOCATION PRICE</td>
                                        <td>₱{{ number_format($display->svc_location_price, 2) }}</td>
                                        <td style="font-weight: bold;">FIXED PRICE</td>
                                        <td>₱{{ number_format($display->svc_fixed_price, 2) }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">FINAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_final_price, 2) }}</td>
                                        <td style="font-weight: bold;">BALANCE</td>
                                        <td colspan="3">₱{{ number_format($display->svc_balance, 2) }}</td>
                                    </tr>

                                    @if ($display->svc_is_termite)
                                        <tr>
                                            <th colspan="6" class="text-center table-light">TERMITE CASE</th>
                                        </tr>

                                        <tr>
                                            <td style="font-weight: bold;">TREATMENT TYPE</td>
                                            <td>{{ $display->svc_type_treatment }}</td>
                                            <td style="font-weight: bold;">INITIAL SQM</td>
                                            <td>{{ $display->svc_sqm_initial }}</td>
                                            <td style="font-weight: bold;">FINAL SQM</td>
                                            <td>{{ $display->svc_sqm_final }}</td>
                                        </tr>

                                        <tr>
                                            <td style="font-weight: bold;">WITH DEVICE</td>
                                            <td>{{ $display->svc_with_device ? 'YES' : 'NO' }}</td>
                                            <td style="font-weight: bold;">DEVICE COUNT</td>
                                            <td colspan="3">{{ $display->svc_device_count ?? 'N/A' }}</td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">CHEMICAL</th>
                                    </tr>

                                    @forelse ($serviceChemicals as $chem)
                                        <tr>
                                            <td style="font-weight: bold;">CHEMICAL</td>
                                            <td>{{ $chem->chem_name }}</td>
                                            <td style="font-weight: bold;">EXPECTED QUANTITY</td>
                                            <td>{{ $chem->svcch_expected_quantity }}</td>
                                            <td style="font-weight: bold;">METRIC</td>
                                            <td>{{ $chem->svcch_unit }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No chemicals recorded.</td>
                                        </tr>
                                    @endforelse

                                    @if (!empty($display->svc_assessment_recommendation))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">ASSESSMENT RECOMMENDATION
                                            </th>
                                        </tr>
                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_assessment_recommendation }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SCHEDULE</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE REQUESTED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_client_date)->format('m/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME REQUESTED</td>
                                        <td colspan="3">{{ \Carbon\Carbon::parse($display->svca_client_time)->format('h:i A') }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE APPROVED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_date_approved)->format('m/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME APPROVED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_approved_time_from)->format('h:i A') }} - {{ \Carbon\Carbon::parse($display->svca_approved_time_to)->format('h:i A') }}
                                        </td>
                                        <td style="font-weight: bold;">APPROVED BY</td>
                                        <td>{{ $display->approved_first_name }} {{ $display->approved_last_name }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE ASSIGNED</td>
                                        <td>
                                            {{ \Carbon\Carbon::parse($display->svcas_date_assigned)->format('m/d/Y | h:i A') }}
                                        </td>

                                        <td style="font-weight: bold;">ASSIGNED TO</td>
                                        <td colspan="3">
                                            {{ $display->assigned_to_label ?? 'N/A' }}
                                        </td>
                                    </tr>

                                    {{-- ONGOING: Date Started / Time Started / Elapsed Time --}}
                                    @if ($display->svc_status === 'ONGOING' && $display->svcas_start_date)
                                        @php
                                            $startDt = \Carbon\Carbon::parse(
                                                $display->svcas_start_date . ' ' . $display->svcas_start_time,
                                            );
                                            $now = \Carbon\Carbon::now();
                                            $elapsed = $startDt->diff($now);
                                            $elapsedStr = '';
                                            if ($elapsed->days) {
                                                $elapsedStr .= $elapsed->days . 'd ';
                                            }
                                            if ($elapsed->h) {
                                                $elapsedStr .= $elapsed->h . 'h ';
                                            }
                                            if ($elapsed->i) {
                                                $elapsedStr .= $elapsed->i . 'm ';
                                            }
                                            $elapsedStr .= $elapsed->s . 's';
                                            $elapsedStr = trim($elapsedStr) ?: '0s';
                                        @endphp
                                        <tr>
                                            <td style="font-weight: bold;">START</td>
                                            <td>{{ \Carbon\Carbon::parse($display->svcas_start_date)->format('m/d/Y') }} -
                                                {{ \Carbon\Carbon::parse($display->svcas_start_time)->format('h:i A') }}
                                            </td>
                                            <td style="font-weight: bold;">ELAPSED TIME</td>
                                            <td colspan="3">{{ $elapsedStr }}</td>
                                        </tr>
                                    @endif

                                    {{-- DONE SERVICE: Travel Time / Service Time / Total Time --}}
                                    @if ($display->svca_status === 'DONE SERVICE')
                                        @php
                                            $formatHrsMins = function ($timeStr) {
                                                [$h, $m] = explode(':', $timeStr ?? '00:00:00');
                                                $h = (int) $h;
                                                $m = (int) $m;

                                                if ($h == 0 && $m == 0) {
                                                    return '-';
                                                } elseif ($h > 0 && $m > 0) {
                                                    return "{$h} hr" . ($h > 1 ? 's' : '') . " and {$m} min" . ($m > 1 ? 's' : '');
                                                } elseif ($h > 0) {
                                                    return "{$h} hr" . ($h > 1 ? 's' : '');
                                                } else {
                                                    return "{$m} min" . ($m > 1 ? 's' : '');
                                                }
                                            };

                                            $totalSeconds = strtotime($display->svcas_time_finished ?? '00:00:00') - strtotime('00:00:00');
                                            $travelSeconds = strtotime($display->svcas_time_travel ?? '00:00:00') - strtotime('00:00:00');
                                            $serviceSeconds = max(0, $totalSeconds - $travelSeconds);

                                            $serviceTimeStr = sprintf('%02d:%02d:00', floor($serviceSeconds / 3600), floor(($serviceSeconds % 3600) / 60));
                                        @endphp
                                        <tr>
                                            <td style="font-weight: bold;">TRAVEL TIME</td>
                                            <td>{{ $formatHrsMins($display->svcas_time_travel) }}</td>
                                            <td style="font-weight: bold;">SERVICE TIME</td>
                                            <td>{{ $formatHrsMins($serviceTimeStr) }}</td>
                                            <td style="font-weight: bold;">TOTAL TIME</td>
                                            <td>{{ $formatHrsMins($display->svcas_time_finished) }}</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-end flex-wrap mb-3 no-print">
                            @if ($display->svca_status == 'ONGOING' && (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('QUALITY OFFICER') == '1'))
                                <button type="button" class="btn btn-warning mr-2 mb-2" data-toggle="modal"
                                    data-target="#markAsArrivedModal">
                                    <span class="fa fa-check"></span> MARK AS ARRIVED
                                </button>
                            @endif
                            @if ($display->svca_status == 'ARRIVED' && (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('QUALITY OFFICER') == '1'))
                                <button type="button" class="btn btn-warning mr-2 mb-2" data-toggle="modal"
                                    data-target="#markAsDoneServiceModal">
                                    <span class="fa fa-check"></span> MARK AS DONE SERVICE
                                </button>
                            @endif
                            @if ($display->svc_status == 'ONGOING')
                                <button type="button" class="btn btn-info mr-2 mb-2" data-toggle="modal"
                                    data-target="#trackTechnicianModal" onclick="loadTrackMap()">
                                    <span class="fa fa-location"></span> Track Technician
                                </button>
                            @endif
                            @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('ACCOUNTING OFFICER') == '1' || session('BILLING OFFICER') == '1')
                                <a class="btn btn-info mr-2 mb-2" href="{{ url('service/order/payment/view/' . $display->svc_id) }}">
                                    <span class="fa {{ $display->svc_payment_status == 'PAID' ? 'fa-history' : 'fa-money-bill' }}"></span> {{ $display->svc_payment_status == 'PAID' ? 'Payment History' : 'Payments' }}
                                </a>
                            @endif
                            <button type="button" class="btn btn-dark mr-2 mb-2" onclick="printDefault()">
                                <span class="fa fa-print"></span> Print
                            </button>
                            <div class="btn-group mr-2 mb-2">
                                <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <span class="fa fa-print"></span> Print Options
                                </button>
                                <div class="dropdown-menu p-3" style="min-width: 200px;">
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionA">
                                        Appointment Information
                                    </label>
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionB"> Service
                                        Orders
                                    </label>
                                    @if ($appointmentImages->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionC">
                                            Client Appointment Images
                                        </label>
                                    @endif
                                    @if ($mappingImages->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionD">
                                            Mapping Images
                                        </label>
                                    @endif
                                    @if ($contracts->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionF"> Client
                                            Service Contract
                                        </label>
                                    @endif
                                    <div class="dropdown-item text-center">
                                        <button class="btn btn-primary btn-sm mt-2" onclick="handlePrint()">Confirm &
                                            Print</button>
                                    </div>
                                    <div class="dropdown-item">
                                        <p id="warning" style="color:red; display:none;" class="mt-1">Select at least
                                            one section.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Service Order Display --}}
                        <div class="table-responsive" id="sectionB">
                            <hr class="no-print">
                            @if ($display->svc_is_termite == 0)
                                <div class="row">
                                    {{-- PEST TYPE TABLE --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="3"><strong>PEST TYPE</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Pest</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($pestTypes as $index => $type)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $type->svcp_pest_type }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>

                                    {{-- SERVICE ORDER TABLE --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="4"><strong>SERVICE ORDER</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Service</th>
                                                    <th>Cost</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($serviceAreas as $index => $area)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $area->svcpa_area }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            ₱{{ number_format($area->svcpa_cost, 2) }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            @elseif ($display->svc_is_termite == 1)
                                <div class="col-md-12">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="5"><strong>TERMITE DETAILS</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>SQM Details</th>
                                                <th>Cost</th>
                                                <th>Computation</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($termiteAreas as $index => $area)
                                                <tr>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $index + 1 }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $area->svcpat_sqm_details }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        ₱{{ number_format($area->svcpat_cost, 2) }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        @if ($display->svc_type_treatment == 'STANDARD TREATMENT')
                                                            <p>STANDARD TREATMENT: sqm × cost</p>
                                                        @elseif ($display->svc_type_treatment == 'HYBRID TREATMENT')
                                                            <p>HYBRID TREATMENT: sqm × cost + device</p>
                                                        @else
                                                            <p>{{ $display->svc_type_treatment }}: sqm × cost</p>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted">No termite areas
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            @endif
                        </div>

                        {{-- Client Appointment Images --}}
                        @if ($appointmentImages->count() > 0)
                            <div class="table-responsive" id="sectionC">
                                <table class="table table-bordered text-center mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5">
                                                <strong>CLIENT APPOINTMENT IMAGES</strong>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" style="padding: 10px;">
                                                <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                                    @foreach ($appointmentImages as $img)
                                                        <div class="p-2" style="width:20%;">
                                                            <a href="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                target="_blank"
                                                                style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                                                <img src="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                    alt="Mapping Image"
                                                                    style="width:100%; height:100%; object-fit:cover; display:block;">
                                                            </a>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Mapping Appointment Images --}}
                        @if ($mappingImages->count() > 0)
                            <div class="table-responsive" id="sectionD">
                                <table class="table table-bordered text-center mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5">
                                                <strong>MAPPING IMAGES</strong>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" style="padding: 10px;">
                                                <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                                    @foreach ($mappingImages as $img)
                                                        <div class="p-2" style="width:20%;">
                                                            <a href="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                                                target="_blank"
                                                                style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                                                <img src="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                                                    alt="Mapping Image"
                                                                    style="width:100%; height:100%; object-fit:cover; display:block;">
                                                            </a>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Service Contracts --}}
                        @if ($contracts->count() > 0)
                            <div class="table-responsive" id="sectionF">
                                <table class="table table-bordered mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5" class="text-center"><strong>SERVICE CONTRACT</strong></th>
                                        </tr>
                                        <tr style="background-color: #f5f5f5;">
                                            <th class="text-center" style="vertical-align: middle;">Frequency</th>
                                            <th class="text-center" style="vertical-align: middle;">Duration</th>
                                            <th class="text-center" style="vertical-align: middle;">Total Services</th>
                                            <th class="text-center no-print" style="vertical-align: middle;">Contract</th>
                                            <th class="text-center" style="vertical-align: middle;">Appointments</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($contracts as $contract)
                                            <tr>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_type }}</td>
                                                <td class="text-center" style="vertical-align: middle;">
                                                    @php
                                                        // Force 2 decimal places so the fraction always represents 2-digit months
                                                        $parts = explode('.', number_format((float) $contract->svcc_total_years, 2, '.', ''));
                                                        $yrs = (int) $parts[0];
                                                        $mos = (int) $parts[1];

                                                        $label = '';
                                                        if ($yrs > 0) {
                                                            $label .= $yrs . ' Year' . ($yrs > 1 ? 's' : '');
                                                        }
                                                        if ($mos > 0) {
                                                            $label .= ($label ? ' and ' : '') . $mos . ' Month' . ($mos > 1 ? 's' : '');
                                                        }
                                                        if (!$label) {
                                                            $label = '0 Months';
                                                        }
                                                    @endphp
                                                    {{ $label }}
                                                </td>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_total_services }}</td>
                                                <td class="text-center no-print" style="vertical-align: middle;">
                                                    @if ($contract->svcc_contract)
                                                        <a href="{{ asset('images/contracts/' . $contract->svcc_contract) }}"
                                                            class="badge badge-info p-2" style="font-size: 0.85rem;"
                                                            download target="_blank">
                                                            <i class="fas fa-download"></i> Download
                                                        </a>
                                                    @else
                                                        <span class="text-muted">No file.</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($contract->generated_services->isEmpty())
                                                        <span class="text-muted">No appointments generated.</span>
                                                    @else
                                                        <div class="d-flex flex-wrap" style="gap: 6px;">
                                                            @foreach ($contract->generated_services as $svc)
                                                                @php
                                                                    $statusRouteMap = [
                                                                        'CONFIRM ASSESSMENT' => 'service/order/appointments/requested/',
                                                                        'ASSESSED' => 'service/order/appointments/assessed/',
                                                                        'SCHEDULED' => 'service/order/appointments/scheduled/',
                                                                        'ONGOING' => 'service/order/appointments/ongoing/',
                                                                        'DONE REPORT' => 'service/order/appointments/finished/',
                                                                        'COMPLETED' => 'service/order/appointments/completed/',
                                                                    ];
                                                                    $routePrefix = $statusRouteMap[$svc->svc_status] ?? null;
                                                                    $saNumber = 'SA-' . str_pad($svc->svc_sa_number, 6, '0', STR_PAD_LEFT);
                                                                @endphp

                                                                @if ($routePrefix)
                                                                    <a href="{{ url($routePrefix . $svc->svc_id) }}" target="_blank"
                                                                        class="badge badge-primary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }}
                                                                    </a>
                                                                @else
                                                                    <span class="badge badge-secondary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }} ({{ $svc->svc_status }})
                                                                    </span>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Mark As Arrived Confirmation Modal --}}
    <div class="modal fade" id="markAsArrivedModal" tabindex="-1" role="dialog"
        aria-labelledby="markAsArrivedModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="markAsArrivedModalLabel">
                        Confirm Arrival
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST"
                    action="{{ url('service/order/appointments/ongoing/mark/arrived/' . $display->svc_id) }}">
                    @csrf

                    <div class="modal-body" style="text-align: center">
                        <input type="text" class="form-control" name="svc_id" value="{{ $display->svc_id }}" hidden>
                        Are you sure you want to mark this service order as <strong>ARRIVED</strong>?
                        <br>
                        <br>
                        <strong style="color: red;">
                            Once confirmed, the service order status will be changed to 
                            <em>"ARRIVED"</em>. This action should only be performed 
                            if the technician has a weak or unstable signal.
                        </strong>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-times"></span> Close
                        </button>
                        <button type="submit" class="btn btn-warning">
                            <span class="fa fa-check"></span> Confirm
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    {{-- Mark As Done Service Confirmation Modal --}}
    <div class="modal fade" id="markAsDoneServiceModal" tabindex="-1" role="dialog"
        aria-labelledby="markAsDoneServiceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="markAsDoneServiceModalLabel">
                        Confirm Service Completion
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST"
                    action="{{ url('service/order/appointments/ongoing/mark/done/service/' . $display->svc_id) }}">
                    @csrf

                    <div class="modal-body" style="text-align: center">
                        <input type="text" class="form-control" name="svc_id" value="{{ $display->svc_id }}" hidden>
                        Are you sure you want to mark this service order as <strong>DONE SERVICE</strong>?
                        <br>
                        <br>
                        <strong style="color: red;">
                            Once confirmed, the service order status will be changed to 
                            <em>"DONE SERVICE"</em>. This action should only be performed 
                            if the technician has a weak or unstable signal.
                        </strong>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-times"></span> Close
                        </button>
                        <button type="submit" class="btn btn-warning">
                            <span class="fa fa-check"></span> Confirm
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    {{-- Track Technician Modal --}}
    <div class="modal fade" id="trackTechnicianModal" tabindex="-1" role="dialog"
        aria-labelledby="trackTechnicianModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="trackTechnicianModalLabel">
                        <span class="fa fa-location"></span> Track Technician
                        <span id="trackTechName"></span>
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body p-0">
                    <div id="trackMapStatusBadge" class="text-center py-2" style="font-weight:bold; font-size:14px;">
                    </div>
                    <div id="trackMapLoading" class="text-center py-4 text-muted">
                        <span class="fa fa-spinner fa-spin"></span> Loading location...
                    </div>
                    <div id="trackMapNoLocation" class="text-center py-4 text-danger" style="display:none;">
                        <span class="fa fa-exclamation-circle"></span> No location data available for this technician.
                    </div>
                    <div id="trackTechMap"
                        style="width:100%; height:350px; border:1px solid #ccc; border-radius:4px; display:none;"></div>
                </div>
                <div class="modal-footer">
                    <small class="text-muted mr-auto">
                        <span class="fa fa-info-circle"></span> Location is fetched when you open this modal.
                    </small>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <span class="fa fa-close"></span> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function printDefault() {
            window.print();
        }

        function handlePrint() {
            const checkboxes = document.querySelectorAll('.print-toggle');
            const warning = document.getElementById('warning');
            let anyChecked = false;

            const sectionIds = ['sectionA', 'sectionB', 'sectionC', 'sectionD', 'sectionF'];

            sectionIds.forEach(sectionId => {
                const section = document.getElementById(sectionId);
                if (section) {
                    section.classList.remove('print-hide');
                }
            });

            checkboxes.forEach(checkbox => {
                const targetId = checkbox.dataset.target;
                const targetDiv = document.getElementById(targetId);

                if (targetDiv) {
                    if (checkbox.checked) {
                        anyChecked = true;
                        targetDiv.classList.remove('print-hide');
                    } else {
                        targetDiv.classList.add('print-hide');
                    }
                }
            });

            if (!anyChecked) {
                warning.style.display = 'block';
                return;
            }

            warning.style.display = 'none';

            setTimeout(() => {
                window.print();
            }, 500);

            setTimeout(() => {
                sectionIds.forEach(sectionId => {
                    const section = document.getElementById(sectionId);
                    if (section) {
                        section.classList.remove('print-hide');
                    }
                });
            }, 1000);
        }
    </script>

    {{-- Leaflet --}}
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        let trackMap = null;

        function loadTrackMap() {
            const svcId = {{ $display->svc_id }};

            // Reset UI
            document.getElementById('trackMapStatusBadge').textContent = '';
            document.getElementById('trackMapNoLocation').style.display = 'none';
            document.getElementById('trackTechMap').style.display = 'none';
            document.getElementById('trackMapLoading').style.display = 'block';
            document.getElementById('trackTechName').textContent = '';

            // Destroy old map instance if exists
            if (trackMap) {
                trackMap.remove();
                trackMap = null;
            }

            fetch(`/service/order/appointments/ongoing/track/${svcId}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('trackMapLoading').style.display = 'none';

                    if (!data || !data.svcal_latitude || !data.svcal_longitude) {
                        document.getElementById('trackMapNoLocation').style.display = 'block';
                        return;
                    }

                    const lat = parseFloat(data.svcal_latitude);
                    const lng = parseFloat(data.svcal_longitude);
                    const status = data.svca_status;

                    const clientLat = data.client_latitude ? parseFloat(data.client_latitude) : null;
                    const clientLng = data.client_longitude ? parseFloat(data.client_longitude) : null;

                    // Technician name in title
                    if (data.tech_first_name) {
                        document.getElementById('trackTechName').textContent =
                            ` — ${data.tech_first_name} ${data.tech_last_name}`;
                    }

                    // Status badge
                    const statusMap = {
                        ONGOING: { text: '🔴 ONGOING — Technician en route', color: '#dc3545' },
                        ARRIVED: { text: '🟠 ARRIVED — Technician on-site', color: '#fd7e14' },
                    };
                    const s = statusMap[status] || { text: status, color: '#6c757d' };
                    const badge = document.getElementById('trackMapStatusBadge');
                    badge.textContent = s.text;
                    badge.style.color = s.color;

                    // Show map container BEFORE initializing
                    const mapEl = document.getElementById('trackTechMap');
                    mapEl.style.display = 'block';

                    // Init map — must happen after display:block
                    setTimeout(() => {
                        trackMap = L.map('trackTechMap').setView([lat, lng], 16);

                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '© OpenStreetMap'
                        }).addTo(trackMap);

                        const motorSVG = `
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 56" width="48" height="56">
                            <circle cx="24" cy="22" r="20" fill="#dc3545" stroke="#fff" stroke-width="2"/>
                            <!-- Motorcycle body -->
                            <rect x="13" y="19" width="22" height="7" rx="2" fill="#fff" opacity="0.9"/>
                            <!-- Handlebars -->
                            <rect x="28" y="14" width="2" height="7" rx="1" fill="#fff" opacity="0.9"/>
                            <!-- Seat/fairing -->
                            <ellipse cx="24" cy="19" rx="7" ry="3" fill="#fff" opacity="0.8"/>
                            <!-- Front fork -->
                            <line x1="33" y1="19" x2="35" y2="26" stroke="#fff" stroke-width="1.5" opacity="0.9"/>
                            <!-- Rear wheel -->
                            <circle cx="14" cy="28" r="5" fill="none" stroke="#fff" stroke-width="2.5"/>
                            <circle cx="14" cy="28" r="2" fill="#fff"/>
                            <!-- Front wheel -->
                            <circle cx="35" cy="28" r="5" fill="none" stroke="#fff" stroke-width="2.5"/>
                            <circle cx="35" cy="28" r="2" fill="#fff"/>
                            <!-- Pin point -->
                            <polygon points="24,44 19,36 29,36" fill="#dc3545" stroke="#fff" stroke-width="1"/>
                            </svg>`;

                        const houseSVG = `
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 56" width="48" height="56">
                            <circle cx="24" cy="22" r="20" fill="#fd7e14" stroke="#fff" stroke-width="2"/>
                            <!-- Roof -->
                            <polygon points="24,8 11,20 37,20" fill="#fff"/>
                            <!-- House body -->
                            <rect x="14" y="20" width="20" height="14" rx="1" fill="#fff"/>
                            <!-- Door -->
                            <rect x="20" y="26" width="8" height="8" rx="1" fill="#fd7e14" opacity="0.4"/>
                            <!-- Wrench tool (rotated) -->
                            <g transform="translate(20,21) rotate(-35,4,5)">
                                <rect x="3" y="1" width="3" height="9" rx="1" fill="#fd7e14"/>
                                <rect x="1" y="1" width="7" height="3" rx="1.5" fill="#fd7e14"/>
                                <rect x="1" y="7" width="7" height="3" rx="1.5" fill="#fd7e14"/>
                            </g>
                            <!-- Pin point -->
                            <polygon points="24,44 19,36 29,36" fill="#fd7e14" stroke="#fff" stroke-width="1"/>
                            </svg>`;

                        // Distinct pin for the client's address (blue "flag/home" marker)
                        const clientSVG = `
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 56" width="40" height="47">
                            <circle cx="24" cy="22" r="20" fill="#0d6efd" stroke="#fff" stroke-width="2"/>
                            <path d="M24 12 L34 20 V32 H14 V20 Z" fill="#fff"/>
                            <rect x="21" y="24" width="6" height="8" fill="#0d6efd" opacity="0.5"/>
                            <polygon points="24,44 19,36 29,36" fill="#0d6efd" stroke="#fff" stroke-width="1"/>
                            </svg>`;

                        const icon = L.divIcon({
                            html: status === 'ARRIVED' ? houseSVG : motorSVG,
                            className: '',
                            iconSize: [48, 56],
                            iconAnchor: [24, 56]
                        });

                        const techMarker = L.marker([lat, lng], { icon }).addTo(trackMap)
                            .bindPopup(`Technician${data.tech_first_name ? ' — ' + data.tech_first_name + ' ' + data.tech_last_name : ''}`);

                        let bounds = L.latLngBounds([[lat, lng]]);

                        if (clientLat && clientLng) {
                            const clientIcon = L.divIcon({
                                html: clientSVG,
                                className: '',
                                iconSize: [40, 47],
                                iconAnchor: [20, 47]
                            });

                            const clientMarker = L.marker([clientLat, clientLng], { icon: clientIcon }).addTo(trackMap)
                                .bindPopup('Client address');

                            bounds.extend([clientLat, clientLng]);
                            trackMap.fitBounds(bounds, { padding: [60, 60], maxZoom: 16 });
                        } else {
                            trackMap.setView([lat, lng], 16);
                        }
                    }, 100);
                })
                .catch(() => {
                    document.getElementById('trackMapLoading').style.display = 'none';
                    document.getElementById('trackMapNoLocation').style.display = 'block';
                });
        }
    </script>
@endsection