import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/features/home/pages/client_home_page.dart';
import 'package:mobile_app/features/home/pages/technician_home_page.dart';
import 'package:mobile_app/features/profiles/pages/client_profile_page.dart';
import 'package:mobile_app/features/profiles/pages/technician_profile_page.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

import 'auth_session_profile_cache_test.dart' show accountA, accountB, profile;

Future<void> settleRoute(WidgetTester tester) async {
  await tester.pump();
  await tester.pump(const Duration(milliseconds: 400));
  await tester.pump();
}

void main() {
  const storageChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final auth = AuthSessionService.instance;
  late Map<String, String> storage;

  testWidgets('Phase 3 Profile/Edit Profile synchronization for both roles', (
    tester,
  ) async {
    storage = {};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(storageChannel, (call) async {
          final args = Map<String, dynamic>.from(call.arguments as Map);
          final key = args['key'] as String;
          switch (call.method) {
            case 'read':
              return storage[key];
            case 'write':
              storage[key] = args['value'] as String;
              return null;
            case 'delete':
              storage.remove(key);
              return null;
          }
          return null;
        });
    await auth.clearSession();
    await auth.displayProfile.persistenceSettled;
    // Keep the singleton and its serialized persistence queue on one test clock.
    Future<void> runScenario(
      String description,
      Future<void> Function(WidgetTester) body,
    ) async {
      debugPrint(description);
      await body(tester);
      await auth.clearSession();
      await auth.displayProfile.persistenceSettled;
    }

    for (final role in [3, 2]) {
      final label = role == 3 ? 'Client' : 'Technician';
      Widget profilePage() => role == 3
          ? const ClientProfilePage(email: accountA)
          : const TechnicianProfilePage(email: accountA);
      Widget homePage() => role == 3
          ? const ClientHomePage(email: accountA)
          : const TechnicianHomePage(email: accountA);

      await runScenario(
        '$label Profile renders cache immediately and refreshes shared state',
        (tester) async {
          await auth.saveSession(
            token: 'test',
            email: accountA,
            userType: role,
          );
          auth.displayProfile.completeEdit(
            auth.displayProfile.beginEdit()!,
            profile(accountA),
          );
          var calls = 0;
          final initial = Completer<http.Response>();
          await http.runWithClient(
            () async {
              await tester.pumpWidget(MaterialApp(home: profilePage()));
              expect(find.text('Alice Example'), findsOneWidget);
              expect(calls, 1);
              initial.complete(http.Response('{"success":false}', 500));
              await settleRoute(tester);
              expect(find.text('Alice Example'), findsOneWidget);
              await tester
                  .widget<RefreshIndicator>(find.byType(RefreshIndicator))
                  .onRefresh();
              await tester.pump();
              expect(find.text('Refreshed Example'), findsOneWidget);
              expect(auth.displayProfile.value?.firstName, 'REFRESHED');
              expect(calls, 2);
              await auth.clearSession();
              await tester.pump();
              expect(find.text('Refreshed Example'), findsNothing);
              await auth.saveSession(
                token: 'B',
                email: accountB,
                userType: role,
              );
              auth.displayProfile.completeEdit(
                auth.displayProfile.beginEdit()!,
                profile(accountB, name: 'BOB'),
              );
              await tester.pump();
              expect(find.text('Bob Example'), findsNothing);
              await tester.pumpWidget(const SizedBox.shrink());
            },
            () => MockClient((request) async {
              if (request.url.path == '/api/mobile/profile') {
                calls++;
                if (calls == 1) return initial.future;
                return http.Response(
                  jsonEncode({
                    'success': true,
                    'data': profile(accountA, name: 'REFRESHED'),
                  }),
                  200,
                );
              }
              return http.Response('{"success":true,"data":{}}', 200);
            }),
          );
        },
      );

      for (final scenario in [
        'name',
        'replace',
        'delete',
        'failed',
        'switch',
      ]) {
        await runScenario(
          '$label $scenario save synchronizes observers and rejects stale responses',
          (tester) async {
            tester.view.physicalSize = const Size(1000, 1800);
            tester.view.devicePixelRatio = 1;
            addTearDown(tester.view.resetPhysicalSize);
            addTearDown(tester.view.resetDevicePixelRatio);
            await auth.saveSession(
              token: 'test',
              email: accountA,
              userType: role,
            );
            final navigator = GlobalKey<NavigatorState>();
            final saveResponse = Completer<http.Response>();
            final oldResponse = Completer<http.Response>();
            var profileCalls = 0;
            var uploads = 0;
            var holdRefresh = false;
            final original = profile(accountA);
            final oldAvatar = original['usr_image_path'] as String;
            await http.runWithClient(
              () async {
                await tester.pumpWidget(
                  MaterialApp(navigatorKey: navigator, home: homePage()),
                );
                await settleRoute(tester);
                expect(find.text('Alice!'), findsOneWidget);
                unawaited(
                  navigator.currentState!.push(
                    MaterialPageRoute<void>(builder: (_) => profilePage()),
                  ),
                );
                await settleRoute(tester);
                expect(find.text('Alice Example'), findsOneWidget);
                expect(
                  profileCalls,
                  1,
                ); // Profile reuses Home's initial refresh.
                await tester.tap(find.byTooltip('Edit Profile'));
                await settleRoute(tester);
                expect(
                  profileCalls,
                  2,
                ); // Edit still needs birth date/non-display fields.
                final fields = find.byType(TextField);
                expect(
                  tester.widget<TextField>(fields.at(0)).controller!.text,
                  'Alice',
                );
                await tester.enterText(fields.at(0), 'Saved');
                await tester.enterText(fields.at(1), 'New Middle');
                await tester.enterText(fields.at(2), 'Person');

                if (scenario == 'replace' || scenario == 'delete') {
                  await tester.tap(find.byTooltip('Change Photo'));
                  await settleRoute(tester);
                  await tester.tap(
                    find.text(
                      scenario == 'delete'
                          ? 'Remove Photo'
                          : 'Choose an Avatar',
                    ),
                  );
                  await settleRoute(tester);
                  if (scenario == 'replace') {
                    final asset =
                        'assets/images/img_${role == 3 ? 'client' : 'technician'}_avatar_01.jpg';
                    await tester.tap(
                      find.byWidgetPredicate(
                        (widget) =>
                            widget is Image &&
                            widget.image is AssetImage &&
                            (widget.image as AssetImage).assetName == asset,
                      ),
                    );
                    await settleRoute(tester);
                  }
                }

                holdRefresh = true;
                final old = auth.displayProfile.refresh();
                await tester.tap(find.text('Save Changes'));
                if (scenario == 'replace') {
                  await tester.runAsync(() async {
                    for (var i = 0; i < 100 && uploads == 0; i++) {
                      await Future<void>.delayed(
                        const Duration(milliseconds: 10),
                      );
                    }
                  });
                }
                await tester.pump();
                expect(uploads, 1);
                expect(auth.displayProfile.value?.firstName, 'ALICE');
                expect(auth.displayProfile.value?.avatarPath, oldAvatar);

                if (scenario == 'switch') {
                  await auth.clearSession();
                  await auth.saveSession(
                    token: 'B',
                    email: accountB,
                    userType: role,
                  );
                  auth.displayProfile.completeEdit(
                    auth.displayProfile.beginEdit()!,
                    profile(accountB, name: 'BOB'),
                  );
                }
                saveResponse.complete(
                  http.Response(
                    jsonEncode({
                      'success': scenario != 'failed',
                      if (scenario == 'failed') 'message': 'Save rejected',
                      if (scenario == 'replace')
                        'image_path': 'images/replaced.jpg',
                      if (scenario == 'delete') 'image_path': null,
                      // A name-only response omits image_path to test absence != deletion.
                    }),
                    scenario == 'failed' ? 422 : 200,
                  ),
                );
                await settleRoute(tester);
                oldResponse.complete(
                  http.Response(
                    jsonEncode({'success': true, 'data': original}),
                    200,
                  ),
                );
                await old;
                await settleRoute(tester);
                expect(
                  profileCalls,
                  3,
                ); // No discovery fetch on return from edit.

                final expectedName = scenario == 'switch'
                    ? 'BOB'
                    : scenario == 'failed'
                    ? 'ALICE'
                    : 'SAVED';
                final expectedAvatar = scenario == 'delete'
                    ? null
                    : scenario == 'replace'
                    ? 'images/replaced.jpg'
                    : scenario == 'switch'
                    ? 'images/$accountB.png'
                    : oldAvatar;
                expect(auth.displayProfile.value?.firstName, expectedName);
                expect(auth.displayProfile.value?.avatarPath, expectedAvatar);
                await auth.displayProfile.persistenceSettled;
                final persisted =
                    jsonDecode(storage['auth_display_profile_v1']!) as Map;
                expect(persisted['usr_first_name'], expectedName);
                expect(persisted['usr_image_path'], expectedAvatar);

                if (scenario == 'failed') {
                  expect(find.text('Save rejected'), findsOneWidget);
                  navigator.currentState!.pop();
                  await settleRoute(tester);
                }
                if (scenario == 'switch') {
                  expect(find.text('Saved Person'), findsNothing);
                  expect(find.text('Bob Example'), findsNothing);
                } else {
                  final displayed = scenario == 'failed'
                      ? 'Alice Example'
                      : 'Saved Person';
                  expect(find.text(displayed), findsOneWidget);
                  final images = tester
                      .widgetList<Image>(find.byType(Image))
                      .where((image) => image.image is NetworkImage)
                      .map((image) => (image.image as NetworkImage).url);
                  if (expectedAvatar == null) {
                    expect(images, isEmpty);
                  } else {
                    expect(
                      images.any((url) => url.endsWith(expectedAvatar)),
                      isTrue,
                    );
                  }
                  navigator.currentState!.pop();
                  await settleRoute(tester);
                  expect(
                    find.text(scenario == 'failed' ? 'Alice!' : 'Saved!'),
                    findsOneWidget,
                  );
                  final scaffold = tester.state<ScaffoldState>(
                    find.byType(Scaffold).first,
                  );
                  scaffold.openDrawer();
                  await settleRoute(tester);
                  expect(find.text(displayed), findsOneWidget);
                  for (final avatar in tester.widgetList<AppProfileAvatar>(
                    find.byType(AppProfileAvatar),
                  )) {
                    if (expectedAvatar == null) {
                      expect(avatar.imageUrl, isNull);
                    } else {
                      expect(avatar.imageUrl, endsWith(expectedAvatar));
                    }
                  }
                  expect(profileCalls, 3);
                }
                await tester.pumpWidget(const SizedBox.shrink());
              },
              () => MockClient((request) async {
                if (request.url.path == '/api/mobile/profile/update') {
                  uploads++;
                  final payload = latin1.decode(request.bodyBytes);
                  expect(payload, contains('name="email"\r\n\r\n$accountA'));
                  expect(payload, contains('name="first_name"\r\n\r\nSaved'));
                  expect(
                    payload,
                    contains('name="middle_name"\r\n\r\nNew Middle'),
                  );
                  expect(payload, contains('name="last_name"\r\n\r\nPerson'));
                  expect(
                    payload,
                    contains('name="birth_date"\r\n\r\n2000-01-01'),
                  );
                  expect(
                    payload,
                    contains(
                      'name="remove_image"\r\n\r\n${scenario == 'delete' ? '1' : '0'}',
                    ),
                  );
                  if (scenario == 'replace') {
                    expect(
                      payload,
                      contains('name="profile_image"; filename="img_'),
                    );
                  } else {
                    expect(payload, isNot(contains('name="profile_image"')));
                  }
                  return saveResponse.future;
                }
                if (request.url.path == '/api/mobile/profile') {
                  profileCalls++;
                  if (holdRefresh) return oldResponse.future;
                  return http.Response(
                    jsonEncode({
                      'success': true,
                      'data': {
                        ...original,
                        'usr_mobile': '9123456789',
                        'usr_birth_date': '2000-01-01',
                      },
                    }),
                    200,
                  );
                }
                return http.Response('{"success":true,"data":{}}', 200);
              }),
            );
          },
        );
      }
    }
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(storageChannel, null);
  });
}
