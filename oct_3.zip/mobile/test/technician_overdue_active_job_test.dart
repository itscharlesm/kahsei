import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_job_details_page.dart';
import 'package:mobile_app/features/technician_jobs/widgets/technician_job_card.dart';

void main() {
  testWidgets('overdue job card remains openable', (tester) async {
    var opened = false;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: TechnicianJobCard(
            clientName: 'Client',
            service: 'Pest Control',
            pestType: 'Ants',
            address: 'Service address',
            schedule: 'Approved schedule',
            status: 'ASSIGNED',
            displayStatus: 'OVERDUE',
            saNumber: '123',
            isDisabled: false,
            onViewDetails: () => opened = true,
            technicianCount: 1,
            isMultipleTechnician: false,
            teamTechnicians: const [],
          ),
        ),
      ),
    );

    await tester.tap(find.byIcon(Icons.keyboard_arrow_down_rounded));
    await tester.pumpAndSettle();
    await tester.tap(find.text('View Job Details'));

    expect(opened, isTrue);
    expect(find.text('OVERDUE'), findsOneWidget);
  });

  testWidgets('overdue job with another active job disables Start Travel', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: TechnicianJobDetailsPage(
          email: 'tech@example.com',
          job: {
            'status': 'ASSIGNED',
            'blockStartTravelForActiveJob': true,
          },
        ),
      ),
    );

    final button = tester.widget<ElevatedButton>(
      find.ancestor(
        of: find.text('Finish Active Job First'),
        matching: find.byType(ElevatedButton),
      ),
    );

    expect(button.onPressed, isNull);
    expect(find.text('Finish Active Job First'), findsOneWidget);
  });

  testWidgets('overdue job without another active job can start travel', (
    tester,
  ) async {
    final job = <String, dynamic>{'status': 'ASSIGNED'};

    await tester.pumpWidget(
      MaterialApp(
        home: TechnicianJobDetailsPage(
          email: 'tech@example.com',
          job: job,
        ),
      ),
    );

    final button = tester.widget<ElevatedButton>(
      find.ancestor(
        of: find.text('Start Travel'),
        matching: find.byType(ElevatedButton),
      ),
    );

    expect(button.onPressed, isNotNull);
    expect(job['status'], 'ASSIGNED');
  });
}