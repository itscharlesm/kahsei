import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/features/home/pages/client_home_page.dart';
import 'package:mobile_app/features/home/pages/technician_home_page.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

import 'auth_session_profile_cache_test.dart'
    show CacheHarness, accountA, accountB, profile;

void main() {
  testWidgets(
    'Client and Technician Home and reopened Drawer use shared display state',
    (tester) async {
      for (final role in [3, 2]) {
        const channel = MethodChannel(
          'plugins.it_nomads.com/flutter_secure_storage',
        );
        tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
          channel,
          (_) async => null,
        );
        final auth = AuthSessionService.instance;
        await auth.saveSession(token: 'test', email: accountA, userType: role);
        final edit = auth.displayProfile.beginEdit()!;
        auth.displayProfile.completeEdit(edit, profile(accountA));
        var calls = 0;
        final pending = Completer<http.Response>();
        await http.runWithClient(
          () async {
            await tester.pumpWidget(
              MaterialApp(
                home: role == 3
                    ? const ClientHomePage(email: accountA)
                    : const TechnicianHomePage(email: accountA),
              ),
            );
            expect(find.text('Alice!'), findsOneWidget);
            expect(
              tester
                  .widget<AppProfileAvatar>(find.byType(AppProfileAvatar).first)
                  .imageUrl,
              contains('images/$accountA.png'),
            );
            for (var i = 0; i < 3; i++) {
              final scaffold = tester.state<ScaffoldState>(
                find.byType(Scaffold).first,
              );
              scaffold.openDrawer();
              await tester.pump();
              await tester.pump(const Duration(milliseconds: 300));
              expect(find.text('Alice Example'), findsOneWidget);
              scaffold.closeDrawer();
              await tester.pump();
              await tester.pump(const Duration(milliseconds: 300));
            }
            expect(calls, 1);
            pending.complete(
              http.Response(
                jsonEncode({
                  'success': true,
                  'data': profile(accountA, name: 'UPDATED'),
                }),
                200,
              ),
            );
            await tester.pump();
            await tester.pump();
            expect(find.text('Updated!'), findsOneWidget);
            final scaffold = tester.state<ScaffoldState>(
              find.byType(Scaffold).first,
            );
            scaffold.openDrawer();
            await tester.pump();
            await tester.pump(const Duration(milliseconds: 300));
            expect(find.text('Updated Example'), findsOneWidget);
            expect(calls, 1);
            await tester.pumpWidget(const SizedBox.shrink());
          },
          () => MockClient((request) async {
            if (request.url.path == '/api/mobile/profile') {
              calls++;
              return pending.future;
            }
            return http.Response('{"success":true,"data":{}}', 200);
          }),
        );
        await auth.displayProfile.clear();
        tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
          channel,
          null,
        );
      }
      const channel = MethodChannel(
        'plugins.it_nomads.com/flutter_secure_storage',
      );
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
        channel,
        (_) async => null,
      );
      final auth = AuthSessionService.instance;
      await auth.saveSession(token: 'test', email: accountA, userType: 2);
      var profileCalls = 0;
      var uploads = 0;
      String? imagePath;
      await http.runWithClient(
        () async {
          await tester.pumpWidget(
            const MaterialApp(home: TechnicianHomePage(email: accountA)),
          );
          await tester.pump();
          await tester.pump(const Duration(milliseconds: 400));
          await tester.pump(const Duration(milliseconds: 400));
          expect(find.text('Choose an Avatar'), findsOneWidget);
          await tester.tap(
            find.byWidgetPredicate(
              (widget) =>
                  widget is Image &&
                  widget.image is AssetImage &&
                  (widget.image as AssetImage).assetName ==
                      'assets/images/img_technician_avatar_01.jpg',
            ),
          );
          await tester.runAsync(() async {
            // rootBundle loads the actual avatar asset outside the fake clock.
            for (var i = 0; i < 50 && uploads == 0; i++) {
              await Future<void>.delayed(const Duration(milliseconds: 10));
            }
          });
          await tester.pump();
          await tester.pump(const Duration(milliseconds: 400));
          expect(uploads, 1);
          expect(profileCalls, 2);
          expect(
            auth.displayProfile.value?.avatarPath,
            'images/new-avatar.jpg',
          );
          expect(find.text('Profile avatar saved.'), findsOneWidget);
          final scaffold = tester.state<ScaffoldState>(
            find.byType(Scaffold).first,
          );
          scaffold.openDrawer();
          await tester.pump();
          await tester.pump(const Duration(milliseconds: 300));
          for (final avatar in tester.widgetList<AppProfileAvatar>(
            find.byType(AppProfileAvatar),
          )) {
            expect(avatar.imageUrl, contains('images/new-avatar.jpg'));
          }
          expect(profileCalls, 2);
          await tester.pumpWidget(const SizedBox.shrink());
        },
        () => MockClient((request) async {
          if (request.url.path == '/api/mobile/profile/update') {
            uploads++;
            final payload = latin1.decode(request.bodyBytes);
            expect(payload, contains('name="birth_date"\r\n\r\n2000-01-01'));
            expect(payload, contains('name="first_name"\r\n\r\nALICE'));
            expect(
              payload,
              contains('filename="img_technician_avatar_01.jpg"'),
            );
            imagePath = 'images/new-avatar.jpg';
            return http.Response(
              jsonEncode({'success': true, 'image_path': imagePath}),
              200,
            );
          }
          if (request.url.path == '/api/mobile/profile') {
            profileCalls++;
            return http.Response(
              jsonEncode({
                'success': true,
                'data': {
                  ...profile(accountA),
                  'usr_image_path': imagePath,
                  'usr_birth_date': '2000-01-01',
                },
              }),
              200,
            );
          }
          return http.Response('{"success":true,"data":{}}', 200);
        }),
      );
      await auth.displayProfile.clear();
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
        channel,
        null,
      );
    },
  );

  test(
    'Home and repeated Drawer mounts share one refresh per session',
    () async {
      final h = CacheHarness()..seed(accountA);
      final response = Completer<Map<String, dynamic>>();
      h.fetch = (_) => response.future;
      await h.store.activate(email: accountA, userType: 3);
      expect(h.store.value?.firstName, 'ALICE');
      final home = h.store.ensureLoaded(email: accountA, userType: 3);
      final drawer = h.store.ensureLoaded(email: accountA, userType: 3);
      expect(identical(home, drawer), isTrue);
      response.complete(profile(accountA, name: 'UPDATED'));
      await home;
      for (var i = 0; i < 5; i++) {
        await h.store.ensureLoaded(email: accountA, userType: 3);
      }
      expect(h.calls, 1);
      expect(h.store.value?.firstName, 'UPDATED');
      await h.store.activate(email: accountB, userType: 3);
      expect(h.store.value, isNull);
      await h.store.ensureLoaded(email: accountA, userType: 3);
      expect(h.calls, 1);
      h.fetch = (email) async => profile(email, name: 'BOB');
      await h.store.ensureLoaded(email: accountB, userType: 3);
      expect(h.calls, 2);
      expect(h.store.value?.firstName, 'BOB');
      await h.store.persistenceSettled;
    },
  );

  test(
    'failed initial refresh retains cache without a Drawer retry loop',
    () async {
      final h = CacheHarness()..seed(accountA);
      h.fetch = (_) async => throw StateError('offline');
      await h.store.activate(email: accountA, userType: 3);
      for (var i = 0; i < 4; i++) {
        await h.store.ensureLoaded(email: accountA, userType: 3);
      }
      expect(h.calls, 1);
      expect(h.store.value?.firstName, 'ALICE');
      expect(h.store.value?.avatarPath, 'images/$accountA.png');
    },
  );

  test(
    'technician setup data stays in memory and edits notify all listeners',
    () async {
      final h = CacheHarness()..seed(accountA, userType: 2);
      h.fetch = (email) async => {
        ...profile(email),
        'usr_birth_date': '2000-01-01',
        'unrelated': 'not retained',
      };
      await h.store.activate(email: accountA, userType: 2);
      expect(
        h.store.avatarSetupFieldsFor(email: accountA, userType: 2),
        isNull,
      );
      await h.store.ensureLoaded(email: accountA, userType: 2);
      var homeUpdates = 0;
      var drawerUpdates = 0;
      h.store.listenable.addListener(() => homeUpdates++);
      h.store.listenable.addListener(() => drawerUpdates++);
      final edit = h.store.beginEdit()!;
      expect(h.store.completeEdit(edit, {'usr_image_path': 'new.png'}), isTrue);
      expect(h.store.value?.avatarPath, 'new.png');
      expect(homeUpdates, 1);
      expect(drawerUpdates, 1);
      final fields = h.store.avatarSetupFieldsFor(
        email: accountA,
        userType: 2,
      )!;
      expect(fields['usr_birth_date'], '2000-01-01');
      expect(fields['usr_first_name'], 'ALICE');
      expect(fields['usr_image_path'], 'new.png');
      expect(fields.containsKey('unrelated'), isFalse);
      await h.store.persistenceSettled;
      expect(h.disk!.containsKey('usr_birth_date'), isFalse);
      expect(
        h.store.avatarSetupFieldsFor(email: accountB, userType: 2),
        isNull,
      );
      final deletion = h.store.beginEdit()!;
      h.store.completeEdit(deletion, {'usr_image_path': null});
      expect(h.store.value?.avatarPath, isNull);
      expect(homeUpdates, 2);
      expect(drawerUpdates, 2);
      await h.store.clear();
      expect(
        h.store.avatarSetupFieldsFor(email: accountA, userType: 2),
        isNull,
      );
    },
  );
}
