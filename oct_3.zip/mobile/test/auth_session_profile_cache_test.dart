import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/features/auth/services/current_user_profile.dart';

const accountA = 'A@example.com';
const accountB = 'B@example.com';

Map<String, dynamic> profile(String email, {String name = 'ALICE'}) => {
  'usr_email': email,
  'usr_first_name': name,
  'usr_middle_name': 'MIDDLE',
  'usr_last_name': 'EXAMPLE',
  'usr_image_path': 'images/$email.png',
};

class CacheHarness {
  Map<String, dynamic>? disk;
  int calls = 0;
  bool failStorage = false;
  Future<Map<String, dynamic>> Function(String)? fetch;
  Future<void> Function()? beforeWrite;
  late final store = CurrentUserProfileStore(
    readCache: () async {
      if (failStorage) throw StateError('storage unavailable');
      return disk;
    },
    writeCache: (data) async {
      await beforeWrite?.call();
      if (failStorage) throw StateError('storage unavailable');
      disk = Map.of(data);
    },
    deleteCache: () async {
      if (failStorage) throw StateError('storage unavailable');
      disk = null;
    },
    fetchProfile: (email) async {
      calls++;
      return fetch == null ? profile(email) : await fetch!(email);
    },
  );

  void seed(String email, {int userType = 3}) {
    disk = CurrentUserProfile(
      email: email,
      userType: userType,
    ).merge(profile(email)).toJson();
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('display profile infrastructure', () {
    test(
      'late cache hydration cannot overwrite a newer confirmed edit',
      () async {
        final readStarted = Completer<void>();
        final cached = Completer<Map<String, dynamic>?>();
        final store = CurrentUserProfileStore(
          readCache: () {
            readStarted.complete();
            return cached.future;
          },
          writeCache: (_) async {},
          deleteCache: () async {},
          fetchProfile: (email) async => profile(email),
        );
        final activation = store.activate(email: accountA, userType: 3);
        await readStarted.future;
        final ticket = store.beginEdit()!;
        store.completeEdit(ticket, {'usr_first_name': 'NEWER'});
        cached.complete(
          CurrentUserProfile(
            email: accountA,
            userType: 3,
          ).merge(profile(accountA)).toJson(),
        );
        await activation;
        expect(store.value?.firstName, 'NEWER');
        await store.persistenceSettled;
      },
    );

    test(
      'a previous session response is rejected even for the same account',
      () async {
        final h = CacheHarness();
        final oldResponse = Completer<Map<String, dynamic>>();
        h.fetch = (_) => oldResponse.future;
        await h.store.activate(email: accountA, userType: 3);
        final old = h.store.refresh();
        await h.store.clear();
        await h.store.activate(email: accountA, userType: 3);
        oldResponse.complete(profile(accountA));
        await old;
        expect(h.store.value, isNull);
        expect(h.disk, isNull);
      },
    );

    test(
      'hydrates only a matching account without a network request',
      () async {
        final h = CacheHarness()..seed(accountA);
        expect(h.store.value, isNull);
        await h.store.activate(email: accountA, userType: 3);
        expect(h.store.value?.firstName, 'ALICE');
        expect(h.calls, 0);
        await h.store.activate(email: accountB, userType: 3);
        expect(h.store.value, isNull);
        expect(h.disk, isNull);
      },
    );

    test(
      'email matching is exact and role mismatches cannot hydrate',
      () async {
        final h = CacheHarness()..seed(accountA);
        await h.store.activate(email: accountA.toLowerCase(), userType: 3);
        expect(h.store.value, isNull);
        h.seed(accountA);
        await h.store.activate(email: accountA, userType: 2);
        expect(h.store.value, isNull);
      },
    );

    test(
      'invalid cache and storage failures do not escape activation',
      () async {
        final h = CacheHarness()..seed(accountA);
        h.disk!['usr_first_name'] = 42;
        await h.store.activate(email: accountA, userType: 3);
        expect(h.store.value, isNull);
        h.failStorage = true;
        await h.store.activate(email: accountA, userType: 3);
        await h.store.refresh();
        await h.store.persistenceSettled;
        expect(h.store.value?.firstName, 'ALICE');
      },
    );

    test(
      'concurrent refreshes share one request and observable result',
      () async {
        final h = CacheHarness();
        final response = Completer<Map<String, dynamic>>();
        h.fetch = (_) => response.future;
        await h.store.activate(email: accountA, userType: 3);
        var notifications = 0;
        h.store.listenable.addListener(() => notifications++);
        final first = h.store.refresh();
        final second = h.store.refresh();
        expect(identical(first, second), isTrue);
        expect(h.calls, 1);
        response.complete(profile(accountA));
        await first;
        await h.store.persistenceSettled;
        expect(notifications, 1);
        expect(h.disk?['usr_first_name'], 'ALICE');
        expect(h.disk!.keys, isNot(contains('token')));
      },
    );

    test('failed or mismatched refresh preserves the cached profile', () async {
      final h = CacheHarness()..seed(accountA);
      await h.store.activate(email: accountA, userType: 3);
      h.fetch = (_) async => throw StateError('network error');
      await h.store.refresh();
      expect(h.store.value?.firstName, 'ALICE');
      h.fetch = (_) async => profile(accountB, name: 'BOB');
      await h.store.refresh();
      expect(h.store.value?.firstName, 'ALICE');
      h.fetch = (_) async => {'usr_first_name': 99};
      await h.store.refresh();
      expect(h.store.value?.firstName, 'ALICE');
    });

    test(
      'partial response preserves absent fields; explicit null deletes avatar',
      () async {
        final h = CacheHarness()..seed(accountA);
        await h.store.activate(email: accountA, userType: 3);
        h.fetch = (_) async => {'usr_first_name': 'NEW'};
        await h.store.refresh();
        expect(h.store.value?.firstName, 'NEW');
        expect(h.store.value?.lastName, 'EXAMPLE');
        expect(h.store.value?.avatarPath, 'images/$accountA.png');
        h.fetch = (_) async => {'usr_image_path': null};
        await h.store.refresh();
        await h.store.persistenceSettled;
        expect(h.store.value?.avatarPath, isNull);
        expect(h.disk!['usr_image_path'], isNull);
      },
    );

    test(
      'account switch rejects an old response without disturbing new request',
      () async {
        final h = CacheHarness()..seed(accountA);
        final a = Completer<Map<String, dynamic>>();
        final b = Completer<Map<String, dynamic>>();
        h.fetch = (email) => email == accountA ? a.future : b.future;
        await h.store.activate(email: accountA, userType: 3);
        final old = h.store.refresh();
        final activation = h.store.activate(email: accountB, userType: 2);
        expect(h.store.value, isNull);
        await activation;
        final current = h.store.refresh();
        a.complete(profile(accountA));
        expect(await old, isNull);
        expect(h.store.value, isNull);
        expect(identical(current, h.store.refresh()), isTrue);
        b.complete(profile(accountB, name: 'BOB'));
        await current;
        expect(h.store.value?.email, accountB);
        expect(h.store.value?.firstName, 'BOB');
      },
    );

    test('edit revision rejects old reads and stale edit tickets', () async {
      final h = CacheHarness()..seed(accountA);
      final response = Completer<Map<String, dynamic>>();
      h.fetch = (_) => response.future;
      await h.store.activate(email: accountA, userType: 3);
      final old = h.store.refresh();
      final ticket = h.store.beginEdit()!;
      await h.store.refresh();
      expect(h.calls, 1);
      expect(
        h.store.completeEdit(ticket, {
          'usr_first_name': 'EDITED',
          'usr_image_path': null,
        }),
        isTrue,
      );
      response.complete(profile(accountA));
      await old;
      expect(h.store.value?.firstName, 'EDITED');
      expect(h.store.value?.avatarPath, isNull);
      expect(h.store.completeEdit(ticket, {'usr_first_name': 'OLD'}), isFalse);
      await h.store.persistenceSettled;
      expect(h.disk?['usr_first_name'], 'EDITED');
    });

    test(
      'post-edit refresh waits for old flight then issues a fresh request',
      () async {
        final h = CacheHarness();
        final response = Completer<Map<String, dynamic>>();
        h.fetch = (_) => response.future;
        await h.store.activate(email: accountA, userType: 3);
        final old = h.store.refresh();
        final ticket = h.store.beginEdit()!;
        h.store.completeEdit(ticket, {'usr_first_name': 'EDITED'});
        h.fetch = (_) async => profile(accountA, name: 'SERVER EDITED');
        final reconciliation = h.store.refreshAfterEdit();
        expect(h.calls, 1);
        response.complete(profile(accountA));
        await old;
        await reconciliation;
        expect(h.calls, 2);
        expect(h.store.value?.firstName, 'SERVER EDITED');
      },
    );

    test(
      'cancelled edit retains saved values and cannot affect another account',
      () async {
        final h = CacheHarness()..seed(accountA);
        await h.store.activate(email: accountA, userType: 3);
        final ticket = h.store.beginEdit()!;
        h.store.cancelEdit(ticket);
        expect(h.store.value?.firstName, 'ALICE');
        final other = h.store.beginEdit()!;
        await h.store.activate(email: accountB, userType: 3);
        expect(h.store.completeEdit(other, profile(accountA)), isFalse);
        expect(h.store.value, isNull);
      },
    );

    test(
      'logout orders deletion after a delayed write and rejects late reads',
      () async {
        final h = CacheHarness();
        final entered = Completer<void>();
        final release = Completer<void>();
        h.beforeWrite = () {
          entered.complete();
          return release.future;
        };
        await h.store.activate(email: accountA, userType: 3);
        await h.store.refresh();
        await entered.future;
        final response = Completer<Map<String, dynamic>>();
        h.fetch = (_) => response.future;
        final old = h.store.refresh();
        final clearing = h.store.clear();
        expect(h.store.value, isNull);
        release.complete();
        await clearing;
        response.complete(profile(accountA));
        await old;
        await h.store.persistenceSettled;
        expect(h.disk, isNull);
        expect(h.store.value, isNull);
      },
    );

    test(
      'account B persistence wins over an already-running account A write',
      () async {
        final h = CacheHarness();
        final entered = Completer<void>();
        final release = Completer<void>();
        h.beforeWrite = () {
          entered.complete();
          return release.future;
        };
        await h.store.activate(email: accountA, userType: 3);
        await h.store.refresh();
        await entered.future;
        final activation = h.store.activate(email: accountB, userType: 2);
        expect(h.store.value, isNull);
        release.complete();
        await activation;
        h.beforeWrite = null;
        h.fetch = (_) async => profile(accountB, name: 'BOB');
        await h.store.refresh();
        await h.store.persistenceSettled;
        expect(h.disk?['email'], accountB);
        expect(h.disk?['usr_first_name'], 'BOB');
      },
    );

    test(
      'failed cache deletion cannot reactivate old disk data in this process',
      () async {
        final h = CacheHarness()..seed(accountA);
        await h.store.activate(email: accountA, userType: 3);
        h.failStorage = true;
        await h.store.clear();
        h.failStorage = false;
        await h.store.activate(email: accountA, userType: 3);
        expect(h.store.value, isNull);
        await h.store.refresh();
        expect(h.store.value?.firstName, 'ALICE');
      },
    );

    test(
      'persisted metadata survives restart but remains inactive until activation',
      () async {
        final first = CacheHarness();
        await first.store.activate(email: accountA, userType: 3);
        await first.store.refresh();
        await first.store.persistenceSettled;
        final restarted = CacheHarness()..disk = first.disk;
        expect(restarted.store.value, isNull);
        await restarted.store.refresh();
        expect(restarted.calls, 0);
        await restarted.store.activate(email: accountA, userType: 3);
        expect(restarted.store.value?.firstName, 'ALICE');
        expect(restarted.calls, 0);
      },
    );
  });

  group('unchanged authentication behavior', () {
    const channel = MethodChannel(
      'plugins.it_nomads.com/flutter_secure_storage',
    );
    final auth = AuthSessionService.instance;
    late Map<String, String> storage;
    late List<http.Request> requests;
    bool failDisplayStorage = false;

    setUp(() async {
      storage = {};
      requests = [];
      failDisplayStorage = false;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            final args = Map<String, dynamic>.from(call.arguments as Map);
            final key = args['key'] as String;
            if (failDisplayStorage && key == 'auth_display_profile_v1') {
              throw PlatformException(code: 'display_storage_failure');
            }
            switch (call.method) {
              case 'read':
                return storage[key];
              case 'write':
                storage[key] = args['value'] as String;
                return null;
              case 'delete':
                storage.remove(key);
                return null;
              default:
                throw StateError('Unexpected storage call ${call.method}');
            }
          });
      await auth.clearSession();
      await auth.displayProfile.persistenceSettled;
    });

    tearDown(() async {
      await auth.clearSession();
      await auth.displayProfile.persistenceSettled;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, null);
    });

    Future<T> withServer<T>(
      Future<T> Function() action,
      Future<http.Response> Function(http.Request) response,
    ) => http.runWithClient(
      action,
      () => MockClient((request) async {
        requests.add(request);
        return response(request);
      }),
    );

    test(
      'session saving uses the existing token keys and makes no profile call',
      () async {
        failDisplayStorage = true;
        await withServer(
          () =>
              auth.saveSession(token: 'token-A', email: accountA, userType: 3),
          (_) async => throw StateError('No network expected'),
        );
        expect(storage['auth_token'], 'token-A');
        expect(storage['auth_email'], accountA);
        expect(storage['auth_user_type'], '3');
        expect(requests, isEmpty);
      },
    );

    for (final userType in [2, 3]) {
      test('restoration validates /me and preserves role $userType', () async {
        storage['auth_token'] = 'token-A';
        final session = await withServer(
          auth.restoreSession,
          (_) async => http.Response(
            jsonEncode({
              'success': true,
              'user': {'usr_email': accountA, 'utyp_id': userType},
            }),
            200,
          ),
        );
        expect(session?.email, accountA);
        expect(session?.userType, userType);
        expect(session?.token, 'token-A');
        expect(requests.single.method, 'GET');
        expect(requests.single.url.path, '/api/mobile/me');
        expect(requests.single.headers['Authorization'], 'Bearer token-A');
        expect(auth.displayProfile.value, isNull);
      });
    }

    test('missing token does not restore from display cache', () async {
      storage['auth_display_profile_v1'] = jsonEncode(
        CurrentUserProfile(
          email: accountA,
          userType: 3,
        ).merge(profile(accountA)).toJson(),
      );
      final result = await withServer(
        auth.restoreSession,
        (_) async => throw StateError('No network expected'),
      );
      expect(result, isNull);
      expect(requests, isEmpty);
      expect(auth.displayProfile.value, isNull);
    });

    test(
      '401 clears credentials; network failures retain credentials without login',
      () async {
        await auth.saveSession(token: 'token-A', email: accountA, userType: 3);
        expect(
          await withServer(
            auth.restoreSession,
            (_) async => http.Response('{}', 401),
          ),
          isNull,
        );
        await auth.displayProfile.persistenceSettled;
        expect(storage['auth_token'], isNull);
        expect(auth.displayProfile.value, isNull);
        await auth.saveSession(token: 'token-A', email: accountA, userType: 3);
        expect(
          await withServer(
            auth.restoreSession,
            (_) async => throw http.ClientException('offline'),
          ),
          isNull,
        );
        expect(storage['auth_token'], 'token-A');
        expect(auth.displayProfile.value, isNull);
      },
    );

    test('non-401 failure and malformed JSON retain existing token', () async {
      storage['auth_token'] = 'token-A';
      expect(
        await withServer(
          auth.restoreSession,
          (_) async => http.Response('{"success":false}', 500),
        ),
        isNull,
      );
      expect(storage['auth_token'], 'token-A');
      expect(
        await withServer(
          auth.restoreSession,
          (_) async => http.Response('invalid JSON', 200),
        ),
        isNull,
      );
      expect(storage['auth_token'], 'token-A');
    });

    test(
      'missing or invalid identity keeps existing credential-clearing behavior',
      () async {
        for (final user in [
          null,
          {'usr_email': '', 'utyp_id': 3},
        ]) {
          storage['auth_token'] = 'token-A';
          expect(
            await withServer(
              auth.restoreSession,
              (_) async => http.Response(
                jsonEncode({'success': true, 'user': user}),
                200,
              ),
            ),
            isNull,
          );
          expect(storage['auth_token'], isNull);
        }
      },
    );

    test(
      'profile refresh failures do not log out or erase displayed values',
      () async {
        await auth.saveSession(token: 'token-A', email: accountA, userType: 3);
        await withServer(
          auth.displayProfile.refresh,
          (_) async => http.Response(
            jsonEncode({'success': true, 'data': profile(accountA)}),
            200,
          ),
        );
        await withServer(
          auth.displayProfile.refresh,
          (_) async => http.Response('{}', 401),
        );
        expect(auth.displayProfile.value?.firstName, 'ALICE');
        expect(storage['auth_token'], 'token-A');
        expect(
          requests.every((r) => r.url.path == '/api/mobile/profile'),
          isTrue,
        );
        expect(requests.first.bodyFields['email'], accountA);
      },
    );

    test(
      'logout retains its request and clears display state even on network failure',
      () async {
        await auth.saveSession(token: 'token-A', email: accountA, userType: 3);
        final ticket = auth.displayProfile.beginEdit()!;
        auth.displayProfile.completeEdit(ticket, profile(accountA));
        await auth.displayProfile.persistenceSettled;
        await withServer(auth.logout, (request) async {
          expect(auth.displayProfile.value, isNull);
          throw http.ClientException('offline');
        });
        await auth.displayProfile.persistenceSettled;
        expect(requests.single.method, 'POST');
        expect(requests.single.url.path, '/api/mobile/logout');
        expect(requests.single.headers['Authorization'], 'Bearer token-A');
        expect(storage, isEmpty);
        expect(auth.displayProfile.value, isNull);
      },
    );
  });
}
