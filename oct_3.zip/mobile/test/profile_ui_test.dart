import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/features/home/pages/client_home_page.dart';
import 'package:mobile_app/features/home/pages/technician_home_page.dart';
import 'package:mobile_app/features/profiles/pages/client_edit_profile_page.dart';
import 'package:mobile_app/features/profiles/pages/technician_edit_profile_page.dart';
import 'package:mobile_app/features/profiles/pages/client_profile_page.dart';
import 'package:mobile_app/features/profiles/pages/technician_profile_page.dart';
import 'package:mobile_app/features/profiles/widgets/client_edit_profile_skeleton_load.dart';
import 'package:mobile_app/features/profiles/widgets/technician_edit_profile_skeleton_load.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';

import 'auth_session_profile_cache_test.dart' show accountA, accountB, profile;

void main() {
  testWidgets(
    'Partial edit loading and responsive identity layouts for both roles',
    (tester) async {
      const channel = MethodChannel(
        'plugins.it_nomads.com/flutter_secure_storage',
      );
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
        channel,
        (_) async => null,
      );
      addTearDown(
        () => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
          channel,
          null,
        ),
      );
      final auth = AuthSessionService.instance;
      tester.view.physicalSize = const Size(360, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      Future<void> pumpPage(Widget page, {double scale = 1}) async {
        await tester.pumpWidget(
          MaterialApp(
            builder: (context, child) => MediaQuery(
              data: MediaQuery.of(
                context,
              ).copyWith(textScaler: TextScaler.linear(scale)),
              child: child!,
            ),
            home: page,
          ),
        );
        await tester.pump();
      }

      Future<void> clean() async {
        await tester.pumpWidget(const SizedBox.shrink());
        await auth.clearSession();
        await auth.displayProfile.persistenceSettled;
      }

      void expectWrapped(String text) {
        final finder = find.text(text);
        expect(finder, findsOneWidget);
        final widget = tester.widget<Text>(finder);
        expect(widget.maxLines, isNull);
        expect(widget.overflow, isNot(TextOverflow.ellipsis));
        final paragraph = tester.renderObject<RenderParagraph>(
          find.descendant(of: finder, matching: find.byType(RichText)),
        );
        expect(paragraph.didExceedMaxLines, isFalse);
        expect(
          paragraph.size.height,
          greaterThan(widget.style!.fontSize! * 1.5),
        );
        expect(tester.takeException(), isNull);
      }

      for (final role in [3, 2]) {
        Widget edit() => role == 3
            ? const ClientEditProfilePage(email: accountA)
            : const TechnicianEditProfilePage(email: accountA);
        Widget profilePage() => role == 3
            ? const ClientProfilePage(email: accountA)
            : const TechnicianProfilePage(email: accountA);
        Widget home() => role == 3
            ? const ClientHomePage(email: accountA)
            : const TechnicianHomePage(email: accountA);
        final skeleton = role == 3
            ? find.byType(ClientEditProfileSkeletonLoad)
            : find.byType(TechnicianEditProfileSkeletonLoad);

        for (final scenario in [
          'success',
          'http failure',
          'network failure',
          'no cache',
          'wrong account',
        ]) {
          debugPrint('Role $role: $scenario loading');
          await auth.saveSession(
            token: 'test',
            email: accountA,
            userType: role,
          );
          if (scenario != 'no cache') {
            if (scenario == 'wrong account') {
              await auth.saveSession(
                token: 'B',
                email: accountB,
                userType: role,
              );
            }
            auth.displayProfile.completeEdit(
              auth.displayProfile.beginEdit()!,
              profile(scenario == 'wrong account' ? accountB : accountA),
            );
          }
          final pending = Completer<http.Response>();
          var saves = 0;
          await http.runWithClient(
            () async {
              await pumpPage(edit());
              final hasCache =
                  scenario != 'no cache' && scenario != 'wrong account';
              if (hasCache) {
                expect(skeleton, findsNothing);
                expect(find.text('Alice Example'), findsOneWidget);
                expect(find.text('Loading profile...'), findsOneWidget);
                final inputs = tester
                    .widgetList<TextField>(find.byType(TextField))
                    .toList();
                expect(inputs.take(3).map((f) => f.controller!.text), [
                  'Alice',
                  'Middle',
                  'Example',
                ]);
                expect(inputs.every((f) => f.readOnly), isTrue);
                expect(inputs.last.controller!.text, isEmpty);
                expect(inputs.last.decoration!.hintText, 'Loading...');
                expect(
                  tester
                      .widget<LoadingButton>(find.byType(LoadingButton))
                      .onPressed,
                  isNull,
                );
                expect(
                  tester
                      .widget<IconButton>(
                        find.byWidgetPredicate(
                          (w) => w is IconButton && w.tooltip == 'Change Photo',
                        ),
                      )
                      .onPressed,
                  isNull,
                );
                final images = tester.widgetList<Image>(find.byType(Image));
                expect(
                  images.any(
                    (i) =>
                        i.image is NetworkImage &&
                        (i.image as NetworkImage).url.endsWith(
                          'images/$accountA.png',
                        ),
                  ),
                  isTrue,
                );
                await tester.tap(find.byTooltip('Change Photo'));
                expect(find.text('Choose from Gallery'), findsNothing);
                final dateControls = tester
                    .widgetList<GestureDetector>(find.byType(GestureDetector))
                    .where((w) => w.child is AbsorbPointer);
                expect(dateControls, isNotEmpty);
                expect(dateControls.every((w) => w.onTap == null), isTrue);
              } else {
                expect(skeleton, findsOneWidget);
                expect(find.byType(TextField), findsNothing);
                expect(find.text('Alice Example'), findsNothing);
              }
              if (scenario == 'network failure') {
                pending.completeError(http.ClientException('offline'));
              } else {
                pending.complete(
                  http.Response(
                    jsonEncode({
                      'success': scenario != 'http failure',
                      'data': {
                        ...profile(accountA, name: 'AUTHORITATIVE'),
                        'usr_birth_date': '2000-01-01',
                      },
                    }),
                    scenario == 'http failure' ? 500 : 200,
                  ),
                );
              }
              await tester.pump();
              await tester.pump(const Duration(milliseconds: 100));
              expect(skeleton, findsNothing);
              final fields = tester
                  .widgetList<TextField>(find.byType(TextField))
                  .toList();
              if (scenario.contains('failure')) {
                expect(find.text('Alice Example'), findsOneWidget);
                expect(fields.every((f) => f.readOnly), isTrue);
                expect(fields.last.controller!.text, isEmpty);
                expect(
                  tester
                      .widget<LoadingButton>(find.byType(LoadingButton))
                      .onPressed,
                  isNull,
                );
                expect(
                  find.text(
                    'Unable to load profile. Reopen this page to try again.',
                  ),
                  findsOneWidget,
                );
                await tester.ensureVisible(find.text('Save Changes'));
                await tester.tap(find.text('Save Changes'));
                await tester.pump();
                expect(saves, 0);
              } else {
                expect(fields.first.controller!.text, 'Authoritative');
                expect(fields.last.controller!.text, '2000-01-01');
                expect(fields.every((f) => !f.readOnly), isTrue);
                expect(
                  tester
                      .widget<LoadingButton>(find.byType(LoadingButton))
                      .onPressed,
                  isNotNull,
                );
                expect(
                  tester
                      .widget<IconButton>(
                        find.byWidgetPredicate(
                          (w) => w is IconButton && w.tooltip == 'Change Photo',
                        ),
                      )
                      .onPressed,
                  isNotNull,
                );
                expect(find.text('Loading profile...'), findsNothing);
              }
              expect(tester.takeException(), isNull);
              await clean();
            },
            () => MockClient((request) async {
              if (request.url.path.endsWith('/profile/update')) {
                saves++;
                return http.Response('{"success":true}', 200);
              }
              return pending.future;
            }),
          );
        }

        for (final scale in [1.0, 1.5]) {
          debugPrint('Role $role: long names at text scale $scale');
          tester.view.physicalSize = const Size(320, 900);
          const first = 'Alexandria Catherine Gabriella';
          const last = 'Montgomery Santiago Fernandez';
          const full = '$first $last';
          await auth.saveSession(
            token: 'test',
            email: accountA,
            userType: role,
          );
          final data = {
            ...profile(accountA, name: first),
            'usr_last_name': last,
            'usr_birth_date': '2000-01-01',
          };
          auth.displayProfile.completeEdit(
            auth.displayProfile.beginEdit()!,
            data,
          );
          await http.runWithClient(
            () async {
              await pumpPage(home());
              await tester.pump(const Duration(milliseconds: 400));
              if (scale > 1) {
                // The unrelated promotional banner has pre-existing large-text
                // overflow. Test the actual greeting row at its original width
                // without changing or suppressing errors from that component.
                final greeting = tester.widget<Row>(
                  find
                      .ancestor(
                        of: find.text(
                          role == 3
                              ? 'Alexandria catherine gabriella!'
                              : '$first!',
                        ),
                        matching: find.byType(Row),
                      )
                      .first,
                );
                await tester.pumpWidget(const SizedBox.shrink());
                await pumpPage(
                  Scaffold(
                    body: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: greeting,
                      ),
                    ),
                  ),
                  scale: scale,
                );
              }
              expectWrapped(
                role == 3 ? 'Alexandria catherine gabriella!' : '$first!',
              );
              await tester.pumpWidget(const SizedBox.shrink());
              await pumpPage(
                Scaffold(
                  drawer: AppDrawer(
                    userType: role,
                    email: accountA,
                    currentPage: 'home',
                  ),
                  body: const SizedBox.shrink(),
                ),
                scale: scale,
              );
              final scaffold = tester.state<ScaffoldState>(
                find.byType(Scaffold).first,
              );
              scaffold.openDrawer();
              await tester.pump();
              await tester.pump(const Duration(milliseconds: 400));
              final drawerName = tester.widget<Text>(find.text(full));
              expect(drawerName.maxLines, 2);
              expect(drawerName.overflow, TextOverflow.ellipsis);
              expect(drawerName.style!.fontSize, 17);
              expect(tester.getSize(find.byType(Drawer)).width, 256);
              expect(tester.takeException(), isNull);
              await tester.pumpWidget(const SizedBox.shrink());
              await pumpPage(profilePage(), scale: scale);
              expectWrapped(full);
              expect(find.byTooltip('Edit Profile'), findsOneWidget);
              await tester.pumpWidget(const SizedBox.shrink());
              await pumpPage(edit(), scale: scale);
              await tester.pump();
              expectWrapped(full);
              final nameFields = tester
                  .widgetList<TextField>(find.byType(TextField))
                  .take(3);
              expect(nameFields.first.controller!.text, first);
              expect(nameFields.last.controller!.text, last);
              expect(nameFields.every((f) => f.maxLines == 1), isTrue);
              await clean();
            },
            () => MockClient(
              (request) async => http.Response(
                jsonEncode({
                  'success': true,
                  'data': request.url.path.endsWith('/profile')
                      ? data
                      : <String, dynamic>{},
                }),
                200,
              ),
            ),
          );
        }
      }
    },
  );
}
