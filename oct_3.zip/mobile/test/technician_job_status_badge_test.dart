import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mobile_app/features/technician_jobs/widgets/technician_job_status_badge.dart';

void main() {
  testWidgets('renders derived technician schedule classifications', (
    WidgetTester tester,
  ) async {
    for (final entry in const {
      'UPCOMING': 'UPCOMING',
      'SERVICE_NOW': 'SERVICE NOW',
      'OVERDUE': 'OVERDUE',
    }.entries) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TechnicianJobStatusBadge(status: entry.key),
          ),
        ),
      );

      expect(find.text(entry.value), findsOneWidget);
    }
  });
}
