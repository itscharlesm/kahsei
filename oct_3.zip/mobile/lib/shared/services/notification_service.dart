// import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// class AppNotificationService {
//   AppNotificationService._();

//   static final AppNotificationService instance =
//       AppNotificationService._();

//   final FlutterLocalNotificationsPlugin _notifications =
//       FlutterLocalNotificationsPlugin();

//   bool _initialized = false;

//   // Called when the user taps a device notification.
//   void Function(String? payload)? onNotificationTap;

//   Future<void> initialize() async {
//     if (_initialized) return;

//     const androidSettings = AndroidInitializationSettings(
//       'img_go_notif_icon',
//     );

//     const initializationSettings = InitializationSettings(
//       android: androidSettings,
//     );

//     await _notifications.initialize(
//       initializationSettings,
//       onDidReceiveNotificationResponse: (response) {
//         onNotificationTap?.call(response.payload);
//       },
//     );

//     final androidPlugin =
//         _notifications.resolvePlatformSpecificImplementation<
//             AndroidFlutterLocalNotificationsPlugin>();

//     await androidPlugin?.requestNotificationsPermission();

//     _initialized = true;
//   }

//   Future<void> showNotification({
//     required int id,
//     required String title,
//     required String body,
//     String? payload,
//   }) async {
//     if (!_initialized) {
//       await initialize();
//     }

//     const androidDetails = AndroidNotificationDetails(
//       'gfpc_notifications_v2',
//       'GFPC Notifications',
//       channelDescription:
//           'Notifications for pest control service updates',
//       importance: Importance.high,
//       priority: Priority.high,
//       playSound: true,
//       enableVibration: true,
//       icon: 'img_go_notif_icon',
//     );

//     const notificationDetails = NotificationDetails(
//       android: androidDetails,
//     );

//     await _notifications.show(
//       id,
//       title,
//       body,
//       notificationDetails,
//       payload: payload,
//     );
//   }
// }

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/config/api_config.dart';

class AppNotificationService {
  AppNotificationService._();

  static final AppNotificationService instance =
      AppNotificationService._();

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  // UNIVERSAL CLIENT NOTIFICATION READER
  Timer? _pollingTimer;
  String? _clientEmail;
  int? _lastNotificationId;
  bool _checkingNotifications = false;
  bool _unreadSummaryShown = false;

  final ValueNotifier<int> unreadCount =
      ValueNotifier<int>(0);

  // TECHNICIAN NOTIFICATION READER
  Timer? _technicianPollingTimer;
  String? _technicianEmail;
  int? _lastTechnicianNotificationId;
  bool _checkingTechnicianNotifications = false;
  bool _technicianUnreadSummaryShown = false;

  final ValueNotifier<int> technicianUnreadCount =
      ValueNotifier<int>(0);

  // Called when the user taps a device notification.
  void Function(String? payload)? onNotificationTap;

  Future<void> initialize() async {
    if (_initialized) return;

    const androidSettings = AndroidInitializationSettings(
      'img_go_notif_icon',
    );

    const initializationSettings = InitializationSettings(
      android: androidSettings,
    );

    await _notifications.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (response) {
        onNotificationTap?.call(response.payload);
      },
    );

    final androidPlugin =
        _notifications.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidPlugin?.requestNotificationsPermission();

    _initialized = true;
  }

  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    if (!_initialized) {
      await initialize();
    }

    const androidDetails = AndroidNotificationDetails(
      'gfpc_notifications_v2',
      'GFPC Notifications',
      channelDescription:
          'Notifications for pest control service updates',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      icon: 'img_go_notif_icon',
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
    );

    await _notifications.show(
      id,
      title,
      body,
      notificationDetails,
      payload: payload,
    );
  }

  // START UNIVERSAL CLIENT POLLING
  Future<void> startClientPolling(String email) async {
    final normalizedEmail = email.trim();

    if (normalizedEmail.isEmpty) {
      return;
    }

    // Prevent duplicate timers for the same logged-in client.
    if (_clientEmail == normalizedEmail &&
        _pollingTimer?.isActive == true) {
      return;
    }

    _pollingTimer?.cancel();

    _clientEmail = normalizedEmail;
    _lastNotificationId = null;
    _checkingNotifications = false;
    _unreadSummaryShown = false;

    await _checkForNewNotification(
      initialCheck: true,
    );

    _pollingTimer = Timer.periodic(
      const Duration(seconds: 15),
      (_) {
        _checkForNewNotification();
      },
    );

    debugPrint(
      'GLOBAL CLIENT NOTIFICATION POLLING STARTED: '
      '$_clientEmail',
    );
  }

  // STOP POLLING
  void stopClientPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = null;

    _clientEmail = null;
    _lastNotificationId = null;
    _checkingNotifications = false;
    _unreadSummaryShown = false;

    unreadCount.value = 0;

    debugPrint(
      'GLOBAL CLIENT NOTIFICATION POLLING STOPPED',
    );
  }

  // CHECK NEW NOTIFICATION
  Future<void> _checkForNewNotification({
    bool initialCheck = false,
  }) async {
    final email = _clientEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    if (_checkingNotifications) {
      return;
    }

    _checkingNotifications = true;

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications?page=1',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': email,
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        return;
      }

      final data = jsonDecode(response.body);

      if (data['success'] != true) {
        return;
      }

      // Update unread badge count every 15-second poll.
      await refreshUnreadCount();

      final List<dynamic> notifications =
          data['data'] ?? [];

      if (notifications.isEmpty) {
        return;
      }

      final newest = notifications.first;

      final int? newestId = int.tryParse(
        newest['id'].toString(),
      );

      if (newestId == null) {
        return;
      }

      // First check only remembers the newest existing notification.
      if (initialCheck || _lastNotificationId == null) {
        _lastNotificationId = newestId;
        return;
      }

      // No new notification.
      if (newestId <= _lastNotificationId!) {
        return;
      }

      _lastNotificationId = newestId;

      final String message = _formatNotificationMessage(
        newest['message']?.toString() ?? '',
      );

      final String title =
          _getNotificationTitle(message);

      await showNotification(
        id: newestId,
        title: title,
        body: message,
        payload: email,
      );

    } catch (e) {
      debugPrint(
        'GLOBAL NOTIFICATION POLLING ERROR: $e',
      );
    } finally {
      _checkingNotifications = false;
    }
  }

  // UNREAD COUNT
  Future<void> refreshUnreadCount() async {
    final email = _clientEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/unread-count',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': email,
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        return;
      }

      final data = jsonDecode(response.body);

      if (data['success'] != true) {
        return;
      }

      final int count = int.tryParse(
            data['unread_count'].toString(),
          ) ??
          0;

      unreadCount.value = count;
    } catch (e) {
      debugPrint(
        'GLOBAL UNREAD COUNT ERROR: $e',
      );
    }
  }

  Future<void> showUnreadSummaryIfNeeded() async {
    final email = _clientEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    // Show unread summary only once per login session.
    if (_unreadSummaryShown) {
      return;
    }

    _unreadSummaryShown = true;

    await refreshUnreadCount();

    final count = unreadCount.value;

    if (count <= 0) {
      return;
    }

    final String message = count == 1
        ? 'You have 1 unread notification.'
        : 'You have $count unread notifications.';

    await showNotification(
      id: 999999,
      title: 'Unread Notifications',
      body: message,
      payload: email,
    );
  }

  // MESSAGE FORMAT
  String _formatNotificationMessage(String value) {
    final text = value.trim();

    if (text.isEmpty) {
      return '';
    }

    final lower = text.toLowerCase();

    return lower[0].toUpperCase() +
        lower.substring(1);
  }

  // NOTIFICATION TITLES
  String _getNotificationTitle(String message) {
    final normalized = message.toUpperCase();

    // APPOINTMENT
    if (normalized.contains('REQUEST') &&
        normalized.contains('SUBMITTED')) {
      return 'Request submitted';
    }

    if (normalized.contains('ASSESSED')) {
      return 'Request assessed';
    }

    if (normalized.contains('SCHEDULED')) {
      return 'Appointment scheduled';
    }

    if (normalized.contains('CANCELLED') ||
        normalized.contains('CANCELED')) {
      return 'Appointment cancelled';
    }

    // PAYMENT
    if (normalized.contains('PAYMENT') &&
        normalized.contains('SUBMITTED')) {
      return 'Payment submitted';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('APPROVED') ||
            normalized.contains('VERIFIED'))) {
      return 'Payment approved';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('REJECTED') ||
            normalized.contains(
              'COULD NOT BE VERIFIED',
            ))) {
      return 'Payment requires attention';
    }

    // TECHNICIAN / SERVICE
    if (normalized.contains('TECHNICIAN') &&
        normalized.contains('ASSIGNED')) {
      return 'Technician assigned';
    }

    if (normalized.contains('TRAVELING')) {
      return 'Technician is on the way';
    }

    if (normalized.contains('ARRIVED')) {
      return 'Technician has arrived';
    }

    if (normalized.contains('COMPLETED')) {
      return 'Service completed';
    }

    return 'Service Update';
  }

  // START TECHNICIAN POLLING
  Future<void> startTechnicianPolling(String email) async {
    final normalizedEmail = email.trim();

    if (normalizedEmail.isEmpty) {
      return;
    }

    // Prevent duplicate timers for the same logged-in technician.
    if (_technicianEmail == normalizedEmail &&
        _technicianPollingTimer?.isActive == true) {
      return;
    }

    _technicianPollingTimer?.cancel();

    _technicianEmail = normalizedEmail;
    _lastTechnicianNotificationId = null;
    _checkingTechnicianNotifications = false;
    _technicianUnreadSummaryShown = false;

    await _checkForNewTechnicianNotification(
      initialCheck: true,
    );

    _technicianPollingTimer = Timer.periodic(
      const Duration(seconds: 15),
      (_) {
        _checkForNewTechnicianNotification();
      },
    );

    debugPrint(
      'GLOBAL TECHNICIAN NOTIFICATION POLLING STARTED: '
      '$_technicianEmail',
    );
  }

  // STOP TECHNICIAN POLLING
  void stopTechnicianPolling() {
    _technicianPollingTimer?.cancel();
    _technicianPollingTimer = null;

    _technicianEmail = null;
    _lastTechnicianNotificationId = null;
    _checkingTechnicianNotifications = false;
    _technicianUnreadSummaryShown = false;

    technicianUnreadCount.value = 0;

    debugPrint(
      'GLOBAL TECHNICIAN NOTIFICATION POLLING STOPPED',
    );
  }

  // CHECK NEW TECHNICIAN NOTIFICATION
  Future<void> _checkForNewTechnicianNotification({
    bool initialCheck = false,
  }) async {
    final email = _technicianEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    if (_checkingTechnicianNotifications) {
      return;
    }

    _checkingTechnicianNotifications = true;

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications?page=1',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': email,
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        return;
      }

      final data = jsonDecode(response.body);

      if (data['success'] != true) {
        return;
      }

      // Update technician unread badge every poll.
      await refreshTechnicianUnreadCount();

      final List<dynamic> notifications =
          data['data'] ?? [];

      if (notifications.isEmpty) {
        return;
      }

      final newest = notifications.first;

      final int? newestId = int.tryParse(
        newest['id'].toString(),
      );

      if (newestId == null) {
        return;
      }

      // Initial check remembers existing newest notification.
      if (initialCheck ||
          _lastTechnicianNotificationId == null) {
        _lastTechnicianNotificationId = newestId;
        return;
      }

      // Nothing new.
      if (newestId <= _lastTechnicianNotificationId!) {
        return;
      }

      _lastTechnicianNotificationId = newestId;

      final String message = _formatNotificationMessage(
        newest['message']?.toString() ?? '',
      );

      final String title =
          _getTechnicianNotificationTitle(message);

      await showNotification(
        id: newestId,
        title: title,
        body: message,
        payload: email,
      );
    } catch (e) {
      debugPrint(
        'GLOBAL TECHNICIAN NOTIFICATION POLLING ERROR: $e',
      );
    } finally {
      _checkingTechnicianNotifications = false;
    }
  }

  // TECHNICIAN UNREAD COUNT
  Future<void> refreshTechnicianUnreadCount() async {
    final email = _technicianEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/unread-count',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': email,
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        return;
      }

      final data = jsonDecode(response.body);

      if (data['success'] != true) {
        return;
      }

      final int count = int.tryParse(
            data['unread_count'].toString(),
          ) ??
          0;

      technicianUnreadCount.value = count;
    } catch (e) {
      debugPrint(
        'GLOBAL TECHNICIAN UNREAD COUNT ERROR: $e',
      );
    }
  }

  // TECHNICIAN UNREAD SUMMARY
  Future<void> showTechnicianUnreadSummaryIfNeeded() async {
    final email = _technicianEmail;

    if (email == null || email.isEmpty) {
      return;
    }

    // Only once per technician login session.
    if (_technicianUnreadSummaryShown) {
      return;
    }

    _technicianUnreadSummaryShown = true;

    await refreshTechnicianUnreadCount();

    final count = technicianUnreadCount.value;

    if (count <= 0) {
      return;
    }

    final String message = count == 1
        ? 'You have 1 unread notification.'
        : 'You have $count unread notifications.';

    await showNotification(
      id: 999998,
      title: 'Unread Notifications',
      body: message,
      payload: email,
    );
  }

  // TECHNICIAN NOTIFICATION TITLES
  String _getTechnicianNotificationTitle(
    String message,
  ) {
    final normalized = message.toUpperCase();

    if (normalized.contains('SERVICE REPORT') &&
        normalized.contains('SUBMITTED')) {
      return 'Report submitted';
    }

    if (normalized.contains('SERVICE') &&
        normalized.contains('COMPLETED')) {
      return 'Service completed';
    }

    if (normalized.contains('REPORT') &&
        normalized.contains('REQUIRED')) {
      return 'Service report required';
    }

    if (normalized.contains('SCHEDULED') ||
        normalized.contains('UPCOMING')) {
      return 'Service scheduled today';
    }

    return 'Service update';
  }
}