import 'package:geolocator/geolocator.dart';

class ProximityService {
  ProximityService._();

  /// Required proximity for both:
  /// - Start Travel → branch location
  /// - Mark as Arrived → client location
  static const double requiredRadiusMeters = 100;

  /// The device should move at least this distance before another
  /// location update is emitted.
  static const int locationDistanceFilterMeters = 5;

  /// Checks whether GPS is enabled and requests location permission.
  ///
  /// Throws a readable exception when location cannot be accessed.
  static Future<void> ensureLocationAccess() async {
    final serviceEnabled =
        await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      throw const ProximityException(
        'Location services are disabled. Please turn on GPS.',
        type: ProximityErrorType.serviceDisabled,
      );
    }

    LocationPermission permission =
        await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      throw const ProximityException(
        'Location permission was denied.',
        type: ProximityErrorType.permissionDenied,
      );
    }

    if (permission == LocationPermission.deniedForever) {
      throw const ProximityException(
        'Location permission is permanently denied. Please enable it in the app settings.',
        type: ProximityErrorType.permissionDeniedForever,
      );
    }
  }

  /// Gets the technician's current GPS position.
  static Future<Position> getCurrentPosition() async {
    await ensureLocationAccess();

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
      timeLimit: const Duration(seconds: 12),
    );
  }

  /// Continuously monitors the technician's GPS position.
  ///
  /// This can be reused by:
  /// - TechnicianJobDetailsPage for branch proximity
  /// - TechnicianTrackingPage for client proximity
  static Stream<Position> getPositionStream() {
    const locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: locationDistanceFilterMeters,
    );

    return Geolocator.getPositionStream(
      locationSettings: locationSettings,
    );
  }

  /// Calculates the distance in meters between the technician
  /// and the target location.
  static double calculateDistance({
    required double currentLatitude,
    required double currentLongitude,
    required double targetLatitude,
    required double targetLongitude,
  }) {
    return Geolocator.distanceBetween(
      currentLatitude,
      currentLongitude,
      targetLatitude,
      targetLongitude,
    );
  }

  /// Returns true when the technician is within the allowed radius.
  static bool isWithinRequiredRadius(
    double distanceInMeters, {
    double radiusInMeters = requiredRadiusMeters,
  }) {
    return distanceInMeters <= radiusInMeters;
  }

  /// Convenience method that calculates the distance and returns
  /// all proximity information in one object.
  ///
  /// The target can be either:
  /// - branch coordinates for Start Travel
  /// - client coordinates for Mark as Arrived
  static ProximityResult evaluate({
    required Position technicianPosition,
    required double targetLatitude,
    required double targetLongitude,
    double radiusInMeters = requiredRadiusMeters,
  }) {
    final distance = calculateDistance(
      currentLatitude: technicianPosition.latitude,
      currentLongitude: technicianPosition.longitude,
      targetLatitude: targetLatitude,
      targetLongitude: targetLongitude,
    );

    return ProximityResult(
      position: technicianPosition,
      distanceInMeters: distance,
      requiredRadiusMeters: radiusInMeters,
      isWithinRadius: isWithinRequiredRadius(
        distance,
        radiusInMeters: radiusInMeters,
      ),
    );
  }

  static Future<bool> openLocationSettings() {
    return Geolocator.openLocationSettings();
  }

  static Future<bool> openAppSettings() {
    return Geolocator.openAppSettings();
  }
}

class ProximityResult {
  final Position position;
  final double distanceInMeters;
  final double requiredRadiusMeters;
  final bool isWithinRadius;

  const ProximityResult({
    required this.position,
    required this.distanceInMeters,
    required this.requiredRadiusMeters,
    required this.isWithinRadius,
  });
}

enum ProximityErrorType {
  serviceDisabled,
  permissionDenied,
  permissionDeniedForever,
  unknown,
}

class ProximityException implements Exception {
  final String message;
  final ProximityErrorType type;

  const ProximityException(
    this.message, {
    this.type = ProximityErrorType.unknown,
  });

  @override
  String toString() => message;
}