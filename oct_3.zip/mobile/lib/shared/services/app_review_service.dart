import 'package:flutter/foundation.dart';
import 'package:in_app_review/in_app_review.dart';

class AppReviewService {
  AppReviewService._();

  static final AppReviewService instance =
      AppReviewService._();

  final InAppReview _inAppReview =
      InAppReview.instance;

  // Native Google Play in-app review prompt.
  Future<void> requestReview() async {
    try {
      final bool available =
          await _inAppReview.isAvailable();

      if (!available) {
        debugPrint(
          'IN-APP REVIEW NOT AVAILABLE',
        );
        return;
      }

      await _inAppReview.requestReview();

      debugPrint(
        'IN-APP REVIEW REQUESTED',
      );
    } catch (e) {
      debugPrint(
        'IN-APP REVIEW ERROR: $e',
      );
    }
  }

  // Opens the Google Play listing directly.
  Future<void> openStoreListing() async {
    try {
      await _inAppReview.openStoreListing();

      debugPrint(
        'STORE LISTING OPENED',
      );
    } catch (e) {
      debugPrint(
        'OPEN STORE LISTING ERROR: $e',
      );
    }
  }
}