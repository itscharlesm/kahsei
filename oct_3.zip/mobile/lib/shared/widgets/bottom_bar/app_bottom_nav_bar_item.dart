import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class AppBottomNavItem extends StatelessWidget {
  final IconData? icon;
  final Widget? customIcon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const AppBottomNavItem({
    super.key,
    this.icon,
    this.customIcon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 8,
            horizontal: 2,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (customIcon != null)
                customIcon!
              else
                Icon(
                  icon,
                  size: 22,
                  color: isActive
                      ? AppTheme.primaryRed
                      : AppTheme.gray,
                ),

              const SizedBox(height: 4),

              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isActive
                      ? AppTheme.primaryRed
                      : AppTheme.gray,
                  fontSize: 7.5,
                  fontWeight: isActive
                      ? FontWeight.w800
                      : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}