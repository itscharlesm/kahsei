import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

import 'package:mobile_app/features/home/pages/client_home_page.dart';
import 'package:mobile_app/features/appointments/pages/client_appointments_menu_page.dart';
import 'package:mobile_app/features/bookings/pages/client_booking_location_page.dart';
import 'package:mobile_app/features/profiles/pages/client_profile_page.dart';
import 'package:mobile_app/features/addresses/pages/client_address_page.dart';

import 'package:mobile_app/shared/widgets/bottom_bar/app_bottom_nav_bar_item.dart';

class ClientBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final String email;

  const ClientBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.email,
  });

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _navigate(
    BuildContext context,
    int index,
  ) {
    // Do nothing when tapping the page we are already on.
    if (index == currentIndex) return;

    Widget? page;

    switch (index) {
      // HOME
      case 0:
        page = ClientHomePage(
          email: email,
        );
        break;

      // PROFILE
      case 1:
        page = ClientProfilePage(
          email: email,
        );
        break;

      // BOOK
      case 2:
        page = ClientBookingLocationPage(
          email: email,
        );
        break;

      // APPOINTMENTS
      case 3:
        page = ClientAppointmentsMenuPage(
          email: email,
        );
        break;

      // ADDRESS
      case 4:
        page = ClientAddressPage(
          email: email,
        );
        break;
    }

    if (page == null) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => page!,
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        height: 75,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppTheme.white,
          border: Border(
            top: BorderSide(
              color: AppTheme.borderGray.withOpacity(0.65),
              width: 1,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.07),
              blurRadius: 12,
              offset: const Offset(0, -3),
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(
                      8,
                      0,
                      8,
                      4,
                    ),
                    child: Row(
                      children: [
                        // ====================================================
                        // HOME
                        // ====================================================

                        AppBottomNavItem(
                          icon: currentIndex == 0
                              ? Icons.home_rounded
                              : Icons.home_outlined,
                          label: 'Home',
                          isActive: currentIndex == 0,
                          onTap: () => _navigate(
                            context,
                            0,
                          ),
                        ),

                        // ====================================================
                        // PROFILE
                        // ====================================================

                        AppBottomNavItem(
                          icon: currentIndex == 1
                              ? Icons.person_rounded
                              : Icons.person_outline_rounded,
                          label: 'Profile',
                          isActive: currentIndex == 1,
                          onTap: () => _navigate(
                            context,
                            1,
                          ),
                        ),

                        // ====================================================
                        // BOOK
                        // ====================================================

                        AppBottomNavItem(
                          customIcon: const SizedBox(
                            height: 22,
                          ),
                          label: 'Book',
                          isActive: currentIndex == 2,
                          onTap: () => _navigate(
                            context,
                            2,
                          ),
                        ),

                        // ====================================================
                        // APPOINTMENTS
                        // ====================================================

                        AppBottomNavItem(
                          icon: currentIndex == 3
                              ? Icons.calendar_month_rounded
                              : Icons.calendar_month_outlined,
                          label: 'Appointments',
                          isActive: currentIndex == 3,
                          onTap: () => _navigate(
                            context,
                            3,
                          ),
                        ),

                        // ====================================================
                        // ADDRESS
                        // ====================================================

                        AppBottomNavItem(
                          icon: currentIndex == 4
                              ? Icons.location_on_rounded
                              : Icons.location_on_outlined,
                          label: 'Address',
                          isActive: currentIndex == 4,
                          onTap: () => _navigate(
                            context,
                            4,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ==========================================================
                  // CENTER BOOK BUTTON
                  // ==========================================================

                  Positioned(
                    top: -10,
                    child: _buildBookButton(
                      context,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // BOOK BUTTON
  // ============================================================

  Widget _buildBookButton(
    BuildContext context,
  ) {
    return InkWell(
      onTap: () => _navigate(
        context,
        2,
      ),
      borderRadius: BorderRadius.circular(50),
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          color: AppTheme.primaryRed,
          shape: BoxShape.circle,
          border: Border.all(
            color: AppTheme.white,
            width: 5,
          ),
        ),
        child: const Icon(
          Icons.add_rounded,
          color: AppTheme.white,
          size: 27,
        ),
      ),
    );
  }
}
