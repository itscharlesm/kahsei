import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';

import 'package:mobile_app/features/home/pages/technician_home_page.dart';
import 'package:mobile_app/features/profiles/pages/technician_profile_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_assigned_jobs_menu_page.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_reports_menu_page.dart';

import 'package:mobile_app/shared/widgets/bottom_bar/app_bottom_nav_bar_item.dart';

class TechnicianBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final String email;

  const TechnicianBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.email,
  });

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _navigate(
    BuildContext context,
    int index,
  ) {
    if (index == currentIndex) return;

    Widget? page;

    switch (index) {
      // ========================================================
      // HOME
      // ========================================================

      case 0:
        page = TechnicianHomePage(
          email: email,
        );
        break;

      // ========================================================
      // PROFILE
      // ========================================================

      case 1:
        page = TechnicianProfilePage(
          email: email,
        );
        break;

      // ========================================================
      // ASSIGNED JOBS
      // ========================================================

      case 2:
        page = TechnicianAssignedJobsMenuPage(
          email: email,
        );
        break;

      // ========================================================
      // SERVICE REPORTS
      // ========================================================

      case 3:
        page = TechnicianServiceReportsMenuPage(
          email: email,
        );
        break;
    }

    if (page == null) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => page!,
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return SafeArea(
      top: false,
      child: Container(
        height: 64,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppTheme.white,
          border: Border(
            top: BorderSide(
              color: AppTheme.borderGray.withOpacity(
                0.65,
              ),
              width: 1,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(
                0.07,
              ),
              blurRadius: 12,
              offset: const Offset(
                0,
                -3,
              ),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            8,
            0,
            8,
            4,
          ),
          child: Row(
            children: [
              // ==================================================
              // HOME
              // ==================================================

              AppBottomNavItem(
                icon: currentIndex == 0
                    ? Icons.home_rounded
                    : Icons.home_outlined,
                label: 'Home',
                isActive: currentIndex == 0,
                onTap: () => _navigate(
                  context,
                  0,
                ),
              ),

              // ==================================================
              // PROFILE
              // ==================================================

              AppBottomNavItem(
                icon: currentIndex == 1
                    ? Icons.person_rounded
                    : Icons.person_outline_rounded,
                label: 'Profile',
                isActive: currentIndex == 1,
                onTap: () => _navigate(
                  context,
                  1,
                ),
              ),

              // ==================================================
              // ASSIGNED JOBS
              // ==================================================

              AppBottomNavItem(
                icon: currentIndex == 2
                    ? Icons.work_rounded
                    : Icons.work_outline_rounded,
                label: 'Assigned Jobs',
                isActive: currentIndex == 2,
                onTap: () => _navigate(
                  context,
                  2,
                ),
              ),

              // ==================================================
              // SERVICE REPORTS
              // ==================================================

              AppBottomNavItem(
                icon: currentIndex == 3
                    ? Icons.description_rounded
                    : Icons.description_outlined,
                label: 'Service Reports',
                isActive: currentIndex == 3,
                onTap: () => _navigate(
                  context,
                  3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}