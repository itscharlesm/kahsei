import 'package:flutter/material.dart';
import 'package:mobile_app/shared/widgets/loading/appointment_skeleton_card.dart';

class AppointmentSkeletonList extends StatelessWidget {
  final int itemCount;

  const AppointmentSkeletonList({
    super.key,
    this.itemCount = 3,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      itemCount: itemCount,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, __) => const AppointmentSkeletonCard(),
    );
  }
}
