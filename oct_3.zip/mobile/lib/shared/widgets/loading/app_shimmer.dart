import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:shimmer/shimmer.dart';

class AppShimmer extends StatelessWidget {
  final Widget child;

  const AppShimmer({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppTheme.borderGray.withOpacity(0.35),
      highlightColor: AppTheme.white,
      child: child,
    );
  }
}