import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class AppointmentSkeletonCard extends StatelessWidget {
  const AppointmentSkeletonCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 125,
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: const AppShimmer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppSkeletonLine(width: 120, height: 14),
            SizedBox(height: 14),
            AppSkeletonLine(width: double.infinity, height: 12),
            SizedBox(height: 8),
            AppSkeletonLine(width: 220, height: 12),
            Spacer(),
            Row(
              children: [
                AppSkeletonLine(width: 80, height: 24),
                Spacer(),
                AppSkeletonLine(width: 90, height: 24),
              ],
            ),
          ],
        ),
      ),
    );
  }
}