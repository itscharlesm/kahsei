import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/services/notification_service.dart';

class AppHomeHeader extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final double height;
  final VoidCallback? onNotificationTap;
  final int notificationCount;

  const AppHomeHeader({
    super.key,
    this.title = 'Home',
    this.height = 60,
    this.onNotificationTap,
    this.notificationCount = 0,
  });

  @override
  Size get preferredSize => Size.fromHeight(height);

  @override
  Widget build(BuildContext context) {
    final String badgeText = notificationCount > 9
        ? '9+'
        : notificationCount.toString();

    return Container(
      decoration: AppTheme.headerDecoration,
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: height,
          width: double.infinity,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Go Forward Logo - Left
              Positioned(
                left: 17,
                child: Image.asset(
                  'assets/images/img_goforward_logo_red.png',
                  height: 48,
                  fit: BoxFit.contain,
                ),
              ),

              // Center Title
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 120,
                ),
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppTheme.primaryRed,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // Right Actions
              Positioned(
                right: 8,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Notification Icon with unread badge
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        IconButton(
                          onPressed: onNotificationTap,
                          icon: const Icon(
                            Icons.notifications_none_rounded,
                            color: AppTheme.primaryRed,
                            size: 27,
                          ),
                          tooltip: 'Notifications',
                        ),

                        if (notificationCount > 0)
                          Positioned(
                            top: 3,
                            right: 3,
                            child: Container(
                              constraints: const BoxConstraints(
                                minWidth: 17,
                                minHeight: 17,
                              ),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryRed,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: AppTheme.white,
                                  width: 1.5,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                badgeText,
                                style: const TextStyle(
                                  color: AppTheme.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  height: 1,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),

                    // Menu Icon
                    Builder(
                      builder: (context) => IconButton(
                        onPressed: () =>
                            Scaffold.of(context).openDrawer(),
                        icon: const Icon(
                          Icons.menu_rounded,
                          color: AppTheme.primaryRed,
                          size: 30,
                        ),
                        tooltip: 'Menu',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}