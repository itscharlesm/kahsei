import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class AppTitleHeader extends StatelessWidget implements PreferredSizeWidget {
  final String title;

  const AppTitleHeader({
    super.key,
    required this.title,
  });

  @override
  Size get preferredSize => const Size.fromHeight(50);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: AppTheme.headerDecoration,
      child: SafeArea(
        child: SizedBox(
          height: 50,
          width: double.infinity,
          child: Center(
            child: Text(
              title,
              style: const TextStyle(
                color: AppTheme.primaryRed,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
