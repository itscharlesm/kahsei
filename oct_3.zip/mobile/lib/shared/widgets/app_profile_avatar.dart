import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

class AppProfileAvatar extends StatefulWidget {
  final String? imageUrl;
  final double size;

  const AppProfileAvatar({super.key, required this.imageUrl, this.size = 58});

  @override
  State<AppProfileAvatar> createState() => _AppProfileAvatarState();
}

class _AppProfileAvatarState extends State<AppProfileAvatar> {
  bool _imageLoaded = false;

  @override
  void didUpdateWidget(covariant AppProfileAvatar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imageUrl?.trim() != widget.imageUrl?.trim()) {
      _imageLoaded = false;
    }
  }

  void _markImageLoaded() {
    if (_imageLoaded) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !_imageLoaded) {
        setState(() => _imageLoaded = true);
      }
    });
  }

  Widget _fallback() {
    return Container(
      color: Colors.transparent,
      alignment: Alignment.center,
      child: Icon(
        Icons.person_rounded,
        color: AppTheme.gray,
        size: widget.size * 0.52,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rawImageUrl = widget.imageUrl?.trim() ?? '';
    final normalizedUrl = rawImageUrl.isEmpty
        ? null
        : rawImageUrl.startsWith('http://') || rawImageUrl.startsWith('https://')
            ? rawImageUrl
            : '${ApiConfig.baseUrl}/${rawImageUrl.replaceFirst(RegExp(r'^/+'), '')}';
    final hasImage = normalizedUrl != null && normalizedUrl.isNotEmpty;

    return Container(
      width: widget.size,
      height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppTheme.white,
        border: Border.all(
          color: _imageLoaded ? AppTheme.white : AppTheme.borderGray,
          width: 2,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: hasImage
          ? Transform.scale(
              scale: 1.12,
              child: Image.network(
                normalizedUrl,
                width: widget.size,
                height: widget.size,
                fit: BoxFit.cover,
                frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                  if (wasSynchronouslyLoaded || frame != null) {
                    _markImageLoaded();
                    return child;
                  }
                  return _fallback();
                },
                errorBuilder: (context, error, stackTrace) => _fallback(),
              ),
            )
          : _fallback(),
    );
  }
}
