// import 'package:flutter/material.dart';
// import 'package:mobile_app/app/theme.dart';

// class FullWidthContainer extends StatelessWidget {
//   final String title;
//   final Widget child;
//   final EdgeInsetsGeometry? margin;
//   final EdgeInsetsGeometry? padding;
//   final Color? backgroundColor;
//   final bool showTitle;

//   const FullWidthContainer({
//     super.key,
//     required this.title,
//     required this.child,
//     this.margin,
//     this.padding,
//     this.backgroundColor,
//     this.showTitle = true,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: double.infinity,
//       margin: margin ?? const EdgeInsets.only(bottom: 14),
//       decoration: BoxDecoration(
//         color: backgroundColor ?? const Color(0xFFFCFCFC),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           if (showTitle)
//             Padding(
//               padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
//               child: Text(
//                 title,
//                 style: const TextStyle(
//                   color: AppTheme.black,
//                   fontSize: 11,
//                   fontWeight: FontWeight.w800,
//                   letterSpacing: 0.6,
//                 ),
//               ),
//             ),
//           Padding(
//             padding:
//                 padding ?? const EdgeInsets.fromLTRB(20, 0, 20, 18),
//             child: child,
//           ),
//         ],
//       ),
//     );
//   }
// }