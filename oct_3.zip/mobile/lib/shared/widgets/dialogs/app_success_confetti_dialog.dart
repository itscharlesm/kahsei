import 'dart:math';

import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class AppSuccessConfettiDialog extends StatefulWidget {
  final IconData icon;
  final String title;
  final String message;
  final String buttonText;
  final VoidCallback? onPressed;
  final Color iconColor;
  final Color buttonColor;

  const AppSuccessConfettiDialog({
    super.key,
    this.icon = Icons.check_circle_rounded,
    required this.title,
    required this.message,
    required this.buttonText,
    this.onPressed,
    this.iconColor = Colors.green,
    this.buttonColor = AppTheme.primaryRed,
  });

  @override
  State<AppSuccessConfettiDialog> createState() =>
      _AppSuccessConfettiDialogState();
}

class _AppSuccessConfettiDialogState
    extends State<AppSuccessConfettiDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _confettiController;

  late final List<_ConfettiParticle> _particles;

  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    _confettiController = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1700,
      ),
    );

    _particles = List.generate(
      28,
      (_) => _createParticle(),
    );

    _confettiController.forward();
  }

  _ConfettiParticle _createParticle() {
    final colors = [
      AppTheme.primaryRed,
      const Color(0xFFFFC107),
      const Color(0xFF4CAF50),
      const Color(0xFF2196F3),
      const Color(0xFFFF7043),
    ];

    return _ConfettiParticle(
      angle:
          (-pi * 0.95) +
          (_random.nextDouble() * pi * 0.90),
      distance:
          55 +
          (_random.nextDouble() * 55),
      rotation:
          (_random.nextDouble() * pi * 5) -
          (pi * 2.5),
      width:
          3.5 +
          (_random.nextDouble() * 3),
      height:
          6 +
          (_random.nextDouble() * 5),
      color:
          colors[
            _random.nextInt(
              colors.length,
            )
          ],
      delay:
          _random.nextDouble() * 0.18,
    );
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    return AlertDialog(
      backgroundColor: AppTheme.white,
      shape: RoundedRectangleBorder(
        borderRadius:
            BorderRadius.circular(18),
      ),
      contentPadding:
          const EdgeInsets.fromLTRB(
        24,
        24,
        24,
        18,
      ),
      content: Column(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          // ==================================================
          // SUCCESS ICON + CONFETTI
          // ==================================================

          SizedBox(
            width: 150,
            height: 110,
            child: Stack(
              alignment:
                  Alignment.center,
              clipBehavior: Clip.none,
              children: [
                AnimatedBuilder(
                  animation:
                      _confettiController,
                  builder: (
                    context,
                    child,
                  ) {
                    return Stack(
                      alignment:
                          Alignment.center,
                      clipBehavior:
                          Clip.none,
                      children: [
                        for (
                          final particle
                              in _particles
                        )
                          _buildParticle(
                            particle,
                          ),
                      ],
                    );
                  },
                ),

                // ============================================
                // ICON
                // ============================================

                Container(
                  width: 62,
                  height: 62,
                  decoration:
                      BoxDecoration(
                    color: widget
                        .iconColor
                        .withOpacity(
                          0.10,
                        ),
                    shape:
                        BoxShape.circle,
                  ),
                  child: Icon(
                    widget.icon,
                    color:
                        widget.iconColor,
                    size: 34,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          // ==================================================
          // TITLE
          // ==================================================

          Text(
            widget.title,
            textAlign:
                TextAlign.center,
            style:
                const TextStyle(
              fontSize: 18,
              fontWeight:
                  FontWeight.w800,
              color:
                  AppTheme.black,
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          // ==================================================
          // MESSAGE
          // ==================================================

          Text(
            widget.message,
            textAlign:
                TextAlign.center,
            style:
                const TextStyle(
              fontSize: 14,
              color:
                  AppTheme.gray,
              height: 1.4,
              fontWeight:
                  FontWeight.w500,
            ),
          ),

          const SizedBox(
            height: 24,
          ),

          // ==================================================
          // BUTTON
          // ==================================================

          SizedBox(
            width:
                double.infinity,
            child:
                ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  context,
                );

                if (widget
                        .onPressed !=
                    null) {
                  widget.onPressed!();
                }
              },
              style:
                  ElevatedButton
                      .styleFrom(
                backgroundColor:
                    widget
                        .buttonColor,
                foregroundColor:
                    AppTheme.white,
                elevation: 0,
                padding:
                    const EdgeInsets
                        .symmetric(
                  vertical: 14,
                ),
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius
                          .circular(
                    12,
                  ),
                ),
              ),
              child: Text(
                widget.buttonText,
                style:
                    const TextStyle(
                  fontWeight:
                      FontWeight
                          .w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildParticle(
    _ConfettiParticle particle,
  ) {
    final rawProgress =
        _confettiController.value;

    final adjustedProgress =
        ((rawProgress -
                    particle.delay) /
                (1 -
                    particle.delay))
            .clamp(
      0.0,
      1.0,
    );

    if (adjustedProgress <= 0) {
      return const SizedBox
          .shrink();
    }

    final curvedProgress =
        Curves.easeOut
            .transform(
      adjustedProgress,
    );

    final horizontal =
        cos(
              particle.angle,
            ) *
            particle.distance *
            curvedProgress;

    final vertical =
        sin(
              particle.angle,
            ) *
            particle.distance *
            curvedProgress +
        (
          42 *
          adjustedProgress *
          adjustedProgress
        );

    final opacity =
        adjustedProgress < 0.72
            ? 1.0
            : 1.0 -
                (
                  (
                        adjustedProgress -
                            0.72
                      ) /
                      0.28
                );

    return Transform.translate(
      offset: Offset(
        horizontal,
        vertical,
      ),
      child: Transform.rotate(
        angle:
            particle.rotation *
            adjustedProgress,
        child: Opacity(
          opacity:
              opacity.clamp(
            0.0,
            1.0,
          ),
          child: Container(
            width:
                particle.width,
            height:
                particle.height,
            decoration:
                BoxDecoration(
              color:
                  particle.color,
              borderRadius:
                  BorderRadius.circular(
                2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// CONFETTI PARTICLE MODEL
// ============================================================

class _ConfettiParticle {
  final double angle;
  final double distance;
  final double rotation;
  final double width;
  final double height;
  final Color color;
  final double delay;

  const _ConfettiParticle({
    required this.angle,
    required this.distance,
    required this.rotation,
    required this.width,
    required this.height,
    required this.color,
    required this.delay,
  });
}