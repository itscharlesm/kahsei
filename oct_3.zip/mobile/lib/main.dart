import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';

import 'app/theme.dart';
import 'app/app_navigator.dart';
import 'config/mapbox_config.dart';
import 'features/auth/services/auth_session_service.dart';
import 'features/auth/pages/welcome_page.dart';
import 'features/home/pages/client_home_page.dart';
import 'features/home/pages/technician_home_page.dart';
import 'shared/services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await dotenv.load(fileName: ".env");

  MapboxOptions.setAccessToken(MapboxConfig.accessToken);

  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  runApp(const MyApp());

  // Notification setup and its permission prompt must not block the first frame.
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try {
      await AppNotificationService.instance.initialize();
    } catch (error, stackTrace) {
      FlutterError.reportError(
        FlutterErrorDetails(
          exception: error,
          stack: stackTrace,
          library: 'app startup',
          context: ErrorDescription('while initializing notifications'),
        ),
      );
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  late final Future<Widget> _initialPageFuture;

  @override
  void initState() {
    super.initState();
    _initialPageFuture = _resolveInitialPage();
  }

  Future<Widget> _resolveInitialPage() async {
    final AuthenticatedSession? session;

    try {
      session = await AuthSessionService.instance.restoreSession();
    } catch (_) {
      return const WelcomePage();
    }

    if (session == null) {
      return const WelcomePage();
    }

    if (session.userType == 3) {
      unawaited(
        AppNotificationService.instance.startClientPolling(session.email),
      );

      return ClientHomePage(email: session.email);
    }

    if (session.userType == 2) {
      unawaited(
        AppNotificationService.instance.startTechnicianPolling(session.email),
      );

      return TechnicianHomePage(email: session.email);
    }

    await AuthSessionService.instance.clearSession();
    return const WelcomePage();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Widget>(
      future: _initialPageFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            snapshot.hasData) {
          return snapshot.data!;
        }

        if (snapshot.connectionState == ConnectionState.done &&
            snapshot.hasError) {
          return const WelcomePage();
        }

        if (snapshot.connectionState == ConnectionState.done) {
          return const WelcomePage();
        }

        return const Scaffold(
          backgroundColor: Colors.white,
          body: Center(
            child: CircularProgressIndicator(
              color: AppTheme.primaryRed,
            ),
          ),
        );
      },
    );
  }
}
