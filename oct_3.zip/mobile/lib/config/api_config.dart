class ApiConfig {
  // LOCAL DEVELOPMENT
  // static const String baseUrl = 'http://192.168.1.4:8000';

  // NGROK TESTING
  // static const String baseUrl =
  //     'https://washcloth-tartar-anchor.ngrok-free.dev';

  // PRODUCTION
  static const String baseUrl = 'https://goserviceph.com';
}
    