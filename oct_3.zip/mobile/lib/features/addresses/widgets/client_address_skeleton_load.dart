import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class ClientAddressSkeletonLoad extends StatelessWidget {
  const ClientAddressSkeletonLoad({super.key});

  static const int addressSkeletonCount = 6;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _AddAddressButtonSkeleton(),
          const SizedBox(height: 10),

          ...List.generate(
            addressSkeletonCount,
            (index) => const _AddressCardSkeleton(),
          ),
        ],
      ),
    );
  }
}

class _AddAddressButtonSkeleton extends StatelessWidget {
  const _AddAddressButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Row(
          children: [
            AppSkeletonLine(width: 22, height: 22, radius: 50),
            SizedBox(width: 12),
            AppSkeletonLine(width: 135, height: 13),
          ],
        ),
      ),
    );
  }
}

class _AddressCardSkeleton extends StatelessWidget {
  const _AddressCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AppSkeletonLine(width: 19, height: 19, radius: 50),
                SizedBox(width: 8),
                AppSkeletonLine(width: 75, height: 14),
                SizedBox(width: 8),
                AppSkeletonLine(width: 60, height: 20, radius: 20),
                Spacer(),
                AppSkeletonLine(width: 22, height: 22, radius: 6),
              ],
            ),

            SizedBox(height: 12),

            AppSkeletonLine(width: double.infinity, height: 12),
            SizedBox(height: 7),
            AppSkeletonLine(width: 260, height: 12),

            SizedBox(height: 20),

            Row(
              children: [
                AppSkeletonLine(width: 32, height: 12),
                SizedBox(width: 16),
                AppSkeletonLine(width: 45, height: 12),
              ],
            ),
          ],
        ),
      ),
    );
  }
}