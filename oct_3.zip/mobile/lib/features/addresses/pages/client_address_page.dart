import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/addresses/widgets/add_address_sheet.dart';
import 'package:mobile_app/features/addresses/widgets/edit_address_sheet.dart';
import 'package:mobile_app/features/addresses/widgets/client_address_skeleton_load.dart';

import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/headers/app_title_header.dart';

class ClientAddressPage extends StatefulWidget {
  final String email;

  const ClientAddressPage({
    super.key,
    required this.email,
  });

  @override
  State<ClientAddressPage> createState() =>
      _ClientAddressPageState();
}

class _ClientAddressPageState
    extends State<ClientAddressPage> {
  List<Map<String, dynamic>> addresses = [];

  bool isLoading = true;

  int? deletingAddressId;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _loadAddresses();
  }

  // ============================================================
  // ADDRESS TYPE
  // ============================================================

  String _addressTypeName(
    dynamic addId,
  ) {
    switch (addId) {
      case 1:
        return 'HOME';

      case 2:
        return 'WORK';

      case 3:
        return 'COMPANY';

      case 4:
        return 'FAVORITE';

      case 5:
        return 'RESIDENTIAL';

      default:
        return 'ADDRESS';
    }
  }

  // ============================================================
  // ADDRESS ICON
  // ============================================================

  IconData _addressIcon(
    String label,
  ) {
    switch (label.toUpperCase()) {
      case 'HOME':
        return Icons.home_outlined;

      case 'WORK':
        return Icons.business_center_outlined;

      case 'COMPANY':
        return Icons.business_outlined;

      case 'FAVORITE':
        return Icons.star_outline_rounded;

      case 'RESIDENTIAL':
        return Icons.apartment_rounded;

      default:
        return Icons.location_on_outlined;
    }
  }

  // ============================================================
  // ADDRESS LABEL
  // ============================================================

  String _formatLabel(
    String label,
  ) {
    switch (label.toUpperCase()) {
      case 'HOME':
        return 'Home';

      case 'WORK':
        return 'Work';

      case 'COMPANY':
        return 'Company';

      case 'FAVORITE':
        return 'Favorite';

      case 'RESIDENTIAL':
        return 'Residential';

      default:
        return label;
    }
  }

  // ============================================================
  // ADDRESS FORMATTER
  // ============================================================

  String _formatAddress(
    Map<String, dynamic> item,
  ) {
    final street =
        (item['uadd_street'] ?? '')
            .toString()
            .trim();

    final barangay =
        (item['uadd_barangay'] ?? '')
            .toString()
            .trim();

    final city =
        (item['uadd_city'] ?? '')
            .toString()
            .trim();

    final province =
        (item['uadd_province'] ?? '')
            .toString()
            .trim();

    final region =
        (item['uadd_region'] ?? '')
            .toString()
            .trim();

    final firstLine = [
      street,
      barangay,
    ].where(
      (value) => value.isNotEmpty,
    ).join(', ');

    final secondLine = [
      city,
      province,
      region,
    ].where(
      (value) => value.isNotEmpty,
    ).join(', ');

    final lines = [
      firstLine,
      secondLine,
    ].where(
      (value) => value.isNotEmpty,
    ).toList();

    if (lines.isEmpty) {
      return 'Address details unavailable';
    }

    return lines.join('\n');
  }

  // ============================================================
  // ADD ADDRESS
  // ============================================================

  void _openAddAddressSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(
            22,
          ),
        ),
      ),
      builder: (_) {
        return AddAddressSheet(
          email: widget.email,
          onSaved: (
            newAddress,
          ) {
            _loadAddresses();
          },
        );
      },
    );
  }

  // ============================================================
  // EDIT ADDRESS
  // ============================================================

  void _openEditAddressSheet(
    Map<String, dynamic> address,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(
            22,
          ),
        ),
      ),
      builder: (_) {
        return EditAddressSheet(
          email: widget.email,
          address: address,
          onUpdated: _loadAddresses,
        );
      },
    );
  }

  // ============================================================
  // LOAD ADDRESSES
  // ============================================================

  Future<void> _loadAddresses() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final response =
          await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/address/list',
        ),
        headers: const {
          'Content-Type':
              'application/json',
          'Accept':
              'application/json',
        },
        body: jsonEncode({
          'email':
              widget.email,
        }),
      );

      final data =
          jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode ==
              200 &&
          data['success'] ==
              true) {
        final List fetchedAddresses =
            data['data'] ??
                [];

        setState(() {
          addresses =
              fetchedAddresses
                  .map<
                      Map<String,
                          dynamic>>(
            (
              item,
            ) {
              return {
                'uadd_id':
                    item['uadd_id'],

                'label':
                    _addressTypeName(
                  item['add_id'],
                ),

                'add_id':
                    item['add_id'],

                'uadd_street':
                    item['uadd_street'] ??
                        '',

                'uadd_barangay':
                    item['uadd_barangay'] ??
                        '',

                'uadd_city':
                    item['uadd_city'] ??
                        '',

                'uadd_province':
                    item['uadd_province'] ??
                        '',

                'uadd_region':
                    item['uadd_region'] ??
                        '',

                'uadd_latitude':
                    item['uadd_latitude'],

                'uadd_longitude':
                    item['uadd_longitude'],
              };
            },
          ).toList();
        });
      } else {
        setState(() {
          addresses = [];
        });

        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              data['message'] ??
                  'Unable to load addresses.',
            ),
          ),
        );
      }
    } catch (error) {
      debugPrint(
        'LOAD ADDRESS ERROR: $error',
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to load addresses.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  // ============================================================
  // DELETE CONFIRMATION
  // ============================================================

  Future<void> _confirmDeleteAddress(
    Map<String, dynamic> address,
  ) async {
    final bool? confirmed =
        await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (
        dialogContext,
      ) {
        return AlertDialog(
          backgroundColor:
              AppTheme.white,

          surfaceTintColor:
              Colors.transparent,

          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
              20,
            ),
          ),

          contentPadding:
              const EdgeInsets.fromLTRB(
            22,
            24,
            22,
            10,
          ),

          actionsPadding:
              const EdgeInsets.fromLTRB(
            18,
            4,
            18,
            18,
          ),

          content:
              Column(
            mainAxisSize:
                MainAxisSize.min,

            children: [
              // ==================================================
              // DELETE ICON
              // ==================================================

              Container(
                width:
                    58,

                height:
                    58,

                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),

                  shape:
                      BoxShape.circle,
                ),

                child:
                    const Icon(
                  Icons.delete_outline_rounded,

                  color:
                      AppTheme.primaryRed,

                  size:
                      28,
                ),
              ),

              const SizedBox(
                height:
                    17,
              ),

              // ==================================================
              // TITLE
              // ==================================================

              const Text(
                'Delete Address?',

                textAlign:
                    TextAlign.center,

                style:
                    TextStyle(
                  color:
                      AppTheme.black,

                  fontSize:
                      17,

                  fontWeight:
                      FontWeight.w900,
                ),
              ),

              const SizedBox(
                height:
                    9,
              ),

              // ==================================================
              // MESSAGE
              // ==================================================

              const Text(
                'Are you sure you want to remove this address from your saved addresses?',

                textAlign:
                    TextAlign.center,

                style:
                    TextStyle(
                  color:
                      AppTheme.gray,

                  fontSize:
                      11.5,

                  height:
                      1.5,

                  fontWeight:
                      FontWeight.w500,
                ),
              ),
            ],
          ),

          actions: [
            Row(
              children: [
                // ================================================
                // CANCEL
                // ================================================

                Expanded(
                  child:
                      OutlinedButton(
                    onPressed: () {
                      Navigator.pop(
                        dialogContext,
                        false,
                      );
                    },

                    style:
                        OutlinedButton.styleFrom(
                      foregroundColor:
                          AppTheme.black,

                      side:
                          const BorderSide(
                        color:
                            AppTheme.borderGray,
                      ),

                      minimumSize:
                          const Size(
                        double.infinity,
                        46,
                      ),

                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(
                          12,
                        ),
                      ),
                    ),

                    child:
                        const Text(
                      'Cancel',

                      style:
                          TextStyle(
                        fontWeight:
                            FontWeight.w700,
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  width:
                      10,
                ),

                // ================================================
                // DELETE
                // ================================================

                Expanded(
                  child:
                      ElevatedButton(
                    onPressed: () {
                      Navigator.pop(
                        dialogContext,
                        true,
                      );
                    },

                    style:
                        ElevatedButton.styleFrom(
                      backgroundColor:
                          AppTheme.primaryRed,

                      foregroundColor:
                          AppTheme.white,

                      elevation:
                          0,

                      minimumSize:
                          const Size(
                        double.infinity,
                        46,
                      ),

                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(
                          12,
                        ),
                      ),
                    ),

                    child:
                        const Text(
                      'Delete',

                      style:
                          TextStyle(
                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    final int? addressId =
        address['uadd_id'];

    if (addressId == null) {
      return;
    }

    await _deleteAddressFromDatabase(
      addressId,
    );
  }

  // ============================================================
  // DELETE ADDRESS
  // ============================================================

  Future<void> _deleteAddressFromDatabase(
    int uaddId,
  ) async {
    if (deletingAddressId != null) {
      return;
    }

    setState(() {
      deletingAddressId =
          uaddId;
    });

    try {
      final response =
          await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/address/delete',
        ),
        headers: const {
          'Content-Type':
              'application/json',
          'Accept':
              'application/json',
        },
        body: jsonEncode({
          'email':
              widget.email,

          'uadd_id':
              uaddId,
        }),
      );

      final data =
          jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode ==
              200 &&
          data['success'] ==
              true) {
        await _loadAddresses();

        if (!mounted) return;

        ScaffoldMessenger.of(context)
            .hideCurrentSnackBar();

        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              'Address removed successfully.',
            ),
          ),
        );

        return;
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            data['message'] ??
                'Unable to remove address.',
          ),
        ),
      );
    } catch (error) {
      debugPrint(
        'DELETE ADDRESS ERROR: $error',
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Connection error while removing address.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          deletingAddressId =
              null;
        });
      }
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      appBar:
          const AppTitleHeader(
        title:
            'My Addresses',
      ),

      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex:
            4,

        email:
            widget.email,
      ),

      body:
          isLoading
              ? const ClientAddressSkeletonLoad()
              : RefreshIndicator(
                  color:
                      AppTheme.primaryRed,

                  onRefresh:
                      _loadAddresses,

                  child:
                      SingleChildScrollView(
                    physics:
                        const AlwaysScrollableScrollPhysics(),

                    padding:
                        const EdgeInsets.fromLTRB(
                      20,
                      18,
                      20,
                      30,
                    ),

                    child:
                        Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [
                        // ==================================================
                        // ADDRESS INTRO CARD
                        // ==================================================

                        _addressHeaderCard(),

                        const SizedBox(
                          height:
                              14,
                        ),

                        // ==================================================
                        // ADD ADDRESS
                        // ==================================================

                        _addAddressButton(),

                        const SizedBox(
                          height:
                              24,
                        ),

                        // ==================================================
                        // SAVED ADDRESSES
                        // ==================================================

                        if (addresses
                            .isNotEmpty) ...[
                          _sectionLabel(
                            'SAVED ADDRESSES',
                          ),

                          const SizedBox(
                            height:
                                10,
                          ),
                        ],

                        // ==================================================
                        // ADDRESS LIST
                        // ==================================================

                        if (addresses
                            .isEmpty)
                          _emptyState()
                        else
                          ...addresses.map(
                            (
                              item,
                            ) {
                              return _addressCard(
                                item:
                                    item,
                              );
                            },
                          ),
                      ],
                    ),
                  ),
                ),
    );
  }

  // ============================================================
  // ADDRESS HEADER CARD
  // ============================================================

  Widget _addressHeaderCard() {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        17,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          18,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.025,
            ),

            blurRadius:
                10,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          Row(
        children: [
          // ======================================================
          // ICON
          // ======================================================

          Container(
            width:
                52,

            height:
                52,

            decoration:
                BoxDecoration(
              color:
                  AppTheme.primaryRed
                      .withOpacity(
                0.08,
              ),

              shape:
                  BoxShape.circle,
            ),

            child:
                const Icon(
              Icons.location_on_outlined,

              color:
                  AppTheme.primaryRed,

              size:
                  25,
            ),
          ),

          const SizedBox(
            width:
                14,
          ),

          // ======================================================
          // INFO
          // ======================================================

          const Expanded(
            child:
                Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  'Your Addresses',

                  style:
                      TextStyle(
                    color:
                        AppTheme.black,

                    fontSize:
                        15,

                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                SizedBox(
                  height:
                      5,
                ),

                Text(
                  'Manage your saved service addresses easily and securely.',

                  style:
                      TextStyle(
                    color:
                        AppTheme.gray,

                    fontSize:
                        10.5,

                    height:
                        1.4,

                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ADD ADDRESS BUTTON
  // ============================================================

  Widget _addAddressButton() {
    return Material(
      color:
          AppTheme.primaryRed,

      borderRadius:
          BorderRadius.circular(
        14,
      ),

      child:
          InkWell(
        onTap:
            _openAddAddressSheet,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        child:
            Container(
          width:
              double.infinity,

          height:
              50,

          alignment:
              Alignment.center,

          child:
              const Row(
            mainAxisAlignment:
                MainAxisAlignment.center,

            children: [
              Icon(
                Icons.add_rounded,

                color:
                    AppTheme.white,

                size:
                    21,
              ),

              SizedBox(
                width:
                    8,
              ),

              Text(
                'Add New Address',

                style:
                    TextStyle(
                  color:
                      AppTheme.white,

                  fontSize:
                      13,

                  fontWeight:
                      FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left:
            2,
      ),

      child:
          Text(
        title,

        style:
            const TextStyle(
          color:
              AppTheme.gray,

          fontSize:
              10,

          letterSpacing:
              0.9,

          fontWeight:
              FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // ADDRESS CARD
  // ============================================================

  Widget _addressCard({
    required Map<String, dynamic> item,
  }) {
    final String label =
        item['label'] ??
            'ADDRESS';

    final int? uaddId =
        item['uadd_id'];

    final bool isDeleting =
        deletingAddressId ==
            uaddId;

    final String address =
        _formatAddress(
      item,
    );

    return Container(
      width:
          double.infinity,

      margin:
          const EdgeInsets.only(
        bottom:
            12,
      ),

      padding:
          const EdgeInsets.all(
        15,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          17,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.025,
            ),

            blurRadius:
                10,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          // ======================================================
          // ADDRESS INFORMATION
          // ======================================================

          Row(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
              // ==================================================
              // ADDRESS TYPE ICON
              // ==================================================

              Container(
                width:
                    44,

                height:
                    44,

                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.07,
                  ),

                  borderRadius:
                      BorderRadius.circular(
                    13,
                  ),
                ),

                child:
                    Icon(
                  _addressIcon(
                    label,
                  ),

                  color:
                      AppTheme.primaryRed,

                  size:
                      21,
                ),
              ),

              const SizedBox(
                width:
                    12,
              ),

              // ==================================================
              // ADDRESS DETAILS
              // ==================================================

              Expanded(
                child:
                    Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [
                    Text(
                      _formatLabel(
                        label,
                      ),

                      maxLines:
                          1,

                      overflow:
                          TextOverflow.ellipsis,

                      style:
                          const TextStyle(
                        color:
                            AppTheme.black,

                        fontSize:
                            14,

                        fontWeight:
                            FontWeight.w900,
                      ),
                    ),

                    const SizedBox(
                      height:
                          8,
                    ),

                    Text(
                      address,

                      style:
                          const TextStyle(
                        color:
                            AppTheme.black,

                        fontSize:
                            11.5,

                        height:
                            1.45,

                        fontWeight:
                            FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(
            height:
                16,
          ),

          const Divider(
            height:
                1,

            color:
                AppTheme.borderGray,
          ),

          const SizedBox(
            height:
                10,
          ),

          // ======================================================
          // ACTIONS
          // ======================================================

          Row(
            children: [
              // ==================================================
              // EDIT
              // ==================================================

              _smallAction(
                icon:
                    Icons.edit_outlined,

                label:
                    'Edit',

                onTap:
                    isDeleting
                        ? null
                        : () {
                            _openEditAddressSheet(
                              item,
                            );
                          },
              ),

              const SizedBox(
                width:
                    18,
              ),

              // ==================================================
              // DELETE
              // ==================================================

              _smallAction(
                icon:
                    Icons.delete_outline_rounded,

                label:
                    isDeleting
                        ? 'Removing...'
                        : 'Delete',

                destructive:
                    true,

                onTap:
                    isDeleting
                        ? null
                        : () {
                            _confirmDeleteAddress(
                              item,
                            );
                          },
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SMALL ACTION
  // ============================================================

  Widget _smallAction({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
    bool destructive = false,
  }) {
    final color =
        destructive
            ? AppTheme.primaryRed
            : AppTheme.black;

    return InkWell(
      borderRadius:
          BorderRadius.circular(
        8,
      ),

      onTap:
          onTap,

      child:
          Padding(
        padding:
            const EdgeInsets.symmetric(
          horizontal:
              3,

          vertical:
              5,
        ),

        child:
            Row(
          children: [
            Icon(
              icon,

              color:
                  onTap == null
                      ? AppTheme.gray
                      : color,

              size:
                  16,
            ),

            const SizedBox(
              width:
                  5,
            ),

            Text(
              label,

              style:
                  TextStyle(
                color:
                    onTap == null
                        ? AppTheme.gray
                        : color,

                fontSize:
                    10.5,

                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================

  Widget _emptyState() {
    return Container(
      width:
          double.infinity,

      margin:
          const EdgeInsets.only(
        top:
            8,
      ),

      padding:
          const EdgeInsets.symmetric(
        horizontal:
            24,

        vertical:
            44,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          17,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),
      ),

      child:
          Column(
        children: [
          Container(
            width:
                66,

            height:
                66,

            decoration:
                BoxDecoration(
              color:
                  AppTheme.primaryRed
                      .withOpacity(
                0.07,
              ),

              shape:
                  BoxShape.circle,
            ),

            child:
                const Icon(
              Icons.location_on_outlined,

              color:
                  AppTheme.primaryRed,

              size:
                  31,
            ),
          ),

          const SizedBox(
            height:
                16,
          ),

          const Text(
            'No Address Yet',

            style:
                TextStyle(
              color:
                  AppTheme.black,

              fontSize:
                  15,

              fontWeight:
                  FontWeight.w900,
            ),
          ),

          const SizedBox(
            height:
                7,
          ),

          const Text(
            'Add a service address to make your future bookings faster and easier.',

            textAlign:
                TextAlign.center,

            style:
                TextStyle(
              color:
                  AppTheme.gray,

              fontSize:
                  11,

              height:
                  1.5,

              fontWeight:
                  FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
