  import 'package:flutter/material.dart';
  import 'package:mobile_app/app/theme.dart';
  import 'package:mobile_app/shared/shared.dart';
  import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
  import 'dart:convert';
  import 'package:http/http.dart' as http;
  import 'package:mobile_app/config/api_config.dart';
  import 'package:mobile_app/features/appointments/pages/client_requested_appointments_page.dart';
  import 'package:mobile_app/features/appointments/pages/client_assessed_appointments_page.dart';
  import 'package:mobile_app/features/appointments/pages/client_scheduled_appointments_page.dart';
  import 'package:mobile_app/features/appointments/pages/client_ongoing_appointments_page.dart';
  import 'package:mobile_app/features/appointments/pages/client_completed_appointments_page.dart';

  class ClientNotificationsPage extends StatefulWidget {
    final String email;

    const ClientNotificationsPage({
      super.key,
      required this.email,
    });

    @override
    State<ClientNotificationsPage> createState() =>
        _ClientNotificationsPageState();
  }

  class _ClientNotificationsPageState
      extends State<ClientNotificationsPage> {

  int _currentPage = 1;
  bool _hasMore = true;
  bool _isLoadingMore = false;

  final ScrollController _scrollController = ScrollController();

  // ============================================================
  // NOTIFICATION DATA
  // ============================================================

  List<Map<String, dynamic>> _notifications = [];

  bool _isLoading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_handleScroll);
    _loadNotifications();
  }

  // ============================================================
  // UNREAD COUNT
  // ============================================================

  int get _unreadCount {
    return _notifications
        .where((notification) => notification['isRead'] == false)
        .length;
  }

  String _formatMessage(String value) {
    final trimmed = value.trim();

    if (trimmed.isEmpty) {
      return '';
    }

    final lower = trimmed.toLowerCase();

    return lower[0].toUpperCase() + lower.substring(1);
  }

  String _getNotificationType(String message) {
    final normalized = message.toUpperCase();

    // Appointment
    if (normalized.contains('REQUEST') &&
        normalized.contains('SUBMITTED')) {
      return 'APPOINTMENT_REQUESTED';
    }

    if (normalized.contains('ASSESSED')) {
      return 'APPOINTMENT_ASSESSED';
    }

    if (normalized.contains('SCHEDULED')) {
      return 'APPOINTMENT_SCHEDULED';
    }

    if (normalized.contains('CANCELLED') ||
        normalized.contains('CANCELED')) {
      return 'APPOINTMENT_CANCELLED';
    }

    // Payment
    if (normalized.contains('PAYMENT') &&
        normalized.contains('SUBMITTED')) {
      return 'PAYMENT_SUBMITTED';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('APPROVED') ||
        normalized.contains('VERIFIED'))) {
      return 'PAYMENT_APPROVED';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('REJECTED') ||
        normalized.contains('COULD NOT BE VERIFIED'))) {
      return 'PAYMENT_REJECTED';
    }

    // Technician / Service
    if (normalized.contains('TECHNICIAN') &&
        normalized.contains('ASSIGNED')) {
      return 'TECHNICIAN_ASSIGNED';
    }
    
    if (normalized.contains('TRAVELING')) {
      return 'TECHNICIAN_ON_THE_WAY';
    }

    if (normalized.contains('ARRIVED')) {
      return 'TECHNICIAN_ARRIVED';
    }

    if (normalized.contains('COMPLETED')) {
      return 'SERVICE_COMPLETED';
    }

    return 'GENERAL';
  }

  String _getNotificationTitle(String message) {
    final normalized = message.toUpperCase();

    // Appointment
    if (normalized.contains('REQUEST') &&
        normalized.contains('SUBMITTED')) {
      return 'Request submitted';
    }

    if (normalized.contains('ASSESSED')) {
      return 'Request assessed';
    }

    if (normalized.contains('SCHEDULED')) {
      return 'Appointment scheduled';
    }

    if (normalized.contains('CANCELLED') ||
        normalized.contains('CANCELED')) {
      return 'Appointment cancelled';
    }

    // Payment
    if (normalized.contains('PAYMENT') &&
        normalized.contains('SUBMITTED')) {
      return 'Payment submitted';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('APPROVED') ||
        normalized.contains('VERIFIED'))) {
      return 'Payment approved';
    }

    if (normalized.contains('PAYMENT') &&
        (normalized.contains('REJECTED') ||
        normalized.contains('COULD NOT BE VERIFIED'))) {
      return 'Payment requires attention';
    }

    // Technician / Service
    if (normalized.contains('TECHNICIAN') &&
        normalized.contains('ASSIGNED')) {
      return 'Technician assigned';
    }

    if (normalized.contains('TRAVELING')) {
      return 'Technician is on the way';
    }

    if (normalized.contains('ARRIVED')) {
      return 'Technician has arrived';
    }

    if (normalized.contains('COMPLETED')) {
      return 'Service completed';
    }

    return 'Service Update';
  }

  String _formatNotificationTime(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '';
    }

    final createdAt = DateTime.tryParse(value);

    if (createdAt == null) {
      return '';
    }

    final now = DateTime.now();
    final difference = now.difference(createdAt);

    if (difference.inMinutes < 1) {
      return 'Now';
    }

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m';
    }

    if (difference.inHours < 24) {
      return '${difference.inHours}h';
    }

    if (difference.inDays == 1) {
      return 'Yesterday';
    }

    return '${createdAt.month}/${createdAt.day}';
  }

  // ============================================================
  // READ / UNREAD
  // ============================================================

  Future<void> _markAsRead(
    Map<String, dynamic> notification,
  ) async {
    if (notification['isRead'] == true) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/read',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
          'notification_id': notification['id'].toString(),
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 &&
          data['success'] == true) {
        if (!mounted) return;

        setState(() {
          notification['isRead'] = true;
        });

        return;
      }

      debugPrint(
        'MARK NOTIFICATION READ FAILED: '
        '${data['message'] ?? 'Unknown error'}',
      );
    } catch (e) {
      debugPrint(
        'MARK NOTIFICATION READ ERROR: $e',
      );
    }
  }

  Future<void> _markAllAsRead() async {
    if (_unreadCount == 0) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/read-all',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 &&
          data['success'] == true) {
        if (!mounted) return;

        setState(() {
          for (final notification in _notifications) {
            notification['isRead'] = true;
          }
        });

        return;
      }

      debugPrint(
        'MARK ALL NOTIFICATIONS READ FAILED: '
        '${data['message'] ?? 'Unknown error'}',
      );
    } catch (e) {
      debugPrint(
        'MARK ALL NOTIFICATIONS READ ERROR: $e',
      );
    }
  }

  // ============================================================
  // NOTIFICATION TAP
  // ============================================================

  void _openNotification(
    Map<String, dynamic> notification,
  ) {
    // Read notifications are display-only.
    if (notification['isRead'] == true) {
      return;
    }

    final String type =
        notification['type']?.toString().toUpperCase() ?? '';

    // Mark as read in the background.
    _markAsRead(notification);

    // Navigate immediately.
    switch (type) {
      case 'APPOINTMENT_REQUESTED':
        _openRequestedAppointments();
        break;

      case 'APPOINTMENT_ASSESSED':
        _openAssessedAppointments();
        break;

      case 'APPOINTMENT_SCHEDULED':
        _openScheduledAppointments();
        break;

      case 'TECHNICIAN_ASSIGNED':
        _openScheduledAppointments();
        break;

      case 'APPOINTMENT_CANCELLED':
        // No separate cancelled appointments page in the new structure.
        break;

      case 'TECHNICIAN_ON_THE_WAY':
        _openOngoingAppointments();
        break;

      case 'TECHNICIAN_ARRIVED':
        _openOngoingAppointments();
        break;

      case 'SERVICE_COMPLETED':
        _openCompletedAppointments();
        break;

      case 'PAYMENT_SUBMITTED':
        _openCompletedAppointments();
        break;

      case 'PAYMENT_APPROVED':
        _openCompletedAppointments();
        break;

      case 'PAYMENT_REJECTED':
        _openCompletedAppointments();
        break;

      default:
        break;
    }
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refreshNotifications() async {
    _currentPage = 1;
    _hasMore = true;

    await _loadNotifications(
      page: 1,
      append: false,
    );
  }

  Future<void> _loadNotifications({
    int page = 1,
    bool append = false,
  }) async {
    try {
      if (mounted && !append) {
        setState(() {
          _isLoading = true;
          _loadError = null;
        });
      }

      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications?page=$page',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
        },
      );

      final data = jsonDecode(response.body);

      final pagination = data['pagination'] ?? {};

      final bool hasMore =
          pagination['has_more'] == true;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final List<dynamic> rows =
            data['data'] ?? [];

        final notifications = rows.map<Map<String, dynamic>>(
          (item) {
            final String rawMessage =
    item['message']?.toString() ?? '';

        return {
          'id': item['id'],

          'type': _getNotificationType(rawMessage),

          'title': _getNotificationTitle(rawMessage),

          'message': _formatMessage(rawMessage),

          'time': _formatNotificationTime(
            item['created_at']?.toString(),
          ),

          'isRead': item['is_read'] == true,
        };
          },
        ).toList();

        if (!mounted) return;

        setState(() {
          if (append) {
            _notifications.addAll(notifications);
          } else {
            _notifications = notifications;
          }

          _currentPage = page;
          _hasMore = hasMore;
          _isLoading = false;
        });

        return;
      }

    } catch (e) {
      debugPrint(
        'CLIENT NOTIFICATIONS ERROR: $e',
      );

      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _loadError =
            'Unable to load notifications.';
      });
    }
  }

  void _handleScroll() {
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent - 200) {
      _loadMoreNotifications();
    }
  }

  Future<void> _loadMoreNotifications() async {
    if (_isLoadingMore || !_hasMore) {
      return;
    }

    _isLoadingMore = true;

    await _loadNotifications(
      page: _currentPage + 1,
      append: true,
    );

    _isLoadingMore = false;
  }

  // ============================================================
  // APPOINTMENT NAVIGATION
  // ============================================================

  void _openRequestedAppointments() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientRequestedAppointmentsPage(
          email: widget.email,
        ),
      ),
    );
  }

  void _openAssessedAppointments() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientAssessedAppointmentsPage(
          email: widget.email,
        ),
      ),
    );
  }

  void _openScheduledAppointments() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientScheduledAppointmentsPage(
          email: widget.email,
        ),
      ),
    );
  }

  void _openOngoingAppointments() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientOngoingAppointmentsPage(
          email: widget.email,
        ),
      ),
    );
  }

  void _openCompletedAppointments() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientCompletedAppointmentsPage(
          email: widget.email,
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 3,
        email: widget.email,
        currentPage: 'notifications',
      ),

      appBar: const AppBackHeader(
        title: 'Notifications',
      ),

      bottomNavigationBar: ClientBottomNavBar(
        currentIndex: -1,
        email: widget.email,
      ),

      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppTheme.primaryRed,
                ),
              )
            : _loadError != null
                ? _errorState()
                : _notifications.isEmpty
                    ? _emptyState()
                    : RefreshIndicator(
                      color: AppTheme.primaryRed,
                      onRefresh: _refreshNotifications,
                      child: ListView.builder(
                        controller: _scrollController,
                        physics: const AlwaysScrollableScrollPhysics(
                          parent: BouncingScrollPhysics(),
                        ),
                        padding: const EdgeInsets.fromLTRB(
                          16,
                          16,
                          16,
                          30,
                        ),
                        itemCount:
                            _notifications.length + (_isLoadingMore ? 3 : 2),
                        itemBuilder: (context, index) {
                          if (index == 0) {
                            return _notificationSummary();
                          }

                          if (index == 1) {
                            return const SizedBox(height: 12);
                          }

                          final notificationIndex = index - 2;

                          if (notificationIndex >= _notifications.length) {
                            return const Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: Center(
                                child: SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: AppTheme.primaryRed,
                                  ),
                                ),
                              ),
                            );
                          }

                          return _lazyNotificationItem(
                            notificationIndex,
                          );
                        },
                      ),
                    ),
      ),
    );
  }

  // ============================================================
  // SUMMARY
  // ============================================================

  Widget _notificationSummary() {
    final int unreadCount = _unreadCount;

    return Row(
      children: [
        Expanded(
          child: Text(
            unreadCount == 0
                ? 'You\'re all caught up'
                : '$unreadCount unread '
                    '${unreadCount == 1 ? 'notification' : 'notifications'}',
            style: TextStyle(
              color: unreadCount > 0
                  ? AppTheme.black
                  : AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),

        if (unreadCount > 0)
          InkWell(
            onTap: _markAllAsRead,
            borderRadius: BorderRadius.circular(8),
            child: const Padding(
              padding: EdgeInsets.symmetric(
                horizontal: 5,
                vertical: 6,
              ),
              child: Text(
                'Mark all as read',
                style: TextStyle(
                  color: AppTheme.primaryRed,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ============================================================
  // NOTIFICATION LIST
  // ============================================================

  // Widget _notificationList() {
  //   return Container(
  //     width: double.infinity,
  //     decoration: BoxDecoration(
  //       color: AppTheme.white,
  //       borderRadius: BorderRadius.circular(16),
  //       border: Border.all(
  //         color: AppTheme.borderGray.withOpacity(0.65),
  //       ),
  //       boxShadow: [
  //         BoxShadow(
  //           color: Colors.black.withOpacity(0.025),
  //           blurRadius: 12,
  //           offset: const Offset(0, 4),
  //         ),
  //       ],
  //     ),
  //     child: ClipRRect(
  //       borderRadius: BorderRadius.circular(16),
  //       child: Column(
  //         children: List.generate(
  //           _notifications.length,
  //           (index) {
  //             final notification = _notifications[index];

  //             return Column(
  //               children: [
  //                 _notificationItem(notification),

  //                 if (index != _notifications.length - 1)
  //                   Divider(
  //                     height: 1,
  //                     thickness: 1,
  //                     color: AppTheme.borderGray.withOpacity(0.50),
  //                   ),
  //               ],
  //             );
  //           },
  //         ),
  //       ),
  //     ),
  //   );
  // }

  Widget _lazyNotificationItem(int index) {
    final notification = _notifications[index];

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: const Color(0xFFD0D0D0),
            width: 1,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(13),
          child: _notificationItem(notification),
        ),
      ),
    );
  }

  // ============================================================
  // NOTIFICATION ITEM
  // ============================================================

  Widget _notificationItem(
    Map<String, dynamic> notification,
  ) {
    final bool isRead = notification['isRead'] == true;

    final NotificationVisual visual =
        _getNotificationVisual(
      notification['type']?.toString() ?? '',
    );

    return Material(
      color: isRead
          ? const Color(0xFFE8E8E8)
          : AppTheme.white,
      child: InkWell(
        onTap: () => _openNotification(notification),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            12,
            13,
            10,
            13,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ==================================================
              // ICON
              // ==================================================

              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: visual.backgroundColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      visual.icon,
                      color: visual.iconColor,
                      size: 22,
                    ),
                  ),

                  if (!isRead)
                    Positioned(
                      top: -2,
                      right: -2,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: AppTheme.primaryRed,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppTheme.white,
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                ],
              ),

              const SizedBox(width: 11),

              // ==================================================
              // CONTENT
              // ==================================================

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            notification['title']?.toString() ?? '',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppTheme.black,
                              fontSize: 13,
                              fontWeight: isRead
                                  ? FontWeight.w700
                                  : FontWeight.w900,
                              height: 1.2,
                            ),
                          ),
                        ),

                        const SizedBox(width: 8),

                        Text(
                          notification['time']?.toString() ?? '',
                          style: TextStyle(
                            color: isRead
                                ? AppTheme.gray
                                : AppTheme.primaryRed,
                            fontSize: 9.5,
                            fontWeight: isRead
                                ? FontWeight.w600
                                : FontWeight.w800,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 5),

                    Text(
                      notification['message']?.toString() ?? '',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 4),

              const Padding(
                padding: EdgeInsets.only(top: 18),
                child: Icon(
                  Icons.chevron_right_rounded,
                  color: AppTheme.gray,
                  size: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // NOTIFICATION VISUALS
  // ============================================================

  NotificationVisual _getNotificationVisual(String type) {
    switch (type.toUpperCase()) {
      case 'APPOINTMENT_REQUESTED':
        return NotificationVisual(
          icon: Icons.receipt_long_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'APPOINTMENT_ASSESSED':
        return NotificationVisual(
          icon: Icons.fact_check_outlined,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'APPOINTMENT_SCHEDULED':
        return NotificationVisual(
          icon: Icons.calendar_month_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'APPOINTMENT_CANCELLED':
        return NotificationVisual(
          icon: Icons.event_busy_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'TECHNICIAN_ASSIGNED':
        return NotificationVisual(
          icon: Icons.engineering_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'TECHNICIAN_ON_THE_WAY':
        return NotificationVisual(
          icon: Icons.local_shipping_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'TECHNICIAN_ARRIVED':
        return NotificationVisual(
          icon: Icons.location_on_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'SERVICE_COMPLETED':
        return NotificationVisual(
          icon: Icons.check_circle_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'PAYMENT_SUBMITTED':
        return NotificationVisual(
          icon: Icons.payments_outlined,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'PAYMENT_APPROVED':
        return NotificationVisual(
          icon: Icons.verified_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'PAYMENT_REJECTED':
        return NotificationVisual(
          icon: Icons.error_outline_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor: AppTheme.primaryRed.withOpacity(0.08),
        );

      default:
        return NotificationVisual(
          icon: Icons.notifications_rounded,
          iconColor: AppTheme.gray,
          backgroundColor: AppTheme.lightGray,
        );
    }
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================

  Widget _emptyState() {
    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _refreshNotifications,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.58,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 35,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryRed.withOpacity(0.07),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.notifications_none_rounded,
                        color: AppTheme.primaryRed,
                        size: 36,
                      ),
                    ),

                    const SizedBox(height: 17),

                    const Text(
                      'No notifications yet',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),

                    const SizedBox(height: 7),

                    const Text(
                      'Updates about your appointments, technicians, '
                      'services, and payments will appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _errorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 30,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.cloud_off_rounded,
              color: AppTheme.gray,
              size: 42,
            ),

            const SizedBox(height: 12),

            Text(
              _loadError ??
                  'Unable to load notifications.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppTheme.gray,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 14),

            TextButton(
              onPressed: () => _loadNotifications(),
              child: const Text(
                'Try Again',
                style: TextStyle(
                  color: AppTheme.primaryRed,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// NOTIFICATION VISUAL MODEL
// ============================================================

class NotificationVisual {
  final IconData icon;
  final Color iconColor;
  final Color backgroundColor;

  const NotificationVisual({
    required this.icon,
    required this.iconColor,
    required this.backgroundColor,
  });
}