import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_reports_menu_page.dart';

class TechnicianNotificationsPage extends StatefulWidget {
  final String email;

  const TechnicianNotificationsPage({
    super.key,
    required this.email,
  });

  @override
  State<TechnicianNotificationsPage> createState() =>
      _TechnicianNotificationsPageState();
}

class _TechnicianNotificationsPageState
    extends State<TechnicianNotificationsPage> {
  int _currentPage = 1;
  bool _hasMore = true;
  bool _isLoadingMore = false;

  final ScrollController _scrollController = ScrollController();

  // NOTIFICATION DATA

  List<Map<String, dynamic>> _notifications = [];

  bool _isLoading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(_handleScroll);

    _loadNotifications();
  }

  // UNREAD COUNT

  int get _unreadCount {
    return _notifications
        .where(
          (notification) => notification['isRead'] == false,
        )
        .length;
  }

  // MESSAGE FORMAT

  String _formatMessage(String value) {
    final trimmed = value.trim();

    if (trimmed.isEmpty) {
      return '';
    }

    final lower = trimmed.toLowerCase();

    return lower[0].toUpperCase() + lower.substring(1);
  }

  // NOTIFICATION TYPE

  String _getNotificationType(String message) {
    final normalized = message.toUpperCase();

    // Job assignment
    if (normalized.contains('ASSIGNED') &&
        (normalized.contains('JOB') ||
            normalized.contains('SERVICE') ||
            normalized.contains('APPOINTMENT'))) {
      return 'JOB_ASSIGNED';
    }

    // Travel
    if (normalized.contains('TRAVEL') ||
        normalized.contains('ON THE WAY') ||
        normalized.contains('TRAVELING')) {
      return 'TRAVEL_STARTED';
    }

    // Arrival
    if (normalized.contains('ARRIVED')) {
      return 'ARRIVAL_CONFIRMED';
    }

    // Service completion
    if (normalized.contains('SERVICE') &&
        (normalized.contains('COMPLETED') ||
            normalized.contains('DONE'))) {
      return 'SERVICE_COMPLETED';
    }

    // Service report
    if (normalized.contains('REPORT') &&
        normalized.contains('SUBMITTED')) {
      return 'REPORT_SUBMITTED';
    }

    if (normalized.contains('REPORT') &&
        (normalized.contains('REQUIRED') ||
            normalized.contains('NEEDED'))) {
      return 'SERVICE_REPORT_REQUIRED';
    }

    // Schedule
    if (normalized.contains('SCHEDULE') &&
        (normalized.contains('UPDATED') ||
            normalized.contains('CHANGED'))) {
      return 'SCHEDULE_CHANGED';
    }

    // Cancellation
    if (normalized.contains('CANCELLED') ||
        normalized.contains('CANCELED')) {
      return 'APPOINTMENT_CANCELLED';
    }

    // Reassignment
    if (normalized.contains('REASSIGNED')) {
      return 'JOB_REASSIGNED';
    }

    return 'GENERAL';
  }

  // NOTIFICATION TITLE

  String _getNotificationTitle(String message) {
    final String type = _getNotificationType(message);

    switch (type) {
      case 'JOB_ASSIGNED':
        return 'New job assigned';

      case 'TRAVEL_STARTED':
        return 'Travel started';

      case 'ARRIVAL_CONFIRMED':
        return 'Arrival confirmed';

      case 'SERVICE_COMPLETED':
        return 'Service completed';

      case 'REPORT_SUBMITTED':
        return 'Report submitted';

      case 'SERVICE_REPORT_REQUIRED':
        return 'Service report required';

      case 'SCHEDULE_CHANGED':
        return 'Schedule updated';

      case 'APPOINTMENT_CANCELLED':
        return 'Appointment cancelled';

      case 'JOB_REASSIGNED':
        return 'Job reassigned';

      default:
        return 'Service update';
    }
  }

  // NOTIFICATION TIME

  String _formatNotificationTime(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '';
    }

    final createdAt = DateTime.tryParse(value);

    if (createdAt == null) {
      return '';
    }

    final now = DateTime.now();
    final difference = now.difference(createdAt);

    if (difference.inMinutes < 1) {
      return 'Now';
    }

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m';
    }

    if (difference.inHours < 24) {
      return '${difference.inHours}h';
    }

    if (difference.inDays == 1) {
      return 'Yesterday';
    }

    return '${createdAt.month}/${createdAt.day}';
  }

  // READ / UNREAD

  Future<void> _markAsRead(
    Map<String, dynamic> notification,
  ) async {
    if (notification['isRead'] == true) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/read',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
          'notification_id': notification['id'].toString(),
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 &&
          data['success'] == true) {
        if (!mounted) return;

        setState(() {
          notification['isRead'] = true;
        });

        return;
      }

      debugPrint(
        'MARK TECHNICIAN NOTIFICATION READ FAILED: '
        '${data['message'] ?? 'Unknown error'}',
      );
    } catch (e) {
      debugPrint(
        'MARK TECHNICIAN NOTIFICATION READ ERROR: $e',
      );
    }
  }

  Future<void> _markAllAsRead() async {
    if (_unreadCount == 0) {
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications/read-all',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 &&
          data['success'] == true) {
        if (!mounted) return;

        setState(() {
          for (final notification in _notifications) {
            notification['isRead'] = true;
          }
        });

        return;
      }

      debugPrint(
        'MARK ALL TECHNICIAN NOTIFICATIONS READ FAILED: '
        '${data['message'] ?? 'Unknown error'}',
      );
    } catch (e) {
      debugPrint(
        'MARK ALL TECHNICIAN NOTIFICATIONS READ ERROR: $e',
      );
    }
  }

  // NOTIFICATION TAP

  void _openNotification(
    Map<String, dynamic> notification,
  ) {
    // Read notifications are display-only.
    if (notification['isRead'] == true) {
      return;
    }

    final String type =
        notification['type']?.toString().toUpperCase() ?? '';

    // Mark as read in the background.
    _markAsRead(notification);

    switch (type) {
      case 'JOB_ASSIGNED':
        // Open Assigned Jobs later.
        break;

      case 'TRAVEL_STARTED':
        // Open active job / tracking later.
        break;

      case 'ARRIVAL_CONFIRMED':
        // Open active job later.
        break;

      case 'SERVICE_COMPLETED':
      case 'REPORT_SUBMITTED':
        _openServiceReports();
        break;

      case 'SERVICE_REPORT_REQUIRED':
        // Open service report submission later.
        break;

      case 'SCHEDULE_CHANGED':
        // Open Assigned Jobs later.
        break;

      case 'APPOINTMENT_CANCELLED':
        // Open Assigned Jobs later.
        break;

      case 'JOB_REASSIGNED':
        // Open Assigned Jobs later.
        break;

      default:
        break;
    }
  }

  void _openServiceReports() {
    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianServiceReportsMenuPage(
          email: widget.email,
        ),
      ),
    );
  }

  // REFRESH

  Future<void> _refreshNotifications() async {
    _currentPage = 1;
    _hasMore = true;

    await _loadNotifications(
      page: 1,
      append: false,
    );
  }

  // LOAD NOTIFICATIONS

  Future<void> _loadNotifications({
    int page = 1,
    bool append = false,
  }) async {
    try {
      if (mounted && !append) {
        setState(() {
          _isLoading = true;
          _loadError = null;
        });
      }

      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/notifications?page=$page',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
        },
      );

      final data = jsonDecode(response.body);

      final pagination = data['pagination'] ?? {};

      final bool hasMore =
          pagination['has_more'] == true;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final List<dynamic> rows =
            data['data'] ?? [];

        final notifications =
            rows.map<Map<String, dynamic>>(
          (item) {
            final String rawMessage =
                item['message']?.toString() ?? '';

            return {
              'id': item['id'],

              'type': _getNotificationType(
                rawMessage,
              ),

              'title': _getNotificationTitle(
                rawMessage,
              ),

              'message': _formatMessage(
                rawMessage,
              ),

              'time': _formatNotificationTime(
                item['created_at']?.toString(),
              ),

              'isRead': item['is_read'] == true,
            };
          },
        ).toList();

        if (!mounted) return;

        setState(() {
          if (append) {
            _notifications.addAll(notifications);
          } else {
            _notifications = notifications;
          }

          _currentPage = page;
          _hasMore = hasMore;
          _isLoading = false;
        });

        return;
      }

      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _loadError = 'Unable to load notifications.';
      });
    } catch (e) {
      debugPrint(
        'TECHNICIAN NOTIFICATIONS ERROR: $e',
      );

      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _loadError = 'Unable to load notifications.';
      });
    }
  }

  // PAGINATION

  void _handleScroll() {
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent - 200) {
      _loadMoreNotifications();
    }
  }

  Future<void> _loadMoreNotifications() async {
    if (_isLoadingMore || !_hasMore) {
      return;
    }

    _isLoadingMore = true;

    await _loadNotifications(
      page: _currentPage + 1,
      append: true,
    );

    _isLoadingMore = false;
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  // BUILD

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 2,
        email: widget.email,
        currentPage: 'notifications',
      ),

      appBar: const AppBackHeader(
        title: 'Notifications',
      ),

      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppTheme.primaryRed,
                ),
              )
            : _loadError != null
                ? _errorState()
                : _notifications.isEmpty
                    ? _emptyState()
                    : RefreshIndicator(
                        color: AppTheme.primaryRed,
                        onRefresh: _refreshNotifications,
                        child: ListView.builder(
                          controller: _scrollController,
                          physics:
                              const AlwaysScrollableScrollPhysics(
                            parent: BouncingScrollPhysics(),
                          ),
                          padding:
                              const EdgeInsets.fromLTRB(
                            16,
                            16,
                            16,
                            30,
                          ),
                          itemCount:
                              _notifications.length +
                                  (_isLoadingMore ? 3 : 2),
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return _notificationSummary();
                            }

                            if (index == 1) {
                              return const SizedBox(
                                height: 12,
                              );
                            }

                            final notificationIndex =
                                index - 2;

                            if (notificationIndex >=
                                _notifications.length) {
                              return const Padding(
                                padding:
                                    EdgeInsets.only(top: 16),
                                child: Center(
                                  child: SizedBox(
                                    width: 22,
                                    height: 22,
                                    child:
                                        CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color:
                                          AppTheme.primaryRed,
                                    ),
                                  ),
                                ),
                              );
                            }

                            return _lazyNotificationItem(
                              notificationIndex,
                            );
                          },
                        ),
                      ),
      ),
    );
  }

  // SUMMARY

  Widget _notificationSummary() {
    final int unreadCount = _unreadCount;

    return Row(
      children: [
        Expanded(
          child: Text(
            unreadCount == 0
                ? 'You\'re all caught up'
                : '$unreadCount unread '
                    '${unreadCount == 1 ? 'notification' : 'notifications'}',
            style: TextStyle(
              color: unreadCount > 0
                  ? AppTheme.black
                  : AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),

        if (unreadCount > 0)
          InkWell(
            onTap: _markAllAsRead,
            borderRadius: BorderRadius.circular(8),
            child: const Padding(
              padding: EdgeInsets.symmetric(
                horizontal: 5,
                vertical: 6,
              ),
              child: Text(
                'Mark all as read',
                style: TextStyle(
                  color: AppTheme.primaryRed,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
      ],
    );
  }

  // NOTIFICATION LIST

  Widget _lazyNotificationItem(int index) {
    final notification = _notifications[index];

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: const Color(0xFFD0D0D0),
            width: 1,
          )
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(13),
          child: _notificationItem(notification),
        ),
      ),
    );
  }

  // NOTIFICATION ITEM

  Widget _notificationItem(
    Map<String, dynamic> notification,
  ) {
    final bool isRead =
        notification['isRead'] == true;

    final NotificationVisual visual =
        _getNotificationVisual(
      notification['type']?.toString() ?? '',
    );

    return Material(
     color: isRead
          ? const Color(0xFFE8E8E8)
          : AppTheme.white,
      child: InkWell(
        onTap: () =>
            _openNotification(notification),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            12,
            13,
            10,
            13,
          ),
          child: Row(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              // ICON

              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: visual.backgroundColor,
                      borderRadius:
                          BorderRadius.circular(12),
                    ),
                    child: Icon(
                      visual.icon,
                      color: visual.iconColor,
                      size: 22,
                    ),
                  ),

                  if (!isRead)
                    Positioned(
                      top: -2,
                      right: -2,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: AppTheme.primaryRed,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppTheme.white,
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                ],
              ),

              const SizedBox(width: 11),

              // CONTENT

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            notification['title']
                                    ?.toString() ??
                                '',
                            maxLines: 2,
                            overflow:
                                TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppTheme.black,
                              fontSize: 13,
                              fontWeight: isRead
                                  ? FontWeight.w700
                                  : FontWeight.w900,
                              height: 1.2,
                            ),
                          ),
                        ),

                        const SizedBox(width: 8),

                        Text(
                          notification['time']
                                  ?.toString() ??
                              '',
                          style: TextStyle(
                            color: isRead
                                ? AppTheme.gray
                                : AppTheme.primaryRed,
                            fontSize: 9.5,
                            fontWeight: isRead
                                ? FontWeight.w600
                                : FontWeight.w800,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 5),

                    Text(
                      notification['message']
                              ?.toString() ??
                          '',
                      maxLines: 2,
                      overflow:
                          TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 4),

              const Padding(
                padding: EdgeInsets.only(top: 18),
                child: Icon(
                  Icons.chevron_right_rounded,
                  color: AppTheme.gray,
                  size: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // NOTIFICATION VISUALS

  NotificationVisual _getNotificationVisual(
    String type,
  ) {
    switch (type.toUpperCase()) {
      case 'JOB_ASSIGNED':
        return NotificationVisual(
          icon: Icons.assignment_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'TRAVEL_STARTED':
        return NotificationVisual(
          icon: Icons.navigation_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'ARRIVAL_CONFIRMED':
        return NotificationVisual(
          icon: Icons.location_on_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'SERVICE_COMPLETED':
        return NotificationVisual(
          icon: Icons.check_circle_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'REPORT_SUBMITTED':
        return NotificationVisual(
          icon: Icons.description_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'SERVICE_REPORT_REQUIRED':
        return NotificationVisual(
          icon: Icons.assignment_late_outlined,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'SCHEDULE_CHANGED':
        return NotificationVisual(
          icon: Icons.update_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'APPOINTMENT_CANCELLED':
        return NotificationVisual(
          icon: Icons.event_busy_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      case 'JOB_REASSIGNED':
        return NotificationVisual(
          icon: Icons.swap_horiz_rounded,
          iconColor: AppTheme.primaryRed,
          backgroundColor:
              AppTheme.primaryRed.withOpacity(0.08),
        );

      default:
        return NotificationVisual(
          icon: Icons.notifications_rounded,
          iconColor: AppTheme.gray,
          backgroundColor: AppTheme.lightGray,
        );
    }
  }

  // ERROR STATE

  Widget _errorState() {
    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _refreshNotifications,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(
            height:
                MediaQuery.of(context).size.height *
                    0.58,
            child: Center(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 35,
                ),
                child: Column(
                  mainAxisAlignment:
                      MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryRed
                            .withOpacity(0.07),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.wifi_off_rounded,
                        color: AppTheme.primaryRed,
                        size: 34,
                      ),
                    ),

                    const SizedBox(height: 17),

                    const Text(
                      'Unable to load notifications',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),

                    const SizedBox(height: 7),

                    const Text(
                      'Check your connection and pull down to try again.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // EMPTY STATE

  Widget _emptyState() {
    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _refreshNotifications,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(
            height:
                MediaQuery.of(context).size.height *
                    0.58,
            child: Center(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 35,
                ),
                child: Column(
                  mainAxisAlignment:
                      MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryRed
                            .withOpacity(0.07),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.notifications_none_rounded,
                        color: AppTheme.primaryRed,
                        size: 36,
                      ),
                    ),

                    const SizedBox(height: 17),

                    const Text(
                      'No notifications yet',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),

                    const SizedBox(height: 7),

                    const Text(
                      'Updates about your assigned jobs, '
                      'service activities, and reports '
                      'will appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// NOTIFICATION VISUAL MODEL

class NotificationVisual {
  final IconData icon;
  final Color iconColor;
  final Color backgroundColor;

  const NotificationVisual({
    required this.icon,
    required this.iconColor,
    required this.backgroundColor,
  });
}
    