import 'dart:async';
import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/auth/services/current_user_profile.dart';
import 'package:mobile_app/shared/services/notification_service.dart';

class AuthenticatedSession {
  final String token;
  final String email;
  final int userType;

  const AuthenticatedSession({
    required this.token,
    required this.email,
    required this.userType,
  });
}

class AuthSessionService {
  AuthSessionService._();

  static final AuthSessionService instance = AuthSessionService._();

  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'auth_token';
  static const _emailKey = 'auth_email';
  static const _userTypeKey = 'auth_user_type';
  static const _profileKey = 'auth_display_profile_v1';

  late final CurrentUserProfileStore displayProfile = CurrentUserProfileStore(
    readCache: () async {
      final raw = await _storage.read(key: _profileKey);
      if (raw == null) return null;
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    },
    writeCache: (profile) =>
        _storage.write(key: _profileKey, value: jsonEncode(profile)),
    deleteCache: () => _storage.delete(key: _profileKey),
    fetchProfile: (email) async {
      final client = http.Client();
      try {
        final response = await client
            .post(
              Uri.parse('${ApiConfig.baseUrl}/api/mobile/profile'),
              headers: {'Accept': 'application/json'},
              body: {'email': email},
            )
            .timeout(const Duration(seconds: 12));
        final data = jsonDecode(response.body);
        if (response.statusCode != 200 ||
            data['success'] != true ||
            data['data'] is! Map) {
          throw const FormatException('Unable to refresh display profile');
        }
        return Map<String, dynamic>.from(data['data'] as Map);
      } finally {
        // Also close timed-out requests before another refresh can start.
        client.close();
      }
    },
  );

  Future<void> saveSession({
    required String token,
    required String email,
    required int userType,
  }) async {
    displayProfile.deactivate();
    await _storage.write(key: _tokenKey, value: token);
    await _storage.write(key: _emailKey, value: email);
    await _storage.write(key: _userTypeKey, value: userType.toString());
    await displayProfile.activate(email: email, userType: userType);
  }

  Future<String?> readToken() async {
    try {
      return await _storage.read(key: _tokenKey);
    } catch (_) {
      return null;
    }
  }

  Future<void> clearSession() async {
    unawaited(displayProfile.clear());
    for (final key in [_tokenKey, _emailKey, _userTypeKey]) {
      try {
        await _storage.delete(key: key);
      } catch (_) {
        // Logout/startup recovery must keep moving even if storage is unavailable.
      }
    }
  }

  Future<AuthenticatedSession?> restoreSession() async {
    displayProfile.deactivate();
    final storedToken = await readToken();

    if (storedToken == null || storedToken.trim().isEmpty) {
      return null;
    }

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/me'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $storedToken',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 401) {
        await clearSession();
        return null;
      }

      final data = jsonDecode(response.body);

      if (response.statusCode != 200 || data['success'] != true) {
        return null;
      }

      final user = data['user'];

      if (user == null) {
        await clearSession();
        return null;
      }

      final email = user['usr_email']?.toString() ?? '';
      final userType = int.tryParse(user['utyp_id'].toString());

      if (email.isEmpty || userType == null) {
        await clearSession();
        return null;
      }

      await saveSession(
        token: storedToken,
        email: email,
        userType: userType,
      );

      return AuthenticatedSession(
        token: storedToken,
        email: email,
        userType: userType,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> logout() async {
    unawaited(displayProfile.clear());
    final token = await readToken();

    if (token != null && token.trim().isNotEmpty) {
      try {
        await http.post(
          Uri.parse('${ApiConfig.baseUrl}/api/mobile/logout'),
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $token',
          },
        );
      } catch (_) {
        // Local logout must still succeed if the network request fails.
      }
    }

    await clearSession();

    try {
      AppNotificationService.instance.stopClientPolling();
    } catch (_) {
      // Logout navigation should not be blocked by cleanup errors.
    }

    try {
      AppNotificationService.instance.stopTechnicianPolling();
    } catch (_) {
      // Logout navigation should not be blocked by cleanup errors.
    }
  }
}
