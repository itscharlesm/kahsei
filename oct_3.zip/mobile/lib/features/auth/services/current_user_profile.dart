import 'dart:async';

import 'package:flutter/foundation.dart';

/// Display metadata only. This object is never evidence of authentication.
@immutable
class CurrentUserProfile {
  final String email;
  final int userType;
  final String? firstName;
  final String? middleName;
  final String? lastName;
  final String? avatarPath;

  const CurrentUserProfile({
    required this.email,
    required this.userType,
    this.firstName,
    this.middleName,
    this.lastName,
    this.avatarPath,
  });

  Map<String, dynamic> toJson() => {
    'version': 1,
    'email': email,
    'userType': userType,
    'usr_first_name': firstName,
    'usr_middle_name': middleName,
    'usr_last_name': lastName,
    'usr_image_path': avatarPath,
  };

  CurrentUserProfile merge(Map<String, dynamic> fields) {
    String? value(String key, String? previous) {
      if (!fields.containsKey(key)) return previous;
      final next = fields[key];
      if (next != null && next is! String) {
        throw const FormatException('Invalid profile display field');
      }
      return next as String?;
    }

    return CurrentUserProfile(
      email: email,
      userType: userType,
      firstName: value('usr_first_name', firstName),
      middleName: value('usr_middle_name', middleName),
      lastName: value('usr_last_name', lastName),
      avatarPath: value('usr_image_path', avatarPath),
    );
  }
}

/// A capability for one edit in one account generation, not an auth token.
class ProfileEditTicket {
  final CurrentUserProfileStore _owner;
  final int _generation;
  final int _revision;

  ProfileEditTicket._(this._owner, this._generation, this._revision);
}

/// All persistence is serialized, including deletes and account activation reads.
/// Consumers share one initial refresh per activated session.
class CurrentUserProfileStore {
  CurrentUserProfileStore({
    required Future<Map<String, dynamic>?> Function() readCache,
    required Future<void> Function(Map<String, dynamic>) writeCache,
    required Future<void> Function() deleteCache,
    required Future<Map<String, dynamic>> Function(String email) fetchProfile,
  }) : _readCache = readCache,
       _writeCache = writeCache,
       _deleteCache = deleteCache,
       _fetchProfile = fetchProfile;

  final Future<Map<String, dynamic>?> Function() _readCache;
  final Future<void> Function(Map<String, dynamic>) _writeCache;
  final Future<void> Function() _deleteCache;
  final Future<Map<String, dynamic>> Function(String email) _fetchProfile;
  final _state = ValueNotifier<CurrentUserProfile?>(null);

  ValueListenable<CurrentUserProfile?> get listenable => _state;
  CurrentUserProfile? get value => _state.value;

  String? _email;
  int? _userType;
  int _generation = 0;
  int _revision = 0;
  bool _editing = false;
  bool _ignorePersistedCache = false;
  Future<void> _persistence = Future<void>.value();
  Future<CurrentUserProfile?>? _refresh;
  Future<CurrentUserProfile?>? _initialRefresh;
  Map<String, dynamic>? _avatarSetupFields;

  bool isActiveAccount({required String email, required int userType}) =>
      _email == email && _userType == userType;

  /// Only fetched fields needed by the existing avatar-upload payload. These
  /// are never persisted, and cached display metadata cannot stand in for them.
  Map<String, dynamic>? avatarSetupFieldsFor({
    required String email,
    required int userType,
  }) => isActiveAccount(email: email, userType: userType)
      ? _avatarSetupFields
      : null;

  /// Home/Drawer mount and remount share this attempt, even after it finishes.
  /// Failure keeps cached metadata and does not create a drawer-triggered loop.
  Future<CurrentUserProfile?> ensureLoaded({
    required String email,
    required int userType,
  }) {
    if (!isActiveAccount(email: email, userType: userType)) {
      return Future.value(null);
    }
    return _initialRefresh ??= refresh();
  }

  /// Immediately hides old account data and invalidates all old operations.
  void deactivate() {
    _generation++;
    _revision++;
    _email = null;
    _userType = null;
    _editing = false;
    _refresh = null;
    _initialRefresh = null;
    _avatarSetupFields = null;
    _state.value = null;
  }

  /// Called only after the existing login/session validation has succeeded.
  /// Does not initiate a network request.
  Future<void> activate({required String email, required int userType}) async {
    deactivate();
    _email = email;
    _userType = userType;
    final generation = _generation;
    final revision = _revision;

    final hydration = _enqueue(() async {
      if (!_isCurrent(generation, revision) || _ignorePersistedCache) return;
      final cached = await _readCache();
      if (!_isCurrent(generation, revision) || cached == null) return;
      if (cached['version'] != 1 ||
          cached['email'] != email ||
          cached['userType'] != userType) {
        await _deleteCache();
        return;
      }
      _state.value = CurrentUserProfile(
        email: email,
        userType: userType,
      ).merge(cached);
    });
    // Display storage must not hold up authentication indefinitely. A delayed
    // read may still hydrate later, but only for its original generation.
    await hydration.timeout(const Duration(seconds: 1), onTimeout: () {});
  }

  Future<void> _enqueue(Future<void> Function() operation) {
    _persistence = _persistence.then((_) async {
      try {
        await operation();
      } catch (_) {
        // Display cache failures never change authentication or erase memory.
      }
    });
    return _persistence;
  }

  bool _isCurrent(int generation, int revision) =>
      _email != null && generation == _generation && revision == _revision;

  bool _matchesAccount(Map<String, dynamic> fields) =>
      (!fields.containsKey('usr_email') || fields['usr_email'] == _email) &&
      (!fields.containsKey('utyp_id') ||
          fields['utyp_id'].toString() == _userType.toString());

  bool _publish(Map<String, dynamic> fields, {bool fromRefresh = false}) {
    if (_email == null || !_matchesAccount(fields)) return false;
    const keys = [
      'usr_first_name',
      'usr_middle_name',
      'usr_last_name',
      'usr_image_path',
    ];
    if (!keys.any(fields.containsKey)) return false;
    final previous =
        value ?? CurrentUserProfile(email: _email!, userType: _userType!);
    final next = previous.merge(fields);
    final generation = _generation;
    final revision = _revision;
    if (fromRefresh || _avatarSetupFields != null) {
      _avatarSetupFields = Map<String, dynamic>.unmodifiable({
        ...?_avatarSetupFields,
        for (final key in [...keys, 'usr_birth_date'])
          if (fields.containsKey(key)) key: fields[key],
      });
    }
    _state.value = next;
    unawaited(
      _enqueue(() async {
        if (_isCurrent(generation, revision)) await _writeCache(next.toJson());
      }),
    );
    return true;
  }

  /// Shared refresh; mounting consumers use ensureLoaded to avoid repeat calls.
  Future<CurrentUserProfile?> refresh() {
    if (_email == null || _editing) return Future.value(value);
    final pending = _refresh;
    if (pending != null) return pending;
    final generation = _generation;
    final revision = _revision;
    final email = _email!;
    late final Future<CurrentUserProfile?> request;
    request =
        (() async {
          try {
            final fields = await _fetchProfile(email);
            if (_isCurrent(generation, revision) && !_editing) {
              _publish(fields, fromRefresh: true);
            }
          } catch (_) {
            // A failed refresh keeps the last successfully loaded profile.
          }
          return generation == _generation ? value : null;
        })().whenComplete(() {
          if (identical(_refresh, request)) _refresh = null;
        });
    _refresh = request;
    return request;
  }

  /// Invalidates pre-edit reads. New refreshes are suspended until the edit ends.
  ProfileEditTicket? beginEdit() {
    if (_email == null) return null;
    _revision++;
    _editing = true;
    return ProfileEditTicket._(this, _generation, _revision);
  }

  bool _accepts(ProfileEditTicket ticket) =>
      identical(ticket._owner, this) &&
      _editing &&
      _isCurrent(ticket._generation, ticket._revision);

  /// Publish only confirmed saved fields. Missing keys retain previous values;
  /// an explicit usr_image_path: null deletes the avatar everywhere.
  bool completeEdit(
    ProfileEditTicket ticket,
    Map<String, dynamic> savedFields,
  ) {
    if (!_accepts(ticket) || !_matchesAccount(savedFields)) return false;
    try {
      // Validate before advancing the revision or changing state.
      (value ?? CurrentUserProfile(email: _email!, userType: _userType!)).merge(
        savedFields,
      );
      _revision++;
      _editing = false;
      _publish(savedFields);
      return true;
    } on FormatException {
      return false;
    }
  }

  void cancelEdit(ProfileEditTicket ticket) {
    if (!_accepts(ticket)) return;
    _revision++;
    _editing = false;
  }

  /// Prevent old in-flight reads from being reused for post-edit reconciliation.
  /// The old network operation finishes first, preserving single-flight behavior.
  Future<CurrentUserProfile?> refreshAfterEdit() async {
    final generation = _generation;
    final pending = _refresh;
    if (pending != null) await pending;
    if (generation != _generation) return null;
    return refresh();
  }

  /// Memory is cleared synchronously; queued deletion follows any active write.
  Future<void> clear() {
    deactivate();
    // Even if deletion fails, this process must not resurrect the old disk data.
    _ignorePersistedCache = true;
    return _enqueue(_deleteCache);
  }

  @visibleForTesting
  Future<void> get persistenceSettled => _persistence;
}
