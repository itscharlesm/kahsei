import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({
    super.key,
  });

  @override
  State<ForgotPasswordPage> createState() =>
      _ForgotPasswordPageState();
}

class _ForgotPasswordPageState
    extends State<ForgotPasswordPage> {
  final TextEditingController
      _identifierController =
      TextEditingController();

  bool _isLoading = false;
  String? _identifierError;

  @override
  void dispose() {
    _identifierController.dispose();
    super.dispose();
  }

  Future<void> _resetPassword() async {
    final identifier =
        _identifierController.text.trim();

    FocusScope.of(context).unfocus();

    setState(() {
      _identifierError = null;
    });

    if (identifier.isEmpty) {
      setState(() {
        _identifierError =
            'Enter your email address or mobile number.';
      });

      return;
    }

    try {
      setState(() {
        _isLoading = true;
      });

      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}/api/mobile/forgot-password',
            ),
            headers: const {
              'Accept':
                  'application/json',
              'Content-Type':
                  'application/json',
            },
            body: jsonEncode({
              'identifier':
                  identifier,
            }),
          )
          .timeout(
            const Duration(
              seconds: 12,
            ),
          );

      final dynamic data =
          jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data is Map &&
          data['success'] == true) {
        await _showResetSuccessDialog();

        return;
      }

      String message =
          'Unable to reset password.';

      if (data is Map &&
          data['message'] != null) {
        message =
            data['message'].toString();
      }

      setState(() {
        _identifierError =
            message;
      });
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to connect to the server. Please try again.',
          ),
        ),
      );
    } finally {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void>
      _showResetSuccessDialog() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (
        dialogContext,
      ) {
        return AlertDialog(
          backgroundColor:
              AppTheme.white,
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
              18,
            ),
          ),
          contentPadding:
              const EdgeInsets.fromLTRB(
            24,
            24,
            24,
            18,
          ),
          content: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              Container(
                width: 62,
                height: 62,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  shape:
                      BoxShape.circle,
                ),
                child:
                    const Icon(
                  Icons
                      .lock_reset_rounded,
                  color:
                      AppTheme.primaryRed,
                  size: 34,
                ),
              ),

              const SizedBox(
                height: 18,
              ),

              const Text(
                'Password Reset',
                textAlign:
                    TextAlign.center,
                style:
                    TextStyle(
                  fontSize: 18,
                  fontWeight:
                      FontWeight.w800,
                  color:
                      AppTheme.black,
                ),
              ),

              const SizedBox(
                height: 8,
              ),

              const Text(
                'Your password has been reset successfully.',
                textAlign:
                    TextAlign.center,
                style:
                    TextStyle(
                  fontSize: 14,
                  color:
                      AppTheme.gray,
                  height: 1.4,
                  fontWeight:
                      FontWeight.w500,
                ),
              ),

              const SizedBox(
                height: 16,
              ),

              Container(
                width:
                    double.infinity,
                padding:
                    const EdgeInsets
                        .symmetric(
                  horizontal: 14,
                  vertical: 13,
                ),
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.lightGray,
                  borderRadius:
                      BorderRadius.circular(
                    12,
                  ),
                  border:
                      Border.all(
                    color:
                        AppTheme.borderGray,
                  ),
                ),
                child:
                    const Column(
                  children: [
                    Text(
                      'Temporary Password',
                      style:
                          TextStyle(
                        color:
                            AppTheme.gray,
                        fontSize: 10,
                        fontWeight:
                            FontWeight.w700,
                      ),
                    ),

                    SizedBox(
                      height: 5,
                    ),

                    Text(
                      '123456',
                      style:
                          TextStyle(
                        color:
                            AppTheme.primaryRed,
                        fontSize: 22,
                        fontWeight:
                            FontWeight.w900,
                        letterSpacing:
                            2,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                height: 12,
              ),

              const Text(
                'Please log in using this temporary password and change it as soon as possible.',
                textAlign:
                    TextAlign.center,
                style:
                    TextStyle(
                  fontSize: 11.5,
                  color:
                      AppTheme.gray,
                  height: 1.4,
                  fontWeight:
                      FontWeight.w500,
                ),
              ),

              const SizedBox(
                height: 22,
              ),

              SizedBox(
                width:
                    double.infinity,
                child:
                    ElevatedButton(
                  onPressed: () {
                    Navigator.pop(
                      dialogContext,
                    );

                    Navigator.pop(
                      context,
                    );
                  },
                  style:
                      ElevatedButton
                          .styleFrom(
                    backgroundColor:
                        AppTheme
                            .primaryRed,
                    foregroundColor:
                        AppTheme.white,
                    elevation: 0,
                    padding:
                        const EdgeInsets
                            .symmetric(
                      vertical: 14,
                    ),
                    shape:
                        RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius
                              .circular(
                        12,
                      ),
                    ),
                  ),
                  child:
                      const Text(
                    'Back to Login',
                    style:
                        TextStyle(
                      fontWeight:
                          FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: () =>
          FocusScope.of(context)
              .unfocus(),
      child: Scaffold(
        backgroundColor:
            AppTheme.white,
        resizeToAvoidBottomInset:
            true,
        body: SafeArea(
          child:
              SingleChildScrollView(
            padding:
                EdgeInsets.fromLTRB(
              24,
              0,
              24,
              MediaQuery.of(context)
                      .viewInsets
                      .bottom +
                  24,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                const SizedBox(
                  height: 10,
                ),

                IconButton(
                  onPressed: () {
                    Navigator.pop(
                      context,
                    );
                  },
                  icon:
                      const Icon(
                    Icons
                        .arrow_back_ios_new,
                  ),
                ),

                const SizedBox(
                  height: 20,
                ),

                Text(
                  'Forgot Password',
                  style:
                      Theme.of(context)
                          .textTheme
                          .titleLarge,
                ),

                const SizedBox(
                  height: 6,
                ),

                Text(
                  'Enter your registered email address or mobile number. Your password will be reset to a temporary password.',
                  style:
                      Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(
                    color:
                        AppTheme.gray,
                    height: 1.4,
                  ),
                ),

                const SizedBox(
                  height: 30,
                ),

                TextField(
                  controller:
                      _identifierController,
                  keyboardType:
                      TextInputType
                          .emailAddress,
                  textInputAction:
                      TextInputAction
                          .done,
                  onSubmitted: (_) {
                    if (!_isLoading) {
                      _resetPassword();
                    }
                  },
                  decoration:
                      InputDecoration(
                    labelText:
                        'Email or Mobile Number',
                    errorText:
                        _identifierError,
                    errorMaxLines:
                        2,
                    prefixIcon:
                        const Icon(
                      Icons
                          .person_search_outlined,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 24,
                ),

                SizedBox(
                  width:
                      double.infinity,
                  height: 50,
                  child:
                      ElevatedButton(
                    onPressed:
                        _isLoading
                            ? null
                            : _resetPassword,
                    style:
                        ElevatedButton
                            .styleFrom(
                      backgroundColor:
                          AppTheme
                              .primaryRed,
                      foregroundColor:
                          AppTheme.white,
                      disabledBackgroundColor:
                          AppTheme
                              .borderGray,
                      elevation: 0,
                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius
                                .circular(
                          12,
                        ),
                      ),
                    ),
                    child:
                        _isLoading
                            ? const SizedBox(
                                width:
                                    22,
                                height:
                                    22,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth:
                                      2.3,
                                  color:
                                      AppTheme.white,
                                ),
                              )
                            : const Text(
                                'Reset Password',
                                style:
                                    TextStyle(
                                  fontWeight:
                                      FontWeight
                                          .w800,
                                ),
                              ),
                  ),
                ),

                const SizedBox(
                  height: 20,
                ),

                Center(
                  child:
                      TextButton(
                    onPressed:
                        _isLoading
                            ? null
                            : () {
                                Navigator.pop(
                                  context,
                                );
                              },
                    child:
                        const Text(
                      'Back to Login',
                    ),
                  ),
                ),

                const SizedBox(
                  height: 40,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}