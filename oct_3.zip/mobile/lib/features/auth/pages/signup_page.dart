import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_app/config/api_config.dart';
import 'dart:convert';
import 'login_page.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/profiles/widgets/default_avatar_picker.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  bool isLoading = false;
  String? firstNameError;
  String? lastNameError;
  String? passwordError;
  String? confirmPasswordError;
  String? mobileError;
  String? emailError;
  String? selectedAvatarPath;

  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController middleNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    passwordController.addListener(_validatePasswordLength);
  }

  @override
  void dispose() {
    passwordController.dispose();
    confirmPasswordController.dispose();
    firstNameController.dispose();
    middleNameController.dispose();
    lastNameController.dispose();
    mobileController.dispose();
    emailController.dispose();
    super.dispose();
  }

  void _validatePasswordLength() {
    final password = passwordController.text;
    if (password.length > 64) {
      setState(() {
        passwordError = 'Password cannot exceed 64 characters';
      });
    } else if (passwordError == 'Password cannot exceed 64 characters') {
      setState(() {
        passwordError = null;
      });
    }
  }

  String cleanMobileNumber(String value) {
    return value.trim().replaceAll(RegExp(r'[\s-]'), '');
  }

  bool isValidPhMobileNumber(String value) {
    final mobile = cleanMobileNumber(value);

    final bool isLocalFormat = RegExp(r'^09\d{9}$').hasMatch(mobile);
    final bool isInternationalFormat = RegExp(r'^\+639\d{9}$').hasMatch(mobile);

    return isLocalFormat || isInternationalFormat;
  }

  String normalizePhMobileNumber(String value) {
    final mobile = cleanMobileNumber(value);

    if (mobile.startsWith('09')) {
      return mobile.substring(1); // remove 0 → 9XXXXXXXXX
    }

    if (mobile.startsWith('+63')) {
      return mobile.substring(3); // remove +63 → 9XXXXXXXXX
    }

    return mobile;
  }

  Future<void> _register() async {
    final String firstName = firstNameController.text.trim();
    final String middleName = middleNameController.text.trim();
    final String lastName = lastNameController.text.trim();
    final String mobile = cleanMobileNumber(mobileController.text);
    final String email = emailController.text.trim();
    final String password = passwordController.text;
    final String confirmPassword = confirmPasswordController.text;

    final newFirstNameError = firstName.isEmpty ? 'First name is required' : null;
    final newLastNameError = lastName.isEmpty ? 'Last name is required' : null;
    final newMobileError = mobile.isEmpty
        ? 'Mobile number is required'
        : (!isValidPhMobileNumber(mobile)
              ? 'Enter a valid Philippine mobile number'
              : null);
    final newEmailError = email.isEmpty
        ? 'Email address is required'
        : (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)
              ? 'Enter a valid email address'
              : null);
    final newPasswordError = password.isEmpty
        ? 'Password is required'
        : (password.length < 12
              ? 'Password must be at least 12 characters'
              : (password.length > 64
                    ? 'Password cannot exceed 64 characters'
                    : (!RegExp(r'^(?=.*[a-zA-Z])(?=.*\d).+$').hasMatch(password)
                          ? 'Password must include letters and numbers'
                          : null)));
    final newConfirmPasswordError = confirmPassword.isEmpty
        ? 'Please confirm your password'
        : (password != confirmPassword ? 'Passwords do not match' : null);

    setState(() {
      firstNameError = newFirstNameError;
      lastNameError = newLastNameError;
      mobileError = newMobileError;
      emailError = newEmailError;
      passwordError = newPasswordError;
      confirmPasswordError = newConfirmPasswordError;
    });

    final hasValidationErrors =
        newFirstNameError != null ||
        newLastNameError != null ||
        newMobileError != null ||
        newEmailError != null ||
        newPasswordError != null ||
        newConfirmPasswordError != null;

    if (hasValidationErrors) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please correct the highlighted fields')),
      );
      return;
    }

    final String normalizedMobile = normalizePhMobileNumber(mobile);

    final avatarPath = selectedAvatarPath ??
        await DefaultAvatarPicker.show(
          context,
          avatarPaths: const [
            'assets/images/img_client_avatar_01.jpg',
            'assets/images/img_client_avatar_04.jpg',
            'assets/images/img_client_avatar_06.jpg',
            'assets/images/img_client_avatar_02.jpg',
            'assets/images/img_client_avatar_05.jpg',
            'assets/images/img_client_avatar_03.jpg',
          ],
          selectedPath: selectedAvatarPath,
        );

    if (!mounted) return;

    if (avatarPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please choose an avatar to create your account.'),
        ),
      );
      return;
    }

    setState(() {
      selectedAvatarPath = avatarPath;
    });

    try {
      setState(() {
        isLoading = true;
      });

      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'first_name': firstName,
          'middle_name': middleName,
          'last_name': lastName,
          'mobile': normalizedMobile,
          'email': email,
          'password': password,
          'password_confirmation': confirmPassword,
        }),
      );

      if (response.statusCode == 201) {
        final avatarSaved = await _uploadRegistrationAvatar(
          avatarPath: avatarPath,
          email: email,
          firstName: firstName,
          middleName: middleName,
          lastName: lastName,
        );

        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              avatarSaved
                  ? 'Registration successful'
                  : 'Account created. You can set your avatar again from your profile.',
            ),
          ),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginPage()),
        );
      } else {
        final data = jsonDecode(response.body);
        if (data['errors'] != null && data['errors'] is Map) {
          final errors = data['errors'] as Map<String, dynamic>;
          setState(() {
            mobileError = errors['mobile']?.join('\n');
            emailError = errors['email']?.join('\n');
            passwordError = errors['password']?.join('\n');
          });
          // Show general error in SnackBar if no field-specific errors
          if (mobileError == null && emailError == null && passwordError == null) {
            String message = data['message'] ?? 'Registration failed';
            final errorMessages = errors.values.expand((e) => e).toList();
            message += '\n' + errorMessages.join('\n');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(message)),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['message'] ?? 'Registration failed')),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<bool> _uploadRegistrationAvatar({
    required String avatarPath,
    required String email,
    required String firstName,
    required String middleName,
    required String lastName,
  }) async {
    try {
      final avatarData = await rootBundle.load(avatarPath);
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/profile/update'),
      );

      request.fields.addAll({
        'email': email,
        'first_name': firstName,
        'middle_name': middleName,
        'last_name': lastName,
        'birth_date': '',
        'remove_image': '0',
      });

      request.files.add(
        http.MultipartFile.fromBytes(
          'profile_image',
          avatarData.buffer.asUint8List(),
          filename: avatarPath.split('/').last,
        ),
      );

      final streamedResponse = await request.send();
      return streamedResponse.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              24,
              0,
              24,
              MediaQuery.of(context).viewInsets.bottom + 24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),

                IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_ios_new),
                ),

                const SizedBox(height: 20),

                Text(
                  "Create Account",
                  style: Theme.of(context).textTheme.titleLarge,
                ),

                const SizedBox(height: 6),

                Text(
                  "Sign up to get started",
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: const Color(0xFF6B6B6B),
                  ),
                ),

                const SizedBox(height: 30),

                TextField(
                  controller: firstNameController,
                  decoration: InputDecoration(
                    labelText: "First Name",
                    errorText: firstNameError,
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: middleNameController,
                  decoration: const InputDecoration(
                    labelText: "Middle Name (Optional)",
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: lastNameController,
                  decoration: InputDecoration(
                    labelText: "Last Name",
                    errorText: lastNameError,
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: mobileController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: "Mobile Number",
                    errorText: mobileError,
                    errorMaxLines: 2,
                    errorStyle: const TextStyle(fontSize: 12),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: "Email Address",
                    errorText: emailError,
                    errorMaxLines: 2,
                    errorStyle: const TextStyle(fontSize: 12),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: passwordController,
                  obscureText: !isPasswordVisible,
                  decoration: InputDecoration(
                    labelText: "Password",
                    errorText: passwordError,
                    errorMaxLines: 2,
                    errorStyle: const TextStyle(fontSize: 12),
                    suffixIcon: IconButton(
                      icon: Icon(
                        isPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          isPasswordVisible = !isPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: confirmPasswordController,
                  obscureText: !isConfirmPasswordVisible,
                  decoration: InputDecoration(
                    labelText: "Confirm Password",
                    errorText: confirmPasswordError,
                    errorMaxLines: 2,
                    errorStyle: const TextStyle(fontSize: 12),
                    suffixIcon: IconButton(
                      icon: Icon(
                        isConfirmPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          isConfirmPasswordVisible =
                              !isConfirmPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                LoadingButton(
                  isLoading: isLoading,
                  onPressed: _register,
                  child: const Text("Sign up"),
                ),

                const SizedBox(height: 20),

                Center(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const LoginPage(),
                        ),
                      );
                    },
                    child: RichText(
                      text: TextSpan(
                        text: "Already have an account? ",
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.black54,
                          fontSize: 14,
                        ),
                        children: [
                          TextSpan(
                            text: "Log in",
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  color: Theme.of(context).colorScheme.primary,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
