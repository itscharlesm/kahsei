import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:mobile_app/app/theme.dart';

import 'login_page.dart';
import 'signup_page.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  final PageController _pageController = PageController();

  Timer? _carouselTimer;

  int _virtualPage = 0;
  int _currentPage = 0;

  final List<_OnboardingItem> _pages = const [
    _OnboardingItem(
      image: 'assets/images/img_welcomepage_graphics1.png',
      title: 'Pest Control Made Easy',
      description:
          'Book and manage your pest control services anytime.',
    ),
    _OnboardingItem(
      image: 'assets/images/img_welcomepage_graphics2.png',
      title: 'Book a Service Easily',
      description:
          'Schedule your pest control service in just a few simple steps.',
    ),
    _OnboardingItem(
      image: 'assets/images/img_welcomepage_graphics3.png',
      title: 'Track Your Technician',
      description:
          'Stay updated while your technician travels to your location.',
    ),
  ];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _hideKeyboard();
      _startCarousel();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _hideKeyboard();
    });
  }

  void _hideKeyboard() {
    FocusManager.instance.primaryFocus?.unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  // =====================================================
  // CAROUSEL
  // 1 -> 2 -> 3 -> 1 -> 2 -> 3
  // Always moves forward
  // =====================================================

  void _startCarousel() {
    _carouselTimer?.cancel();

    _carouselTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) {
        if (!mounted || !_pageController.hasClients) return;

        _virtualPage++;

        _pageController.animateToPage(
          _virtualPage,
          duration: const Duration(milliseconds: 450),
          curve: Curves.easeInOutCubic,
        );
      },
    );
  }

  void _restartCarousel() {
    _carouselTimer?.cancel();

    _carouselTimer = Timer(
      const Duration(seconds: 4),
      () {
        if (!mounted) return;
        _startCarousel();
      },
    );
  }

  // =====================================================
  // LOCATION ACCESS
  // =====================================================

  Future<bool> _checkLocationAccess() async {
    final serviceEnabled =
        await geo.Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      _showLocationServiceDialog();
      return false;
    }

    var permission = await geo.Geolocator.checkPermission();

    if (permission == geo.LocationPermission.denied) {
      permission = await geo.Geolocator.requestPermission();
    }

    if (permission == geo.LocationPermission.denied ||
        permission == geo.LocationPermission.deniedForever) {
      _showLocationPermissionDialog();
      return false;
    }

    return true;
  }

  void _showLocationServiceDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text(
          'Turn On Location',
        ),
        content: const Text(
          'Please turn on your phone location to continue using the app.',
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await geo.Geolocator.openLocationSettings();
            },
            child: const Text(
              'Open Settings',
            ),
          ),
        ],
      ),
    );
  }

  void _showLocationPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text(
          'Location Permission Required',
        ),
        content: const Text(
          'This app needs location access to detect your address and assign the nearest branch.',
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await geo.Geolocator.openAppSettings();
            },
            child: const Text(
              'Open App Settings',
            ),
          ),
        ],
      ),
    );
  }

  // =====================================================
  // NAVIGATION
  // =====================================================

  Future<void> _goToLogin() async {
    _hideKeyboard();

    final hasAccess = await _checkLocationAccess();

    if (!hasAccess || !mounted) return;

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginPage(),
      ),
    );

    if (mounted) {
      _hideKeyboard();
    }
  }

  Future<void> _goToSignUp() async {
    _hideKeyboard();

    final hasAccess = await _checkLocationAccess();

    if (!hasAccess || !mounted) return;

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const SignUpPage(),
      ),
    );

    if (mounted) {
      _hideKeyboard();
    }
  }

  @override
  void dispose() {
    _carouselTimer?.cancel();
    _pageController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,

      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final bool isCompact =
                constraints.maxHeight < 700;

            // Bigger logo than before
            final double logoWidth =
                isCompact ? 165 : 195;

            final double buttonHeight =
                isCompact ? 50 : 54;

            return Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 28,
              ),
              child: Column(
                children: [
                  // =================================================
                  // TOP SPACE
                  // =================================================

                  SizedBox(
                    height: isCompact ? 8 : 12,
                  ),

                  // =================================================
                  // LOGO
                  // =================================================

                  Image.asset(
                    'assets/images/img_drawer_gfpc_logo_clean.png',
                    width: logoWidth,
                    fit: BoxFit.contain,
                  ),

                  // Slightly larger gap to push carousel downward
                  SizedBox(
                    height: isCompact ? 12 : 18,
                  ),

                  // =================================================
                  // CAROUSEL
                  // =================================================

                  Expanded(
                    child: Stack(
                      children: [
                        PageView.builder(
                          controller: _pageController,

                          onPageChanged: (index) {
                            _virtualPage = index;

                            setState(() {
                              _currentPage =
                                  index % _pages.length;
                            });

                            _restartCarousel();
                          },

                          itemBuilder: (context, index) {
                            final realIndex =
                                index % _pages.length;

                            return _OnboardingPage(
                              item: _pages[realIndex],
                              compact: isCompact,
                            );
                          },
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Transform.translate(
                            offset: Offset(
                              0,
                              isCompact ? -60 : -72,
                            ),
                            child: _PageIndicator(
                              currentPage: _currentPage,
                              pageCount: _pages.length,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(
                    height: isCompact ? 16 : 22,
                  ),

                  // =================================================
                  // LOGIN
                  // =================================================

                  Transform.translate(
                    offset: Offset(0, isCompact ? -32 : -36),
                    child: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          height: buttonHeight,
                          child: ElevatedButton(
                            onPressed: _goToLogin,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryRed,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(14),
                              ),
                            ),
                            child: const Text(
                              'Log in',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight:
                                    FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          height: buttonHeight,
                          child: OutlinedButton(
                            onPressed: _goToSignUp,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.black,
                              side: const BorderSide(
                                color: AppTheme.primaryRed,
                                width: 1.5,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(14),
                              ),
                            ),
                            child: const Text(
                              'Sign up',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight:
                                    FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Preserves the carousel's original layout height.
                  SizedBox(
                    height: isCompact ? 30 : 44,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

// =====================================================
// INDIVIDUAL ONBOARDING PAGE
// =====================================================

class _OnboardingPage extends StatelessWidget {
  final _OnboardingItem item;
  final bool compact;

  const _OnboardingPage({
    required this.item,
    required this.compact,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // =================================================
        // GRAPHIC
        // Slightly lower than previous version
        // =================================================

        Expanded(
          child: Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: EdgeInsets.only(
                top: compact ? 20 : 28,
                left: compact ? 20 : 12,
                right: compact ? 20 : 12,
              ),
              child: Image.asset(
                item.image,
                width: double.infinity,
                fit: BoxFit.contain,
                alignment: Alignment.topCenter,
              ),
            ),
          ),
        ),

        // =================================================
        // TITLE + DESCRIPTION
        // Keep text close to graphic
        // =================================================

        Transform.translate(
          offset: Offset(
            0,
            compact ? -60 : -72,
          ),
          child: Column(
            children: [
              Text(
                item.title,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: TextStyle(
                  fontSize: compact ? 23 : 26,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                  height: 1.2,
                ),
              ),

              SizedBox(
                height: compact ? 6 : 9,
              ),

              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                ),
                child: Text(
                  item.description,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize:
                        compact ? 14 : 15.5,
                    fontWeight:
                        FontWeight.w400,
                    color:
                        const Color(0xFF777777),
                    height: 1.4,
                  ),
                ),
              ),

              SizedBox(
                height: compact ? 18 : 22,
              ),

              const SizedBox(height: 9),
            ],
          ),
        ),

        const SizedBox(
          height: 0,
        ),
      ],
    );
  }
}

class _PageIndicator extends StatelessWidget {
  final int currentPage;
  final int pageCount;

  const _PageIndicator({
    required this.currentPage,
    required this.pageCount,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        pageCount,
        (index) {
          final active = currentPage == index;

          return AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: active ? 9 : 8,
            height: active ? 9 : 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active
                  ? AppTheme.primaryRed
                  : const Color(0xFFD9D9D9),
            ),
          );
        },
      ),
    );
  }
}

// =====================================================
// ONBOARDING DATA
// =====================================================

class _OnboardingItem {
  final String image;
  final String title;
  final String description;

  const _OnboardingItem({
    required this.image,
    required this.title,
    required this.description,
  });
}
