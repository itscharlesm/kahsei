import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';

import 'package:mobile_app/features/technician_reports/widgets/technician_service_report_card.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_report_details_page.dart';

class TechnicianCompletedServiceReportsPage extends StatefulWidget {
  final String email;

  const TechnicianCompletedServiceReportsPage({
    super.key,
    required this.email,
  });

  @override
  State<TechnicianCompletedServiceReportsPage> createState() =>
      _TechnicianCompletedServiceReportsPageState();
}

class _TechnicianCompletedServiceReportsPageState
    extends State<TechnicianCompletedServiceReportsPage> {
  // ============================================================
  // SCROLL
  // ============================================================

  final ScrollController _scrollController = ScrollController();

  // ============================================================
  // DATA
  // ============================================================

  List<Map<String, dynamic>> completedReports = [];

  // ============================================================
  // PAGINATION
  // ============================================================

  int currentPage = 1;
  bool hasMore = true;

  // ============================================================
  // LOADING
  // ============================================================

  bool isLoading = false;
  bool isLoadingMore = false;

  // ============================================================
  // ERROR
  // ============================================================

  String? errorMessage;

  // ============================================================
  // INIT / DISPOSE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(
      _handleScroll,
    );

    _loadCompletedReports(
      forceRefresh: true,
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(
      _handleScroll,
    );

    _scrollController.dispose();

    super.dispose();
  }

  // ============================================================
  // LOAD COMPLETED REPORTS
  // ============================================================

  Future<void> _loadCompletedReports({
    bool forceRefresh = false,
  }) async {
    if (isLoading || isLoadingMore) {
      return;
    }

    if (!forceRefresh && !hasMore) {
      return;
    }

    final page = forceRefresh ? 1 : currentPage;

    try {
      if (!mounted) return;

      setState(() {
        if (forceRefresh || completedReports.isEmpty) {
          isLoading = true;
        } else {
          isLoadingMore = true;
        }

        errorMessage = null;
      });

      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}/api/mobile/technician/service-reports',
            ),
            headers: const {
              'Accept': 'application/json',
            },
            body: {
              'email': widget.email,

              // Completed service report.
              'status': 'DONE REPORT',

              'page': page.toString(),
            },
          )
          .timeout(
            const Duration(seconds: 12),
          );

      final data = jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final List list = data['data'] ?? [];

        final mappedReports = list
            .map(
              (item) => Map<String, dynamic>.from(
                item,
              ),
            )
            .toList();

        final pagination =
            data['pagination'] is Map
                ? Map<String, dynamic>.from(
                    data['pagination'],
                  )
                : <String, dynamic>{};

        final hasMoreData =
            pagination['has_more'] == true;

        final nextPage =
            pagination['next_page'];

        setState(() {
          if (forceRefresh) {
            completedReports = mappedReports;
          } else {
            completedReports.addAll(
              mappedReports,
            );
          }

          hasMore = hasMoreData;

          currentPage =
              hasMoreData && nextPage != null
                  ? int.tryParse(
                        nextPage.toString(),
                      ) ??
                      (page + 1)
                  : page + 1;

          isLoading = false;
          isLoadingMore = false;
          errorMessage = null;
        });
      } else {
        setState(() {
          isLoading = false;
          isLoadingMore = false;

          errorMessage =
              data['message']
                      ?.toString() ??
                  'Unable to load completed service reports.';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        isLoadingMore = false;

        errorMessage =
            'Unable to connect to the server.';
      });

      debugPrint(
        'COMPLETED SERVICE REPORTS ERROR [PAGE $page]: $e',
      );
    }
  }

  // ============================================================
  // SCROLL / LOAD MORE
  // ============================================================

  void _handleScroll() {
    if (!_scrollController.hasClients) {
      return;
    }

    final position =
        _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent - 180) {
      _loadMore();
    }
  }

  Future<void> _loadMore() async {
    if (!hasMore ||
        isLoading ||
        isLoadingMore) {
      return;
    }

    await _loadCompletedReports();
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refreshReports() async {
    currentPage = 1;
    hasMore = true;

    await _loadCompletedReports(
      forceRefresh: true,
    );
  }

  // ============================================================
  // OPEN COMPLETED REPORT
  // ============================================================

  Future<void> _openReport(
    Map<String, dynamic> report,
  ) async {
    final scheduleId =
        report['id'];

    if (scheduleId == null) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to open report details.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );

      return;
    }

    final parsedScheduleId =
        int.tryParse(
      scheduleId.toString(),
    );

    if (parsedScheduleId == null) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to open report details.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );

      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TechnicianServiceReportDetailsPage(
          scheduleId: parsedScheduleId,
          email: widget.email,
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 2,
        email: widget.email,
        currentPage: 'service_reports',
      ),

      appBar: const AppBackHeader(
        title: 'Completed Reports',
      ),

      bottomNavigationBar: TechnicianBottomNavBar(
        currentIndex: 3,
        email: widget.email,
      ),

      body: Padding(
        padding: const EdgeInsets.fromLTRB(
          20,
          16,
          20,
          0,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _pageHeader(),

            const SizedBox(height: 16),

            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // PAGE HEADER
  // ============================================================

  Widget _pageHeader() {
    return const Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Completed Reports',
          style: TextStyle(
            color: AppTheme.black,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),

        SizedBox(height: 5),

        Text(
          'Review completed service reports and service records.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.35,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget _buildContent() {
    if (isLoading &&
        completedReports.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(
          color: AppTheme.primaryRed,
        ),
      );
    }

    if (errorMessage != null &&
        completedReports.isEmpty) {
      return RefreshIndicator(
        color: AppTheme.primaryRed,
        onRefresh: _refreshReports,
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: [
            const SizedBox(height: 100),

            _ErrorCompletedReportsContent(
              message: errorMessage!,
              onRetry: _refreshReports,
            ),
          ],
        ),
      );
    }

    if (completedReports.isEmpty) {
      return RefreshIndicator(
        color: AppTheme.primaryRed,
        onRefresh: _refreshReports,
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 90),

            _EmptyCompletedReportsContent(),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _refreshReports,
      child: ListView.separated(
        controller: _scrollController,

        physics:
            const AlwaysScrollableScrollPhysics(),

        padding: const EdgeInsets.only(
          bottom: 24,
        ),

        itemCount:
            completedReports.length +
            (isLoadingMore ? 1 : 0),

        separatorBuilder: (_, __) =>
            const SizedBox(
          height: 12,
        ),

        itemBuilder: (
          context,
          index,
        ) {
          // ====================================================
          // PAGINATION LOADER
          // ====================================================

          if (index >=
              completedReports.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(
                vertical: 14,
              ),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child:
                      CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            );
          }

          final report =
              completedReports[index];

          final submittedDate =
              report['submittedDate']
                      ?.toString() ??
                  '-';

          return TechnicianServiceReportCard(
            saNumber:
                report['svc_sa_number']?.toString() ??
                '-',

            clientName:
                report['clientName']
                        ?.toString() ??
                    'Client',

            service:
                report['service']
                        ?.toString() ??
                    'Pest Control Service',

            pestType:
                report['pestType']
                        ?.toString() ??
                    'General Pest',

            address:
                report['address']
                        ?.toString() ??
                    'No address',

            schedule:
                report['schedule']
                        ?.toString() ??
                    '-',

            submittedDate:
                submittedDate,

            status:
                'DONE REPORT',

            onViewReport: () {
              _openReport(
                report,
              );
            },
          );
        },
      ),
    );
  }
}

// ============================================================
// EMPTY STATE
// ============================================================

class _EmptyCompletedReportsContent
    extends StatelessWidget {
  const _EmptyCompletedReportsContent();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      mainAxisSize:
          MainAxisSize.min,
      children: [
        Container(
          width: 68,
          height: 68,
          decoration: BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            shape:
                BoxShape.circle,
          ),
          child: const Icon(
            Icons.description_outlined,
            color:
                AppTheme.primaryRed,
            size: 34,
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        const Text(
          'No completed reports',
          style: TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        const Padding(
          padding:
              EdgeInsets.symmetric(
            horizontal: 28,
          ),
          child: Text(
            'Completed service reports will appear here.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}

// ============================================================
// ERROR STATE
// ============================================================

class _ErrorCompletedReportsContent
    extends StatelessWidget {
  final String message;

  final Future<void> Function()
      onRetry;

  const _ErrorCompletedReportsContent({
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      mainAxisSize:
          MainAxisSize.min,
      children: [
        Container(
          width: 68,
          height: 68,
          decoration: BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            shape:
                BoxShape.circle,
          ),
          child: const Icon(
            Icons.wifi_off_rounded,
            color:
                AppTheme.primaryRed,
            size: 32,
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        const Text(
          'Unable to load reports',
          style: TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        Padding(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 28,
          ),
          child: Text(
            message,
            textAlign:
                TextAlign.center,
            style:
                const TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        OutlinedButton.icon(
          onPressed: () {
            onRetry();
          },
          icon: const Icon(
            Icons.refresh_rounded,
            size: 18,
          ),
          label: const Text(
            'Retry',
          ),
          style:
              OutlinedButton.styleFrom(
            foregroundColor:
                AppTheme.primaryRed,
            side:
                const BorderSide(
              color:
                  AppTheme.primaryRed,
            ),
          ),
        ),
      ],
    );
  }
}