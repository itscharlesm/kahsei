import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_pending_service_reports_page.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_completed_service_reports_page.dart';

class TechnicianServiceReportsMenuPage extends StatelessWidget {
  final String email;

  const TechnicianServiceReportsMenuPage({
    super.key,
    required this.email,
  });

  void _openPendingReports(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianPendingServiceReportsPage(
          email: email,
        ),
      ),
    );
  }

  void _openCompletedReports(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianCompletedServiceReportsPage(
          email: email,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 2,
        email: email,
        currentPage: 'service_reports',
      ),

      appBar: const AppTitleHeader(
        title: 'Service Reports',
      ),

      bottomNavigationBar: TechnicianBottomNavBar(
        currentIndex: 3,
        email: email,
      ),

      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            18,
            20,
            28,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Service Reports',
                style: TextStyle(
                  color: AppTheme.black,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  height: 1.2,
                ),
              ),

              const SizedBox(height: 6),

              const Text(
                'View pending and completed service reports.',
                style: TextStyle(
                  color: AppTheme.gray,
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 24),

              _ReportMenuCard(
                icon: Icons.assignment_outlined,
                title: 'Pending Reports',
                description:
                    'Service reports that still need to be completed and submitted.',
                onTap: () => _openPendingReports(
                  context,
                ),
              ),

              const SizedBox(height: 14),

              _ReportMenuCard(
                icon: Icons.description_outlined,
                title: 'Completed Reports',
                description:
                    'Completed service reports and service records.',
                onTap: () => _openCompletedReports(
                  context,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReportMenuCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;

  const _ReportMenuCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          width: double.infinity,
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppTheme.borderGray,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.primaryRed.withOpacity(
                    0.08,
                  ),
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primaryRed,
                  size: 24,
                ),
              ),

              const SizedBox(width: 14),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w900,
                        height: 1.2,
                      ),
                    ),

                    const SizedBox(height: 5),

                    Text(
                      description,
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11.5,
                        height: 1.35,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 8),

              const Icon(
                Icons.chevron_right_rounded,
                color: AppTheme.gray,
                size: 24,
              ),
            ],
          ),
        ),
      ),
    );
  }
}