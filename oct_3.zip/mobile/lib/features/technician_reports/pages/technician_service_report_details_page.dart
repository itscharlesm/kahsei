import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';

class TechnicianServiceReportDetailsPage extends StatefulWidget {
  final int scheduleId;
  final String email;

  const TechnicianServiceReportDetailsPage({
    super.key,
    required this.scheduleId,
    required this.email,
  });

  @override
  State<TechnicianServiceReportDetailsPage> createState() =>
      _TechnicianServiceReportDetailsPageState();
}

class _TechnicianServiceReportDetailsPageState
    extends State<TechnicianServiceReportDetailsPage> {
  bool isLoading = true;
  String? loadError;

  Map<String, dynamic>? report;

  @override
  void initState() {
    super.initState();
    _loadReportDetails();
  }

  // ============================================================
  // LOAD REPORT DETAILS
  // ============================================================

  Future<void> _loadReportDetails() async {
    try {
      setState(() {
        isLoading = true;
        loadError = null;
      });

      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}/api/mobile/technician/service-report-details',
            ),
            headers: {
              'Accept': 'application/json',
            },
            body: {
              'email': widget.email,
              'schedule_id': widget.scheduleId.toString(),
            },
          )
          .timeout(
            const Duration(seconds: 10),
          );

      final data = jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        setState(() {
          report = Map<String, dynamic>.from(
            data['data'] ?? {},
          );

          isLoading = false;
        });
      } else {
        setState(() {
          loadError =
              data['message']?.toString() ??
              'Unable to load report details.';

          isLoading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        loadError = 'Unable to connect to the server.';
        isLoading = false;
      });

      debugPrint(
        'SERVICE REPORT DETAILS ERROR: $e',
      );
    }
  }

  // ============================================================
  // HELPERS
  // ============================================================

  // ============================================================
  // HELPERS
  // ============================================================

  String _text(
    dynamic value, [
    String fallback = '-',
  ]) {
    if (value == null) return fallback;

    final text = value.toString().trim();

    return text.isEmpty ? fallback : text;
  }

  String _formatSaNumber(
    dynamic value,
  ) {
    if (value == null) {
      return 'SA #-';
    }

    final String raw =
        value.toString().trim();

    if (raw.isEmpty || raw == '-') {
      return 'SA #-';
    }

    final String cleaned = raw
        .toUpperCase()
        .replaceAll('SA-', '')
        .replaceAll('SA #', '')
        .trim();

    final int? number =
        int.tryParse(cleaned);

    if (number == null) {
      return 'SA-$cleaned';
    }

    return 'SA-${number.toString().padLeft(6, '0')}';
  }

  int _number(dynamic value) {
    if (value == null) return 0;

    return int.tryParse(
          value.toString(),
        ) ??
        0;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      appBar: const AppBackHeader(
        title: 'Report Details',
      ),

      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          color: AppTheme.primaryRed,
        ),
      );
    }

    if (loadError != null) {
      return _errorState();
    }

    if (report == null) {
      return const Center(
        child: Text(
          'Report details are unavailable.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
          ),
        ),
      );
    }

    final data = report!;

    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _loadReportDetails,
      child: SingleChildScrollView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            // ============================================================
            // REPORT HEADER
            // ============================================================

            _topHeader(data),

            const SizedBox(height: 24),

            // ============================================================
            // SERVICE SUMMARY
            // ============================================================

            _serviceSummarySection(data),

            const SizedBox(height: 20),

            // ============================================================
            // CHEMICALS
            // ============================================================

            _chemicalsSection(data),

            const SizedBox(height: 20),

            // ============================================================
            // CAPTURED PESTS
            // ============================================================

            _capturedPestsSection(data),

            const SizedBox(height: 20),

            // ============================================================
            // SERVICE EVIDENCE
            // ============================================================

            _evidenceSection(data),

            const SizedBox(height: 20),

            // ============================================================
            // RECOMMENDATION
            // ============================================================

            _recommendationSection(data),

            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // REPORT HEADER
  // ============================================================

  Widget _topHeader(
    Map<String, dynamic> data,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppTheme.white.withOpacity(
                0.18,
              ),
              borderRadius:
                  BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.assignment_turned_in_outlined,
              color: AppTheme.white,
              size: 25,
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'COMPLETED REPORT',
                  style: TextStyle(
                    color: AppTheme.white,
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w800,
                    letterSpacing: 0.4,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  _text(
                    data['clientName'],
                    'Client',
                  ),
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.white,
                    fontSize: 18,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  'Submitted ${_text(data['submittedDate'])}',
                  style: TextStyle(
                    color:
                        AppTheme.white.withOpacity(
                      0.85,
                    ),
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SERVICE SUMMARY SECTION
  // ============================================================

  Widget _serviceSummarySection(
    Map<String, dynamic> data,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title: 'Service Summary',
          description:
              'Review the completed service and client information.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
          ),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius:
                BorderRadius.circular(14),
            border: Border.all(
              color: AppTheme.borderGray,
            ),
          ),
          child: Column(
            children: [

                 _detailRow(
                Icons.numbers_rounded,
                'SA Number',
                _formatSaNumber(
                  data['svc_sa_number'],
                ),
              ),

              _divider(),

              _detailRow(
                Icons.person_outline_rounded,
                'Client',
                _text(data['clientName']),
              ),

              _divider(),

              _detailRow(
                Icons.assignment_outlined,
                'Service Type',
                _text(data['service']),
              ),

              _divider(),

              _detailRow(
                Icons.bug_report_outlined,
                'Pest Type',
                _text(data['pestType']),
              ),

              _divider(),

              _detailRow(
                Icons.location_on_outlined,
                'Address',
                _text(data['address']),
                maxLines: 3,
              ),

              _divider(),

              _detailRow(
                Icons.calendar_month_outlined,
                'Schedule',
                _text(data['schedule']),
                maxLines: 2,
              ),

              _divider(),

              _detailRow(
                Icons.route_outlined,
                'Travel Time',
                _text(data['travelTime']),
              ),

              _divider(),

              _detailRow(
                Icons.home_repair_service_outlined,
                'Service Time',
                _text(data['serviceTime']),
              ),

              _divider(),

              _detailRow(
                Icons.timer_outlined,
                'Total Duration',
                _text(data['totalDuration']),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CHEMICALS SECTION
  // ============================================================

  Widget _chemicalsSection(
    Map<String, dynamic> data,
  ) {
    final List chemicals =
        data['chemicals'] ?? [];

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title: 'Chemicals Used',
          description:
              'View the chemicals and actual quantities recorded during the service.',
        ),

        const SizedBox(height: 12),

        if (chemicals.isEmpty)
          _emptySectionCard(
            icon: Icons.science_outlined,
            message:
                'No chemicals were recorded for this service.',
          )
        else
          Column(
            children: chemicals
                .asMap()
                .entries
                .map(
                  (entry) {
                    final index = entry.key;

                    final chemical =
                        Map<String, dynamic>.from(
                      entry.value,
                    );

                    return Column(
                      children: [
                        _chemicalCard(
                          chemical,
                        ),

                        if (index <
                            chemicals.length - 1)
                          const SizedBox(
                            height: 10,
                          ),
                      ],
                    );
                  },
                )
                .toList(),
          ),
      ],
    );
  }

  Widget _chemicalCard(
    Map<String, dynamic> chemical,
  ) {
    final quantity = _text(
      chemical['actualQuantity'],
      '0',
    );

    final unit = _text(
      chemical['unit'],
      '',
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed
                  .withOpacity(0.08),
              borderRadius:
                  BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.science_outlined,
              color: AppTheme.primaryRed,
              size: 20,
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  _text(
                    chemical['name'],
                    'Chemical',
                  ),
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  'Quantity used: $quantity${unit.isEmpty ? '' : ' $unit'}',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 12,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CAPTURED PESTS SECTION
  // ============================================================

  Widget _capturedPestsSection(
    Map<String, dynamic> data,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title: 'Captured Pests',
          description:
              'Review the number of pests captured during the service.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius:
                BorderRadius.circular(14),
            border: Border.all(
              color: AppTheme.borderGray,
            ),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _pestResult(
                      'Rats',
                      _number(
                        data['ratCaptured'],
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: _pestResult(
                      'Snakes',
                      _number(
                        data['snakeCaptured'],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: _pestResult(
                      'Lizards',
                      _number(
                        data['lizardCaptured'],
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: _pestResult(
                      'Kittens',
                      _number(
                        data['kittenCaptured'],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: _pestResult(
                      'Others',
                      _number(
                        data['otherCaptured'],
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  const Expanded(
                    child: SizedBox.shrink(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _pestResult(
    String label,
    int value,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 13,
      ),
      decoration: BoxDecoration(
        color:
            AppTheme.lightGray.withOpacity(
          0.55,
        ),
        borderRadius:
            BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: AppTheme.black,
                fontSize: 11.5,
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),

          Text(
            value.toString(),
            style: const TextStyle(
              color: AppTheme.primaryRed,
              fontSize: 17,
              fontWeight:
                  FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SERVICE EVIDENCE SECTION
  // ============================================================

  Widget _evidenceSection(
    Map<String, dynamic> data,
  ) {
    final List images =
        data['images'] ?? [];

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title: 'Service Evidence',
          description:
              'View the documentation photos submitted for this completed service.',
        ),

        const SizedBox(height: 12),

        if (images.isEmpty)
          _emptySectionCard(
            icon: Icons.photo_outlined,
            message:
                'No service evidence photos were submitted.',
          )
        else
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.white,
              borderRadius:
                  BorderRadius.circular(14),
              border: Border.all(
                color: AppTheme.borderGray,
              ),
            ),
            child: GridView.builder(
              shrinkWrap: true,
              physics:
                  const NeverScrollableScrollPhysics(),
              itemCount: images.length,
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemBuilder:
                  (context, index) {
                final image =
                    images[index].toString();

                return ClipRRect(
                  borderRadius:
                      BorderRadius.circular(
                    10,
                  ),
                  child: Image.network(
                    image,
                    fit: BoxFit.cover,
                    loadingBuilder:
                        (
                          context,
                          child,
                          progress,
                        ) {
                      if (progress == null) {
                        return child;
                      }

                      return Container(
                        color:
                            AppTheme.lightGray,
                        alignment:
                            Alignment.center,
                        child:
                            const SizedBox(
                          width: 20,
                          height: 20,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                            color:
                                AppTheme.primaryRed,
                          ),
                        ),
                      );
                    },
                    errorBuilder:
                        (
                          context,
                          error,
                          stackTrace,
                        ) {
                      return Container(
                        color:
                            AppTheme.lightGray,
                        alignment:
                            Alignment.center,
                        child: const Icon(
                          Icons
                              .broken_image_outlined,
                          color:
                              AppTheme.gray,
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ============================================================
  // RECOMMENDATION SECTION
  // ============================================================

  Widget _recommendationSection(
    Map<String, dynamic> data,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title: 'Recommendation',
          description:
              'Review the technician’s recommendation or follow-up advice.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius:
                BorderRadius.circular(14),
            border: Border.all(
              color: AppTheme.borderGray,
            ),
          ),
          child: Row(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: AppTheme.primaryRed
                      .withOpacity(0.08),
                  borderRadius:
                      BorderRadius.circular(
                    10,
                  ),
                ),
                child: const Icon(
                  Icons
                      .lightbulb_outline_rounded,
                  color:
                      AppTheme.primaryRed,
                  size: 20,
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Text(
                  _text(
                    data['recommendation'],
                    'No recommendation provided.',
                  ),
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 12.5,
                    height: 1.45,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SECTION HEADER
  // ============================================================

  Widget _sectionHeader({
    required String title,
    required String description,
  }) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: AppTheme.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 6),

        Text(
          description,
          style: const TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.3,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // EMPTY SECTION
  // ============================================================

  Widget _emptySectionCard({
    required IconData icon,
    required String message,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 18,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppTheme.gray,
            size: 20,
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: AppTheme.gray,
                fontSize: 12,
                height: 1.3,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DETAIL ROW
  // ============================================================

  Widget _detailRow(
    IconData icon,
    String label,
    String value, {
    int maxLines = 1,
  }) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        vertical: 13,
      ),
      child: Row(
        children: [
          _softIcon(icon),

          const SizedBox(width: 12),

          SizedBox(
            width: 82,
            child: Text(
              label,
              style: const TextStyle(
                color: AppTheme.gray,
                fontSize: 11.5,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(width: 8),

          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: maxLines,
              overflow:
                  TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppTheme.black,
                fontSize: 12,
                height: 1.3,
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _softIcon(
    IconData icon,
  ) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: AppTheme.primaryRed
            .withOpacity(0.08),
        borderRadius:
            BorderRadius.circular(9),
      ),
      child: Icon(
        icon,
        color: AppTheme.primaryRed,
        size: 18,
      ),
    );
  }

  Widget _divider() {
    return const Divider(
      height: 1,
      color: AppTheme.borderGray,
    );
  }

  // ============================================================
  // ERROR STATE
  // ============================================================

  Widget _errorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              color: AppTheme.primaryRed,
              size: 38,
            ),

            const SizedBox(height: 12),

            Text(
              loadError ??
                  'Unable to load report.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppTheme.gray,
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 16),

            OutlinedButton.icon(
              onPressed:
                  _loadReportDetails,
              icon: const Icon(
                Icons.refresh_rounded,
              ),
              label: const Text(
                'Retry',
              ),
            ),
          ],
        ),
      ),
    );
  }
}