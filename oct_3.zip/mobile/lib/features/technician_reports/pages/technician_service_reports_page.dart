// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// import 'package:mobile_app/app/theme.dart';
// import 'package:mobile_app/config/api_config.dart';

// import 'package:mobile_app/shared/shared.dart';
// import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';

// import 'package:mobile_app/features/technician_reports/widgets/technician_service_report_card.dart';
// import 'package:mobile_app/features/technician_reports/pages/technician_service_report_submission_page.dart';
// import 'package:mobile_app/features/technician_reports/pages/technician_service_report_details_page.dart';

// class TechnicianServiceReportsPage extends StatefulWidget {
//   final String email;

//   const TechnicianServiceReportsPage({
//     super.key,
//     required this.email,
//   });

//   @override
//   State<TechnicianServiceReportsPage> createState() =>
//       _TechnicianServiceReportsPageState();
// }

// class _TechnicianServiceReportsPageState
//     extends State<TechnicianServiceReportsPage> {
//   // ============================================================
//   // TAB
//   // ============================================================

//   String selectedTab = 'Pending';

//   final List<String> tabs = [
//     'Pending',
//     'Submitted',
//   ];

//   // ============================================================
//   // SCROLL
//   // ============================================================

//   final ScrollController _scrollController =
//       ScrollController();

//   // ============================================================
//   // DATA PER TAB
//   // ============================================================

//   List<Map<String, dynamic>> pendingReports = [];
//   List<Map<String, dynamic>> submittedReports = [];

//   // ============================================================
//   // PAGE PER TAB
//   // ============================================================

//   int pendingPage = 1;
//   int submittedPage = 1;

//   // ============================================================
//   // HAS MORE PER TAB
//   // ============================================================

//   bool pendingHasMore = true;
//   bool submittedHasMore = true;

//   // ============================================================
//   // INITIAL LOADING
//   // ============================================================

//   bool isLoadingPending = false;
//   bool isLoadingSubmitted = false;

//   // ============================================================
//   // PAGINATION LOADING
//   // ============================================================

//   bool isLoadingMorePending = false;
//   bool isLoadingMoreSubmitted = false;

//   // ============================================================
//   // CACHE STATE
//   // ============================================================

//   bool pendingLoaded = false;
//   bool submittedLoaded = false;

//   // ============================================================
//   // ERRORS
//   // ============================================================

//   String? pendingError;
//   String? submittedError;

//   // ============================================================
//   // INIT / DISPOSE
//   // ============================================================

//   @override
//   void initState() {
//     super.initState();

//     _scrollController.addListener(
//       _handleScroll,
//     );

//     // Only Pending loads when the page first opens.
//     _loadReportsForTab(
//       'Pending',
//       forceRefresh: true,
//     );
//   }

//   @override
//   void dispose() {
//     _scrollController.removeListener(
//       _handleScroll,
//     );

//     _scrollController.dispose();

//     super.dispose();
//   }

//   // ============================================================
//   // ACTIVE TAB HELPERS
//   // ============================================================

//   List<Map<String, dynamic>> get activeReports {
//     return selectedTab == 'Pending'
//         ? pendingReports
//         : submittedReports;
//   }

//   bool get activeLoading {
//     return selectedTab == 'Pending'
//         ? isLoadingPending
//         : isLoadingSubmitted;
//   }

//   bool get activeLoadingMore {
//     return selectedTab == 'Pending'
//         ? isLoadingMorePending
//         : isLoadingMoreSubmitted;
//   }

//   bool get activeHasMore {
//     return selectedTab == 'Pending'
//         ? pendingHasMore
//         : submittedHasMore;
//   }

//   String? get activeError {
//     return selectedTab == 'Pending'
//         ? pendingError
//         : submittedError;
//   }

//   // ============================================================
//   // LOAD REPORTS PER TAB
//   // ============================================================

//   Future<void> _loadReportsForTab(
//     String tab, {
//     bool forceRefresh = false,
//   }) async {
//     final isPending = tab == 'Pending';

//     final currentlyLoading = isPending
//         ? isLoadingPending
//         : isLoadingSubmitted;

//     final currentlyLoadingMore = isPending
//         ? isLoadingMorePending
//         : isLoadingMoreSubmitted;

//     if (currentlyLoading ||
//         currentlyLoadingMore) {
//       return;
//     }

//     if (!forceRefresh) {
//       final hasMore = isPending
//           ? pendingHasMore
//           : submittedHasMore;

//       if (!hasMore) {
//         return;
//       }
//     }

//     final page = forceRefresh
//         ? 1
//         : isPending
//             ? pendingPage
//             : submittedPage;

//     try {
//       if (!mounted) return;

//       setState(() {
//         if (isPending) {
//           if (forceRefresh ||
//               pendingReports.isEmpty) {
//             isLoadingPending = true;
//           } else {
//             isLoadingMorePending = true;
//           }

//           pendingError = null;
//         } else {
//           if (forceRefresh ||
//               submittedReports.isEmpty) {
//             isLoadingSubmitted = true;
//           } else {
//             isLoadingMoreSubmitted = true;
//           }

//           submittedError = null;
//         }
//       });

//       final databaseStatus = isPending
//           ? 'DONE SERVICE'
//           : 'DONE REPORT';

//       final response = await http
//           .post(
//             Uri.parse(
//               '${ApiConfig.baseUrl}/api/mobile/technician/service-reports',
//             ),
//             headers: {
//               'Accept': 'application/json',
//             },
//             body: {
//               'email': widget.email,
//               'status': databaseStatus,
//               'page': page.toString(),
//             },
//           )
//           .timeout(
//             const Duration(seconds: 12),
//           );

//       final data =
//           jsonDecode(response.body);

//       if (!mounted) return;

//       if (response.statusCode == 200 &&
//           data['success'] == true) {
//         final List list =
//             data['data'] ?? [];

//         final mappedReports = list
//             .map(
//               (item) =>
//                   Map<String, dynamic>.from(
//                 item,
//               ),
//             )
//             .toList();

//         final pagination =
//             data['pagination'] is Map
//                 ? Map<String, dynamic>.from(
//                     data['pagination'],
//                   )
//                 : <String, dynamic>{};

//         final hasMore =
//             pagination['has_more'] == true;

//         final nextPage =
//             pagination['next_page'];

//         setState(() {
//           if (isPending) {
//             if (forceRefresh) {
//               pendingReports =
//                   mappedReports;
//             } else {
//               pendingReports.addAll(
//                 mappedReports,
//               );
//             }

//             pendingLoaded = true;

//             pendingHasMore =
//                 hasMore;

//             pendingPage =
//                 hasMore &&
//                         nextPage != null
//                     ? int.tryParse(
//                           nextPage.toString(),
//                         ) ??
//                         (page + 1)
//                     : page + 1;

//             isLoadingPending = false;
//             isLoadingMorePending = false;
//             pendingError = null;
//           } else {
//             if (forceRefresh) {
//               submittedReports =
//                   mappedReports;
//             } else {
//               submittedReports.addAll(
//                 mappedReports,
//               );
//             }

//             submittedLoaded = true;

//             submittedHasMore =
//                 hasMore;

//             submittedPage =
//                 hasMore &&
//                         nextPage != null
//                     ? int.tryParse(
//                           nextPage.toString(),
//                         ) ??
//                         (page + 1)
//                     : page + 1;

//             isLoadingSubmitted = false;
//             isLoadingMoreSubmitted = false;
//             submittedError = null;
//           }
//         });
//       } else {
//         setState(() {
//           if (isPending) {
//             isLoadingPending = false;
//             isLoadingMorePending = false;

//             pendingError =
//                 data['message']
//                         ?.toString() ??
//                     'Unable to load pending reports.';
//           } else {
//             isLoadingSubmitted = false;
//             isLoadingMoreSubmitted = false;

//             submittedError =
//                 data['message']
//                         ?.toString() ??
//                     'Unable to load submitted reports.';
//           }
//         });
//       }
//     } catch (e) {
//       if (!mounted) return;

//       setState(() {
//         if (isPending) {
//           isLoadingPending = false;
//           isLoadingMorePending = false;

//           pendingError =
//               'Unable to connect to the server.';
//         } else {
//           isLoadingSubmitted = false;
//           isLoadingMoreSubmitted = false;

//           submittedError =
//               'Unable to connect to the server.';
//         }
//       });

//       debugPrint(
//         'SERVICE REPORTS ERROR [$tab PAGE $page]: $e',
//       );
//     }
//   }

//   // ============================================================
//   // SCROLL
//   // ============================================================

//   void _handleScroll() {
//     if (!_scrollController.hasClients) {
//       return;
//     }

//     final position =
//         _scrollController.position;

//     if (position.pixels >=
//         position.maxScrollExtent - 180) {
//       _loadMoreCurrentTab();
//     }
//   }

//   Future<void> _loadMoreCurrentTab() async {
//     if (!activeHasMore ||
//         activeLoading ||
//         activeLoadingMore) {
//       return;
//     }

//     await _loadReportsForTab(
//       selectedTab,
//     );
//   }

//   // ============================================================
//   // SELECT TAB
//   // ============================================================

//   Future<void> _selectTab(
//     String tab,
//   ) async {
//     if (selectedTab == tab) {
//       return;
//     }

//     setState(() {
//       selectedTab = tab;
//     });

//     if (_scrollController.hasClients) {
//       _scrollController.jumpTo(0);
//     }

//     // Load the tab only the first time it is opened.
//     if (tab == 'Pending' &&
//         !pendingLoaded) {
//       await _loadReportsForTab(
//         'Pending',
//         forceRefresh: true,
//       );
//     }

//     if (tab == 'Submitted' &&
//         !submittedLoaded) {
//       await _loadReportsForTab(
//         'Submitted',
//         forceRefresh: true,
//       );
//     }
//   }

//   // ============================================================
//   // REFRESH CURRENT TAB ONLY
//   // ============================================================

//   Future<void> _refreshCurrentTab() async {
//     if (selectedTab == 'Pending') {
//       pendingPage = 1;
//       pendingHasMore = true;
//     } else {
//       submittedPage = 1;
//       submittedHasMore = true;
//     }

//     await _loadReportsForTab(
//       selectedTab,
//       forceRefresh: true,
//     );
//   }

//   // ============================================================
//   // OPEN REPORT
//   // ============================================================

//   Future<void> _openReport(
//     Map<String, dynamic> report,
//   ) async {
//     final status =
//         report['status']
//             ?.toString()
//             .trim()
//             .toUpperCase() ??
//         '';

//     // ============================================================
//     // PENDING REPORT
//     // ============================================================

//     if (status == 'DONE SERVICE') {
//       await Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               TechnicianServiceReportSubmissionPage(
//             job: report,
//             email: widget.email,
//           ),
//         ),
//       );

//       if (!mounted) return;

//       // Pending may now have moved to Submitted.
//       pendingPage = 1;
//       pendingHasMore = true;

//       await _loadReportsForTab(
//         'Pending',
//         forceRefresh: true,
//       );

//       // Submitted may now contain a new report.
//       submittedLoaded = false;
//       submittedReports = [];
//       submittedPage = 1;
//       submittedHasMore = true;

//       return;
//     }

//     // ============================================================
//     // SUBMITTED REPORT
//     // ============================================================

//     if (status == 'DONE REPORT') {
//       final scheduleId =
//           report['id'];

//       if (scheduleId == null) {
//         if (!mounted) return;

//         ScaffoldMessenger.of(context)
//             .showSnackBar(
//           const SnackBar(
//             content: Text(
//               'Unable to open report details.',
//             ),
//             behavior:
//                 SnackBarBehavior.floating,
//           ),
//         );

//         return;
//       }

//       await Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               TechnicianServiceReportDetailsPage(
//             scheduleId: int.parse(
//               scheduleId.toString(),
//             ),
//             email: widget.email,
//           ),
//         ),
//       );
//     }
//   }

//   // ============================================================
//   // BUILD
//   // ============================================================

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//           AppTheme.lightGray,

//       drawer: AppDrawer(
//         userType: 2,
//         email: widget.email,
//         currentPage:
//             'service_reports',
//       ),

//       appBar:
//           const AppTitleHeader(
//         title: 'Service Reports',
//       ),

//       bottomNavigationBar:
//           TechnicianBottomNavBar(
//         currentIndex: 2,
//         email: widget.email,
//       ),

//       body: Padding(
//         padding:
//             const EdgeInsets.fromLTRB(
//           20,
//           16,
//           20,
//           0,
//         ),
//         child: Column(
//           crossAxisAlignment:
//               CrossAxisAlignment.start,
//           children: [
//             _pageHeader(),

//             const SizedBox(height: 16),

//             _tabChips(),

//             const SizedBox(height: 16),

//             Expanded(
//               child:
//                   _buildContent(),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // ============================================================
//   // PAGE HEADER
//   // ============================================================

//   Widget _pageHeader() {
//     return const Column(
//       crossAxisAlignment:
//           CrossAxisAlignment.start,
//       children: [
//         Text(
//           'Service Reports',
//           style: TextStyle(
//             color:
//                 AppTheme.black,
//             fontSize: 18,
//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         SizedBox(height: 5),

//         Text(
//           'Complete pending reports and review submitted service reports.',
//           style: TextStyle(
//             color:
//                 AppTheme.gray,
//             fontSize: 13,
//             height: 1.35,
//           ),
//         ),
//       ],
//     );
//   }

//   // ============================================================
//   // TAB CHIPS
//   // ============================================================

//   Widget _tabChips() {
//     return SizedBox(
//       height: 38,
//       child: ListView.separated(
//         scrollDirection:
//             Axis.horizontal,
//         itemCount:
//             tabs.length,
//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           width: 8,
//         ),
//         itemBuilder:
//             (context, index) {
//           final tab =
//               tabs[index];

//           final isSelected =
//               selectedTab == tab;

//           return GestureDetector(
//             onTap: () {
//               _selectTab(tab);
//             },
//             child: Container(
//               padding:
//                   const EdgeInsets.symmetric(
//                 horizontal: 16,
//               ),
//               alignment:
//                   Alignment.center,
//               decoration:
//                   BoxDecoration(
//                 color:
//                     isSelected
//                         ? AppTheme.primaryRed
//                         : AppTheme.white,
//                 borderRadius:
//                     BorderRadius.circular(
//                   20,
//                 ),
//                 border:
//                     Border.all(
//                   color:
//                       isSelected
//                           ? AppTheme.primaryRed
//                           : AppTheme.borderGray,
//                 ),
//               ),
//               child: Text(
//                 tab,
//                 style:
//                     TextStyle(
//                   color:
//                       isSelected
//                           ? AppTheme.white
//                           : AppTheme.black,
//                   fontSize: 12,
//                   fontWeight:
//                       FontWeight.w700,
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }

//   // ============================================================
//   // CONTENT
//   // ============================================================

//   Widget _buildContent() {
//     if (activeLoading &&
//         activeReports.isEmpty) {
//       return const Center(
//         child:
//             CircularProgressIndicator(
//           color:
//               AppTheme.primaryRed,
//         ),
//       );
//     }

//     if (activeError != null &&
//         activeReports.isEmpty) {
//       return ListView(
//         physics:
//             const AlwaysScrollableScrollPhysics(),
//         children: [
//           const SizedBox(
//             height: 100,
//           ),

//           _ErrorReportsContent(
//             message:
//                 activeError!,
//             onRetry: () async {
//               await _refreshCurrentTab();
//             },
//           ),
//         ],
//       );
//     }

//     if (activeReports.isEmpty) {
//       return RefreshIndicator(
//         color:
//             AppTheme.primaryRed,
//         onRefresh:
//             _refreshCurrentTab,
//         child: ListView(
//           physics:
//               const AlwaysScrollableScrollPhysics(),
//           children: [
//             const SizedBox(
//               height: 90,
//             ),

//             _EmptyReportsContent(
//               isPending:
//                   selectedTab ==
//                       'Pending',
//             ),
//           ],
//         ),
//       );
//     }

//     return RefreshIndicator(
//       color:
//           AppTheme.primaryRed,
//       onRefresh:
//           _refreshCurrentTab,
//       child: ListView.separated(
//         controller:
//             _scrollController,

//         physics:
//             const AlwaysScrollableScrollPhysics(),

//         padding:
//             const EdgeInsets.only(
//           bottom: 24,
//         ),

//         itemCount:
//             activeReports.length +
//             (activeLoadingMore ? 1 : 0),

//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           height: 12,
//         ),

//         itemBuilder:
//             (context, index) {
//           // ============================================================
//           // BOTTOM PAGINATION LOADER
//           // ============================================================

//           if (index >=
//               activeReports.length) {
//             return const Padding(
//               padding:
//                   EdgeInsets.symmetric(
//                 vertical: 14,
//               ),
//               child: Center(
//                 child: SizedBox(
//                   width: 22,
//                   height: 22,
//                   child:
//                       CircularProgressIndicator(
//                     strokeWidth: 2.2,
//                     color:
//                         AppTheme.primaryRed,
//                   ),
//                 ),
//               ),
//             );
//           }

//           final report =
//               activeReports[index];

//           final status =
//               report['status']
//                   ?.toString()
//                   .trim()
//                   .toUpperCase() ??
//               '';

//           final submittedDate =
//               status == 'DONE SERVICE'
//                   ? 'Pending submission'
//                   : report['submittedDate']
//                           ?.toString() ??
//                       '-';

//           return TechnicianServiceReportCard(
//             saNumber:
//                 report['saNumber']?.toString() ??
//                 report['sa_number']?.toString() ??
//                 '-',

//             clientName:
//                 report['clientName']
//                         ?.toString() ??
//                     'Client',

//             service:
//                 report['service']
//                         ?.toString() ??
//                     'Pest Control Service',

//             pestType:
//                 report['pestType']
//                         ?.toString() ??
//                     'General Pest',

//             address:
//                 report['address']
//                         ?.toString() ??
//                     'No address',

//             schedule:
//                 report['schedule']
//                         ?.toString() ??
//                     '-',

//             submittedDate:
//                 submittedDate,

//             status:
//                 status,

//             onViewReport: () {
//               _openReport(
//                 report,
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }

// // ============================================================
// // EMPTY STATE
// // ============================================================

// class _EmptyReportsContent
//     extends StatelessWidget {
//   final bool isPending;

//   const _EmptyReportsContent({
//     required this.isPending,
//   });

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     return Column(
//       mainAxisSize:
//           MainAxisSize.min,
//       children: [
//         Container(
//           width: 68,
//           height: 68,
//           decoration:
//               BoxDecoration(
//             color:
//                 AppTheme.primaryRed
//                     .withOpacity(
//               0.08,
//             ),
//             shape:
//                 BoxShape.circle,
//           ),
//           child: Icon(
//             isPending
//                 ? Icons.assignment_turned_in_outlined
//                 : Icons.description_outlined,
//             color:
//                 AppTheme.primaryRed,
//             size: 34,
//           ),
//         ),

//         const SizedBox(
//           height: 16,
//         ),

//         Text(
//           isPending
//               ? 'No pending reports'
//               : 'No submitted reports',
//           style:
//               const TextStyle(
//             color:
//                 AppTheme.black,
//             fontSize: 16,
//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         const SizedBox(
//           height: 7,
//         ),

//         Padding(
//           padding:
//               const EdgeInsets.symmetric(
//             horizontal: 28,
//           ),
//           child: Text(
//             isPending
//                 ? 'Services waiting for report submission will appear here.'
//                 : 'Completed service reports will appear here.',
//             textAlign:
//                 TextAlign.center,
//             style:
//                 const TextStyle(
//               color:
//                   AppTheme.gray,
//               fontSize: 13,
//               height: 1.35,
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }

// // ============================================================
// // ERROR STATE
// // ============================================================

// class _ErrorReportsContent
//     extends StatelessWidget {
//   final String message;

//   final Future<void> Function()
//       onRetry;

//   const _ErrorReportsContent({
//     required this.message,
//     required this.onRetry,
//   });

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     return Column(
//       mainAxisSize:
//           MainAxisSize.min,
//       children: [
//         Container(
//           width: 68,
//           height: 68,
//           decoration:
//               BoxDecoration(
//             color:
//                 AppTheme.primaryRed
//                     .withOpacity(
//               0.08,
//             ),
//             shape:
//                 BoxShape.circle,
//           ),
//           child:
//               const Icon(
//             Icons.wifi_off_rounded,
//             color:
//                 AppTheme.primaryRed,
//             size: 32,
//           ),
//         ),

//         const SizedBox(
//           height: 16,
//         ),

//         const Text(
//           'Unable to load reports',
//           style:
//               TextStyle(
//             color:
//                 AppTheme.black,
//             fontSize: 16,
//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         const SizedBox(
//           height: 7,
//         ),

//         Padding(
//           padding:
//               const EdgeInsets.symmetric(
//             horizontal: 28,
//           ),
//           child: Text(
//             message,
//             textAlign:
//                 TextAlign.center,
//             style:
//                 const TextStyle(
//               color:
//                   AppTheme.gray,
//               fontSize: 13,
//               height: 1.35,
//             ),
//           ),
//         ),

//         const SizedBox(
//           height: 16,
//         ),

//         OutlinedButton.icon(
//           onPressed: () {
//             onRetry();
//           },
//           icon:
//               const Icon(
//             Icons.refresh_rounded,
//             size: 18,
//           ),
//           label:
//               const Text(
//             'Retry',
//           ),
//           style:
//               OutlinedButton.styleFrom(
//             foregroundColor:
//                 AppTheme.primaryRed,
//             side:
//                 const BorderSide(
//               color:
//                   AppTheme.primaryRed,
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }