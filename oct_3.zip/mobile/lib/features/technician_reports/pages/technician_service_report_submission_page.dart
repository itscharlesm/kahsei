import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_reports_menu_page.dart';
import 'package:mobile_app/features/technician_reports/widgets/report_area_photos_card.dart';

import 'package:mobile_app/shared/widgets/dialogs/app_confirmation_dialog.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_success_dialog.dart';
import 'package:mobile_app/shared/widgets/headers/app_center_title_header.dart';

class TechnicianServiceReportSubmissionPage extends StatefulWidget {
  final Map<String, dynamic> job;
  final String email;

  const TechnicianServiceReportSubmissionPage({
    super.key,
    required this.job,
    required this.email,
  });

  @override
  State<TechnicianServiceReportSubmissionPage> createState() =>
      _TechnicianServiceReportPageState();
}

// ============================================================
// CHEMICAL MODEL
// ============================================================

class ChemicalUsedItem {
  final int serviceChemicalId;
  final int chemicalId;
  final String chemicalName;
  final String expectedQuantity;
  final String unit;
  final TextEditingController quantityController;

  bool hasError;

  ChemicalUsedItem({
    required this.serviceChemicalId,
    required this.chemicalId,
    required this.chemicalName,
    required this.expectedQuantity,
    required this.unit,
    required this.quantityController,
    this.hasError = false,
  });
}

class _TechnicianServiceReportPageState
    extends State<TechnicianServiceReportSubmissionPage> {
  bool _isSubmitting = false;
  bool _isReportSubmitted = false;
  bool _showPhotoError = false;

  bool _isLoadingChemicals = false;
  String? _chemicalLoadError;

  final ImagePicker _imagePicker = ImagePicker();

  final TextEditingController _recommendationController =
      TextEditingController();

  List<ChemicalUsedItem> _chemicals = [];

  int _ratsCaptured = 0;
  int _snakesCaptured = 0;
  int _lizardsCaptured = 0;
  int _kittensCaptured = 0;
  int _othersCaptured = 0;

  final List<XFile> _selectedImages = [];

  static const int maxImages = 10;

  // ============================================================
  // INIT / DISPOSE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _loadServiceChemicals();
  }

  @override
  void dispose() {
    for (final chemical in _chemicals) {
      chemical.quantityController.dispose();
    }

    _recommendationController.dispose();

    super.dispose();
  }

  // ============================================================
  // HELPERS
  // ============================================================

  String _text(
    dynamic value, [
    String fallback = '-',
  ]) {
    if (value == null) return fallback;

    final text = value.toString().trim();

    return text.isEmpty
        ? fallback
        : text;
  }

  String _formatSaNumber(
    dynamic value,
  ) {
    if (value == null) {
      return 'SA #-';
    }

    final String raw =
        value.toString().trim();

    if (raw.isEmpty || raw == '-') {
      return 'SA #-';
    }

    final String cleaned = raw
        .toUpperCase()
        .replaceAll('SA-', '')
        .replaceAll('SA #', '')
        .trim();

    final int? number =
        int.tryParse(cleaned);

    if (number == null) {
      return 'SA-$cleaned';
    }

    return 'SA-${number.toString().padLeft(6, '0')}';
  }

  // ============================================================
  // LOAD CHEMICALS
  // ============================================================

  Future<void> _loadServiceChemicals() async {
    final appointmentId =
        widget.job['appointment_id'] ??
        widget.job['appointmentId'];

    if (appointmentId == null) return;

    setState(() {
      _isLoadingChemicals = true;
    });

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/technician/service-chemicals',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'appointment_id':
              appointmentId.toString(),
        },
      );

      final data =
          jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final List list =
            data['chemicals'] ?? [];

        setState(() {
          _chemicalLoadError = null;

          for (final chemical
              in _chemicals) {
            chemical.quantityController
                .dispose();
          }

          _chemicals = list.map((item) {
            return ChemicalUsedItem(
              serviceChemicalId:
                  int.parse(
                item['svcch_id']
                    .toString(),
              ),
              chemicalId:
                  int.parse(
                item['chem_id']
                    .toString(),
              ),
              chemicalName:
                  item['chem_name']
                          ?.toString() ??
                      'Chemical',
              expectedQuantity:
                  item['svcch_expected_quantity']
                          ?.toString() ??
                      '',
              unit:
                  item['svcch_unit']
                          ?.toString() ??
                      '',
              quantityController:
                  TextEditingController(
                text:
                    item['svcch_actual_quantity']
                            ?.toString() ??
                        '',
              ),
            );
          }).toList();
        });
      } else {
        setState(() {
          _chemicalLoadError =
              data['message']
                      ?.toString() ??
                  'Unable to load service chemicals.';
        });
      }
    } catch (e) {
      debugPrint(
        'LOAD SERVICE CHEMICALS ERROR: $e',
      );

      if (!mounted) return;

      setState(() {
        _chemicalLoadError =
            'Unable to connect to the server.';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingChemicals = false;
        });
      }
    }
  }

  // ============================================================
  // IMAGE
  // ============================================================

  Future<void> _pickImageFromCamera() async {
    if (_selectedImages.length >=
        maxImages) {
      _showMessage(
        'Maximum of $maxImages photos only.',
      );
      return;
    }

    final image =
        await _imagePicker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
    );

    if (image == null) return;

    setState(() {
      _selectedImages.add(image);
      _showPhotoError = false;
    });
  }

  void _removeImage(int index) {
    setState(() {
      _selectedImages.removeAt(index);
    });
  }

  // ============================================================
  // SUBMIT REPORT
  // ============================================================

  Future<void> _submitReport() async {
    if (_isLoadingChemicals) {
      _showMessage(
        'Please wait while chemicals are loading.',
      );
      return;
    }

    if (_chemicalLoadError != null) {
      _showMessage(
        'Unable to submit because chemicals failed to load.',
      );
      return;
    }

    bool hasChemicalError = false;

    setState(() {
      for (final chemical
          in _chemicals) {
        chemical.hasError =
            chemical
                .quantityController
                .text
                .trim()
                .isEmpty;

        if (chemical.hasError) {
          hasChemicalError = true;
        }
      }
    });

    if (hasChemicalError) {
      _showMessage(
        'Please complete the required chemical information.',
      );
      return;
    }

    if (_selectedImages.isEmpty) {
      setState(() {
        _showPhotoError = true;
      });

      _showMessage(
        'Please add at least one site documentation photo.',
      );

      return;
    }

    final appointmentId =
        widget.job['appointment_id'] ??
        widget.job['appointmentId'];

    final scheduleId =
        widget.job['id'] ??
        widget.job['schedule_id'] ??
        widget.job['scheduleId'];

    if (appointmentId == null ||
        scheduleId == null) {
      _showMessage(
        'Missing appointment or schedule ID.',
      );

      debugPrint(
        'REPORT JOB DATA: ${widget.job}',
      );

      return;
    }

    try {
      setState(() {
        _isSubmitting = true;
      });

      final request =
          http.MultipartRequest(
        'POST',
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/technician/submit-report',
        ),
      );

      request.headers.addAll({
        'Accept': 'application/json',
      });

      request.fields['appointment_id'] =
          appointmentId.toString();

      request.fields['schedule_id'] =
          scheduleId.toString();

      request.fields['recommendation'] =
          _recommendationController
              .text
              .trim();

      final chemicalUpdates =
          _chemicals.map((chemical) {
        return {
          'svcch_id':
              chemical.serviceChemicalId,
          'svcch_actual_quantity':
              double.parse(
            chemical
                .quantityController
                .text
                .trim(),
          ),
        };
      }).toList();

      request.fields['chemicals'] =
          jsonEncode(
        chemicalUpdates,
      );

      request.fields['rat_captured'] =
          _ratsCaptured.toString();

      request.fields['snake_captured'] =
          _snakesCaptured.toString();

      request.fields['lizard_captured'] =
          _lizardsCaptured.toString();

      request.fields['kitten_captured'] =
          _kittensCaptured.toString();

      request.fields['other_captured'] =
          _othersCaptured.toString();

      for (final image
          in _selectedImages) {
        request.files.add(
          await http.MultipartFile
              .fromPath(
            'area_photos[]',
            image.path,
          ),
        );
      }

      final streamedResponse =
          await request.send();

      final response =
          await http.Response.fromStream(
        streamedResponse,
      );

      debugPrint(
        'SUBMIT REPORT STATUS: ${response.statusCode}',
      );

      debugPrint(
        'SUBMIT REPORT BODY: ${response.body}',
      );

      final data =
          jsonDecode(response.body);

      if (response.statusCode == 200 &&
          data['success'] == true) {
        widget.job['status'] =
            'DONE REPORT';

        _isReportSubmitted = true;

        if (!mounted) return;

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) =>
              AppSuccessDialog(
            title:
                'Service Completed',
            message:
                'The service report has been submitted and the job has been marked as completed.',
            buttonText:
                'View Reports',
            onPressed: () {
              Navigator.of(context)
                  .pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (_) =>
                      TechnicianServiceReportsMenuPage(
                    email:
                        widget.email,
                  ),
                ),
                (route) => false,
              );
            },
          ),
        );
      } else {
        _showMessage(
          data['message'] ??
              'Unable to submit report.',
        );
      }
    } catch (e) {
      _showMessage(
        'Unable to connect to server.',
      );

      debugPrint(
        'Submit report error: $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior:
            SnackBarBehavior.floating,
        duration:
            const Duration(seconds: 2),
      ),
    );
  }

  // ============================================================
  // LEAVE CONFIRMATION
  // ============================================================

  Future<bool>
      _confirmLeaveReportPage() async {
    if (_isReportSubmitted) {
      return true;
    }

    bool shouldLeave = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) =>
          AppConfirmationDialog(
        icon:
            Icons.assignment_late_outlined,
        title: 'Leave Report?',
        message:
            'This service report has not been submitted yet. You can continue it later from Service Reports as a pending report.',
        cancelText: 'Stay Here',
        confirmText: 'Leave',
        onConfirm: () {
          shouldLeave = true;
        },
      ),
    );

    return shouldLeave;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final saNumber = _formatSaNumber(
      widget.job['svc_sa_number'] ??
          widget.job['saNumber'] ??
          widget.job['sa_number'],
    );
    
    final clientName =
        _text(
      widget.job['clientName'],
      'Client',
    );

    final service =
        _text(
      widget.job['service'],
      '-',
    );

    final pestType =
        _text(
      widget.job['pestType'],
      '-',
    );

    final address =
        _text(
      widget.job['address'],
      'No address',
    );

    final schedule =
        _text(
      widget.job['schedule'],
      '-',
    );

    final travelTime =
        _text(
      widget.job['travelTime'],
      '-',
    );

    final serviceTime =
        _text(
      widget.job['serviceTime'],
      '-',
    );

    final totalDuration =
        _text(
      widget.job['totalDuration'] ??
          widget.job['timeFinished'],
      '-',
    );

    return PopScope(
      canPop: false,
      onPopInvokedWithResult:
          (
        didPop,
        result,
      ) async {
        if (didPop) return;

        final shouldLeave =
            await _confirmLeaveReportPage();

        if (!mounted ||
            !shouldLeave) {
          return;
        }

        Navigator.of(context)
            .pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (_) =>
                TechnicianServiceReportsMenuPage(
              email: widget.email,
            ),
          ),
          (route) => false,
        );
      },

      child: Scaffold(
        backgroundColor:
            AppTheme.lightGray,

        appBar:
            const AppCenterTitleHeader(
          title:
              'Service Report Submission',
        ),

        bottomNavigationBar:
            _submitBar(),

        body: SingleChildScrollView(
          padding:
              const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              // ============================================================
              // HEADER
              // ============================================================

              _topHeader(
                clientName,
              ),

              const SizedBox(height: 24),

              // ============================================================
              // SERVICE SUMMARY
              // ============================================================

              _serviceSummarySection(
                saNumber: 
                    saNumber,
                clientName:
                    clientName,
                service:
                    service,
                pestType:
                    pestType,
                address:
                    address,
                schedule:
                    schedule,
                travelTime:
                    travelTime,
                serviceTime:
                    serviceTime,
                totalDuration:
                    totalDuration,
              ),

              const SizedBox(height: 20),

              // ============================================================
              // CHEMICAL USED
              // ============================================================

              _chemicalUsedSection(),

              const SizedBox(height: 20),

              // ============================================================
              // CAPTURED PESTS
              // ============================================================

              _capturedPestsSection(),

              const SizedBox(height: 20),

              // ============================================================
              // SERVICE EVIDENCE
              // ============================================================

              _serviceEvidenceSection(),

              const SizedBox(height: 20),

              // ============================================================
              // RECOMMENDATION
              // ============================================================

              _recommendationSection(),

              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // TOP HEADER
  // ============================================================

  Widget _topHeader(
    String clientName,
  ) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:
            AppTheme.primaryRed,
        borderRadius:
            BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color:
                  AppTheme.white.withOpacity(
                0.18,
              ),
              borderRadius:
                  BorderRadius.circular(
                14,
              ),
            ),
            child: const Icon(
              Icons
                  .assignment_turned_in_outlined,
              color:
                  AppTheme.white,
              size: 25,
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'SERVICE COMPLETED',
                  style: TextStyle(
                    color:
                        AppTheme.white,
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w800,
                    letterSpacing:
                        0.4,
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  clientName,
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.white,
                    fontSize: 18,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  'Complete the required service report below.',
                  style: TextStyle(
                    color:
                        AppTheme.white
                            .withOpacity(
                      0.85,
                    ),
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SERVICE SUMMARY SECTION
  // ============================================================

  Widget _serviceSummarySection({
    required String saNumber,
    required String clientName,
    required String service,
    required String pestType,
    required String address,
    required String schedule,
    required String travelTime,
    required String serviceTime,
    required String totalDuration,
  }) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title:
              'Service Summary',
          description:
              'Review the completed service information before submitting the report.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding:
              const EdgeInsets.symmetric(
            horizontal: 14,
          ),
          decoration:
              BoxDecoration(
            color:
                AppTheme.white,
            borderRadius:
                BorderRadius.circular(
              14,
            ),
            border: Border.all(
              color:
                  AppTheme.borderGray,
            ),
          ),
          child: Column(
            children: [
              _detailRow(
                Icons.numbers_rounded,
                'SA Number',
                saNumber,
              ),

              _divider(),

              _detailRow(
                Icons
                    .person_outline_rounded,
                'Client',
                clientName,
              ),

              _divider(),

              _detailRow(
                Icons
                    .assignment_outlined,
                'Service Type',
                service,
              ),

              _divider(),

              _detailRow(
                Icons
                    .bug_report_outlined,
                'Pest Type',
                pestType,
              ),

              _divider(),

              _detailRow(
                Icons
                    .location_on_outlined,
                'Address',
                address,
                maxLines: 3,
              ),

              _divider(),

              _detailRow(
                Icons
                    .calendar_month_outlined,
                'Schedule',
                schedule,
                maxLines: 2,
              ),

              _divider(),

              _detailRow(
                Icons.route_outlined,
                'Travel Time',
                travelTime,
              ),

              _divider(),

              _detailRow(
                Icons
                    .home_repair_service_outlined,
                'Service Time',
                serviceTime,
              ),

              _divider(),

              _detailRow(
                Icons.timer_outlined,
                'Total Duration',
                totalDuration,
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CHEMICAL USED SECTION
  // ============================================================

  Widget _chemicalUsedSection() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title:
              'Chemicals Used',
          description:
              'Record the actual quantity used for each assigned chemical.',
        ),

        const SizedBox(height: 12),

        if (_isLoadingChemicals)
          Container(
            width: double.infinity,
            padding:
                const EdgeInsets.symmetric(
              vertical: 24,
            ),
            decoration:
                _cardDecoration(),
            child:
                const Center(
              child:
                  CircularProgressIndicator(
                strokeWidth: 2.5,
                color:
                    AppTheme.primaryRed,
              ),
            ),
          )
        else if (_chemicalLoadError !=
            null)
          _messageCard(
            icon:
                Icons.error_outline,
            message:
                _chemicalLoadError!,
            isError: true,
          )
        else if (_chemicals.isEmpty)
          _messageCard(
            icon:
                Icons.science_outlined,
            message:
                'No chemicals assigned to this service.',
          )
        else
          Column(
            children: _chemicals
                .asMap()
                .entries
                .map(
                  (entry) {
                    final index =
                        entry.key;

                    final chemical =
                        entry.value;

                    return Column(
                      children: [
                        _chemicalActualQuantityField(
                          chemical,
                        ),

                        if (index <
                            _chemicals
                                    .length -
                                1)
                          const SizedBox(
                            height: 10,
                          ),
                      ],
                    );
                  },
                )
                .toList(),
          ),
      ],
    );
  }

  // ============================================================
  // CHEMICAL FIELD
  // ============================================================

  Widget _chemicalActualQuantityField(
    ChemicalUsedItem chemical,
  ) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(14),
      decoration:
          BoxDecoration(
        color:
            AppTheme.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              chemical.hasError
                  ? AppTheme.primaryRed
                  : AppTheme.borderGray,
          width:
              chemical.hasError
                  ? 1.6
                  : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  borderRadius:
                      BorderRadius
                          .circular(
                    10,
                  ),
                ),
                child:
                    const Icon(
                  Icons
                      .science_outlined,
                  color:
                      AppTheme.primaryRed,
                  size: 20,
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              Expanded(
                child: Text(
                  chemical
                      .chemicalName,
                  maxLines: 2,
                  overflow:
                      TextOverflow
                          .ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,
                    fontSize: 13,
                    height: 1.2,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 12,
          ),

          const Divider(
            height: 1,
            color:
                AppTheme.borderGray,
          ),

          const SizedBox(
            height: 12,
          ),

          const Text(
            'Quantity Used',
            style: TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 11.5,
              fontWeight:
                  FontWeight.w600,
            ),
          ),

          const SizedBox(
            height: 7,
          ),

          TextField(
            controller:
                chemical
                    .quantityController,
            keyboardType:
                const TextInputType
                    .numberWithOptions(
              decimal: true,
            ),
            inputFormatters: [
              FilteringTextInputFormatter
                  .allow(
                RegExp(
                  r'^\d*\.?\d{0,2}',
                ),
              ),
            ],
            onChanged: (_) {
              if (chemical.hasError &&
                  chemical
                      .quantityController
                      .text
                      .trim()
                      .isNotEmpty) {
                setState(() {
                  chemical.hasError =
                      false;
                });
              }
            },
            decoration:
                InputDecoration(
              hintText: '0.00',
              hintStyle:
                  const TextStyle(
                color:
                    AppTheme.gray,
                fontSize: 13,
              ),
              filled: true,
              fillColor:
                  AppTheme.white,
              contentPadding:
                  const EdgeInsets
                      .symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              suffixIconConstraints:
                  const BoxConstraints(
                minWidth: 76,
              ),
              suffixIcon:
                  Padding(
                padding:
                    const EdgeInsets
                        .only(
                  right: 14,
                  left: 10,
                ),
                child: Align(
                  alignment:
                      Alignment
                          .centerRight,
                  widthFactor: 1,
                  child: Text(
                    chemical.unit
                        .toUpperCase(),
                    style:
                        const TextStyle(
                      color:
                          AppTheme.gray,
                      fontSize: 11,
                      fontWeight:
                          FontWeight
                              .w700,
                    ),
                  ),
                ),
              ),
              border:
                  _inputBorder(),
              enabledBorder:
                  _inputBorder(),
              focusedBorder:
                  _inputBorder(
                AppTheme.primaryRed,
              ),
              errorText:
                  chemical.hasError
                      ? 'Required'
                      : null,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CAPTURED PESTS SECTION
  // ============================================================

  Widget _capturedPestsSection() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title:
              'Captured Pests',
          description:
              'Record the total number of pests captured during the service.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding:
              const EdgeInsets.all(
            14,
          ),
          decoration:
              _cardDecoration(),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child:
                        _pestCounterField(
                      label: 'Rats',
                      value:
                          _ratsCaptured,
                      onChanged:
                          (value) {
                        _ratsCaptured =
                            value;
                      },
                      onMinus: () {
                        _updateCounter(
                          'rats',
                          -1,
                        );
                      },
                      onPlus: () {
                        _updateCounter(
                          'rats',
                          1,
                        );
                      },
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child:
                        _pestCounterField(
                      label:
                          'Snakes',
                      value:
                          _snakesCaptured,
                      onChanged:
                          (value) {
                        _snakesCaptured =
                            value;
                      },
                      onMinus: () {
                        _updateCounter(
                          'snakes',
                          -1,
                        );
                      },
                      onPlus: () {
                        _updateCounter(
                          'snakes',
                          1,
                        );
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 14,
              ),

              Row(
                children: [
                  Expanded(
                    child:
                        _pestCounterField(
                      label:
                          'Lizards',
                      value:
                          _lizardsCaptured,
                      onChanged:
                          (value) {
                        _lizardsCaptured =
                            value;
                      },
                      onMinus: () {
                        _updateCounter(
                          'lizards',
                          -1,
                        );
                      },
                      onPlus: () {
                        _updateCounter(
                          'lizards',
                          1,
                        );
                      },
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child:
                        _pestCounterField(
                      label:
                          'Kittens',
                      value:
                          _kittensCaptured,
                      onChanged:
                          (value) {
                        _kittensCaptured =
                            value;
                      },
                      onMinus: () {
                        _updateCounter(
                          'kittens',
                          -1,
                        );
                      },
                      onPlus: () {
                        _updateCounter(
                          'kittens',
                          1,
                        );
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 14,
              ),

              Row(
                children: [
                  Expanded(
                    child:
                        _pestCounterField(
                      label:
                          'Others',
                      value:
                          _othersCaptured,
                      onChanged:
                          (value) {
                        _othersCaptured =
                            value;
                      },
                      onMinus: () {
                        _updateCounter(
                          'others',
                          -1,
                        );
                      },
                      onPlus: () {
                        _updateCounter(
                          'others',
                          1,
                        );
                      },
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  const Expanded(
                    child:
                        SizedBox
                            .shrink(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // PEST COUNTER
  // ============================================================

  Widget _pestCounterField({
    required String label,
    required int value,
    required Function(int)
        onChanged,
    required VoidCallback onMinus,
    required VoidCallback onPlus,
  }) {
    final controller =
        TextEditingController(
      text: value.toString(),
    );

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Padding(
          padding:
              const EdgeInsets.only(
            left: 4,
          ),
          child: Text(
            label,
            style:
                const TextStyle(
              color:
                  AppTheme.black,
              fontSize: 12,
              fontWeight:
                  FontWeight.w700,
            ),
          ),
        ),

        const SizedBox(height: 8),

        TextField(
          controller:
              controller,
          keyboardType:
              TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter
                .digitsOnly,
          ],
          onTap: () {
            if (controller.text ==
                '0') {
              controller.clear();
            }
          },
          onChanged: (text) {
            final parsed =
                int.tryParse(
                      text,
                    ) ??
                    0;

            onChanged(parsed);
          },
          onEditingComplete: () {
            if (controller.text
                .trim()
                .isEmpty) {
              controller.text =
                  '0';

              onChanged(0);
            }

            FocusScope.of(context)
                .unfocus();
          },
          decoration:
              InputDecoration(
            filled: true,
            fillColor:
                AppTheme.white,
            contentPadding:
                const EdgeInsets
                    .symmetric(
              horizontal: 12,
              vertical: 8,
            ),
            border:
                _inputBorder(),
            enabledBorder:
                _inputBorder(),
            focusedBorder:
                _inputBorder(
              AppTheme.primaryRed,
            ),
            suffixIcon:
                SizedBox(
              width: 72,
              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment
                        .end,
                mainAxisSize:
                    MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: onMinus,
                    child:
                        const Icon(
                      Icons.remove,
                      size: 18,
                      color:
                          AppTheme.gray,
                    ),
                  ),

                  const SizedBox(
                    width: 10,
                  ),

                  GestureDetector(
                    onTap: onPlus,
                    child:
                        const Icon(
                      Icons.add,
                      size: 18,
                      color:
                          AppTheme
                              .primaryRed,
                    ),
                  ),

                  const SizedBox(
                    width: 10,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _updateCounter(
    String type,
    int change,
  ) {
    setState(() {
      switch (type) {
        case 'rats':
          _ratsCaptured =
              (_ratsCaptured +
                      change)
                  .clamp(
            0,
            999,
          );
          break;

        case 'snakes':
          _snakesCaptured =
              (_snakesCaptured +
                      change)
                  .clamp(
            0,
            999,
          );
          break;

        case 'lizards':
          _lizardsCaptured =
              (_lizardsCaptured +
                      change)
                  .clamp(
            0,
            999,
          );
          break;

        case 'kittens':
          _kittensCaptured =
              (_kittensCaptured +
                      change)
                  .clamp(
            0,
            999,
          );
          break;

        case 'others':
          _othersCaptured =
              (_othersCaptured +
                      change)
                  .clamp(
            0,
            999,
          );
          break;
      }
    });
  }

  // ============================================================
  // SERVICE EVIDENCE SECTION
  // ============================================================

  Widget _serviceEvidenceSection() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title:
              'Service Evidence',
          description:
              'Capture clear photos of the completed service as supporting documentation.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding:
              const EdgeInsets.all(
            14,
          ),
          decoration:
              BoxDecoration(
            color:
                AppTheme.white,
            borderRadius:
                BorderRadius.circular(
              14,
            ),
            border: Border.all(
              color:
                  _showPhotoError
                      ? AppTheme
                          .primaryRed
                      : AppTheme
                          .borderGray,
              width:
                  _showPhotoError
                      ? 1.6
                      : 1,
            ),
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              if (widget.job[
                      'isMultipleTechnician'] ==
                  true) ...[
                _multiTechnicianInstruction(),

                const SizedBox(
                  height: 12,
                ),
              ],

              ReportAreaPhotosCard(
                images:
                    _selectedImages,
                maxImages:
                    maxImages,
                onAddPhoto:
                    _pickImageFromCamera,
                onRemovePhoto:
                    _removeImage,
                hasError:
                    _showPhotoError,
              ),

              if (_showPhotoError) ...[
                const SizedBox(
                  height: 8,
                ),

                const Text(
                  'At least one service evidence photo is required.',
                  style:
                      TextStyle(
                    color:
                        AppTheme
                            .primaryRed,
                    fontSize: 11,
                    fontWeight:
                        FontWeight
                            .w600,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // RECOMMENDATION SECTION
  // ============================================================

  Widget _recommendationSection() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          title:
              'Recommendation',
          description:
              'Provide recommendations or follow-up actions based on the completed service.',
        ),

        const SizedBox(height: 12),

        Container(
          width: double.infinity,
          padding:
              const EdgeInsets.all(
            14,
          ),
          decoration:
              _cardDecoration(),
          child: Stack(
            children: [
              TextField(
                controller:
                    _recommendationController,
                onChanged: (_) {
                  setState(() {});
                },
                textAlignVertical:
                    TextAlignVertical
                        .top,
                maxLines: 4,
                maxLength: 250,
                decoration:
                    InputDecoration(
                  hintText:
                      'Write your recommendation...',
                  hintStyle:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 12,
                  ),
                  counterText: '',
                  filled: true,
                  fillColor:
                      AppTheme
                          .lightGray
                          .withOpacity(
                    0.45,
                  ),
                  contentPadding:
                      const EdgeInsets
                          .fromLTRB(
                    14,
                    14,
                    14,
                    34,
                  ),
                  enabledBorder:
                      _inputBorder(),
                  focusedBorder:
                      _inputBorder(
                    AppTheme
                        .primaryRed,
                  ),
                ),
              ),

              Positioned(
                right: 12,
                bottom: 10,
                child: Text(
                  '${_recommendationController.text.length}/250',
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SECTION HEADER
  // ============================================================

  Widget _sectionHeader({
    required String title,
    required String description,
  }) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style:
              const TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 6,
        ),

        Text(
          description,
          style:
              const TextStyle(
            color:
                AppTheme.gray,
            fontSize: 13,
            height: 1.3,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // DETAIL ROW
  // ============================================================

  Widget _detailRow(
    IconData icon,
    String label,
    String value, {
    int maxLines = 1,
  }) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        vertical: 13,
      ),
      child: Row(
        children: [
          _softIcon(icon),

          const SizedBox(
            width: 12,
          ),

          SizedBox(
            width: 82,
            child: Text(
              label,
              style:
                  const TextStyle(
                color:
                    AppTheme.gray,
                fontSize: 11.5,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(
            width: 8,
          ),

          Expanded(
            child: Tooltip(
              message: value,
              triggerMode:
                  TooltipTriggerMode
                      .longPress,
              child: Text(
                value,
                textAlign:
                    TextAlign.right,
                maxLines:
                    maxLines,
                overflow:
                    TextOverflow
                        .ellipsis,
                style:
                    const TextStyle(
                  color:
                      AppTheme.black,
                  fontSize: 12,
                  height: 1.3,
                  fontWeight:
                      FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _softIcon(
    IconData icon,
  ) {
    return Container(
      width: 34,
      height: 34,
      decoration:
          BoxDecoration(
        color:
            AppTheme.primaryRed
                .withOpacity(
          0.08,
        ),
        borderRadius:
            BorderRadius.circular(
          9,
        ),
      ),
      child: Icon(
        icon,
        color:
            AppTheme.primaryRed,
        size: 18,
      ),
    );
  }

  Widget _divider() {
    return const Divider(
      height: 1,
      color:
          AppTheme.borderGray,
    );
  }

  // ============================================================
  // COMMON CARDS
  // ============================================================

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: AppTheme.white,
      borderRadius:
          BorderRadius.circular(14),
      border: Border.all(
        color:
            AppTheme.borderGray,
      ),
    );
  }

  Widget _messageCard({
    required IconData icon,
    required String message,
    bool isError = false,
  }) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 18,
      ),
      decoration:
          _cardDecoration(),
      child: Row(
        children: [
          Icon(
            icon,
            color:
                isError
                    ? AppTheme.primaryRed
                    : AppTheme.gray,
            size: 20,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              message,
              style:
                  TextStyle(
                color:
                    isError
                        ? AppTheme
                            .primaryRed
                        : AppTheme
                            .gray,
                fontSize: 12,
                height: 1.3,
                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // INPUT BORDER
  // ============================================================

  OutlineInputBorder _inputBorder([
    Color color =
        AppTheme.borderGray,
  ]) {
    return OutlineInputBorder(
      borderRadius:
          BorderRadius.circular(12),
      borderSide:
          BorderSide(
        color: color,
      ),
    );
  }

  // ============================================================
  // MULTI TECHNICIAN INFO
  // ============================================================

  Widget
      _multiTechnicianInstruction() {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration:
          BoxDecoration(
        color:
            Colors.blue.withOpacity(
          0.08,
        ),
        borderRadius:
            BorderRadius.circular(
          10,
        ),
        border: Border.all(
          color:
              Colors.blue
                  .withOpacity(
            0.35,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Icon(
            Icons
                .info_outline_rounded,
            color:
                Colors.blue.shade700,
            size: 16,
          ),

          const SizedBox(
            width: 8,
          ),

          Expanded(
            child: Text(
              'Include all assigned technicians in at least one photo as proof of attendance.',
              style:
                  TextStyle(
                color:
                    Colors.blue
                        .shade700,
                fontSize: 10.8,
                height: 1.35,
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SUBMIT BAR
  // ============================================================

  Widget _submitBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding:
            const EdgeInsets
                .fromLTRB(
          20,
          12,
          20,
          16,
        ),
        decoration:
            const BoxDecoration(
          color:
              AppTheme.white,
          border: Border(
            top: BorderSide(
              color:
                  AppTheme.borderGray,
            ),
          ),
        ),
        child: SizedBox(
          height: 52,
          child:
              ElevatedButton(
            onPressed:
                _isSubmitting ||
                        _isLoadingChemicals
                    ? null
                    : _submitReport,
            style:
                ElevatedButton
                    .styleFrom(
              backgroundColor:
                  AppTheme
                      .primaryRed,
              foregroundColor:
                  AppTheme.white,
              elevation: 0,
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius
                        .circular(
                  14,
                ),
              ),
            ),
            child:
                _isSubmitting
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child:
                            CircularProgressIndicator(
                          strokeWidth:
                              2.5,
                          valueColor:
                              AlwaysStoppedAnimation<
                                  Color>(
                            AppTheme
                                .white,
                          ),
                        ),
                      )
                    : const Row(
                        mainAxisAlignment:
                            MainAxisAlignment
                                .center,
                        children: [
                          Icon(
                            Icons
                                .send_rounded,
                            size: 18,
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Text(
                            'SUBMIT REPORT',
                            style:
                                TextStyle(
                              fontSize:
                                  13,
                              fontWeight:
                                  FontWeight
                                      .w900,
                              letterSpacing:
                                  0.3,
                            ),
                          ),
                        ],
                      ),
          ),
        ),
      ),
    );
  }
}