import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class TechnicianServiceReportCard extends StatelessWidget {
  final String clientName;
  final String service;
  final String pestType;
  final String address;
  final String schedule;
  final String submittedDate;
  final String status;
  final String saNumber;
  final VoidCallback onViewReport;

  const TechnicianServiceReportCard({
    super.key,
    required this.clientName,
    required this.service,
    required this.pestType,
    required this.address,
    required this.schedule,
    required this.submittedDate,
    required this.status,
    required this.saNumber,
    required this.onViewReport,
  });

  @override
  Widget build(BuildContext context) {
    final normalizedStatus = status.trim().toUpperCase();

    final isPending = normalizedStatus == 'DONE SERVICE';

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ====================================================
          // MAIN INFORMATION
          // ====================================================

          Padding(
            padding: const EdgeInsets.fromLTRB(
              16,
              16,
              16,
              14,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ==================================================
                // SERVICE TITLE
                // ==================================================

                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryRed.withOpacity(
                          0.07,
                        ),
                        borderRadius: BorderRadius.circular(
                          10,
                        ),
                      ),
                      child: const Icon(
                        Icons.home_repair_service_outlined,
                        color: AppTheme.primaryRed,
                        size: 17,
                      ),
                    ),

                    const SizedBox(width: 10),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            service,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.black,
                              fontSize: 13.5,
                              height: 1.2,
                              fontWeight: FontWeight.w900,
                            ),
                          ),

                          const SizedBox(height: 3),

                          Text(
                              _formatSaNumber(saNumber),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.gray,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                const Divider(
                  height: 1,
                  thickness: 1,
                  color: AppTheme.borderGray,
                ),

                const SizedBox(height: 10),

                // ==================================================
                // CLIENT
                // ==================================================

                _infoRow(
                  icon: Icons.person_outline_rounded,
                  label: 'Client',
                  value: clientName,
                ),

                const SizedBox(height: 12),

                // ==================================================
                // LOCATION
                // ==================================================

                _infoRow(
                  icon: Icons.location_on_outlined,
                  label: 'Location',
                  value: address,
                  maxLines: 2,
                ),

                const SizedBox(height: 12),

                // ==================================================
                // SCHEDULE
                // ==================================================

                _infoRow(
                  icon: Icons.calendar_month_outlined,
                  label: 'Schedule',
                  value: schedule,
                  maxLines: 2,
                ),

                const SizedBox(height: 12),

                // ==================================================
                // PEST TYPE
                // ==================================================

                _infoRow(
                  icon: Icons.bug_report_outlined,
                  label: 'Pest Type',
                  value: pestType,
                  maxLines: 2,
                ),

                // ==================================================
                // COMPLETED DATE
                // ==================================================

                if (!isPending) ...[
                  const SizedBox(height: 12),

                  _infoRow(
                    icon: Icons.check_circle_outline,
                    label: 'Completed',
                    value: submittedDate,
                    maxLines: 1,
                  ),
                ],
              ],
            ),
          ),

          // ====================================================
          // DIVIDER BEFORE ACTION
          // ====================================================

          const Divider(
            height: 1,
            thickness: 1,
            color: AppTheme.borderGray,
          ),

          // ====================================================
          // ACTION
          // ====================================================

          InkWell(
            onTap: onViewReport,
            borderRadius: const BorderRadius.vertical(
              bottom: Radius.circular(18),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              child: Row(
                children: [
                  Icon(
                    isPending
                        ? Icons.edit_note_rounded
                        : Icons.description_outlined,
                    color: AppTheme.primaryRed,
                    size: 20,
                  ),

                  const SizedBox(width: 9),

                  Expanded(
                    child: Text(
                      isPending
                          ? 'Complete Report'
                          : 'View Report',
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),

                  const Icon(
                    Icons.chevron_right_rounded,
                    color: AppTheme.gray,
                    size: 22,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SA NUMBER
  // ============================================================

  String _formatSaNumber(
    dynamic value,
  ) {
    if (value == null) {
      return 'SA #-';
    }

    final String raw =
        value.toString().trim();

    if (raw.isEmpty ||
        raw == '-') {
      return 'SA #-';
    }

    final String cleaned =
        raw
            .toUpperCase()
            .replaceAll(
              'SA-',
              '',
            )
            .replaceAll(
              'SA #',
              '',
            )
            .trim();

    final int? number =
        int.tryParse(
      cleaned,
    );

    if (number == null) {
      return 'SA-$cleaned';
    }

    return 'SA-${number.toString().padLeft(6, '0')}';
  }

  // ============================================================
  // INFORMATION ROW
  // ============================================================

  Widget _infoRow({
    required IconData icon,
    required String label,
    required String value,
    int maxLines = 1,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            top: 2,
          ),
          child: Icon(
            icon,
            color: AppTheme.gray,
            size: 15,
          ),
        ),

        const SizedBox(width: 7),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),

              const SizedBox(height: 2),

              Text(
                value,
                maxLines: maxLines,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 11.5,
                  height: 1.3,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}