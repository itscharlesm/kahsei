import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mobile_app/app/theme.dart';

class ReportAreaPhotosCard extends StatelessWidget {
  final List<XFile> images;
  final int maxImages;
  final VoidCallback onAddPhoto;
  final void Function(int index) onRemovePhoto;
  final bool hasError;
  final bool isMultipleTechnician;

  const ReportAreaPhotosCard({
    super.key,
    required this.images,
    required this.maxImages,
    required this.onAddPhoto,
    required this.onRemovePhoto,
    this.hasError = false,
    this.isMultipleTechnician = false,
  });

  bool get isLimitReached => images.length >= maxImages;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: hasError ? Colors.red.shade400 : AppTheme.borderGray,
          width: hasError ? 1.4 : 1,
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.image_outlined,
            color: AppTheme.black,
            size: 26,
          ),
          const SizedBox(height: 8),
          const Text(
            'Add Area Photos *',
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Capture service area and attendance photos.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),

          if (isMultipleTechnician) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.primaryRed.withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: AppTheme.primaryRed.withOpacity(0.15),
                ),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.groups_2_outlined,
                    color: AppTheme.primaryRed,
                    size: 15,
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'For multiple-technician services, include all assigned technicians in at least one photo.',
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 10.5,
                        height: 1.35,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 14),

          SizedBox(
            width: double.infinity,
            height: 42,
            child: OutlinedButton.icon(
              onPressed: isLimitReached ? null : onAddPhoto,
              icon: const Icon(
                Icons.camera_alt_outlined,
                size: 17,
              ),
              label: Text(
                isLimitReached ? 'Maximum Photos Added' : 'Take Photo',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor:
                    isLimitReached ? AppTheme.gray : AppTheme.primaryRed,
                side: BorderSide(
                  color: isLimitReached
                      ? AppTheme.borderGray
                      : AppTheme.borderGray,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),

          if (images.isNotEmpty) ...[
            const SizedBox(height: 14),
            _imagePreviewRow(),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${images.length} / $maxImages photos added',
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _imagePreviewRow() {
    return SizedBox(
      height: 86,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: isLimitReached ? images.length : images.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          if (index < images.length) {
            return _imageTile(index);
          }

          return _addMoreTile();
        },
      ),
    );
  }

  Widget _imageTile(int index) {
    return SizedBox(
      width: 86,
      height: 86,
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.file(
                File(images[index].path),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: GestureDetector(
              onTap: () => onRemovePhoto(index),
              child: Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: AppTheme.white.withOpacity(0.92),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.close_rounded,
                  color: AppTheme.black,
                  size: 15,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _addMoreTile() {
    return GestureDetector(
      onTap: isLimitReached ? null : onAddPhoto,
      child: Container(
        width: 86,
        height: 86,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomPaint(
          painter: _DashedBorderPainter(),
          child: const Center(
            child: Icon(
              Icons.add_rounded,
              color: AppTheme.black,
              size: 28,
            ),
          ),
        ),
      ),
    );
  }
}

class _DashedBorderPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const dashWidth = 6.0;
    const dashSpace = 4.0;
    const strokeWidth = 1.2;
    const radius = 8.0;

    final paint = Paint()
      ..color = AppTheme.borderGray
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final rect = RRect.fromRectAndRadius(
      Offset.zero & size,
      const Radius.circular(radius),
    );

    final path = Path()..addRRect(rect);

    for (final metric in path.computeMetrics()) {
      double distance = 0.0;
      while (distance < metric.length) {
        final next = distance + dashWidth;
        canvas.drawPath(
          metric.extractPath(distance, next),
          paint,
        );
        distance += dashWidth + dashSpace;
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}