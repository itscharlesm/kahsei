import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/auth/pages/login_page.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_success_dialog.dart';

class ClientChangePasswordPage extends StatefulWidget {
  final String email;

  const ClientChangePasswordPage({
    super.key,
    required this.email,
  });

  @override
  State<ClientChangePasswordPage> createState() =>
      _ClientChangePasswordPageState();
}

class _ClientChangePasswordPageState
    extends State<ClientChangePasswordPage> {
  final TextEditingController currentPasswordController =
      TextEditingController();

  final TextEditingController newPasswordController =
      TextEditingController();

  final TextEditingController confirmPasswordController =
      TextEditingController();

  bool isSaving = false;
  bool isLoading = true;

  bool showCurrentPassword = false;
  bool showNewPassword = false;
  bool showConfirmPassword = false;

  String? currentPasswordError;
  String? newPasswordError;
  String? confirmPasswordError;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    newPasswordController.addListener(
      _onPasswordChanged,
    );

    _initializePage();
  }

  Future<void> _initializePage() async {
    await Future.delayed(
      const Duration(milliseconds: 450),
    );

    if (!mounted) return;

    setState(() {
      isLoading = false;
    });
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    newPasswordController.removeListener(
      _onPasswordChanged,
    );

    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();

    super.dispose();
  }

  // ============================================================
  // PASSWORD CHANGE LISTENER
  // ============================================================

  void _onPasswordChanged() {
    if (!mounted) return;

    setState(() {
      if (newPasswordError != null) {
        newPasswordError = null;
      }
    });
  }

  // ============================================================
  // PASSWORD CONDITIONS
  // ============================================================

  bool get hasMinimumLength {
    return newPasswordController.text.length >= 12;
  }

  bool get hasLetter {
    return RegExp(
      r'[a-zA-Z]',
    ).hasMatch(
      newPasswordController.text,
    );
  }

  bool get hasNumber {
    return RegExp(
      r'\d',
    ).hasMatch(
      newPasswordController.text,
    );
  }

  bool get hasUppercase {
    return RegExp(
      r'[A-Z]',
    ).hasMatch(
      newPasswordController.text,
    );
  }

  bool get hasLowercase {
    return RegExp(
      r'[a-z]',
    ).hasMatch(
      newPasswordController.text,
    );
  }

  bool get hasSpecialCharacter {
    return RegExp(
      r'[^a-zA-Z0-9]',
    ).hasMatch(
      newPasswordController.text,
    );
  }

  // ============================================================
  // PASSWORD STRENGTH
  // ============================================================

  int get passwordStrength {
    final password =
        newPasswordController.text;

    if (password.isEmpty) {
      return 0;
    }

    int score = 0;

    if (password.length >= 8) {
      score++;
    }

    if (password.length >= 12) {
      score++;
    }

    if (hasLetter && hasNumber) {
      score++;
    }

    if (hasUppercase &&
        hasLowercase) {
      score++;
    }

    if (hasSpecialCharacter) {
      score++;
    }

    if (score <= 1) {
      return 1;
    }

    if (score == 2) {
      return 2;
    }

    if (score == 3 ||
        score == 4) {
      return 3;
    }

    return 4;
  }

  String get passwordStrengthLabel {
    switch (passwordStrength) {
      case 1:
        return 'Weak';

      case 2:
        return 'Fair';

      case 3:
        return 'Good';

      case 4:
        return 'Strong';

      default:
        return '';
    }
  }

  Color get passwordStrengthColor {
    switch (passwordStrength) {
      case 1:
        return AppTheme.primaryRed;

      case 2:
        return Colors.orange;

      case 3:
        return Colors.amber.shade700;

      case 4:
        return Colors.green;

      default:
        return AppTheme.borderGray;
    }
  }

  // ============================================================
  // CHANGE PASSWORD
  // ============================================================

  Future<void> _changePassword() async {
    FocusScope.of(context).unfocus();

    final currentPassword =
        currentPasswordController.text;

    final newPassword =
        newPasswordController.text;

    final confirmPassword =
        confirmPasswordController.text;

    // Clear previous errors.
    setState(() {
      currentPasswordError = null;
      newPasswordError = null;
      confirmPasswordError = null;
    });

    // ============================================================
    // CURRENT PASSWORD
    // ============================================================

    if (currentPassword.isEmpty) {
      setState(() {
        currentPasswordError =
            'Enter your current password';
      });

      return;
    }

    // ============================================================
    // NEW PASSWORD REQUIRED
    // ============================================================

    if (newPassword.isEmpty) {
      setState(() {
        newPasswordError =
            'Enter your new password';
      });

      return;
    }

    // ============================================================
    // MINIMUM LENGTH
    // ============================================================

    if (newPassword.length < 12) {
      setState(() {
        newPasswordError =
            'Your password needs at least 12 characters';
      });

      return;
    }

    // ============================================================
    // MAXIMUM LENGTH
    // ============================================================

    if (newPassword.length > 64) {
      setState(() {
        newPasswordError =
            'Your password is too long';
      });

      return;
    }

    // ============================================================
    // LETTER
    // ============================================================

    if (!hasLetter) {
      setState(() {
        newPasswordError =
            'Add at least one letter';
      });

      return;
    }

    // ============================================================
    // NUMBER
    // ============================================================

    if (!hasNumber) {
      setState(() {
        newPasswordError =
            'Add at least one number';
      });

      return;
    }

    // ============================================================
    // CURRENT AND NEW PASSWORD
    // ============================================================

    if (currentPassword ==
        newPassword) {
      setState(() {
        newPasswordError =
            'Choose a password different from your current password';
      });

      return;
    }

    // ============================================================
    // CONFIRM PASSWORD
    // ============================================================

    if (confirmPassword.isEmpty) {
      setState(() {
        confirmPasswordError =
            'Confirm your new password';
      });

      return;
    }

    if (newPassword !=
        confirmPassword) {
      setState(() {
        confirmPasswordError =
            'Passwords do not match';
      });

      return;
    }

    // ============================================================
    // SEND TO BACKEND
    // ============================================================

    setState(() {
      isSaving = true;
    });

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/change-password',
        ),
        headers: const {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email':
              widget.email,
          'current_password':
              currentPassword,
          'new_password':
              newPassword,
          'new_password_confirmation':
              confirmPassword,
        }),
      );

      Map<String, dynamic> data = {};

      try {
        final decoded =
            jsonDecode(
          response.body,
        );

        if (decoded is Map<String, dynamic>) {
          data = decoded;
        }
      } catch (_) {
        // Keep data empty if response is not valid JSON.
      }

      if (!mounted) return;

      // ==========================================================
      // SUCCESS
      // ==========================================================

      if (response.statusCode == 200 &&
          data['success'] == true) {
        currentPasswordController.clear();
        newPasswordController.clear();
        confirmPasswordController.clear();

        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (
            dialogContext,
          ) {
            return AppSuccessDialog(
              icon:
                  Icons.lock_reset_rounded,
              title:
                  'Password Changed',
              message:
                  'Your password has been updated successfully. Please log in again using your new password.',
              buttonText:
                  'Log In',
              onPressed: () {
                if (!mounted) return;

                Navigator.of(context)
                    .pushAndRemoveUntil(
                  MaterialPageRoute(
                    builder: (_) =>
                        const LoginPage(),
                  ),
                  (route) => false,
                );
              },
            );
          },
        );

        return;
      }

      // ==========================================================
      // BACKEND FIELD ERROR
      // ==========================================================

      final field =
          data['field']?.toString();

      final message =
          data['message']?.toString() ??
          'Unable to change your password.';

      if (field ==
          'current_password') {
        setState(() {
          currentPasswordError =
              message;
        });

        return;
      }

      if (field ==
          'new_password') {
        setState(() {
          newPasswordError =
              message;
        });

        return;
      }

      if (field ==
          'new_password_confirmation') {
        setState(() {
          confirmPasswordError =
              message;
        });

        return;
      }

      // ==========================================================
      // LARAVEL VALIDATION ERRORS
      // ==========================================================

      final errors =
          data['errors'];

      if (errors is Map) {
        if (errors['current_password'] !=
            null) {
          setState(() {
            currentPasswordError =
                _firstValidationMessage(
              errors['current_password'],
            );
          });

          return;
        }

        if (errors['new_password'] !=
            null) {
          setState(() {
            newPasswordError =
                _firstValidationMessage(
              errors['new_password'],
            );
          });

          return;
        }

        if (errors[
                'new_password_confirmation'] !=
            null) {
          setState(() {
            confirmPasswordError =
                _firstValidationMessage(
              errors[
                  'new_password_confirmation'],
            );
          });

          return;
        }
      }

      // ==========================================================
      // GENERAL ERROR
      // ==========================================================

      _showMessage(
        message,
      );
    } catch (error) {
      if (!mounted) return;

      _showMessage(
        'Unable to connect to the server. Please try again.',
      );
    } finally {
      if (mounted) {
        setState(() {
          isSaving = false;
        });
      }
    }
  }

  // ============================================================
  // VALIDATION MESSAGE HELPER
  // ============================================================

  String _firstValidationMessage(
    dynamic value,
  ) {
    if (value is List &&
        value.isNotEmpty) {
      return value.first.toString();
    }

    return value.toString();
  }

  // ============================================================
  // GENERAL MESSAGE
  // ============================================================

  void _showMessage(
    String message,
  ) {
    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          message,
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context)
            .unfocus();
      },
      child: Scaffold(
        backgroundColor:
            AppTheme.lightGray,

        appBar:
            const AppBackHeader(
          title:
              'Change Password',
        ),

        body:
            LayoutBuilder(
          builder: (
            context,
            constraints,
          ) {
            return SingleChildScrollView(
              padding:
                  const EdgeInsets.fromLTRB(
                20,
                18,
                20,
                16,
              ),
              child:
                  ConstrainedBox(
                constraints:
                    BoxConstraints(
                  minHeight:
                      constraints.maxHeight -
                          34,
                ),
                child:
                    IntrinsicHeight(
                  child:
                      Column(
                    crossAxisAlignment:
                        CrossAxisAlignment
                            .start,
                    children: [
                      // ==================================================
                      // SECURITY CARD
                      // ==================================================

                      _securityCard(),

                      const SizedBox(
                        height: 24,
                      ),

                      // ==================================================
                      // PASSWORD
                      // ==================================================

                      _sectionLabel(
                        'PASSWORD',
                      ),

                      const SizedBox(
                        height: 10,
                      ),

                      _formCard(
                        children: [
                          // ==============================================
                          // CURRENT PASSWORD
                          // ==============================================

                          _passwordInput(
                            label:
                                'Current Password',
                            controller:
                                currentPasswordController,
                            hintText:
                                'Enter current password',
                            visible:
                                showCurrentPassword,
                            errorText:
                                currentPasswordError,
                            onToggle: () {
                              setState(() {
                                showCurrentPassword =
                                    !showCurrentPassword;
                              });
                            },
                          ),

                          const SizedBox(
                            height: 16,
                          ),

                          // ==============================================
                          // NEW PASSWORD
                          // ==============================================

                          _passwordInput(
                            label:
                                'New Password',
                            controller:
                                newPasswordController,
                            hintText:
                                'Create a new password',
                            visible:
                                showNewPassword,
                            errorText:
                                newPasswordError,
                            onToggle: () {
                              setState(() {
                                showNewPassword =
                                    !showNewPassword;
                              });
                            },
                          ),

                          // ==============================================
                          // PASSWORD STRENGTH
                          // ==============================================

                          if (newPasswordController
                              .text
                              .isNotEmpty) ...[
                            const SizedBox(
                              height: 12,
                            ),

                            _passwordStrengthIndicator(),
                          ],

                          const SizedBox(
                            height: 16,
                          ),

                          // ==============================================
                          // CONFIRM PASSWORD
                          // ==============================================

                          _passwordInput(
                            label:
                                'Confirm New Password',
                            controller:
                                confirmPasswordController,
                            hintText:
                                'Re-enter new password',
                            visible:
                                showConfirmPassword,
                            errorText:
                                confirmPasswordError,
                            textInputAction:
                                TextInputAction.done,
                            onToggle: () {
                              setState(() {
                                showConfirmPassword =
                                    !showConfirmPassword;
                              });
                            },
                            onSubmitted: (_) {
                              if (!isSaving) {
                                _changePassword();
                              }
                            },
                          ),
                        ],
                      ),

                      const SizedBox(
                        height: 12,
                      ),

                      // ==================================================
                      // PASSWORD GUIDE
                      // ==================================================

                      _passwordGuide(),

                      // ==================================================
                      // PUSH BUTTON DOWN
                      // ==================================================

                      const Spacer(),

                      const SizedBox(
                        height: 18,
                      ),

                      // ==================================================
                      // BUTTON
                      // ==================================================

                      SizedBox(
                        width:
                            double.infinity,
                        child:
                            LoadingButton(
                          isLoading:
                              isSaving,
                          onPressed:
                              isSaving
                                  ? null
                                  : _changePassword,
                          child:
                              const Text(
                            'Change Password',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ============================================================
  // SECURITY CARD
  // ============================================================

  Widget _securityCard() {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        18,
      ),
      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFF272727,
        ),
        borderRadius:
            BorderRadius.circular(
          20,
        ),
        boxShadow: [
          BoxShadow(
            color:
                Colors.black
                    .withOpacity(
              0.10,
            ),
            blurRadius:
                18,
            offset:
                const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child:
          Row(
        children: [
          Container(
            width:
                62,
            height:
                62,
            decoration:
                const BoxDecoration(
              color:
                  AppTheme.primaryRed,
              shape:
                  BoxShape.circle,
            ),
            child:
                const Icon(
              Icons.lock_outline_rounded,
              color:
                  AppTheme.white,
              size:
                  28,
            ),
          ),

          const SizedBox(
            width: 15,
          ),

          const Expanded(
            child:
                Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Account Security',
                  style:
                      TextStyle(
                    color:
                        AppTheme.white,
                    fontSize:
                        17,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                SizedBox(
                  height: 6,
                ),

                Text(
                  'Choose a strong password to help protect your account.',
                  style:
                      TextStyle(
                    color:
                        Color(
                      0xFFC7C7C7,
                    ),
                    fontSize:
                        10.5,
                    height:
                        1.4,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PASSWORD STRENGTH
  // ============================================================

  Widget _passwordStrengthIndicator() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Password strength',
              style:
                  TextStyle(
                color:
                    AppTheme.gray,
                fontSize:
                    10,
                fontWeight:
                    FontWeight.w600,
              ),
            ),

            const Spacer(),

            Text(
              passwordStrengthLabel,
              style:
                  TextStyle(
                color:
                    passwordStrengthColor,
                fontSize:
                    10,
                fontWeight:
                    FontWeight.w800,
              ),
            ),
          ],
        ),

        const SizedBox(
          height: 7,
        ),

        Row(
          children:
              List.generate(
            4,
            (
              index,
            ) {
              final active =
                  index <
                      passwordStrength;

              return Expanded(
                child:
                    Container(
                  height:
                      4,
                  margin:
                      EdgeInsets.only(
                    right:
                        index < 3
                            ? 5
                            : 0,
                  ),
                  decoration:
                      BoxDecoration(
                    color:
                        active
                            ? passwordStrengthColor
                            : AppTheme.borderGray,
                    borderRadius:
                        BorderRadius.circular(
                      20,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ============================================================
  // PASSWORD GUIDE
  // ============================================================

  Widget _passwordGuide() {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        14,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.black
                .withOpacity(
          0.035,
        ),
        borderRadius:
            BorderRadius.circular(
          13,
        ),
        border:
            Border.all(
          color:
              AppTheme.black
                  .withOpacity(
            0.08,
          ),
        ),
      ),
      child:
          Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.shield_outlined,
                color:
                    AppTheme.gray,
                size:
                    17,
              ),

              SizedBox(
                width: 8,
              ),

              Text(
                'Create a strong password',
                style:
                    TextStyle(
                  color:
                      AppTheme.black,
                  fontSize:
                      11,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 11,
          ),

          _requirementRow(
            text:
                'At least 12 characters',
            complete:
                hasMinimumLength,
          ),

          const SizedBox(
            height: 7,
          ),

          _requirementRow(
            text:
                'Contains a letter',
            complete:
                hasLetter,
          ),

          const SizedBox(
            height: 7,
          ),

          _requirementRow(
            text:
                'Contains a number',
            complete:
                hasNumber,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // REQUIREMENT ROW
  // ============================================================

  Widget _requirementRow({
    required String text,
    required bool complete,
  }) {
    return Row(
      children: [
        Container(
          width:
              18,
          height:
              18,
          decoration:
              BoxDecoration(
            color:
                complete
                    ? Colors.green.withOpacity(
                        0.10,
                      )
                    : AppTheme.black.withOpacity(
                        0.05,
                      ),
            shape:
                BoxShape.circle,
          ),
          alignment:
              Alignment.center,
          child:
              Icon(
            complete
                ? Icons.check_rounded
                : Icons.circle_outlined,
            color:
                complete
                    ? Colors.green
                    : AppTheme.gray,
            size:
                complete
                    ? 13
                    : 10,
          ),
        ),

        const SizedBox(
          width: 8,
        ),

        Text(
          text,
          style:
              TextStyle(
            color:
                complete
                    ? AppTheme.black
                    : AppTheme.gray,
            fontSize:
                10.5,
            fontWeight:
                complete
                    ? FontWeight.w700
                    : FontWeight.w500,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left: 2,
      ),
      child:
          Text(
        title,
        style:
            const TextStyle(
          color:
              AppTheme.gray,
          fontSize:
              10,
          letterSpacing:
              0.9,
          fontWeight:
              FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // FORM CARD
  // ============================================================

  Widget _formCard({
    required List<Widget>
        children,
  }) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        15,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.white,
        borderRadius:
            BorderRadius.circular(
          17,
        ),
        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),
        boxShadow: [
          BoxShadow(
            color:
                Colors.black
                    .withOpacity(
              0.025,
            ),
            blurRadius:
                10,
            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),
      child:
          Column(
        children:
            children,
      ),
    );
  }

  // ============================================================
  // PASSWORD INPUT
  // ============================================================

  Widget _passwordInput({
    required String label,
    required TextEditingController
        controller,
    required String hintText,
    required bool visible,
    required VoidCallback onToggle,
    String? errorText,
    TextInputAction
        textInputAction =
        TextInputAction.next,
    ValueChanged<String>?
        onSubmitted,
  }) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style:
              const TextStyle(
            color:
                AppTheme.black,
            fontWeight:
                FontWeight.w700,
            fontSize:
                11.5,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        TextField(
          controller:
              controller,

          obscureText:
              !visible,

          enableSuggestions:
              false,

          autocorrect:
              false,

          textInputAction:
              textInputAction,

          onSubmitted:
              onSubmitted,

          style:
              const TextStyle(
            color:
                AppTheme.black,
            fontSize:
                12.5,
            fontWeight:
                FontWeight.w600,
          ),

          decoration:
              InputDecoration(
            hintText:
                hintText,

            errorText:
                errorText,

            errorMaxLines:
                2,

            errorStyle:
                const TextStyle(
              fontSize:
                  11,
            ),

            filled:
                true,

            fillColor:
                AppTheme.white,

            prefixIcon:
                const Icon(
              Icons.lock_outline_rounded,
              color:
                  AppTheme.primaryRed,
              size:
                  19,
            ),

            suffixIcon:
                IconButton(
              onPressed:
                  onToggle,
              icon: Icon(
                visible
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
                color: AppTheme.gray,
                size: 19,
              ),
            ),

            contentPadding:
                const EdgeInsets.symmetric(
              horizontal:
                  13,
              vertical:
                  13,
            ),

            enabledBorder:
                OutlineInputBorder(
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
              borderSide:
                  const BorderSide(
                color:
                    AppTheme.borderGray,
              ),
            ),

            focusedBorder:
                OutlineInputBorder(
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
              borderSide:
                  const BorderSide(
                color:
                    Color(
                  0xFF4A4A4A,
                ),
                width:
                    1.25,
              ),
            ),

            errorBorder:
                OutlineInputBorder(
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
              borderSide:
                  const BorderSide(
                color:
                    AppTheme.primaryRed,
              ),
            ),

            focusedErrorBorder:
                OutlineInputBorder(
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
              borderSide:
                  const BorderSide(
                color:
                    AppTheme.primaryRed,
                width:
                    1.25,
              ),
            ),
          ),
        ),
      ],
    );
  }
}