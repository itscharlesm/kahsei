import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';

import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_sheets/app_bottom_sheet.dart';

import 'package:mobile_app/features/profiles/widgets/technician_edit_profile_skeleton_load.dart';
import 'package:mobile_app/features/profiles/widgets/default_avatar_picker.dart';

class TechnicianEditProfilePage extends StatefulWidget {
  final String email;

  const TechnicianEditProfilePage({super.key, required this.email});

  @override
  State<TechnicianEditProfilePage> createState() =>
      _TechnicianEditProfilePageState();
}

class _TechnicianEditProfilePageState extends State<TechnicianEditProfilePage> {
  XFile? _selectedImage;
  String? _selectedDefaultAvatar;

  bool isSaving = false;
  bool isFetching = true;
  bool _profileLoaded = false;
  bool _hasCachedPreview = false;
  bool isImageRemoved = false;

  String? profileImagePath;

  final TextEditingController firstNameController = TextEditingController();

  final TextEditingController middleNameController = TextEditingController();

  final TextEditingController lastNameController = TextEditingController();

  final TextEditingController birthDateController = TextEditingController();

  final TextEditingController emailController = TextEditingController();

  DateTime? selectedDate;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    emailController.text = widget.email;

    final profile = AuthSessionService.instance.displayProfile.value;
    if (profile?.email == widget.email && profile?.userType == 2) {
      firstNameController.text = formatName(profile?.firstName ?? '');
      middleNameController.text = formatName(profile?.middleName ?? '');
      lastNameController.text = formatName(profile?.lastName ?? '');
      profileImagePath = profile?.avatarPath;
      _hasCachedPreview = [
        profile?.firstName,
        profile?.middleName,
        profile?.lastName,
        profile?.avatarPath,
      ].any((value) => value?.trim().isNotEmpty == true);
    }
    // Keep the fetch for fields outside the display snapshot (e.g. birth date).
    _fetchUserProfile();
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    firstNameController.dispose();
    middleNameController.dispose();
    lastNameController.dispose();
    birthDateController.dispose();
    emailController.dispose();

    super.dispose();
  }

  // ============================================================
  // FORMAT NAME
  // ============================================================

  String formatName(String value) {
    if (value.isEmpty) {
      return '';
    }

    return value
        .toLowerCase()
        .split(' ')
        .map(
          (word) => word.isNotEmpty
              ? '${word[0].toUpperCase()}${word.substring(1)}'
              : '',
        )
        .join(' ');
  }

  // ============================================================
  // FETCH PROFILE
  // ============================================================

  Future<void> _fetchUserProfile() async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/profile'),
        headers: const {'Accept': 'application/json'},
        body: {'email': widget.email},
      );

      final data = jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 && data['success'] == true) {
        final user = data['data'];

        setState(() {
          firstNameController.text = formatName(user['usr_first_name'] ?? '');

          middleNameController.text = formatName(user['usr_middle_name'] ?? '');

          lastNameController.text = formatName(user['usr_last_name'] ?? '');

          birthDateController.text = user['usr_birth_date'] ?? '';

          emailController.text = user['usr_email'] ?? widget.email;

          profileImagePath = user['usr_image_path'];
          _profileLoaded = true;

          isFetching = false;
        });

        return;
      }

      setState(() {
        isFetching = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        isFetching = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Unable to load profile: $error')));
    }
  }

  // ============================================================
  // EDIT SELECTED IMAGE
  // ============================================================

  Future<void> _editSelectedImage() async {
    if (_selectedImage == null) {
      return;
    }

    await _cropImage(_selectedImage!.path);
  }

  // ============================================================
  // CROP IMAGE
  // ============================================================

  Future<void> _cropImage(String imagePath) async {
    final croppedFile = await ImageCropper().cropImage(
      sourcePath: imagePath,

      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),

      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Adjust Profile Photo',
          toolbarColor: AppTheme.primaryRed,
          toolbarWidgetColor: Colors.white,
          lockAspectRatio: true,
        ),

        IOSUiSettings(
          title: 'Adjust Profile Photo',
          aspectRatioLockEnabled: true,
        ),
      ],
    );

    if (croppedFile != null) {
      setState(() {
        _selectedDefaultAvatar = null;
        _selectedImage = XFile(croppedFile.path);

        isImageRemoved = false;
      });
    }
  }

  // ============================================================
  // PICK DATE
  // ============================================================

  Future<void> _pickDate() async {
    final now = DateTime.now();

    DateTime initialDate;

    if (birthDateController.text.isNotEmpty) {
      initialDate =
          DateTime.tryParse(birthDateController.text) ??
          DateTime(now.year - 18, now.month, now.day);
    } else {
      initialDate = DateTime(now.year - 18, now.month, now.day);
    }

    final DateTime? picked = await showDatePicker(
      context: context,

      initialDate: initialDate,

      firstDate: DateTime(1950),

      lastDate: now,

      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.primaryRed,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: AppTheme.black,
              surfaceContainerHigh: Colors.white,
              surfaceContainerHighest: Colors.white,
            ),

            datePickerTheme: DatePickerThemeData(
              backgroundColor: Colors.white,

              surfaceTintColor: Colors.transparent,

              headerBackgroundColor: AppTheme.primaryRed,

              headerForegroundColor: Colors.white,

              dayBackgroundColor: WidgetStateProperty.resolveWith((states) {
                if (states.contains(WidgetState.selected)) {
                  return AppTheme.primaryRed;
                }

                return Colors.transparent;
              }),

              dayForegroundColor: WidgetStateProperty.resolveWith((states) {
                if (states.contains(WidgetState.selected)) {
                  return Colors.white;
                }

                return AppTheme.black;
              }),

              todayBorder: const BorderSide(
                color: AppTheme.primaryRed,
                width: 1,
              ),

              todayForegroundColor: const WidgetStatePropertyAll(
                AppTheme.primaryRed,
              ),

              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),

            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.primaryRed,
                textStyle: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),

          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        selectedDate = picked;

        birthDateController.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  // ============================================================
  // SAVE PROFILE
  // ============================================================

  Future<void> _saveProfile() async {
    if (!_profileLoaded || isFetching) return;
    FocusScope.of(context).unfocus();

    if (firstNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('First name is required.')));

      return;
    }

    if (lastNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Last name is required.')));

      return;
    }

    final store = AuthSessionService.instance.displayProfile;
    if (!store.isActiveAccount(email: widget.email, userType: 2)) return;
    final edit = store.beginEdit();
    if (edit == null) return;

    setState(() {
      isSaving = true;
    });

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/profile/update'),
      );

      // Email remains the current internal identifier.
      // It is not shown as an editable field.
      request.fields['email'] = emailController.text.trim();

      request.fields['first_name'] = firstNameController.text.trim();

      request.fields['middle_name'] = middleNameController.text.trim();

      request.fields['last_name'] = lastNameController.text.trim();

      request.fields['birth_date'] = birthDateController.text.trim();

      request.fields['remove_image'] = isImageRemoved ? '1' : '0';

      if (_selectedImage != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'profile_image',
            _selectedImage!.path,
          ),
        );
      } else if (_selectedDefaultAvatar != null) {
        final avatarData = await rootBundle.load(_selectedDefaultAvatar!);
        request.files.add(
          http.MultipartFile.fromBytes(
            'profile_image',
            avatarData.buffer.asUint8List(
              avatarData.offsetInBytes,
              avatarData.lengthInBytes,
            ),
            filename: _selectedDefaultAvatar!.split('/').last,
          ),
        );
      }

      final streamedResponse = await request.send();

      final response = await http.Response.fromStream(streamedResponse);

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['success'] == true) {
        final published = store.completeEdit(edit, {
          'usr_first_name': request.fields['first_name']!.toUpperCase(),
          'usr_middle_name': request.fields['middle_name']!.isEmpty
              ? null
              : request.fields['middle_name']!.toUpperCase(),
          'usr_last_name': request.fields['last_name']!.toUpperCase(),
          if (data.containsKey('image_path'))
            'usr_image_path': data['image_path']
          else if (request.fields['remove_image'] == '1' && request.files.isEmpty)
            'usr_image_path': null,
        });
        // Current API returns image_path. Reconcile only if an upload response
        // omits it; an absent field must never erase the previous avatar.
        if (published &&
            request.files.isNotEmpty &&
            !data.containsKey('image_path')) {
          unawaited(store.refreshAfterEdit());
        }
      }

      if (!mounted) return;

      if (response.statusCode == 200 && data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully.')),
        );

        Navigator.pop(context, true);

        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data['message'] ?? 'Failed to update profile.')),
      );
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unable to update profile: $error')),
      );
    } finally {
      store.cancelEdit(edit);
      if (mounted) {
        setState(() {
          isSaving = false;
        });
      }
    }
  }

  // ============================================================
  // PICK IMAGE - GALLERY
  // ============================================================

  Future<void> _pickImageFromGallery() async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );

    if (image != null) {
      await _cropImage(image.path);
    }
  }

  // ============================================================
  // PICK IMAGE - CAMERA
  // ============================================================

  Future<void> _pickImageFromCamera() async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 70,
    );

    if (image != null) {
      await _cropImage(image.path);
    }
  }

  // ============================================================
  // PHOTO OPTIONS
  // ============================================================

  Future<void> _chooseDefaultAvatar() async {
    final selected = await DefaultAvatarPicker.show(
      context,
      avatarPaths: DefaultAvatarPicker.technicianAvatarPaths,
      selectedPath: _selectedDefaultAvatar,
    );

    if (selected == null || !mounted) return;

    setState(() {
      _selectedDefaultAvatar = selected;
      _selectedImage = null;
      isImageRemoved = false;
    });
  }

  void _showPhotoOptions() {
    final bool hasImage =
        _selectedDefaultAvatar != null ||
        _selectedImage != null ||
        (profileImagePath != null && profileImagePath!.trim().isNotEmpty);

    showModalBottomSheet(
      context: context,

      isScrollControlled: true,

      backgroundColor: Colors.transparent,

      builder: (context) {
        return AppBottomSheet(
          children: [
            AppBottomSheetItem(
              icon: Icons.face_rounded,
              title: 'Choose an Avatar',
              onTap: () {
                Navigator.pop(context);
                _chooseDefaultAvatar();
              },
            ),

            AppBottomSheetItem(
              icon: Icons.photo_library_outlined,
              title: 'Choose from Gallery',
              onTap: () {
                Navigator.pop(context);

                _pickImageFromGallery();
              },
            ),

            AppBottomSheetItem(
              icon: Icons.camera_alt_outlined,
              title: 'Take a Photo',
              showDivider: hasImage,
              onTap: () {
                Navigator.pop(context);

                _pickImageFromCamera();
              },
            ),

            if (_selectedImage != null) ...[
              AppBottomSheetItem(
                icon: Icons.edit_outlined,
                title: 'Edit Current Photo',
                onTap: () {
                  Navigator.pop(context);

                  _editSelectedImage();
                },
              ),
            ],

            if (hasImage) ...[
              AppBottomSheetItem(
                icon: Icons.delete_outline,
                title: 'Remove Photo',
                showDivider: false,
                isDestructive: true,
                onTap: () {
                  Navigator.pop(context);

                  setState(() {
                    _selectedDefaultAvatar = null;
                    _selectedImage = null;

                    profileImagePath = null;

                    isImageRemoved = true;
                  });
                },
              ),
            ],
          ],
        );
      },
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },

      child: Scaffold(
        backgroundColor: AppTheme.lightGray,

        appBar: const AppBackHeader(title: 'Edit Profile'),

        body: isFetching && !_hasCachedPreview
            ? const TechnicianEditProfileSkeletonLoad()
            : LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),

                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight - 34,
                      ),

                      child: IntrinsicHeight(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: [
                            // ======================================
                            // PROFILE PHOTO CARD
                            // ======================================
                            _profilePhotoCard(),

                            const SizedBox(height: 24),

                            // ======================================
                            // PERSONAL INFORMATION
                            // ======================================
                            _sectionLabel('PERSONAL INFORMATION'),

                            const SizedBox(height: 10),

                            if (!_profileLoaded)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: Text(
                                  isFetching
                                      ? 'Loading profile...'
                                      : 'Unable to load profile. Reopen this page to try again.',
                                  style: const TextStyle(
                                    color: AppTheme.gray,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            _formCard(
                              children: [
                                _input(
                                  label: 'First Name',
                                  controller: firstNameController,
                                  icon: Icons.person_outline_rounded,
                                  hintText: 'Enter first name',
                                ),

                                const SizedBox(height: 16),

                                _input(
                                  label: 'Middle Name',
                                  controller: middleNameController,
                                  icon: Icons.person_outline_rounded,
                                  hintText: 'Enter middle name',
                                  optional: true,
                                ),

                                const SizedBox(height: 16),

                                _input(
                                  label: 'Last Name',
                                  controller: lastNameController,
                                  icon: Icons.person_outline_rounded,
                                  hintText: 'Enter last name',
                                ),

                                const SizedBox(height: 16),

                                GestureDetector(
                                  onTap: _profileLoaded ? _pickDate : null,

                                  child: AbsorbPointer(
                                    child: _input(
                                      label: 'Birth Date',
                                      controller: birthDateController,
                                      icon: Icons.calendar_month_outlined,
                                      hintText: _profileLoaded
                                          ? 'Select birth date'
                                          : isFetching
                                            ? 'Loading...'
                                            : 'Unavailable',
                                      suffixIcon:
                                          Icons.keyboard_arrow_down_rounded,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            // ======================================
                            // PUSH BUTTON TO BOTTOM
                            // ======================================
                            const Spacer(),

                            const SizedBox(height: 18),

                            // ======================================
                            // SAVE BUTTON
                            // ======================================
                            SizedBox(
                              width: double.infinity,

                              child: LoadingButton(
                                isLoading: isSaving,

                                onPressed: isSaving || !_profileLoaded
                                    ? null
                                    : _saveProfile,

                                child: const Text('Save Changes'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  // ============================================================
  // PROFILE PHOTO CARD
  // ============================================================

  Widget _profilePhotoCard() {
    final firstName = firstNameController.text.trim();

    final lastName = lastNameController.text.trim();

    final displayName = '$firstName $lastName'.trim();

    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: const Color(0xFF272727),

        borderRadius: BorderRadius.circular(20),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.10),

            blurRadius: 18,

            offset: const Offset(0, 6),
          ),
        ],
      ),

      child: Row(
        children: [
          // ======================================================
          // PHOTO
          // ======================================================
          GestureDetector(
            onTap: _profileLoaded ? _showPhotoOptions : null,

            child: Stack(
              clipBehavior: Clip.none,

              children: [
                Container(
                  width: 82,

                  height: 82,

                  decoration: BoxDecoration(
                    shape: BoxShape.circle,

                    color: AppTheme.lightGray,

                    border: Border.all(color: AppTheme.white, width: 3),
                  ),

                  child: ClipOval(child: _profileImageWidget()),
                ),

                Positioned(
                  right: -2,

                  bottom: 1,

                  child: Container(
                    width: 29,

                    height: 29,

                    decoration: BoxDecoration(
                      color: AppTheme.white,

                      shape: BoxShape.circle,

                      border: Border.all(color: AppTheme.borderGray),
                    ),

                    alignment: Alignment.center,

                    child: const Icon(
                      Icons.camera_alt_outlined,

                      color: AppTheme.primaryRed,

                      size: 15,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 15),

          // ======================================================
          // DETAILS
          // ======================================================
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  displayName.isNotEmpty ? displayName : 'Profile Photo',
                  softWrap: true,

                  style: const TextStyle(
                    color: AppTheme.white,

                    fontSize: 17,

                    height: 1.2,

                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 7),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,

                    vertical: 4,
                  ),

                  decoration: BoxDecoration(
                    color: AppTheme.primaryRed,

                    borderRadius: BorderRadius.circular(20),
                  ),

                  child: const Text(
                    'TECHNICIAN',

                    style: TextStyle(
                      color: AppTheme.white,

                      fontSize: 8,

                      letterSpacing: 0.5,

                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),

                const SizedBox(height: 9),

                const Text(
                  'Tap the photo to update your profile picture.',

                  style: TextStyle(
                    color: Color(0xFFC7C7C7),

                    fontSize: 10.5,

                    height: 1.35,

                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 8),

          IconButton(
            tooltip: 'Change Photo',

            onPressed: _profileLoaded ? _showPhotoOptions : null,

            icon: const Icon(
              Icons.edit_outlined,

              color: AppTheme.white,

              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PROFILE IMAGE
  // ============================================================

  Widget _profileImageWidget() {
    if (_selectedDefaultAvatar != null) {
      return Image.asset(_selectedDefaultAvatar!, fit: BoxFit.cover);
    }

    if (_selectedImage != null) {
      return Image.file(File(_selectedImage!.path), fit: BoxFit.cover);
    }

    if (profileImagePath != null && profileImagePath!.trim().isNotEmpty) {
      final path = profileImagePath!.trim();

      final imageUrl = path.startsWith('http://') || path.startsWith('https://')
          ? path
          : '${ApiConfig.baseUrl}/$path';

      return Image.network(
        imageUrl,

        fit: BoxFit.cover,

        errorBuilder: (context, error, stackTrace) {
          return _profileImageFallback();
        },
      );
    }

    return _profileImageFallback();
  }

  // ============================================================
  // PROFILE IMAGE FALLBACK
  // ============================================================

  Widget _profileImageFallback() {
    return Container(
      color: AppTheme.lightGray,

      alignment: Alignment.center,

      child: const Icon(Icons.person_rounded, color: AppTheme.gray, size: 40),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 2),

      child: Text(
        title,

        style: const TextStyle(
          color: AppTheme.gray,

          fontSize: 10,

          letterSpacing: 0.9,

          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // FORM CARD
  // ============================================================

  Widget _formCard({required List<Widget> children}) {
    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(15),

      decoration: BoxDecoration(
        color: AppTheme.white,

        borderRadius: BorderRadius.circular(17),

        border: Border.all(color: AppTheme.borderGray),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.025),

            blurRadius: 10,

            offset: const Offset(0, 3),
          ),
        ],
      ),

      child: Column(children: children),
    );
  }

  // ============================================================
  // INPUT FIELD
  // ============================================================

  Widget _input({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    String? hintText,
    bool optional = false,
    IconData? suffixIcon,
    TextInputType keyboard = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,

      children: [
        Row(
          children: [
            Text(
              label,

              style: const TextStyle(
                color: AppTheme.black,

                fontWeight: FontWeight.w700,

                fontSize: 11.5,
              ),
            ),

            if (optional) ...[
              const SizedBox(width: 5),

              const Text(
                '(Optional)',

                style: TextStyle(
                  color: AppTheme.gray,

                  fontWeight: FontWeight.w500,

                  fontSize: 9.5,
                ),
              ),
            ],
          ],
        ),

        const SizedBox(height: 7),

        TextField(
          controller: controller,
          readOnly: !_profileLoaded,

          keyboardType: keyboard,

          style: const TextStyle(
            color: AppTheme.black,

            fontSize: 12.5,

            fontWeight: FontWeight.w600,
          ),

          decoration: InputDecoration(
            hintText: hintText,

            filled: true,

            fillColor: AppTheme.white,

            prefixIcon: Icon(icon, color: AppTheme.primaryRed, size: 19),

            suffixIcon: suffixIcon != null
                ? Icon(suffixIcon, color: AppTheme.gray, size: 19)
                : null,

            contentPadding: const EdgeInsets.symmetric(
              horizontal: 13,

              vertical: 13,
            ),

            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),

              borderSide: const BorderSide(color: AppTheme.borderGray),
            ),

            // Focus is neutral dark gray.
            // Red is reserved for branding/errors.
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),

              borderSide: const BorderSide(
                color: Color(0xFF4A4A4A),

                width: 1.25,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
