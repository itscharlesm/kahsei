import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/auth/pages/login_page.dart';

import 'package:mobile_app/features/profiles/pages/technician_edit_profile_page.dart';
import 'package:mobile_app/features/profiles/pages/technician_change_password.dart';

import 'package:mobile_app/features/profiles/widgets/technician_profile_skeleton_load.dart';

import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_confirmation_dialog.dart';
import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';

class TechnicianProfilePage extends StatefulWidget {
  final String email;

  const TechnicianProfilePage({
    super.key,
    required this.email,
  });

  @override
  State<TechnicianProfilePage> createState() =>
      _TechnicianProfilePageState();
}

class _TechnicianProfilePageState
    extends State<TechnicianProfilePage> {
  bool isLoading = true;

  String fullName = '';
  String? profileImagePath;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _syncSharedProfile();
    AuthSessionService.instance.displayProfile.listenable.addListener(
      _syncSharedProfile,
    );
    unawaited(_loadSharedProfile());
  }

  // ============================================================
  // NAME FORMAT
  // ============================================================

  String formatName(
    String value,
  ) {
    if (value.isEmpty) {
      return '';
    }

    return value
        .toLowerCase()
        .split(' ')
        .map(
          (word) => word.isNotEmpty
              ? '${word[0].toUpperCase()}${word.substring(1)}'
              : '',
        )
        .join(' ');
  }

  // ============================================================
  // FETCH PROFILE
  // ============================================================

  void _syncSharedProfile() {
    if (!mounted) return;
    final profile = AuthSessionService.instance.displayProfile.value;
    final matches = profile?.email == widget.email && profile?.userType == 2;
    setState(() {
      final firstName = formatName(matches ? profile?.firstName ?? '' : '');
      final lastName = formatName(matches ? profile?.lastName ?? '' : '');
      fullName = '$firstName $lastName'.trim();
      profileImagePath = matches ? profile?.avatarPath : null;
      if (matches) isLoading = false;
    });
  }

  Future<void> _loadSharedProfile() async {
    await AuthSessionService.instance.displayProfile.ensureLoaded(
      email: widget.email,
      userType: 2,
    );
    if (!mounted) return;
    _syncSharedProfile();
    setState(() => isLoading = false);
  }

  Future<void> _fetchProfile() async {
    final store = AuthSessionService.instance.displayProfile;
    if (!store.isActiveAccount(email: widget.email, userType: 2)) return;
    await store.refresh();
  }

  @override
  void dispose() {
    AuthSessionService.instance.displayProfile.listenable.removeListener(
      _syncSharedProfile,
    );
    super.dispose();
  }

  // ============================================================
  // PROFILE IMAGE
  // ============================================================

  String? get profileImageUrl {
    if (profileImagePath == null ||
        profileImagePath!
            .trim()
            .isEmpty) {
      return null;
    }

    final path =
        profileImagePath!
            .trim();

    if (path.startsWith(
          'http://',
        ) ||
        path.startsWith(
          'https://',
        )) {
      return path;
    }

    return '${ApiConfig.baseUrl}/$path';
  }

  // ============================================================
  // EDIT PROFILE
  // ============================================================

  Future<void> _openEditProfile() async {
    final bool? updated =
        await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TechnicianEditProfilePage(
          email:
              widget.email,
        ),
      ),
    );

    if (!mounted) return;

    if (updated == true) {
      _syncSharedProfile();
    }
  }

  // ============================================================
  // CHANGE PASSWORD
  // ============================================================

  Future<void> _openChangePassword() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TechnicianChangePasswordPage(
          email:
              widget.email,
        ),
      ),
    );
  }

  // ============================================================
  // LOG OUT
  // ============================================================

  Future<void> _confirmLogout() async {
    await showDialog<void>(
      context:
          context,

      barrierDismissible:
          false,

      builder: (
        dialogContext,
      ) {
        return AppConfirmationDialog(
          icon:
              Icons.logout_rounded,

          title:
              'Log Out?',

          message:
              'Are you sure you want to log out from your account?',

          cancelText:
              'No',

          confirmText:
              'Yes',

          onConfirm: () {
            if (!mounted) return;

            Navigator.of(context)
                .pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (_) =>
                    const LoginPage(),
              ),
              (route) =>
                  false,
            );
          },
        );
      },
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      drawer:
          AppDrawer(
        userType:
            2,

        email:
            widget.email,

        currentPage:
            'profile',
      ),

      appBar:
          const AppTitleHeader(
        title:
            'My Profile',
      ),

      // ========================================================
      // TECHNICIAN BOTTOM NAVIGATION
      // ========================================================

      bottomNavigationBar:
          TechnicianBottomNavBar(
        currentIndex:
            1,

        email:
            widget.email,
      ),

      body:
          isLoading
              ? const TechnicianProfileSkeletonLoad()
              : RefreshIndicator(
                  color:
                      AppTheme.primaryRed,

                  onRefresh:
                      _fetchProfile,

                  child:
                      SingleChildScrollView(
                    physics:
                        const AlwaysScrollableScrollPhysics(),

                    padding:
                        const EdgeInsets.fromLTRB(
                      20,
                      18,
                      20,
                      30,
                    ),

                    child:
                        Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [
                        // ==================================================
                        // PROFILE CARD
                        // ==================================================

                        _profileCard(),

                        const SizedBox(
                          height:
                              24,
                        ),

                        // ==================================================
                        // ACCOUNT
                        // ==================================================

                        _sectionLabel(
                          'ACCOUNT',
                        ),

                        const SizedBox(
                          height:
                              10,
                        ),

                        _accountCard(),

                        const SizedBox(
                          height:
                              24,
                        ),

                        // ==================================================
                        // SESSION
                        // ==================================================

                        _sectionLabel(
                          'SESSION',
                        ),

                        const SizedBox(
                          height:
                              10,
                        ),

                        _sessionCard(),

                        const SizedBox(
                          height:
                              28,
                        ),

                        const Center(
                          child:
                              Text(
                            'Manage your profile and account security.',

                            textAlign:
                                TextAlign.center,

                            style:
                                TextStyle(
                              color:
                                  AppTheme.gray,

                              fontSize:
                                  10.5,

                              height:
                                  1.4,

                              fontWeight:
                                  FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }

  // ============================================================
  // PROFILE CARD
  // ============================================================

  Widget _profileCard() {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        18,
      ),

      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFF272727,
        ),

        borderRadius:
            BorderRadius.circular(
          20,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.10,
            ),

            blurRadius:
                18,

            offset:
                const Offset(
              0,
              6,
            ),
          ),
        ],
      ),

      child:
          Row(
        crossAxisAlignment:
            CrossAxisAlignment.center,

        children: [
          // ======================================================
          // AVATAR
          // ======================================================

          Stack(
            clipBehavior:
                Clip.none,

            children: [
              Container(
                width:
                    78,

                height:
                    78,

                decoration:
                    BoxDecoration(
                  shape:
                      BoxShape.circle,

                  color:
                      AppTheme.lightGray,

                  border:
                      Border.all(
                    color:
                        AppTheme.white,

                    width:
                        3,
                  ),
                ),

                child:
                    ClipOval(
                  child:
                      profileImageUrl != null
                          ? Image.network(
                              profileImageUrl!,

                              fit:
                                  BoxFit.cover,

                              errorBuilder: (
                                context,
                                error,
                                stackTrace,
                              ) {
                                return _avatarFallback();
                              },
                            )
                          : _avatarFallback(),
                ),
              ),

              Positioned(
                right:
                    -2,

                bottom:
                    1,

                child:
                    Material(
                  color:
                      AppTheme.white,

                  shape:
                      const CircleBorder(),

                  elevation:
                      2,

                  child:
                      InkWell(
                    customBorder:
                        const CircleBorder(),

                    onTap:
                        _openEditProfile,

                    child:
                        Container(
                      width:
                          28,

                      height:
                          28,

                      alignment:
                          Alignment.center,

                      child:
                          const Icon(
                        Icons.camera_alt_outlined,

                        color:
                            AppTheme.primaryRed,

                        size:
                            15,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            width:
                15,
          ),

          // ======================================================
          // INFO
          // ======================================================

          Expanded(
            child:
                Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  fullName.isNotEmpty
                      ? fullName
                      : 'Technician',
                  softWrap: true,

                  style:
                      const TextStyle(
                    color:
                        AppTheme.white,

                    fontSize:
                        18,

                    height:
                        1.2,

                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                const SizedBox(
                  height:
                      7,
                ),

                // ==================================================
                // TECHNICIAN BADGE
                // ==================================================

                Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal:
                        9,

                    vertical:
                        4,
                  ),

                  decoration:
                      BoxDecoration(
                    color:
                        AppTheme.primaryRed,

                    borderRadius:
                        BorderRadius.circular(
                      20,
                    ),
                  ),

                  child:
                      const Text(
                    'TECHNICIAN',

                    style:
                        TextStyle(
                      color:
                          AppTheme.white,

                      fontSize:
                          8,

                      letterSpacing:
                          0.5,

                      fontWeight:
                          FontWeight.w900,
                    ),
                  ),
                ),

                const SizedBox(
                  height:
                      9,
                ),

                Row(
                  children: [
                    const Icon(
                      Icons.mail_outline_rounded,

                      color:
                          Color(
                        0xFFBDBDBD,
                      ),

                      size:
                          14,
                    ),

                    const SizedBox(
                      width:
                          6,
                    ),

                    Expanded(
                      child:
                          Text(
                        widget.email,

                        maxLines:
                            1,

                        overflow:
                            TextOverflow.ellipsis,

                        style:
                            const TextStyle(
                          color:
                              Color(
                            0xFFD6D6D6,
                          ),

                          fontSize:
                              10.5,

                          fontWeight:
                              FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ======================================================
          // EDIT
          // ======================================================

          IconButton(
            tooltip:
                'Edit Profile',

            onPressed:
                _openEditProfile,

            icon:
                const Icon(
              Icons.edit_outlined,

              color:
                  AppTheme.white,

              size:
                  20,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // AVATAR FALLBACK
  // ============================================================

  Widget _avatarFallback() {
    return Container(
      color:
          AppTheme.lightGray,

      alignment:
          Alignment.center,

      child:
          const Icon(
        Icons.person_rounded,

        size:
            38,

        color:
            AppTheme.gray,
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left:
            2,
      ),

      child:
          Text(
        title,

        style:
            const TextStyle(
          color:
              AppTheme.gray,

          fontSize:
              10,

          letterSpacing:
              0.9,

          fontWeight:
              FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // ACCOUNT CARD
  // ============================================================

  Widget _accountCard() {
    return _menuCard(
      children: [
        _menuTile(
          icon:
              Icons.person_outline_rounded,

          title:
              'Edit Profile',

          subtitle:
              'Update your personal information',

          onTap:
              _openEditProfile,
        ),

        _menuDivider(),

        _menuTile(
          icon:
              Icons.lock_outline_rounded,

          title:
              'Change Password',

          subtitle:
              'Update your account password',

          onTap:
              _openChangePassword,
        ),
      ],
    );
  }

  // ============================================================
  // SESSION CARD
  // ============================================================

  Widget _sessionCard() {
    return _menuCard(
      children: [
        _menuTile(
          icon:
              Icons.logout_rounded,

          title:
              'Log Out',

          subtitle:
              'Log out from your account',

          onTap:
              _confirmLogout,

          destructive:
              true,
        ),
      ],
    );
  }

  // ============================================================
  // MENU CARD
  // ============================================================

  Widget _menuCard({
    required List<Widget> children,
  }) {
    return Container(
      width:
          double.infinity,

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          17,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.025,
            ),

            blurRadius:
                10,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          Column(
        children:
            children,
      ),
    );
  }

  // ============================================================
  // MENU TILE
  // ============================================================

  Widget _menuTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool destructive = false,
  }) {
    return Material(
      color:
          Colors.transparent,

      child:
          InkWell(
        onTap:
            onTap,

        borderRadius:
            BorderRadius.circular(
          17,
        ),

        splashColor:
            AppTheme.primaryRed.withOpacity(
          0.06,
        ),

        highlightColor:
            AppTheme.primaryRed.withOpacity(
          0.03,
        ),

        child:
            Padding(
          padding:
              const EdgeInsets.symmetric(
            horizontal:
                14,

            vertical:
                14,
          ),

          child:
              Row(
            crossAxisAlignment:
                CrossAxisAlignment.center,

            children: [
              Container(
                width:
                    40,

                height:
                    40,

                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed.withOpacity(
                    0.07,
                  ),

                  borderRadius:
                      BorderRadius.circular(
                    11,
                  ),
                ),

                child:
                    Icon(
                  icon,

                  size:
                      20,

                  color:
                      AppTheme.primaryRed,
                ),
              ),

              const SizedBox(
                width:
                    12,
              ),

              Expanded(
                child:
                    Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [
                    Text(
                      title,

                      style:
                          TextStyle(
                        color:
                            destructive
                                ? AppTheme.primaryRed
                                : AppTheme.black,

                        fontSize:
                            13,

                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),

                    const SizedBox(
                      height:
                          4,
                    ),

                    Text(
                      subtitle,

                      style:
                          const TextStyle(
                        color:
                            AppTheme.gray,

                        fontSize:
                            10.5,

                        height:
                            1.35,

                        fontWeight:
                            FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                width:
                    10,
              ),

              Icon(
                Icons.chevron_right_rounded,

                color:
                    destructive
                        ? AppTheme.primaryRed
                        : AppTheme.gray,

                size:
                    21,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // DIVIDER
  // ============================================================

  Widget _menuDivider() {
    return const Padding(
      padding:
          EdgeInsets.only(
        left:
            66,

        right:
            14,
      ),

      child:
          Divider(
        height:
            1,

        color:
            AppTheme.borderGray,
      ),
    );
  }
}