import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class ClientProfileSkeletonLoad extends StatelessWidget {
  const ClientProfileSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        20,
        18,
        20,
        30,
      ),
      child: const Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          // ==================================================
          // PROFILE CARD
          // ==================================================

          _ProfileCardSkeleton(),

          SizedBox(
            height: 24,
          ),

          // ==================================================
          // ACCOUNT
          // ==================================================

          _SectionLabelSkeleton(
            width: 58,
          ),

          SizedBox(
            height: 10,
          ),

          _MenuCardSkeleton(
            itemCount: 2,
          ),

          SizedBox(
            height: 24,
          ),

          // ==================================================
          // SESSION
          // ==================================================

          _SectionLabelSkeleton(
            width: 56,
          ),

          SizedBox(
            height: 10,
          ),

          _MenuCardSkeleton(
            itemCount: 1,
          ),

          SizedBox(
            height: 28,
          ),

          // ==================================================
          // FOOTER TEXT
          // ==================================================

          Center(
            child: AppShimmer(
              child: AppSkeletonLine(
                width: 220,
                height: 10,
                radius: 5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// PROFILE CARD SKELETON
// ============================================================

class _ProfileCardSkeleton extends StatelessWidget {
  const _ProfileCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        18,
      ),
      decoration: BoxDecoration(
        color: const Color(
          0xFF272727,
        ),
        borderRadius: BorderRadius.circular(
          20,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.10,
            ),
            blurRadius: 18,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: const AppShimmer(
        child: Row(
          crossAxisAlignment:
              CrossAxisAlignment.center,
          children: [
            // ======================================================
            // AVATAR
            // ======================================================

            AppSkeletonLine(
              width: 78,
              height: 78,
              radius: 50,
            ),

            SizedBox(
              width: 15,
            ),

            // ======================================================
            // PROFILE INFO
            // ======================================================

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width: 145,
                    height: 16,
                    radius: 6,
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  AppSkeletonLine(
                    width: 52,
                    height: 18,
                    radius: 20,
                  ),

                  SizedBox(
                    height: 10,
                  ),

                  Row(
                    children: [
                      AppSkeletonLine(
                        width: 14,
                        height: 14,
                        radius: 5,
                      ),

                      SizedBox(
                        width: 6,
                      ),

                      Expanded(
                        child: AppSkeletonLine(
                          width:
                              double.infinity,
                          height: 10,
                          radius: 5,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(
              width: 10,
            ),

            // ======================================================
            // EDIT ICON
            // ======================================================

            AppSkeletonLine(
              width: 25,
              height: 25,
              radius: 50,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL SKELETON
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  final double width;

  const _SectionLabelSkeleton({
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return AppShimmer(
      child: AppSkeletonLine(
        width: width,
        height: 10,
        radius: 5,
      ),
    );
  }
}

// ============================================================
// MENU CARD SKELETON
// ============================================================

class _MenuCardSkeleton extends StatelessWidget {
  final int itemCount;

  const _MenuCardSkeleton({
    required this.itemCount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          17,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.025,
            ),
            blurRadius: 10,
            offset: const Offset(
              0,
              3,
            ),
          ),
        ],
      ),
      child: Column(
        children: List.generate(
          itemCount,
          (index) {
            return Column(
              children: [
                const _MenuItemSkeleton(),

                if (index <
                    itemCount - 1)
                  const Padding(
                    padding:
                        EdgeInsets.only(
                      left: 66,
                      right: 14,
                    ),
                    child: Divider(
                      height: 1,
                      color:
                          AppTheme.borderGray,
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// MENU ITEM SKELETON
// ============================================================

class _MenuItemSkeleton extends StatelessWidget {
  const _MenuItemSkeleton();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(
        14,
      ),
      child: AppShimmer(
        child: Row(
          crossAxisAlignment:
              CrossAxisAlignment.center,
          children: [
            // ======================================================
            // ICON
            // ======================================================

            AppSkeletonLine(
              width: 40,
              height: 40,
              radius: 11,
            ),

            SizedBox(
              width: 12,
            ),

            // ======================================================
            // TEXT
            // ======================================================

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width: 118,
                    height: 12,
                    radius: 5,
                  ),

                  SizedBox(
                    height: 7,
                  ),

                  AppSkeletonLine(
                    width: 205,
                    height: 10,
                    radius: 5,
                  ),
                ],
              ),
            ),

            SizedBox(
              width: 10,
            ),

            // ======================================================
            // CHEVRON
            // ======================================================

            AppSkeletonLine(
              width: 20,
              height: 20,
              radius: 50,
            ),
          ],
        ),
      ),
    );
  }
}