import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class TechnicianEditProfileSkeletonLoad extends StatelessWidget {
  const TechnicianEditProfileSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            18,
            20,
            16,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight:
                  constraints.maxHeight - 34,
            ),
            child: const IntrinsicHeight(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  // ==================================================
                  // PROFILE PHOTO CARD
                  // ==================================================

                  _ProfilePhotoCardSkeleton(),

                  SizedBox(
                    height: 24,
                  ),

                  // ==================================================
                  // PERSONAL INFORMATION
                  // ==================================================

                  _SectionLabelSkeleton(),

                  SizedBox(
                    height: 10,
                  ),

                  _FormCardSkeleton(),

                  // ==================================================
                  // PUSH BUTTON TO BOTTOM
                  // ==================================================

                  Spacer(),

                  SizedBox(
                    height: 18,
                  ),

                  // ==================================================
                  // SAVE BUTTON
                  // ==================================================

                  _ButtonSkeleton(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// PROFILE PHOTO CARD SKELETON
// ============================================================

class _ProfilePhotoCardSkeleton extends StatelessWidget {
  const _ProfilePhotoCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        18,
      ),
      decoration: BoxDecoration(
        color: const Color(
          0xFF272727,
        ),
        borderRadius: BorderRadius.circular(
          20,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.10,
            ),
            blurRadius: 18,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: const AppShimmer(
        child: Row(
          crossAxisAlignment:
              CrossAxisAlignment.center,
          children: [
            // ======================================================
            // PROFILE IMAGE
            // ======================================================

            Stack(
              clipBehavior:
                  Clip.none,
              children: [
                AppSkeletonLine(
                  width: 82,
                  height: 82,
                  radius: 50,
                ),

                Positioned(
                  right: -2,
                  bottom: 1,
                  child: AppSkeletonLine(
                    width: 29,
                    height: 29,
                    radius: 50,
                  ),
                ),
              ],
            ),

            SizedBox(
              width: 15,
            ),

            // ======================================================
            // PROFILE DETAILS
            // ======================================================

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width: 145,
                    height: 16,
                    radius: 6,
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  // TECHNICIAN badge placeholder
                  AppSkeletonLine(
                    width: 78,
                    height: 18,
                    radius: 20,
                  ),

                  SizedBox(
                    height: 10,
                  ),

                  AppSkeletonLine(
                    width: double.infinity,
                    height: 10,
                    radius: 5,
                  ),

                  SizedBox(
                    height: 6,
                  ),

                  AppSkeletonLine(
                    width: 165,
                    height: 10,
                    radius: 5,
                  ),
                ],
              ),
            ),

            SizedBox(
              width: 8,
            ),

            // ======================================================
            // EDIT ICON
            // ======================================================

            AppSkeletonLine(
              width: 28,
              height: 28,
              radius: 50,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL SKELETON
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  const _SectionLabelSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child: AppSkeletonLine(
        width: 142,
        height: 10,
        radius: 5,
      ),
    );
  }
}

// ============================================================
// FORM CARD SKELETON
// ============================================================

class _FormCardSkeleton extends StatelessWidget {
  const _FormCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        15,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          17,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.025,
            ),
            blurRadius: 10,
            offset: const Offset(
              0,
              3,
            ),
          ),
        ],
      ),
      child: const Column(
        children: [
          // First Name
          _InputSkeleton(),

          SizedBox(
            height: 16,
          ),

          // Middle Name
          _InputSkeleton(
            labelWidth: 105,
          ),

          SizedBox(
            height: 16,
          ),

          // Last Name
          _InputSkeleton(),

          SizedBox(
            height: 16,
          ),

          // Birth Date
          _InputSkeleton(
            labelWidth: 72,
            hasSuffix: true,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// INPUT SKELETON
// ============================================================

class _InputSkeleton extends StatelessWidget {
  final double labelWidth;
  final bool hasSuffix;

  const _InputSkeleton({
    this.labelWidth = 88,
    this.hasSuffix = false,
  });

  @override
  Widget build(BuildContext context) {
    return AppShimmer(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          AppSkeletonLine(
            width: labelWidth,
            height: 11,
            radius: 5,
          ),

          const SizedBox(
            height: 7,
          ),

          _InputBoxSkeleton(
            hasSuffix: hasSuffix,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// INPUT BOX SKELETON
// ============================================================

class _InputBoxSkeleton extends StatelessWidget {
  final bool hasSuffix;

  const _InputBoxSkeleton({
    required this.hasSuffix,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 52,
      padding: const EdgeInsets.symmetric(
        horizontal: 13,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          12,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        children: [
          // Prefix icon
          const AppSkeletonLine(
            width: 19,
            height: 19,
            radius: 5,
          ),

          const SizedBox(
            width: 11,
          ),

          // Input text
          const Expanded(
            child: AppSkeletonLine(
              width: double.infinity,
              height: 11,
              radius: 5,
            ),
          ),

          if (hasSuffix) ...[
            const SizedBox(
              width: 18,
            ),

            const AppSkeletonLine(
              width: 19,
              height: 19,
              radius: 50,
            ),
          ] else
            const SizedBox(
              width: 8,
            ),
        ],
      ),
    );
  }
}

// ============================================================
// SAVE BUTTON SKELETON
// ============================================================

class _ButtonSkeleton extends StatelessWidget {
  const _ButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child: AppSkeletonLine(
        width: double.infinity,
        height: 50,
        radius: 14,
      ),
    );
  }
}