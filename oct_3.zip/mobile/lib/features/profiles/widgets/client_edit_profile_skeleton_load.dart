import 'package:flutter/material.dart';

import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class ClientEditProfileSkeletonLoad extends StatelessWidget {
  const ClientEditProfileSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            18,
            20,
            16,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight:
                  constraints.maxHeight - 34,
            ),
            child: const IntrinsicHeight(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  // ==================================================
                  // PROFILE CARD
                  // ==================================================

                  _ProfileCardSkeleton(),

                  SizedBox(
                    height: 24,
                  ),

                  // ==================================================
                  // SECTION LABEL
                  // ==================================================

                  _SectionLabelSkeleton(),

                  SizedBox(
                    height: 10,
                  ),

                  // ==================================================
                  // FORM CARD
                  // ==================================================

                  _FormCardSkeleton(),

                  // ==================================================
                  // PUSH BUTTON TO BOTTOM
                  // ==================================================

                  Spacer(),

                  SizedBox(
                    height: 18,
                  ),

                  // ==================================================
                  // BUTTON
                  // ==================================================

                  _ButtonSkeleton(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// PROFILE CARD SKELETON
// ============================================================

class _ProfileCardSkeleton extends StatelessWidget {
  const _ProfileCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        18,
      ),
      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFF272727,
        ),
        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),
      child:
          const AppShimmer(
        child:
            Row(
          children: [
            // ======================================================
            // AVATAR
            // ======================================================

            AppSkeletonLine(
              width:
                  82,
              height:
                  82,
              radius:
                  50,
            ),

            SizedBox(
              width:
                  15,
            ),

            // ======================================================
            // DETAILS
            // ======================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width:
                        145,
                    height:
                        16,
                    radius:
                        6,
                  ),

                  SizedBox(
                    height:
                        9,
                  ),

                  AppSkeletonLine(
                    width:
                        54,
                    height:
                        18,
                    radius:
                        20,
                  ),

                  SizedBox(
                    height:
                        10,
                  ),

                  AppSkeletonLine(
                    width:
                        180,
                    height:
                        10,
                    radius:
                        5,
                  ),
                ],
              ),
            ),

            SizedBox(
              width:
                  10,
            ),

            AppSkeletonLine(
              width:
                  26,
              height:
                  26,
              radius:
                  50,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL SKELETON
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  const _SectionLabelSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child:
          AppSkeletonLine(
        width:
            125,
        height:
            10,
        radius:
            5,
      ),
    );
  }
}

// ============================================================
// FORM CARD SKELETON
// ============================================================

class _FormCardSkeleton extends StatelessWidget {
  const _FormCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        15,
      ),
      decoration:
          BoxDecoration(
        color:
            Colors.white,
        borderRadius:
            BorderRadius.circular(
          17,
        ),
        border:
            Border.all(
          color:
              const Color(
            0xFFE5E5E5,
          ),
        ),
      ),
      child:
          const Column(
        children: [
          _InputSkeleton(),

          SizedBox(
            height:
                16,
          ),

          _InputSkeleton(),

          SizedBox(
            height:
                16,
          ),

          _InputSkeleton(),

          SizedBox(
            height:
                16,
          ),

          _InputSkeleton(
            hasSuffix:
                true,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// INPUT SKELETON
// ============================================================

class _InputSkeleton extends StatelessWidget {
  final bool hasSuffix;

  const _InputSkeleton({
    this.hasSuffix = false,
  });

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child:
          Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          AppSkeletonLine(
            width:
                88,
            height:
                11,
            radius:
                5,
          ),

          SizedBox(
            height:
                7,
          ),

          _InputBoxSkeleton(),
        ],
      ),
    );
  }
}

// ============================================================
// INPUT BOX SKELETON
// ============================================================

class _InputBoxSkeleton extends StatelessWidget {
  const _InputBoxSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,
      height:
          52,
      padding:
          const EdgeInsets.symmetric(
        horizontal:
            13,
      ),
      decoration:
          BoxDecoration(
        borderRadius:
            BorderRadius.circular(
          12,
        ),
        border:
            Border.all(
          color:
              const Color(
            0xFFE2E2E2,
          ),
        ),
      ),
      child:
          const Row(
        children: [
          AppSkeletonLine(
            width:
                20,
            height:
                20,
            radius:
                6,
          ),

          SizedBox(
            width:
                11,
          ),

          Expanded(
            child:
                AppSkeletonLine(
              width:
                  double.infinity,
              height:
                  11,
              radius:
                  5,
            ),
          ),

          SizedBox(
            width:
                30,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// BUTTON SKELETON
// ============================================================

class _ButtonSkeleton extends StatelessWidget {
  const _ButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child:
          AppSkeletonLine(
        width:
            double.infinity,
        height:
            50,
        radius:
            14,
      ),
    );
  }
}