import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/bottom_sheets/app_bottom_sheet.dart';

class DefaultAvatarPicker {
  static const List<String> clientAvatarPaths = [
    'assets/images/img_client_avatar_01.jpg',
    'assets/images/img_client_avatar_04.jpg',
    'assets/images/img_client_avatar_06.jpg',
    'assets/images/img_client_avatar_02.jpg',
    'assets/images/img_client_avatar_05.jpg',
    'assets/images/img_client_avatar_03.jpg',
  ];

  static const List<String> technicianAvatarPaths = [
    'assets/images/img_technician_avatar_01.jpg',
    'assets/images/img_technician_avatar_02.jpg',
    'assets/images/img_technician_avatar_03.jpg',
    'assets/images/img_technician_avatar_04.jpg',
    'assets/images/img_technician_avatar_05.jpg',
    'assets/images/img_technician_avatar_06.jpg',
  ];

  static Future<String?> show(
    BuildContext context, {
    required List<String> avatarPaths,
    String? selectedPath,
    bool isDismissible = true,
    bool enableDrag = true,
  }) {
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: isDismissible,
      enableDrag: enableDrag,
      constraints: BoxConstraints(
        minWidth: MediaQuery.sizeOf(context).width,
        maxWidth: MediaQuery.sizeOf(context).width,
      ),
      builder: (context) {
        return AppBottomSheet(
          backgroundColor: Colors.white,
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 28),
          children: [
            const Text(
              'Choose an Avatar',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'You can replace it with your own photo anytime.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.gray, fontSize: 13),
            ),
            const SizedBox(height: 22),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 18,
              runSpacing: 18,
              children: avatarPaths.map((path) {
                final isSelected = path == selectedPath;
                return InkWell(
                  onTap: () => Navigator.pop(context, path),
                  customBorder: const CircleBorder(),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 82,
                    height: 82,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primaryRed
                            : AppTheme.borderGray,
                        width: isSelected ? 3 : 1.5,
                      ),
                    ),
                    child: ClipOval(
                      child: Image.asset(path, fit: BoxFit.cover),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        );
      },
    );
  }
}
