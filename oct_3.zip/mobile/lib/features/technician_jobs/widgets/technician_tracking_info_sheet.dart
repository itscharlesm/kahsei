import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:mobile_app/features/technician_jobs/widgets/app_call_dialog.dart';

class TechnicianTrackingInfoSheet extends StatelessWidget {
  final Map<String, dynamic> job;
  final String trackingStatus;
  final bool isMarkingArrived;
  final bool isCompletingService;
  final VoidCallback? onPrimaryAction;
  final String etaText;
  final bool isCheckingClientProximity;
  final bool isWithinClientProximity;
  final double? distanceFromClient;
  final String? clientProximityError;

  const TechnicianTrackingInfoSheet({
    super.key,
    required this.job,
    required this.trackingStatus,
    required this.isMarkingArrived,
    required this.isCompletingService,
    required this.onPrimaryAction,
    required this.etaText,
    required this.isCheckingClientProximity,
    required this.isWithinClientProximity,
    required this.distanceFromClient,
    required this.clientProximityError,
  });

  String _text(dynamic value, [String fallback = 'N/A']) {
    if (value == null) return fallback;
    final text = value.toString().trim();
    return text.isEmpty ? fallback : text;
  }

  String _statusLabel() {
    switch (trackingStatus.toUpperCase()) {
      case 'DONE SERVICE':
        return 'COMPLETED';
      case 'ARRIVED':
        return 'ARRIVED';
      default:
        return 'ON THE WAY';
    }
  }

  String _buttonText() {
    switch (trackingStatus.toUpperCase()) {
      case 'DONE SERVICE':
        return 'BACK TO JOBS';
      case 'ARRIVED':
        return 'DONE SERVICE';
      default:
        return 'MARK AS ARRIVED';
    }
  }

  IconData _buttonIcon() {
    switch (trackingStatus.toUpperCase()) {
      case 'DONE SERVICE':
        return Icons.arrow_back_rounded;
      case 'ARRIVED':
        return Icons.check_circle_outline;
      default:
        return Icons.flag_outlined;
    }
  }

  String _statusMessage() {
    switch (trackingStatus.toUpperCase()) {
      case 'DONE SERVICE':
        return 'Service has been completed successfully.';

      case 'ARRIVED':
        return 'You have arrived at the customer location. You may now begin the service.';

      default:
        if (clientProximityError != null) {
          return clientProximityError!;
        }

        if (isCheckingClientProximity) {
          return 'Checking your current distance from the customer location.';
        }

        final distance =
            distanceFromClient?.round();

        if (isWithinClientProximity) {
          return distance == null
              ? 'You are within the required proximity and may now mark the job as arrived.'
              : 'You are approximately $distance meters from the customer location and may now mark the job as arrived.';
        }

        return distance == null
            ? 'Move within 100 meters of the customer location to mark the job as arrived.'
            : 'You are approximately $distance meters from the customer location. Move within 100 meters to mark the job as arrived.';
    }
  }

  String _formatPestName(String pest) {
    final normalized = pest.trim().toUpperCase();

    switch (normalized) {
      case 'RATS/MICE':
        return 'Rodent';

      case 'BED BUGS':
        return 'Bed Bug';

      case 'COCKROACHES':
        return 'Cockroach';

      case 'ANTS':
        return 'Ant';

      case 'TERMITES':
        return 'Termite';

      default:
        return normalized
            .toLowerCase()
            .split(' ')
            .map((word) {
              if (word.isEmpty) return word;

              return word[0].toUpperCase() + word.substring(1);
            })
            .join(' ');
    }
  }

  List<String> _pestList() {
    final fullPestTypes = _text(job['fullPestTypes'], '');

    if (fullPestTypes.isNotEmpty) {
      return fullPestTypes
          .split(',')
          .map((item) => item.trim())
          .where((item) => item.isNotEmpty)
          .toList();
    }

    final pestType = _text(job['pestType'], '');

    if (pestType.isNotEmpty && pestType != 'N/A') {
      return [pestType];
    }

    return [];
  }

  String _serviceName() {
    final isTermite =
        job['isTermite'] == true ||
        job['svc_is_termite'] == 1 ||
        _text(job['service'], '').toUpperCase().contains('TERMITE') ||
        _text(job['pestType'], '').toUpperCase().contains('TERMITE');

    final pests = _pestList();

    if (isTermite) {
      return 'Termite Control';
    }

    if (pests.length == 1) {
      return '${_formatPestName(pests.first)} Control';
    }

    if (pests.length >= 2) {
      return 'General Pest Control';
    }

    return _text(job['service'], 'Pest Control Service');
  }

  String _scheduleText() {
    final approvedDate = _text(
      job['approvedDate'] ?? job['svca_approved_date'],
      '',
    );

    final approvedTimeFrom = _text(
      job['approvedTimeFrom'] ?? job['svca_approved_time_from'],
      '',
    );

    final approvedTimeTo = _text(
      job['approvedTimeTo'] ?? job['svca_approved_time_to'],
      '',
    );

    if (approvedDate.isEmpty &&
        approvedTimeFrom.isEmpty &&
        approvedTimeTo.isEmpty) {
      return 'N/A';
    }

    String formattedDate = approvedDate;

    if (approvedDate.isNotEmpty) {
      try {
        final parsedDate = DateTime.parse(approvedDate);

        const months = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December',
        ];

        formattedDate =
            '${months[parsedDate.month - 1]} ${parsedDate.day}, ${parsedDate.year}';
      } catch (_) {
        formattedDate = approvedDate;
      }
    }

    String formatTime(String value) {
      if (value.isEmpty) return '';

      try {
        final parts = value.split(':');
        final hour = int.parse(parts[0]);
        final minute = parts.length > 1 ? int.parse(parts[1]) : 0;

        final period = hour >= 12 ? 'PM' : 'AM';
        final displayHour = hour == 0
            ? 12
            : hour > 12
                ? hour - 12
                : hour;

        return '$displayHour:${minute.toString().padLeft(2, '0')} $period';
      } catch (_) {
        return value;
      }
    }

    final from = formatTime(approvedTimeFrom);
    final to = formatTime(approvedTimeTo);

    final timeRange = from.isNotEmpty && to.isNotEmpty
        ? '$from - $to'
        : from.isNotEmpty
            ? from
            : to;

    if (formattedDate.isEmpty) return timeRange;
    if (timeRange.isEmpty) return formattedDate;

    return '$formattedDate\n$timeRange';
  }

  String _formatMobile(String mobile) {
    if (mobile == 'N/A') return mobile;

    final cleaned = mobile.trim();

    if (cleaned.startsWith('09')) {
      return cleaned;
    }

    if (cleaned.startsWith('9') && cleaned.length == 10) {
      return '0$cleaned';
    }

    return cleaned;
  }

  void _showCallDialog(
    BuildContext context,
    String mobile,
  ) {
    if (mobile == 'N/A') return;

    showDialog(
      context: context,
      builder: (_) => AppCallDialog(
        mobile: mobile,
        onCall: () => _callClient(mobile),
      ),
    );
  }


  // ============================================================
  // PEOPLE / TEAM HELPERS
  // ============================================================

  List<Map<String, dynamic>> _teamTechnicians() {
    final raw = job['teamTechnicians'];

    if (raw is! List || raw.isEmpty) {
      final fallbackName = _text(
        job['technicianName'] ??
            job['assignedTechnician'] ??
            job['technician'],
        '',
      );

      if (fallbackName.isEmpty) {
        return [];
      }

      return [
        {
          'id': job['technicianId'],
          'name': fallbackName,
        },
      ];
    }

    return raw
        .whereType<Map>()
        .map(
          (item) => Map<String, dynamic>.from(item),
        )
        .where(
          (item) =>
              _text(item['name'], '').isNotEmpty,
        )
        .toList();
  }

  Map<String, dynamic>? _teamLeader(
    List<Map<String, dynamic>> technicians,
  ) {
    if (technicians.isEmpty) return null;

    final leaderId = job['leaderId'];

    if (leaderId != null) {
      for (final technician in technicians) {
        if (technician['id']?.toString() ==
            leaderId.toString()) {
          return technician;
        }
      }
    }

    return technicians.first;
  }

  @override
  Widget build(BuildContext context) {
    final clientName =
        _text(job['clientName'], 'Client');

    final address =
        _text(job['address'], 'No address');

    final rawMobile = _text(
      job['clientMobile'] ??
          job['mobile'] ??
          job['contactNumber'],
      'N/A',
    );

    final clientMobile =
        _formatMobile(rawMobile);

    final technicians =
        _teamTechnicians();

    final isBusy =
        isMarkingArrived ||
        isCompletingService;

    final isOngoing =
        trackingStatus.toUpperCase() ==
            'ONGOING';

    final isArrivalProximityBlocked =
        isOngoing &&
        (
          isCheckingClientProximity ||
          !isWithinClientProximity
        );

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          16,
          10,
          16,
          18,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _dragHandle(),

            _durationHeader(),

            // ==================================================
            // CLIENT
            // ==================================================

            const SizedBox(height: 16),

            _sectionLabel('CLIENT'),

            const SizedBox(height: 8),

            _clientCard(
              context: context,
              clientName: clientName,
              address: address,
              mobile: clientMobile,
              profileImage: (job['clientProfileImage'] ??
                      job['clientImage'] ??
                      job['client_image_path'])
                  ?.toString(),
            ),

            // ==================================================
            // TECHNICIAN / SERVICE TEAM
            // ==================================================

            if (technicians.isNotEmpty) ...[
              const SizedBox(height: 16),

              _sectionLabel(
                technicians.length > 1
                    ? 'SERVICE TEAM'
                    : 'TECHNICIAN',
              ),

              const SizedBox(height: 8),

              _technicianCard(
                technicians: technicians,
              ),
            ],

            // ==================================================
            // SERVICE DETAILS
            // ==================================================

            const SizedBox(height: 16),

            _sectionLabel('SERVICE DETAILS'),

            const SizedBox(height: 8),

            _serviceDetailsCard(
              service: _serviceName(),
              schedule: _scheduleText(),
              showDuration: isOngoing,
            ),

            // ==================================================
            // ARRIVAL REQUIREMENT / STATUS
            // ==================================================

            const SizedBox(height: 16),

            _sectionLabel(
              isOngoing
                  ? 'ARRIVAL REQUIREMENT'
                  : 'STATUS',
            ),

            const SizedBox(height: 8),

            _messageCard(),

            // ==================================================
            // PRIMARY ACTION
            // ==================================================

            const SizedBox(height: 14),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed:
                    isBusy ||
                            isArrivalProximityBlocked
                        ? null
                        : onPrimaryAction,
                style:
                    ElevatedButton.styleFrom(
                  backgroundColor:
                      AppTheme.primaryRed,
                  foregroundColor:
                      AppTheme.white,
                  disabledBackgroundColor:
                      Colors.grey.shade300,
                  disabledForegroundColor:
                      Colors.grey.shade600,
                  elevation: 0,
                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(
                      14,
                    ),
                  ),
                ),
                child: isBusy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child:
                            CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor:
                              AlwaysStoppedAnimation<
                                  Color>(
                            AppTheme.white,
                          ),
                        ),
                      )
                    : Row(
                        mainAxisAlignment:
                            MainAxisAlignment.center,
                        children: [
                          Icon(
                            isArrivalProximityBlocked
                                ? Icons
                                    .lock_outline_rounded
                                : _buttonIcon(),
                            size: 19,
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          Text(
                            _buttonText(),
                            style:
                                const TextStyle(
                              fontSize: 13,
                              fontWeight:
                                  FontWeight.w900,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _callClient(String mobile) async {
    final uri = Uri.parse('tel:$mobile');

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Widget _dragHandle() {
    return Center(
      child: Container(
        width: 42,
        height: 4,
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppTheme.borderGray,
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget _durationHeader() {
    final isArrivedOrDone =
        trackingStatus.toUpperCase() == 'ARRIVED' ||
        trackingStatus.toUpperCase() == 'DONE SERVICE';

    if (isArrivedOrDone) {
      return _jobDurationHeader();  
    }

    return _etaHeader();
  }

  Widget _etaHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryRed.withOpacity(0.22),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppTheme.white.withOpacity(0.18),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.access_time_rounded,
              color: AppTheme.white,
              size: 26,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Estimated Arrival',
                  style: TextStyle(
                    color: AppTheme.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  etaText,
                  style: TextStyle(
                    color: AppTheme.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 11,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.white.withOpacity(0.45),
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              _statusLabel(),
              style: const TextStyle(
                color: AppTheme.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _jobDurationHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryRed.withOpacity(0.22),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppTheme.white.withOpacity(0.18),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.timer_outlined,
              color: AppTheme.white,
              size: 25,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _HeaderDurationTimer(
              startDate: job['startDate'],
              startTime: job['startTime'],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 11,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.white.withOpacity(0.45),
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              _statusLabel(),
              style: const TextStyle(
                color: AppTheme.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CLIENT CARD
  // ============================================================

  Widget _clientCard({
    required BuildContext context,
    required String clientName,
    required String address,
    required String mobile,
    String? profileImage,
  }) {
    return Container(
      width: double.infinity,
      decoration: _cardDecoration(),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            // ==================================================
            // CLIENT AVATAR
            // ==================================================

            AppProfileAvatar(
              imageUrl: profileImage,
              size: 46,
            ),

            const SizedBox(width: 12),

            // ==================================================
            // CLIENT INFORMATION
            // ==================================================

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Service Client',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 9.5,
                      fontWeight:
                          FontWeight.w700,
                    ),
                  ),

                  const SizedBox(height: 3),

                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          clientName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.black,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),

                      if (mobile != 'N/A') ...[
                        const SizedBox(width: 10),

                        InkWell(
                          onTap: () => _showCallDialog(
                            context,
                            mobile,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: AppTheme.primaryRed.withOpacity(0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.call_outlined,
                              color: AppTheme.primaryRed,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // TECHNICIAN / SERVICE TEAM CARD
  // ============================================================

  Widget _technicianCard({
    required List<Map<String, dynamic>>
        technicians,
  }) {
    final leader =
        _teamLeader(technicians);

    if (leader == null) {
      return const SizedBox.shrink();
    }

    final leaderName =
        _text(
      leader['name'],
      'Technician',
    );

    final isMultiple =
        technicians.length > 1;

    final members = technicians
        .where(
          (technician) =>
              technician['id']?.toString() !=
              leader['id']?.toString(),
        )
        .toList();

    // ============================================================
    // SINGLE TECHNICIAN
    // ============================================================

    if (!isMultiple) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: _cardDecoration(),
        child: Row(
          children: [
            _personAvatar(
              name: leaderName,
              isLeader: false,
              profileImage:
                  leader['profileImage']
                      ?.toString(),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Assigned Technician',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 9.5,
                      fontWeight:
                          FontWeight.w700,
                    ),
                  ),

                  const SizedBox(height: 3),

                  Text(
                    leaderName,
                    maxLines: 1,
                    overflow:
                        TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.black,
                      fontSize: 13.5,
                      fontWeight:
                          FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // MULTIPLE TECHNICIANS
    // LEADER SHOWN BY DEFAULT, MEMBERS EXPAND BELOW
    // ============================================================

    return Container(
      width: double.infinity,
      decoration: _cardDecoration(),
      child: Theme(
        data: ThemeData(
          dividerColor: Colors.transparent,
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
        ),
        child: ExpansionTile(
          tilePadding:
              const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 3,
          ),
          childrenPadding:
              const EdgeInsets.fromLTRB(
            14,
            0,
            14,
            12,
          ),
          leading: _personAvatar(
            name: leaderName,
            isLeader: true,
            profileImage:
                leader['profileImage']
                    ?.toString(),
          ),
          title: Text(
            leaderName,
            maxLines: 1,
            overflow:
                TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppTheme.black,
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
            ),
          ),
          subtitle: const Padding(
            padding:
                EdgeInsets.only(top: 3),
            child: Text(
              'Team Leader',
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 9.5,
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),
          trailing: const Icon(
            Icons
                .keyboard_arrow_down_rounded,
            color: AppTheme.gray,
            size: 22,
          ),
          children: [
            const Divider(
              height: 1,
              color: AppTheme.borderGray,
            ),

            const SizedBox(height: 11),

            Row(
              children: [
                const Text(
                  'TEAM MEMBERS',
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 9,
                    fontWeight:
                        FontWeight.w900,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(width: 7),
                Container(
                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal: 7,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.lightGray,
                    borderRadius:
                        BorderRadius.circular(
                      20,
                    ),
                  ),
                  child: Text(
                    '${members.length}',
                    style:
                        const TextStyle(
                      color: AppTheme.gray,
                      fontSize: 9,
                      fontWeight:
                          FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 9),

            ...members.asMap().entries.map(
              (entry) {
                final member =
                    entry.value;

                final memberName =
                    _text(
                  member['name'],
                  'Technician',
                );

                return Padding(
                  padding:
                      EdgeInsets.only(
                    bottom:
                        entry.key <
                                members.length -
                                    1
                            ? 10
                            : 0,
                  ),
                  child: Row(
                    children: [
                      _personAvatar(
                        name: memberName,
                        isLeader: false,
                        small: true,
                        profileImage:
                            member['profileImage']
                                ?.toString(),
                      ),

                      const SizedBox(
                        width: 10,
                      ),

                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,
                          children: [
                            Text(
                              memberName,
                              maxLines: 1,
                              overflow:
                                  TextOverflow
                                      .ellipsis,
                              style:
                                  const TextStyle(
                                color: AppTheme
                                    .black,
                                fontSize: 11.5,
                                fontWeight:
                                    FontWeight
                                        .w700,
                              ),
                            ),
                            const SizedBox(
                              height: 2,
                            ),
                            const Text(
                              'Technician',
                              style:
                                  TextStyle(
                                color: AppTheme
                                    .gray,
                                fontSize: 9,
                                fontWeight:
                                    FontWeight
                                        .w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _personAvatar({
    required String name,
    required bool isLeader,
    String? profileImage,
    bool small = false,
  }) {
    final size =
        small ? 34.0 : 44.0;

    return AppProfileAvatar(
      imageUrl: profileImage,
      size: size,
    );
  }

  Widget _sectionLabel(String label) {
    return Text(
      label,
      style: const TextStyle(
        color: AppTheme.gray,
        fontSize: 11,
        fontWeight: FontWeight.w900,
        letterSpacing: 0.4,
      ),
    );
  }

  Widget _serviceDetailsCard({
    required String service,
    required String schedule,
    required bool showDuration,
  }) {
    return Container(
      width: double.infinity,
      decoration: _cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ====================================================
          // SERVICE
          // ====================================================

          _detailRow(
            icon: Icons.home_repair_service_outlined,
            label: 'Service',
            value: service,
          ),

          _divider(),

          // ====================================================
          // SCHEDULE
          // ====================================================

          _detailRow(
            icon: Icons.calendar_month_outlined,
            label: 'Schedule',
            value: schedule,
          ),

          // ====================================================
          // DURATION
          // ====================================================

          if (showDuration) ...[
            _divider(),

            Padding(
              padding: const EdgeInsets.fromLTRB(
                14,
                14,
                14,
                15,
              ),
              child: Row(
                children: [
                  _softIcon(
                    Icons.timer_outlined,
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: _SheetDurationTimer(
                      startDate: job['startDate'],
                      startTime: job['startTime'],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _routeInfoCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          Expanded(
            child: _routeMiniInfo(
              icon: Icons.place_outlined,
              label: 'Distance',
              value: 'Calculating',
            ),
          ),
          Container(
            width: 1,
            height: 48,
            color: AppTheme.borderGray,
          ),
          Expanded(
            child: _routeMiniInfo(
              icon: Icons.access_time_rounded,
              label: 'ETA',
              value: 'Calculating',
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS / CLIENT PROXIMITY CARD
  // ============================================================

  Widget _messageCard() {
    final status = trackingStatus.toUpperCase();

    // ============================================================
    // ARRIVED / DONE SERVICE
    // Keep normal message card for these statuses
    // ============================================================

    if (status != 'ONGOING') {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: _cardDecoration(),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.info_outline_rounded,
              color: AppTheme.primaryRed,
              size: 20,
            ),

            const SizedBox(width: 11),

            Expanded(
              child: Text(
                _statusMessage(),
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 11,
                  height: 1.35,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // CHECKING CLIENT LOCATION
    // ============================================================

    if (isCheckingClientProximity) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _cardDecoration(),
        child: const Row(
          children: [
            SizedBox(
              width: 78,
              height: 78,
              child: Center(
                child: SizedBox(
                  width: 42,
                  height: 42,
                  child: CircularProgressIndicator(
                    strokeWidth: 5,
                    color: AppTheme.primaryRed,
                    backgroundColor: AppTheme.lightGray,
                  ),
                ),
              ),
            ),

            SizedBox(width: 15),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Checking Your Location',
                    style: TextStyle(
                      color: AppTheme.black,
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      height: 1.2,
                    ),
                  ),

                  SizedBox(height: 5),

                  Text(
                    'Checking your distance from the service location.',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 11,
                      height: 1.35,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // LOCATION ERROR
    // ============================================================

    if (clientProximityError != null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _cardDecoration(),
        child: Row(
          children: [
            SizedBox(
              width: 78,
              height: 78,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 72,
                    height: 72,
                    child: CircularProgressIndicator(
                      value: 1,
                      strokeWidth: 7,
                      color: AppTheme.primaryRed.withOpacity(
                        0.16,
                      ),
                      backgroundColor: AppTheme.lightGray,
                    ),
                  ),

                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryRed.withOpacity(
                        0.08,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.location_off_outlined,
                      color: AppTheme.primaryRed,
                      size: 23,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 15),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Location Unavailable',
                    style: TextStyle(
                      color: AppTheme.black,
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      height: 1.2,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Text(
                    clientProximityError!,
                    style: const TextStyle(
                      color: AppTheme.gray,
                      fontSize: 11,
                      height: 1.35,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // DISTANCE
    // ============================================================

    final distance =
        distanceFromClient ?? 0;

    final ready =
        isWithinClientProximity;

    String distanceValue;
    String distanceUnit;

    if (distance >= 1000) {
      distanceValue =
          (distance / 1000).toStringAsFixed(1);

      distanceUnit = 'km';
    } else {
      distanceValue =
          distance.toStringAsFixed(0);

      distanceUnit = 'm';
    }

    // ============================================================
    // GAUGE VALUE
    // ============================================================

    double gaugeValue;

    if (ready) {
      gaugeValue = 1;
    } else if (distance <= 0) {
      gaugeValue = 0;
    } else {
      gaugeValue =
          (100 / distance).clamp(
        0.08,
        1.0,
      );
    }

    // ============================================================
    // CLIENT PROXIMITY CARD
    // ============================================================

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // ======================================================
          // CIRCULAR DISTANCE GAUGE
          // ======================================================

          SizedBox(
            width: 78,
            height: 78,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 72,
                  height: 72,
                  child: CircularProgressIndicator(
                    value: gaugeValue,
                    strokeWidth: 7,
                    strokeCap: StrokeCap.round,
                    color: ready
                        ? Colors.green
                        : AppTheme.primaryRed,
                    backgroundColor: ready
                        ? Colors.green.withOpacity(
                            0.12,
                          )
                        : AppTheme.primaryRed.withOpacity(
                            0.10,
                          ),
                  ),
                ),

                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      distanceValue,
                      style: TextStyle(
                        color: ready
                            ? Colors.green.shade700
                            : AppTheme.primaryRed,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        height: 1,
                      ),
                    ),

                    const SizedBox(height: 2),

                    Text(
                      distanceUnit,
                      style: TextStyle(
                        color: ready
                            ? Colors.green.shade700
                            : AppTheme.primaryRed,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(width: 15),

          // ======================================================
          // STATUS
          // ======================================================

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ready
                      ? 'Ready to Mark as Arrived'
                      : 'Not Yet Within Service Range',
                  style: TextStyle(
                    color: ready
                        ? Colors.green.shade700
                        : AppTheme.primaryRed,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  ready
                      ? 'You are within the required service location range.'
                      : 'You must be within 100 meters of the service location.',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 11,
                    height: 1.35,
                    fontWeight: FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 9),

                // =================================================
                // RANGE STATUS
                // =================================================

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: ready
                        ? Colors.green.withOpacity(
                            0.08,
                          )
                        : AppTheme.primaryRed.withOpacity(
                            0.07,
                          ),
                    borderRadius: BorderRadius.circular(
                      20,
                    ),
                    border: Border.all(
                      color: ready
                          ? Colors.green.withOpacity(
                              0.20,
                            )
                          : AppTheme.primaryRed.withOpacity(
                              0.18,
                            ),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        ready
                            ? Icons.check_circle_outline_rounded
                            : Icons.cancel_outlined,
                        size: 13,
                        color: ready
                            ? Colors.green.shade700
                            : AppTheme.primaryRed,
                      ),

                      const SizedBox(width: 5),

                      Text(
                        ready
                            ? 'Within Range'
                            : 'Out of Range',
                        style: TextStyle(
                          color: ready
                              ? Colors.green.shade700
                              : AppTheme.primaryRed,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailRow({
    required IconData icon,
    required String label,
    required String value,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 13,
        ),
        child: Row(
          children: [
            _softIcon(icon),
            const SizedBox(width: 12),
            SizedBox(
              width: 72,
              child: Text(
                label,
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Expanded(
              child: Text(
                value,
                textAlign: TextAlign.right,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 12,
                  height: 1.3,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            if (onTap != null) ...[
              const SizedBox(width: 8),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppTheme.gray,
                size: 20,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _routeMiniInfo({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _softIcon(icon),
        const SizedBox(width: 10),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _softIcon(IconData icon) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppTheme.primaryRed.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(
        icon,
        color: AppTheme.primaryRed,
        size: 19,
      ),
    );
  }

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: AppTheme.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppTheme.borderGray),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    );
  }

  Widget _divider() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 14),
      child: Divider(
        height: 1,
        color: AppTheme.borderGray,
      ),
    );
  }

  Widget _jobDurationMiniCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          _softIcon(Icons.timer_outlined),
          const SizedBox(width: 12),
          Expanded(
            child: _SheetDurationTimer(
              startDate: job['startDate'],
              startTime: job['startTime'],
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderDurationTimer extends StatefulWidget {
  final dynamic startDate;
  final dynamic startTime;

  const _HeaderDurationTimer({
    required this.startDate,
    required this.startTime,
  });

  @override
  State<_HeaderDurationTimer> createState() => _HeaderDurationTimerState();
}

class _HeaderDurationTimerState extends State<_HeaderDurationTimer> {
  Timer? timer;
  Duration elapsed = Duration.zero;

  @override
  void initState() {
    super.initState();
    _updateElapsed();

    timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _updateElapsed(),
    );
  }

  DateTime? _startDateTime() {
    final date = widget.startDate?.toString().trim();
    final time = widget.startTime?.toString().trim();

    if (date == null || date.isEmpty || date == 'N/A') return null;
    if (time == null || time.isEmpty || time == 'N/A') return null;

    return DateTime.tryParse('$date $time');
  }

  void _updateElapsed() {
    final startedAt = _startDateTime();

    if (startedAt == null) return;

    final difference = DateTime.now().difference(startedAt);

    if (!mounted) return;

    setState(() {
      elapsed = difference.isNegative ? Duration.zero : difference;
    });
  }

  String _twoDigits(int value) => value.toString().padLeft(2, '0');

  String _formatDuration(Duration duration) {
    final hours = _twoDigits(duration.inHours);
    final minutes = _twoDigits(duration.inMinutes.remainder(60));
    final seconds = _twoDigits(duration.inSeconds.remainder(60));

    return '$hours:$minutes:$seconds';
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final startedAt = _startDateTime();

    if (startedAt == null) {
      return const Text(
        'Job Duration\n--:--:--',
        style: TextStyle(
          color: AppTheme.white,
          fontSize: 12,
          fontWeight: FontWeight.w800,
          height: 1.3,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Job Duration',
          style: TextStyle(
            color: AppTheme.white,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          _formatDuration(elapsed),
          style: const TextStyle(
            color: AppTheme.white,
            fontSize: 20,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}

class _SheetDurationTimer extends StatefulWidget {
  final dynamic startDate;
  final dynamic startTime;

  const _SheetDurationTimer({
    required this.startDate,
    required this.startTime,
  });

  @override
  State<_SheetDurationTimer> createState() => _SheetDurationTimerState();
}

class _SheetDurationTimerState extends State<_SheetDurationTimer> {
  Timer? timer;
  Duration elapsed = Duration.zero;

  @override
  void initState() {
    super.initState();
    _updateElapsed();

    timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _updateElapsed(),
    );
  }

  DateTime? _startDateTime() {
    final date = widget.startDate?.toString().trim();
    final time = widget.startTime?.toString().trim();

    if (date == null || date.isEmpty || date == 'N/A') return null;
    if (time == null || time.isEmpty || time == 'N/A') return null;

    return DateTime.tryParse('$date $time');
  }

  void _updateElapsed() {
    final startedAt = _startDateTime();

    if (startedAt == null) return;

    final difference = DateTime.now().difference(startedAt);

    if (!mounted) return;

    setState(() {
      elapsed = difference.isNegative ? Duration.zero : difference;
    });
  }

  String _twoDigits(int value) => value.toString().padLeft(2, '0');

  String _formatDuration(Duration duration) {
    final hours = _twoDigits(duration.inHours);
    final minutes = _twoDigits(duration.inMinutes.remainder(60));
    final seconds = _twoDigits(duration.inSeconds.remainder(60));

    return '$hours:$minutes:$seconds';
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final startedAt = _startDateTime();

    if (startedAt == null) {
      return const Text(
        'Job Duration unavailable',
        style: TextStyle(
          color: AppTheme.gray,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      );
    }

    return Row(
      children: [
        const Expanded(
          child: Text(
            'Job Duration',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Text(
          _formatDuration(elapsed),
          style: const TextStyle(
            color: AppTheme.black,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}
