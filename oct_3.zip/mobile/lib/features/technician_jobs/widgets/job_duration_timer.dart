import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class JobDurationTimer extends StatefulWidget {
  final dynamic startDate;
  final dynamic startTime;

  const JobDurationTimer({
    super.key,
    required this.startDate,
    required this.startTime,
  });

  @override
  State<JobDurationTimer> createState() => _JobDurationTimerState();
}

class _JobDurationTimerState extends State<JobDurationTimer> {
  Timer? timer;
  Duration elapsed = Duration.zero;

  @override
  void initState() {
    super.initState();
    _updateElapsed();

    timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _updateElapsed(),
    );
  }

  DateTime? _startDateTime() {
    final date = widget.startDate?.toString().trim();
    final time = widget.startTime?.toString().trim();

    if (date == null || date.isEmpty || date == 'N/A') return null;
    if (time == null || time.isEmpty || time == 'N/A') return null;

    return DateTime.tryParse('$date $time');
  }

  void _updateElapsed() {
    final startedAt = _startDateTime();

    if (startedAt == null) return;

    final difference = DateTime.now().difference(startedAt);

    if (!mounted) return;

    setState(() {
      elapsed = difference.isNegative ? Duration.zero : difference;
    });
  }

  String _twoDigits(int value) => value.toString().padLeft(2, '0');

  String _formatDuration(Duration duration) {
    final hours = _twoDigits(duration.inHours);
    final minutes = _twoDigits(duration.inMinutes.remainder(60));
    final seconds = _twoDigits(duration.inSeconds.remainder(60));

    return '$hours:$minutes:$seconds';
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final startedAt = _startDateTime();

    if (startedAt == null) {
      return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.primaryRed.withOpacity(0.18),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Icon(
              Icons.timer_outlined,
              color: AppTheme.primaryRed,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'Job Duration',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Text(
            _formatDuration(elapsed),
            style: const TextStyle(
              color: AppTheme.primaryRed,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}