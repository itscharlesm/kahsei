import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';

import 'package:mobile_app/features/technician_jobs/widgets/technician_job_status_badge.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

class TechnicianJobCard extends StatefulWidget {
  final String clientName;
  final String service;
  final String pestType;
  final String address;
  final String schedule;
  final String status;
  final String? displayStatus;

  final dynamic saNumber;

  final bool isDisabled;
  final String? disabledReason;

  final VoidCallback onViewDetails;

  final int technicianCount;
  final bool isMultipleTechnician;

  final List<Map<String, dynamic>> teamTechnicians;

  const TechnicianJobCard({
    super.key,
    required this.clientName,
    required this.service,
    required this.pestType,
    required this.address,
    required this.schedule,
    required this.status,
    this.displayStatus,
    required this.saNumber,
    required this.isDisabled,
    this.disabledReason,
    required this.onViewDetails,
    required this.technicianCount,
    required this.isMultipleTechnician,
    required this.teamTechnicians,
  });

  @override
  State<TechnicianJobCard> createState() =>
      _TechnicianJobCardState();
}

class _TechnicianJobCardState
    extends State<TechnicianJobCard> {
  bool isExpanded = false;

  bool get isPendingReport =>
      widget.status.toUpperCase() ==
      'DONE SERVICE';

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return AnimatedContainer(
      duration: const Duration(
        milliseconds: 220,
      ),
      width: double.infinity,
      padding: const EdgeInsets.all(
        14,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(
          18,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          // ====================================================
          // SA NUMBER + STATUS
          // ====================================================

          Row(
            children: [
              Expanded(
                child: Text(
                  _formatSaNumber(
                    widget.saNumber,
                  ),
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w700,
                    letterSpacing:
                        0.4,
                  ),
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              TechnicianJobStatusBadge(
                status: widget.displayStatus ?? widget.status,
              ),
            ],
          ),

          const SizedBox(
            height: 10,
          ),

          // ====================================================
          // SERVICE TITLE + EXPAND ARROW
          // ====================================================

          Row(
            crossAxisAlignment:
                CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Text(
                  widget.service,
                  maxLines: 2,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,
                    fontSize: 16,
                    fontWeight:
                        FontWeight.w900,
                    height: 1.2,
                  ),
                ),
              ),

              const SizedBox(
                width: 8,
              ),

              InkWell(
                borderRadius:
                    BorderRadius.circular(
                  20,
                ),
                onTap: () {
                  setState(() {
                    isExpanded =
                        !isExpanded;
                  });
                },
                child: Padding(
                  padding:
                      const EdgeInsets.all(
                    2,
                  ),
                  child: Icon(
                    isExpanded
                        ? Icons
                            .keyboard_arrow_up_rounded
                        : Icons
                            .keyboard_arrow_down_rounded,
                    color:
                        AppTheme.black,
                    size: 24,
                  ),
                ),
              ),
            ],
          ),

          // ====================================================
          // MULTIPLE TECHNICIAN INDICATOR
          // ====================================================

          if (widget
              .isMultipleTechnician) ...[
            const SizedBox(
              height: 8,
            ),

            _multiTechnicianBadge(),
          ],

          const SizedBox(
            height: 12,
          ),

          // ====================================================
          // CLIENT
          // ====================================================

          _infoRow(
            icon:
                Icons.person_outline,
            text:
                widget.clientName,
          ),

          const SizedBox(
            height: 8,
          ),

          // ====================================================
          // SCHEDULE
          // ====================================================

          _infoRow(
            icon: Icons
                .calendar_month_outlined,
            text:
                widget.schedule,
          ),

          const SizedBox(
            height: 8,
          ),

          // ====================================================
          // ADDRESS
          // ====================================================

          _infoRow(
            icon: Icons
                .location_on_outlined,
            text:
                widget.address,
            showTooltip: true,
          ),

          // ====================================================
          // EXPANDED AREA
          // ====================================================

          if (isExpanded) ...[
            const SizedBox(
              height: 16,
            ),

            Divider(
              height: 1,
              thickness: 1,
              color:
                  AppTheme.borderGray,
            ),

            const SizedBox(
              height: 14,
            ),

            // ==================================================
            // PEST TYPE + SERVICE
            // ==================================================

            IntrinsicHeight(
              child: Row(
                crossAxisAlignment:
                    CrossAxisAlignment
                        .stretch,
                children: [
                  Expanded(
                    child:
                        _detailCard(
                      icon: Icons
                          .bug_report_outlined,
                      title:
                          'PEST TYPE',
                      value:
                          widget.pestType,
                    ),
                  ),

                  const SizedBox(
                    width: 8,
                  ),

                  Expanded(
                    child:
                        _detailCard(
                      icon: Icons
                          .assignment_outlined,
                      title:
                          'SERVICE',
                      value:
                          widget.service,
                    ),
                  ),
                ],
              ),
            ),

            // ==================================================
            // ASSIGNED TEAM
            // ==================================================

            if (widget
                .isMultipleTechnician) ...[
              const SizedBox(
                height: 10,
              ),

              _assignedTeamBox(),
            ],

            const SizedBox(
              height: 10,
            ),

            // ==================================================
            // SERVICE LOCATION
            // ==================================================

            _infoSummaryBox(
              icon: Icons
                  .location_on_outlined,
              title:
                  'Service Location',
              value:
                  widget.address,
            ),

            const SizedBox(
              height: 12,
            ),

            // ==================================================
            // ACTION
            // ==================================================

            _viewDetailsButton(),
          ],
        ],
      ),
    );
  }

  // ============================================================
  // SA NUMBER
  // ============================================================

  String _formatSaNumber(
    dynamic value,
  ) {
    if (value == null) {
      return 'SA #-';
    }

    final String raw =
        value.toString().trim();

    if (raw.isEmpty ||
        raw == '-') {
      return 'SA #-';
    }

    final String cleaned =
        raw
            .toUpperCase()
            .replaceAll(
              'SA-',
              '',
            )
            .replaceAll(
              'SA #',
              '',
            )
            .trim();

    final int? number =
        int.tryParse(
      cleaned,
    );

    if (number == null) {
      return 'SA-$cleaned';
    }

    return 'SA-${number.toString().padLeft(6, '0')}';
  }

  // ============================================================
  // MULTIPLE TECHNICIAN BADGE
  // ============================================================

  Widget _multiTechnicianBadge() {
    return Align(
      alignment:
          Alignment.centerLeft,
      child: Container(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 9,
          vertical: 5,
        ),
        decoration:
            BoxDecoration(
          color:
              AppTheme.primaryRed
                  .withOpacity(
            0.08,
          ),
          borderRadius:
              BorderRadius.circular(
            8,
          ),
        ),
        child: Row(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            const Icon(
              Icons
                  .groups_2_outlined,
              size: 14,
              color:
                  AppTheme.primaryRed,
            ),

            const SizedBox(
              width: 5,
            ),

            Text(
              '${widget.technicianCount} '
              'Technicians Assigned',
              style:
                  const TextStyle(
                color:
                    AppTheme.primaryRed,
                fontSize: 10.5,
                fontWeight:
                    FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // INFORMATION ROW
  // ============================================================

  Widget _infoRow({
    required IconData icon,
    required String text,
    bool showTooltip = false,
  }) {
    final textWidget =
        Text(
      text,
      maxLines: 1,
      overflow:
          TextOverflow.ellipsis,
      style:
          const TextStyle(
        color:
            AppTheme.gray,
        fontSize: 12,
        height: 1.3,
        fontWeight:
            FontWeight.w500,
      ),
    );

    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.center,
      children: [
        Icon(
          icon,
          color:
              AppTheme.gray,
          size: 15,
        ),

        const SizedBox(
          width: 8,
        ),

        Expanded(
          child:
              showTooltip
                  ? Tooltip(
                      message:
                          text,
                      triggerMode:
                          TooltipTriggerMode
                              .longPress,
                      child:
                          textWidget,
                    )
                  : textWidget,
        ),
      ],
    );
  }

  // ============================================================
  // DETAIL CARD
  // ============================================================

  Widget _detailCard({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(
        10,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.lightGray
                .withOpacity(
          0.45,
        ),
        borderRadius:
            BorderRadius.circular(
          12,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment:
                CrossAxisAlignment
                    .center,
            children: [
              Icon(
                icon,
                color:
                    AppTheme.primaryRed,
                size: 17,
              ),

              const SizedBox(
                width: 7,
              ),

              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow:
                      TextOverflow
                          .ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 8,
                    fontWeight:
                        FontWeight
                            .w800,
                    letterSpacing:
                        0.4,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 7,
          ),

          Text(
            value,
            maxLines: 2,
            overflow:
                TextOverflow
                    .ellipsis,
            style:
                const TextStyle(
              color:
                  AppTheme.black,
              fontSize: 10.5,
              height: 1.2,
              fontWeight:
                  FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ASSIGNED TEAM
  // ============================================================

  Widget _assignedTeamBox() {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.fromLTRB(
        11,
        10,
        11,
        6,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.white,
        borderRadius:
            BorderRadius.circular(
          12,
        ),
        border: Border.all(
          color:
              AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'ASSIGNED TEAM',
            style:
                TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 8,
              fontWeight:
                  FontWeight.w900,
              letterSpacing:
                  0.4,
            ),
          ),

          const SizedBox(
            height: 9,
          ),

          ...widget
              .teamTechnicians
              .asMap()
              .entries
              .map<Widget>(
            (entry) {
              final int index =
                  entry.key;

              final Map<
                  String,
                  dynamic> tech =
                  entry.value;

              return Padding(
                padding:
                    EdgeInsets.only(
                  bottom:
                      index ==
                              widget
                                      .teamTechnicians
                                      .length -
                                  1
                          ? 4
                          : 8,
                ),
                child: Row(
                  children: [
                    AppProfileAvatar(
                      imageUrl: tech['profileImage']
                          ?.toString(),
                      size: 25,
                    ),

                    const SizedBox(
                      width: 8,
                    ),

                    Expanded(
                      child:
                          Text(
                        tech['name'] ??
                            'Technician',
                        maxLines: 1,
                        overflow:
                            TextOverflow
                                .ellipsis,
                        style:
                            const TextStyle(
                          color:
                              AppTheme
                                  .black,
                          fontSize:
                              11,
                          fontWeight:
                              FontWeight
                                  .w700,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ============================================================
  // INFORMATION SUMMARY BOX
  // ============================================================

  Widget _infoSummaryBox({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        11,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.lightGray
                .withOpacity(
          0.5,
        ),
        borderRadius:
            BorderRadius.circular(
          12,
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.center,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration:
                BoxDecoration(
              color:
                  AppTheme.white,
              borderRadius:
                  BorderRadius
                      .circular(
                9,
              ),
            ),
            child: Icon(
              icon,
              size: 17,
              color:
                  AppTheme.gray,
            ),
          ),

          const SizedBox(
            width: 9,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                Text(
                  title
                      .toUpperCase(),
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 8,
                    fontWeight:
                        FontWeight
                            .w900,
                    letterSpacing:
                        0.4,
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  value,
                  maxLines: 2,
                  overflow:
                      TextOverflow
                          .ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,
                    fontSize: 10.5,
                    height: 1.25,
                    fontWeight:
                        FontWeight
                            .w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DISABLED LABEL
  // ============================================================

  String _disabledLabel() {
    if (widget.disabledReason ==
        'scheduled') {
      return 'Wait Until Scheduled Date';
    }

    if (widget.disabledReason ==
        'pending_report') {
      return 'Finish Pending Report First';
    }

    if (widget.disabledReason ==
        'leader_report') {
      return 'Report Must Be Submitted by Team Leader';
    }

    return 'Finish Active Job First';
  }

  // ============================================================
  // VIEW DETAILS BUTTON
  // ============================================================

  Widget _viewDetailsButton() {
    final bool disabled =
        widget.isDisabled;

    final String label =
        disabled
            ? _disabledLabel()
            : isPendingReport
                ? 'Proceed to Report Submission'
                : 'View Job Details';

    return InkWell(
      borderRadius:
          BorderRadius.circular(
        12,
      ),
      onTap:
          disabled
              ? null
              : widget
                  .onViewDetails,
      child: Container(
        width:
            double.infinity,
        padding:
            const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 13,
        ),
        decoration:
            BoxDecoration(
          color:
              AppTheme.white,
          borderRadius:
              BorderRadius.circular(
            12,
          ),
          border: Border.all(
            color:
                disabled
                    ? AppTheme
                        .borderGray
                    : AppTheme
                        .primaryRed,
          ),
        ),
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment
                  .center,
          children: [
            Icon(
              isPendingReport
                  ? Icons
                      .description_outlined
                  : Icons
                      .assignment_outlined,
              color:
                  disabled
                      ? AppTheme
                          .gray
                      : AppTheme
                          .primaryRed,
              size: 16,
            ),

            const SizedBox(
              width: 7,
            ),

            Flexible(
              child: Text(
                label,
                textAlign:
                    TextAlign
                        .center,
                style:
                    TextStyle(
                  color:
                      disabled
                          ? AppTheme
                              .gray
                          : AppTheme
                              .primaryRed,
                  fontSize: 11.5,
                  fontWeight:
                      FontWeight
                          .w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
