import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class TechnicianJobStatusBadge extends StatelessWidget {
  final String status;

  const TechnicianJobStatusBadge({
    super.key,
    required this.status,
  });

  String get label {
    switch (status.toUpperCase()) {
      case 'ASSIGNED':
        return 'ASSIGNED';

      case 'UPCOMING':
        return 'UPCOMING';

      case 'SERVICE_NOW':
        return 'SERVICE NOW';

      case 'OVERDUE':
        return 'OVERDUE';

      case 'SCHEDULE_MISSING':
        return 'SCHEDULE UNAVAILABLE';

      case 'ONGOING':
        return 'ON THE WAY';

      case 'ARRIVED':
        return 'ARRIVED';

      case 'DONE SERVICE':
        return 'PENDING REPORT';

      default:
        return status.toUpperCase();
    }
  }

  Color get color {
    switch (status.toUpperCase()) {
      case 'ASSIGNED':
        return Colors.blue;

      case 'UPCOMING':
        return Colors.blue;

      case 'SERVICE_NOW':
        return Colors.green;

      case 'OVERDUE':
        return Colors.red;

      case 'SCHEDULE_MISSING':
        return Colors.grey;

      case 'ONGOING':
        return Colors.orange;

      case 'ARRIVED':
        return Colors.teal;

      case 'DONE SERVICE':
        return Colors.deepOrange;

      case 'DONE REPORT':
          return Colors.green;

      default:
        return AppTheme.gray;
    }
  }

  @override
  Widget build(BuildContext context) {
    final badgeColor = color;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: badgeColor,
          fontSize: 9.5,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}