// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// import 'package:mobile_app/app/theme.dart';
// import 'package:mobile_app/config/api_config.dart';

// import 'package:mobile_app/features/technician_jobs/pages/technician_job_details_page.dart';
// import 'package:mobile_app/features/technician_jobs/widgets/technician_job_card.dart';

// import 'package:mobile_app/features/technician_reports/pages/technician_service_report_submission_page.dart';

// import 'package:mobile_app/shared/shared.dart';
// import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';

// class TechnicianAssignedJobsPage extends StatefulWidget {
//   final String email;
//   final String initialFilter;
//   final int? focusJobId;

//   const TechnicianAssignedJobsPage({
//     super.key,
//     required this.email,
//     this.initialFilter = 'Active',
//     this.focusJobId,
//   });

//   @override
//   State<TechnicianAssignedJobsPage> createState() =>
//       _TechnicianAssignedJobsPageState();
// }

// class _TechnicianAssignedJobsPageState
//     extends State<TechnicianAssignedJobsPage> {
//   // ============================================================
//   // FILTERS
//   // ============================================================

//   final List<String> filters = [
//     'Active',
//     'Upcoming',
//     'Completed',
//   ];

//   late String selectedFilter;

//   // ============================================================
//   // SCROLL
//   // ============================================================

//   final ScrollController _scrollController = ScrollController();

//   // ============================================================
//   // JOB DATA PER TAB
//   // ============================================================

//   final Map<String, List<Map<String, dynamic>>> _jobsByFilter = {
//     'Active': [],
//     'Upcoming': [],
//     'Completed': [],
//   };

//   // ============================================================
//   // PAGINATION PER TAB
//   // ============================================================

//   final Map<String, int> _pageByFilter = {
//     'Active': 1,
//     'Upcoming': 1,
//     'Completed': 1,
//   };

//   final Map<String, bool> _hasMoreByFilter = {
//     'Active': true,
//     'Upcoming': true,
//     'Completed': true,
//   };

//   // ============================================================
//   // STATE PER TAB
//   // ============================================================

//   final Map<String, bool> _loadedByFilter = {
//     'Active': false,
//     'Upcoming': false,
//     'Completed': false,
//   };

//   final Map<String, bool> _loadingByFilter = {
//     'Active': false,
//     'Upcoming': false,
//     'Completed': false,
//   };

//   final Map<String, bool> _loadingMoreByFilter = {
//     'Active': false,
//     'Upcoming': false,
//     'Completed': false,
//   };

//   final Map<String, String?> _errorByFilter = {
//     'Active': null,
//     'Upcoming': null,
//     'Completed': null,
//   };

//   // ============================================================
//   // FOCUS JOB
//   // ============================================================

//   bool _focusJobHandled = false;

//   // ============================================================
//   // INIT / DISPOSE
//   // ============================================================

//   @override
//   void initState() {
//     super.initState();

//     selectedFilter = filters.contains(widget.initialFilter)
//         ? widget.initialFilter
//         : 'Active';

//     _scrollController.addListener(_handleScroll);

//     // Only the selected tab loads on page opening.
//     _loadJobs(
//       selectedFilter,
//       reset: true,
//     );
//   }

//   @override
//   void dispose() {
//     _scrollController.removeListener(_handleScroll);
//     _scrollController.dispose();

//     super.dispose();
//   }

//   // ============================================================
//   // CURRENT TAB HELPERS
//   // ============================================================

//   List<Map<String, dynamic>> get currentJobs =>
//       _jobsByFilter[selectedFilter] ?? [];

//   bool get isCurrentTabLoading =>
//       _loadingByFilter[selectedFilter] ?? false;

//   bool get isCurrentTabLoadingMore =>
//       _loadingMoreByFilter[selectedFilter] ?? false;

//   bool get currentTabHasMore =>
//       _hasMoreByFilter[selectedFilter] ?? false;

//   String? get currentTabError =>
//       _errorByFilter[selectedFilter];

//   // ============================================================
//   // API FILTER
//   // ============================================================

//   String _apiFilter(String filter) {
//     switch (filter) {
//       case 'Upcoming':
//         return 'upcoming';

//       case 'Completed':
//         return 'completed';

//       case 'Active':
//       default:
//         return 'active';
//     }
//   }

//   // ============================================================
//   // MAP API JOB
//   // ============================================================

//   Map<String, dynamic> _mapJob(
//     dynamic item,
//   ) {
//     return {
//       'id': item['id'],
//       'appointmentId': item['appointment_id'],
//       'uuid': item['uuid'],

//       'addressId': item['addressId'],

//       'clientLatitude': item['clientLatitude'],
//       'clientLongitude': item['clientLongitude'],

//       'branchId': item['branchId'],
//       'branchName': item['branchName'],
//       'branchLatitude': item['branchLatitude'],
//       'branchLongitude': item['branchLongitude'],

//       'clientName':
//           item['clientName'] ?? 'Client',

//       'clientMobile':
//           item['clientMobile'] ?? '',

//       'service':
//           item['service'] ??
//           'Pest Control Service',

//       'pestType':
//           item['pestType'] ??
//           'General Pest',

//       'fullPestTypes':
//           item['fullPestTypes'] ?? '',

//       'isTermite':
//           item['isTermite'] ?? false,

//       'svc_is_termite':
//           item['svc_is_termite'],

//       'address':
//           item['address'] ??
//           'No address',

//       'schedule':
//           item['schedule'] ??
//           'No schedule',

//       'scheduleDate':
//           item['scheduleDate'],

//       'scheduleTime':
//           item['scheduleTime'],

//       'status':
//           item['status'] ??
//           'ASSIGNED',

//       'assignedDate':
//           item['assignedDate'],

//       'startDate':
//           item['startDate'],

//       'startTime':
//           item['startTime'],

//       'endDate':
//           item['endDate'],

//       'endTime':
//           item['endTime'],

//       'travelTime':
//           item['travelTime'],

//       'serviceTime':
//           item['serviceTime'],

//       'totalDuration':
//           item['totalDuration'],

//       'timeFinished':
//           item['totalDuration'],

//       'technicianCount':
//           item['technicianCount'] ?? 1,

//       'isMultipleTechnician':
//           item['isMultipleTechnician'] ?? false,

//       'teamTechnicians':
//           item['teamTechnicians'] ?? [],

//       'leaderId':
//           item['leaderId'],

//       'isLeader':
//           item['isLeader'] ?? false,
//     };
//   }

//   // ============================================================
//   // LOAD TAB
//   // ============================================================

//   Future<void> _loadJobs(
//     String filter, {
//     bool reset = false,
//   }) async {
//     final currentlyLoading =
//         _loadingByFilter[filter] ?? false;

//     final currentlyLoadingMore =
//         _loadingMoreByFilter[filter] ?? false;

//     if (currentlyLoading ||
//         currentlyLoadingMore) {
//       return;
//     }

//     if (!reset &&
//         !(_hasMoreByFilter[filter] ?? true)) {
//       return;
//     }

//     final page = reset
//         ? 1
//         : (_pageByFilter[filter] ?? 1);

//     if (!mounted) return;

//     setState(() {
//       if (reset) {
//         _loadingByFilter[filter] = true;
//         _errorByFilter[filter] = null;
//       } else {
//         _loadingMoreByFilter[filter] = true;
//       }
//     });

//     try {
//       final response = await http
//           .post(
//             Uri.parse(
//               '${ApiConfig.baseUrl}/api/mobile/technician/assigned-jobs',
//             ),
//             headers: {
//               'Accept': 'application/json',
//             },
//             body: {
//               'email': widget.email,
//               'filter': _apiFilter(filter),
//               'page': page.toString(),
//             },
//           )
//           .timeout(
//             const Duration(seconds: 12),
//           );

//       final data =
//           jsonDecode(response.body);

//       if (!mounted) return;

//       if (response.statusCode == 200 &&
//           data['success'] == true) {
//         final List rawJobs =
//             data['data'] ?? [];

//         final newJobs = rawJobs
//             .map(_mapJob)
//             .toList();

//         final pagination =
//             data['pagination'] is Map
//                 ? Map<String, dynamic>.from(
//                     data['pagination'],
//                   )
//                 : <String, dynamic>{};

//         final hasMore =
//             pagination['has_more'] == true;

//         final nextPage =
//             pagination['next_page'];

//         setState(() {
//           if (reset) {
//             _jobsByFilter[filter] =
//                 newJobs;
//           } else {
//             _jobsByFilter[filter]!
//                 .addAll(newJobs);
//           }

//           _loadedByFilter[filter] =
//               true;

//           _hasMoreByFilter[filter] =
//               hasMore;

//           if (hasMore &&
//               nextPage != null) {
//             _pageByFilter[filter] =
//                 int.tryParse(
//                       nextPage.toString(),
//                     ) ??
//                     (page + 1);
//           } else {
//             _pageByFilter[filter] =
//                 page + 1;
//           }

//           _loadingByFilter[filter] =
//               false;

//           _loadingMoreByFilter[filter] =
//               false;

//           _errorByFilter[filter] =
//               null;
//         });

//         // Preserve the existing focus-job behavior
//         // when the requested job is in the loaded page.
//         if (!_focusJobHandled &&
//             widget.focusJobId != null &&
//             filter == selectedFilter) {
//           _tryOpenFocusedJob(filter);
//         }
//       } else {
//         setState(() {
//           _loadingByFilter[filter] =
//               false;

//           _loadingMoreByFilter[filter] =
//               false;

//           _errorByFilter[filter] =
//               data['message']
//                       ?.toString() ??
//                   'Unable to load assigned jobs.';
//         });
//       }
//     } catch (e) {
//       if (!mounted) return;

//       setState(() {
//         _loadingByFilter[filter] =
//             false;

//         _loadingMoreByFilter[filter] =
//             false;

//         _errorByFilter[filter] =
//             'Unable to connect to the server.';
//       });

//       debugPrint(
//         'ASSIGNED JOBS ERROR [$filter PAGE $page]: $e',
//       );
//     }
//   }

//   // ============================================================
//   // LOAD MORE
//   // ============================================================

//   Future<void> _loadMore() async {
//     if (!currentTabHasMore ||
//         isCurrentTabLoading ||
//         isCurrentTabLoadingMore) {
//       return;
//     }

//     await _loadJobs(
//       selectedFilter,
//     );
//   }

//   // ============================================================
//   // SCROLL LISTENER
//   // ============================================================

//   void _handleScroll() {
//     if (!_scrollController.hasClients) {
//       return;
//     }

//     final position =
//         _scrollController.position;

//     // Start loading shortly before the absolute bottom
//     // so scrolling feels smoother.
//     if (position.pixels >=
//         position.maxScrollExtent - 180) {
//       _loadMore();
//     }
//   }

//   // ============================================================
//   // CHANGE TAB
//   // ============================================================

//   Future<void> _selectFilter(
//     String filter,
//   ) async {
//     if (filter == selectedFilter) {
//       return;
//     }

//     setState(() {
//       selectedFilter = filter;
//     });

//     // Return new tab to the top.
//     if (_scrollController.hasClients) {
//       _scrollController.jumpTo(0);
//     }

//     // Do NOT call the API again if this tab
//     // has already been loaded.
//     if (!(_loadedByFilter[filter] ?? false)) {
//       await _loadJobs(
//         filter,
//         reset: true,
//       );
//     }
//   }

//   // ============================================================
//   // REFRESH CURRENT TAB ONLY
//   // ============================================================

//   Future<void> _refreshCurrentTab() async {
//     final filter = selectedFilter;

//     _pageByFilter[filter] = 1;
//     _hasMoreByFilter[filter] = true;

//     await _loadJobs(
//       filter,
//       reset: true,
//     );
//   }

//   // ============================================================
//   // INVALIDATE TAB
//   // ============================================================

//   void _invalidateTab(
//     String filter,
//   ) {
//     _loadedByFilter[filter] = false;
//     _pageByFilter[filter] = 1;
//     _hasMoreByFilter[filter] = true;
//   }

//   // ============================================================
//   // FOCUS JOB
//   // ============================================================

//   void _tryOpenFocusedJob(
//     String filter,
//   ) {
//     if (_focusJobHandled ||
//         widget.focusJobId == null) {
//       return;
//     }

//     Map<String, dynamic>? targetJob;

//     for (final job
//         in _jobsByFilter[filter] ?? []) {
//       if (job['id'].toString() ==
//           widget.focusJobId.toString()) {
//         targetJob = job;
//         break;
//       }
//     }

//     if (targetJob == null) {
//       return;
//     }

//     _focusJobHandled = true;

//     WidgetsBinding.instance
//         .addPostFrameCallback((_) {
//       if (!mounted) return;

//       _openJob(targetJob!);
//     });
//   }

//   // ============================================================
//   // OPEN JOB
//   // ============================================================

//   Future<void> _openJob(
//     Map<String, dynamic> job,
//   ) async {
//     final status =
//         job['status']
//             ?.toString()
//             .trim()
//             .toUpperCase() ??
//         '';

//     if (status == 'DONE SERVICE') {
//       await Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               TechnicianServiceReportSubmissionPage(
//             job: job,
//             email: widget.email,
//           ),
//         ),
//       );

//       if (!mounted) return;

//       // Submission may move the job from Active
//       // to Completed.
//       _invalidateTab('Completed');

//       await _refreshCurrentTab();

//       return;
//     }

//     await Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) =>
//             TechnicianJobDetailsPage(
//           job: job,
//           email: widget.email,
//         ),
//       ),
//     );

//     if (!mounted) return;

//     // Status may have changed from Job Details.
//     await _refreshCurrentTab();
//   }

//   // ============================================================
//   // ACTIVE JOB STATE
//   // ============================================================

//   bool get hasActiveJobToday {
//     final activeJobs =
//         _jobsByFilter['Active'] ?? [];

//     return activeJobs.any((job) {
//       final status =
//           job['status']
//               ?.toString()
//               .toUpperCase() ??
//           '';

//       return status == 'ONGOING' ||
//           status == 'ARRIVED' ||
//           status == 'DONE SERVICE';
//     });
//   }

//   bool get hasPendingReportToday {
//     final activeJobs =
//         _jobsByFilter['Active'] ?? [];

//     return activeJobs.any((job) {
//       final status =
//           job['status']
//               ?.toString()
//               .toUpperCase() ??
//           '';

//       return status == 'DONE SERVICE';
//     });
//   }

//   // ============================================================
//   // BUILD
//   // ============================================================

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//           AppTheme.lightGray,

//       drawer: AppDrawer(
//         userType: 2,
//         email: widget.email,
//         currentPage:
//             'assigned_jobs',
//       ),

//       appBar:
//           const AppTitleHeader(
//         title: 'Assigned Jobs',
//       ),

//       bottomNavigationBar:
//           TechnicianBottomNavBar(
//         currentIndex: 1,
//         email: widget.email,
//       ),

//       body: Padding(
//         padding:
//             const EdgeInsets.fromLTRB(
//           20,
//           20,
//           20,
//           0,
//         ),
//         child: Column(
//           crossAxisAlignment:
//               CrossAxisAlignment.start,
//           children: [
//             _pageHeader(),

//             const SizedBox(
//               height: 16,
//             ),

//             _filterChips(),

//             const SizedBox(
//               height: 16,
//             ),

//             Expanded(
//               child: _buildTabContent(),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // ============================================================
//   // TAB CONTENT
//   // ============================================================

//   Widget _buildTabContent() {
//     if (isCurrentTabLoading &&
//         currentJobs.isEmpty) {
//       return const Center(
//         child:
//             CircularProgressIndicator(
//           color:
//               AppTheme.primaryRed,
//         ),
//       );
//     }

//     if (currentTabError != null &&
//         currentJobs.isEmpty) {
//       return _errorState();
//     }

//     if (currentJobs.isEmpty) {
//       return RefreshIndicator(
//         color:
//             AppTheme.primaryRed,
//         onRefresh:
//             _refreshCurrentTab,
//         child: ListView(
//           physics:
//               const AlwaysScrollableScrollPhysics(),
//           children: [
//             const SizedBox(
//               height: 80,
//             ),

//             _EmptyAssignedJobsContent(
//               filter:
//                   selectedFilter,
//             ),
//           ],
//         ),
//       );
//     }

//     return RefreshIndicator(
//       color:
//           AppTheme.primaryRed,
//       onRefresh:
//           _refreshCurrentTab,
//       child: ListView.separated(
//         controller:
//             _scrollController,

//         physics:
//             const AlwaysScrollableScrollPhysics(),

//         padding:
//             const EdgeInsets.only(
//           bottom: 24,
//         ),

//         itemCount:
//             currentJobs.length +
//             (isCurrentTabLoadingMore
//                 ? 1
//                 : 0),

//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           height: 12,
//         ),

//         itemBuilder:
//             (context, index) {
//           // Bottom pagination loader.
//           if (index >=
//               currentJobs.length) {
//             return const Padding(
//               padding:
//                   EdgeInsets.symmetric(
//                 vertical: 14,
//               ),
//               child: Center(
//                 child: SizedBox(
//                   width: 22,
//                   height: 22,
//                   child:
//                       CircularProgressIndicator(
//                     strokeWidth: 2.2,
//                     color:
//                         AppTheme.primaryRed,
//                   ),
//                 ),
//               ),
//             );
//           }

//           final job =
//               currentJobs[index];

//           return _buildJobCard(job);
//         },
//       ),
//     );
//   }

//   // ============================================================
//   // JOB CARD
//   // ============================================================

//   Widget _buildJobCard(
//     Map<String, dynamic> job,
//   ) {
//     final status =
//         job['status']
//             ?.toString()
//             .toUpperCase() ??
//         '';

//     final isUpcomingTab =
//         selectedFilter == 'Upcoming';

//     final isBlockedPendingReport =
//         status == 'DONE SERVICE' &&
//         job['isMultipleTechnician'] ==
//             true &&
//         job['isLeader'] == false;

//     final shouldDisable =
//         (hasActiveJobToday &&
//             status == 'ASSIGNED') ||
//         isUpcomingTab ||
//         isBlockedPendingReport;

//     final disabledReason =
//         isBlockedPendingReport
//             ? 'leader_report'
//             : isUpcomingTab
//                 ? 'scheduled'
//                 : shouldDisable &&
//                         hasPendingReportToday
//                     ? 'pending_report'
//                     : 'active_job';

//     return TechnicianJobCard(
//       clientName:
//           job['clientName'] ??
//           'Client',

//       service:
//           job['service'] ??
//           'Pest Control Service',

//       pestType:
//           job['pestType'] ??
//           'General Pest',

//       address:
//           job['address'] ??
//           'No address',

//       schedule:
//           job['schedule'] ??
//           'No schedule',

//       status:
//           job['status'] ??
//           'ASSIGNED',

//       isDisabled:
//           shouldDisable,

//       disabledReason:
//           disabledReason,

//       technicianCount:
//           job['technicianCount'] ??
//           1,

//       isMultipleTechnician:
//           job['isMultipleTechnician'] ??
//           false,

//       teamTechnicians:
//           List<Map<String, dynamic>>.from(
//         job['teamTechnicians'] ?? [],
//       ),

//       onViewDetails: () async {
//         await _openJob(job);
//       },
//     );
//   }

//   // ============================================================
//   // ERROR
//   // ============================================================

//   Widget _errorState() {
//     return RefreshIndicator(
//       color:
//           AppTheme.primaryRed,
//       onRefresh:
//           _refreshCurrentTab,
//       child: ListView(
//         physics:
//             const AlwaysScrollableScrollPhysics(),
//         children: [
//           const SizedBox(
//             height: 85,
//           ),

//           Column(
//             children: [
//               Container(
//                 width: 68,
//                 height: 68,
//                 decoration:
//                     BoxDecoration(
//                   color:
//                       AppTheme.primaryRed
//                           .withOpacity(
//                     0.08,
//                   ),
//                   shape:
//                       BoxShape.circle,
//                 ),
//                 child:
//                     const Icon(
//                   Icons.wifi_off_rounded,
//                   color:
//                       AppTheme.primaryRed,
//                   size: 32,
//                 ),
//               ),

//               const SizedBox(
//                 height: 16,
//               ),

//               const Text(
//                 'Unable to load jobs',
//                 style:
//                     TextStyle(
//                   color:
//                       AppTheme.black,
//                   fontSize: 16,
//                   fontWeight:
//                       FontWeight.bold,
//                 ),
//               ),

//               const SizedBox(
//                 height: 7,
//               ),

//               Padding(
//                 padding:
//                     const EdgeInsets.symmetric(
//                   horizontal: 28,
//                 ),
//                 child: Text(
//                   currentTabError ??
//                       'Please try again.',
//                   textAlign:
//                       TextAlign.center,
//                   style:
//                       const TextStyle(
//                     color:
//                         AppTheme.gray,
//                     fontSize: 13,
//                     height: 1.35,
//                   ),
//                 ),
//               ),

//               const SizedBox(
//                 height: 16,
//               ),

//               OutlinedButton.icon(
//                 onPressed: () {
//                   _refreshCurrentTab();
//                 },
//                 icon:
//                     const Icon(
//                   Icons.refresh_rounded,
//                   size: 18,
//                 ),
//                 label:
//                     const Text(
//                   'Retry',
//                 ),
//                 style:
//                     OutlinedButton
//                         .styleFrom(
//                   foregroundColor:
//                       AppTheme.primaryRed,
//                   side:
//                       const BorderSide(
//                     color:
//                         AppTheme.primaryRed,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // ============================================================
//   // PAGE HEADER
//   // ============================================================

//   Widget _pageHeader() {
//     return const Column(
//       crossAxisAlignment:
//           CrossAxisAlignment.start,
//       children: [
//         Text(
//           'Your Assigned Services',
//           style:
//               TextStyle(
//             color:
//                 AppTheme.black,
//             fontSize: 18,
//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         SizedBox(height: 5),

//         Text(
//           'View and manage pest control services assigned to you',
//           style:
//               TextStyle(
//             color:
//                 AppTheme.gray,
//             fontSize: 13,
//             height: 1.35,
//           ),
//         ),
//       ],
//     );
//   }

//   // ============================================================
//   // FILTER CHIPS
//   // ============================================================

//   Widget _filterChips() {
//     return SizedBox(
//       height: 38,
//       child:
//           ListView.separated(
//         scrollDirection:
//             Axis.horizontal,

//         itemCount:
//             filters.length,

//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           width: 8,
//         ),

//         itemBuilder:
//             (context, index) {
//           final filter =
//               filters[index];

//           final isSelected =
//               selectedFilter ==
//               filter;

//           return GestureDetector(
//             onTap: () {
//               _selectFilter(
//                 filter,
//               );
//             },

//             child: Container(
//               padding:
//                   const EdgeInsets
//                       .symmetric(
//                 horizontal: 14,
//               ),
//               alignment:
//                   Alignment.center,

//               decoration:
//                   BoxDecoration(
//                 color:
//                     isSelected
//                         ? AppTheme
//                             .primaryRed
//                         : AppTheme
//                             .white,

//                 borderRadius:
//                     BorderRadius
//                         .circular(
//                   20,
//                 ),

//                 border:
//                     Border.all(
//                   color:
//                       isSelected
//                           ? AppTheme
//                               .primaryRed
//                           : AppTheme
//                               .borderGray,
//                 ),
//               ),

//               child: Text(
//                 filter,
//                 style:
//                     TextStyle(
//                   color:
//                       isSelected
//                           ? AppTheme
//                               .white
//                           : AppTheme
//                               .black,

//                   fontSize: 12,

//                   fontWeight:
//                       FontWeight
//                           .w700,
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// // ============================================================
// // EMPTY STATE
// // ============================================================

// class _EmptyAssignedJobsContent
//     extends StatelessWidget {
//   final String filter;

//   const _EmptyAssignedJobsContent({
//     required this.filter,
//   });

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     String title;
//     String message;
//     IconData icon;

//     switch (filter) {
//       case 'Upcoming':
//         title =
//             'No upcoming jobs';

//         message =
//             'Future pest control services assigned to you will appear here.';

//         icon =
//             Icons.event_outlined;

//         break;

//       case 'Completed':
//         title =
//             'No completed jobs';

//         message =
//             'Completed services with submitted reports will appear here.';

//         icon =
//             Icons.check_circle_outline_rounded;

//         break;

//       case 'Active':
//       default:
//         title =
//             'No active jobs today';

//         message =
//             'Today’s assigned pest control services will appear here.';

//         icon =
//             Icons.assignment_outlined;

//         break;
//     }

//     return Column(
//       mainAxisSize:
//           MainAxisSize.min,
//       children: [
//         Container(
//           width: 68,
//           height: 68,
//           decoration:
//               BoxDecoration(
//             color:
//                 AppTheme.primaryRed
//                     .withOpacity(
//               0.08,
//             ),
//             shape:
//                 BoxShape.circle,
//           ),
//           child: Icon(
//             icon,
//             color:
//                 AppTheme.primaryRed,
//             size: 34,
//           ),
//         ),

//         const SizedBox(
//           height: 16,
//         ),

//         Text(
//           title,
//           style:
//               const TextStyle(
//             color:
//                 AppTheme.black,
//             fontSize: 16,
//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         const SizedBox(
//           height: 7,
//         ),

//         Padding(
//           padding:
//               const EdgeInsets.symmetric(
//             horizontal: 28,
//           ),
//           child: Text(
//             message,
//             textAlign:
//                 TextAlign.center,
//             style:
//                 const TextStyle(
//               color:
//                   AppTheme.gray,
//               fontSize: 13,
//               height: 1.35,
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }