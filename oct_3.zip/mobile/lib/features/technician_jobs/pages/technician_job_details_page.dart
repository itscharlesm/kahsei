import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:http/http.dart' as http;
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_tracking_page.dart';
import 'package:mobile_app/shared/services/proximity_service.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

class TechnicianJobDetailsPage extends StatefulWidget {
  final Map<String, dynamic> job;
  final String email;

  const TechnicianJobDetailsPage({
    super.key,
    required this.job,
    required this.email,
  });

  @override
  State<TechnicianJobDetailsPage> createState() =>
      _TechnicianJobDetailsPageState();
}

class _TechnicianJobDetailsPageState extends State<TechnicianJobDetailsPage> {
  late String status;
  bool isStartingTravel = false;

  // DEVELOPMENT ONLY.
  // Keep disabled unless branch-proximity testing is explicitly needed.
  static const bool _enableProximityTest = false;
  bool _isProximityTestBypassed = false;

  StreamSubscription<geo.Position>? _branchProximitySubscription;
  geo.Position? _latestTechnicianPosition;

  bool _isCheckingBranchProximity = true;
  bool _isWithinBranchProximity = false;
  double? _distanceFromBranch;
  String? _branchProximityError;

  bool get _isBlockedByLeader =>
      (widget.job['leaderId'] ?? 0) != 0 &&
      widget.job['isLeader'] == false &&
      (status == 'ASSIGNED' ||
          status == 'ONGOING' ||
          status == 'ARRIVED' ||
          status == 'DONE SERVICE');

  @override
  void initState() {
    super.initState();

    status = _text(widget.job['status'], 'ASSIGNED').toUpperCase();

    // Temporarily disabled: branch proximity is not required to start travel.
    // if (status == 'ASSIGNED' && !_isBlockedByLeader) {
    //   _startBranchProximityMonitoring();
    // } else {
    _isCheckingBranchProximity = false;
    // }
  }

  String _text(dynamic value, [String fallback = 'N/A']) {
    if (value == null) return fallback;
    final text = value.toString().trim();
    return text.isEmpty ? fallback : text;
  }

  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString().trim());
  }

  String _formatProblemDescription(dynamic value) {
    final text = _text(value, '').trim();

    if (text.isEmpty) {
      return '';
    }

    // If the stored description is all uppercase,
    // convert it to normal sentence-style display.
    if (text == text.toUpperCase()) {
      final lower = text.toLowerCase();

      return lower.isEmpty
          ? ''
          : '${lower[0].toUpperCase()}${lower.substring(1)}';
    }

    return text;
  }

  List<String> _clientImages() {
    final rawImages = widget.job['clientImages'];

    if (rawImages is! List) {
      return [];
    }

    return rawImages
        .map(
          (image) =>
              image?.toString().trim() ?? '',
        )
        .where(
          (image) => image.isNotEmpty,
        )
        .toList();
  }

  Future<void> _startBranchProximityMonitoring() async {
    await _branchProximitySubscription?.cancel();

    final branchLatitude = _toDouble(widget.job['branchLatitude']);
    final branchLongitude = _toDouble(widget.job['branchLongitude']);

    if (branchLatitude == null || branchLongitude == null) {
      if (!mounted) return;

      setState(() {
        _isCheckingBranchProximity = false;
        _isWithinBranchProximity = false;
        _branchProximityError = 'The branch location is unavailable.';
      });
      return;
    }

    setState(() {
      _isCheckingBranchProximity = true;
      _isWithinBranchProximity = false;
      _branchProximityError = null;
    });

    try {
      await ProximityService.ensureLocationAccess();
      final currentPosition = await ProximityService.getCurrentPosition();

      _applyBranchProximity(
        position: currentPosition,
        branchLatitude: branchLatitude,
        branchLongitude: branchLongitude,
      );

      _branchProximitySubscription =
          ProximityService.getPositionStream().listen(
        (position) {
          _applyBranchProximity(
            position: position,
            branchLatitude: branchLatitude,
            branchLongitude: branchLongitude,
          );
        },
        onError: (Object error) {
          if (!mounted) return;

          setState(() {
            _isCheckingBranchProximity = false;
            _isWithinBranchProximity = false;
            _branchProximityError =
                'Unable to update your current location.';
          });
        },
      );
    } on ProximityException catch (error) {
      if (!mounted) return;

      setState(() {
        _isCheckingBranchProximity = false;
        _isWithinBranchProximity = false;
        _branchProximityError = error.message;
      });
    } catch (error) {
      debugPrint('BRANCH PROXIMITY ERROR: $error');

      if (!mounted) return;

      setState(() {
        _isCheckingBranchProximity = false;
        _isWithinBranchProximity = false;
        _branchProximityError =
            'Unable to determine your current location.';
      });
    }
  }

  void _applyBranchProximity({
    required geo.Position position,
    required double branchLatitude,
    required double branchLongitude,
  }) {
    if (_isProximityTestBypassed) return;

    final result = ProximityService.evaluate(
      technicianPosition: position,
      targetLatitude: branchLatitude,
      targetLongitude: branchLongitude,
    );

    if (!mounted) return;

    setState(() {
      _latestTechnicianPosition = position;
      _distanceFromBranch = result.distanceInMeters;
      _isWithinBranchProximity = result.isWithinRadius;
      _isCheckingBranchProximity = false;
      _branchProximityError = null;
    });

    debugPrint(
      'BRANCH PROXIMITY: '
      '${result.distanceInMeters.toStringAsFixed(1)} meters | '
      'within radius: ${result.isWithinRadius}',
    );
  }

  String _formatPestName(String pest) {
    final normalized = pest.trim().toUpperCase();

    switch (normalized) {
      case 'RATS/MICE':
        return 'Rodent';
      case 'BED BUGS':
        return 'Bed Bug';
      case 'COCKROACHES':
        return 'Cockroach';
      case 'ANTS':
        return 'Ant';
      case 'TERMITES':
        return 'Termite';
      default:
        return normalized
            .toLowerCase()
            .split(' ')
            .map((word) => word.isEmpty
                ? word
                : '${word[0].toUpperCase()}${word.substring(1)}')
            .join(' ');
    }
  }

  String _formatAssignedDate(
    dynamic value,
  ) {
    if (value == null) {
      return 'No assigned date';
    }

    final raw = value.toString().trim();

    if (raw.isEmpty) {
      return 'No assigned date';
    }

    final dateTime = DateTime.tryParse(raw);

    if (dateTime == null) {
      return raw;
    }

    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[dateTime.month - 1]} '
        '${dateTime.day}, '
        '${dateTime.year}';
  }

  List<String> _pestList() {
    final fullPestTypes = _text(widget.job['fullPestTypes'], '');

    if (fullPestTypes.isNotEmpty) {
      return fullPestTypes
          .split(',')
          .map((item) => item.trim())
          .where((item) => item.isNotEmpty)
          .map(_formatPestName)
          .toList();
    }

    return [_formatPestName(_text(widget.job['pestType'], 'General Pest'))];
  }

  List<Map<String, String>> _clientList() {
    final possibleLists = [
      widget.job['clients'],
      widget.job['multipleClients'],
      widget.job['clientDetails'],
      widget.job['serviceClients'],
    ];

    for (final rawList in possibleLists) {
      if (rawList is List && rawList.isNotEmpty) {
        final clients = rawList.whereType<Map>().map((rawClient) {
          final client = Map<String, dynamic>.from(rawClient);

          return {
            'name': _text(
              client['clientName'] ?? client['name'] ?? client['fullName'],
              'Client',
            ),
            'contact': _text(
              client['clientMobile'] ??
                  client['mobile'] ??
                  client['contact'] ??
                  client['phone'],
              'No contact number',
            ),
            'address': _text(
              client['address'] ??
                  client['serviceAddress'] ??
                  client['location'],
              'No address',
            ),
          };
        }).toList();

        if (clients.isNotEmpty) return clients;
      }
    }

    return [
      {
        'name': _text(widget.job['clientName'], 'Client'),
        'contact': _text(
          widget.job['clientMobile'],
          'No contact number',
        ),
        'address': _text(widget.job['address'], 'No address'),
      },
    ];
  }

  bool get _isMultipleClientJob {
    final value = widget.job['isMultipleClient'] ??
        widget.job['isMultipleClients'] ??
        widget.job['multipleClient'];

    if (value is bool) return value;
    if (value is num) return value != 0;
    if (value is String) {
      final normalized = value.trim().toLowerCase();
      return normalized == 'true' || normalized == '1' || normalized == 'yes';
    }

    return _clientList().length > 1;
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<bool> _startTravel() async {
    final appointmentId =
        widget.job['appointment_id'] ?? widget.job['appointmentId'];
    final scheduleId = widget.job['id'] ??
        widget.job['schedule_id'] ??
        widget.job['scheduleId'];

    if (appointmentId == null) {
      _showMessage('Missing appointment ID.');
      return false;
    }

    if (scheduleId == null) {
      _showMessage('Missing schedule ID.');
      return false;
    }

    try {
      final position = await ProximityService.getCurrentPosition();

      /* Temporarily disabled; restore this block if branch proximity is
         required for Start Travel again.
      final branchLatitude = _toDouble(widget.job['branchLatitude']);
      final branchLongitude = _toDouble(widget.job['branchLongitude']);

      if (branchLatitude == null || branchLongitude == null) {
        _showMessage('The branch location is unavailable.');
        return false;
      }

      final proximity = ProximityService.evaluate(
        technicianPosition: position,
        targetLatitude: branchLatitude,
        targetLongitude: branchLongitude,
      );

      if (!_isProximityTestBypassed && !proximity.isWithinRadius) {
        if (mounted) {
          setState(() {
            _latestTechnicianPosition = position;
            _distanceFromBranch = proximity.distanceInMeters;
            _isWithinBranchProximity = false;
          });
        }

        _showMessage(
          'You must be within 100 meters of the branch office to start travel.',
        );

        return false;
      }
      */

      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/technician/jobs/start-travel',
        ),
        headers: const {'Accept': 'application/json'},
        body: {
          'email': widget.email,
          'appointment_id': appointmentId.toString(),
          'schedule_id': scheduleId.toString(),
          'latitude': position.latitude.toString(),
          'longitude': position.longitude.toString(),
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['success'] == true) {
        widget.job['status'] = 'ONGOING';
        widget.job['startDate'] = data['startDate'];
        widget.job['startTime'] = data['startTime'];
        if (data['leaderId'] != null) {
          widget.job['leaderId'] = data['leaderId'];
        }
        // A successful Start Travel response means this technician won the
        // leader race. Default to true for compatibility with older servers
        // that do not return the leader fields yet.
        widget.job['isLeader'] = data['isLeader'] != false;

        setState(() {
          status = 'ONGOING';
        });

        return true;
      }

      _showMessage(data['message'] ?? 'Unable to start travel.');
      return false;
    } catch (e) {
      _showMessage(
        'Unable to start travel. Please check location permission.',
      );
      return false;
    }
  }

  @override
  void dispose() {
    _branchProximitySubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final job = widget.job;

    final clients = _clientList();

    final service =
    _text(
      job['service'],
      'Pest Control Service',
    );

    final pestTypes =
        _pestList();

    final schedule =
        _text(
      job['schedule'],
      'No schedule',
    );

    final assignedDate =
        _formatAssignedDate(
      job['assignedDate'],
    );

    final startDate =
        _text(
      job['startDate'],
      'Not started yet',
    );

    final startTime =
        _text(
      job['startTime'],
      'Not started yet',
    );

    final endDate =
        _text(
      job['endDate'],
      'Not completed yet',
    );

    final endTime =
        _text(
      job['endTime'],
      'Not completed yet',
    );

    final problemDescription =
        _formatProblemDescription(
      job['problemDescription'],
    );

    final clientImages =
        _clientImages();

    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: const AppBackHeader(title: 'Job Details'),
      bottomNavigationBar: status == 'DONE REPORT'
          ? null
          : SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
                decoration: const BoxDecoration(
                  color: AppTheme.white,
                  border: Border(
                    top: BorderSide(color: AppTheme.borderGray),
                  ),
                ),
                child: _actionButtons(),
              ),
            ),
      floatingActionButton: _enableProximityTest && status == 'ASSIGNED'
          ? FloatingActionButton.small(
              tooltip: 'Test Branch Proximity',
              backgroundColor: AppTheme.primaryRed,
              foregroundColor: AppTheme.white,
              onPressed: () {
                setState(() {
                  _isProximityTestBypassed = true;
                  _isCheckingBranchProximity = false;
                  _isWithinBranchProximity = true;
                  _distanceFromBranch = 50;
                  _branchProximityError = null;
                });

                debugPrint('TEST MODE: Branch proximity enabled.');
              },
              child: const Icon(Icons.navigation_rounded),
            )
          : null,
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          16,
          16,
          16,
          24,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _jobHeroCard(
              service: service,
            ),
            const SizedBox(height: 16),
            _sectionLabel('SERVICE DETAILS'),
            const SizedBox(height: 10),
            _detailsCard(
              children: [
                if (_isMultipleClientJob)
                  ..._multipleClientTiles(clients)
                else ...[
                  _detailTile(
                    icon: Icons.person_outline_rounded,
                    label: 'Client',
                    value: clients.first['name'] ?? 'Client',
                  ),
                  _divider(),
                  _detailTile(
                    icon: Icons.call_outlined,
                    label: 'Contact',
                    value: clients.first['contact'] ?? 'No contact number',
                  ),
                  _divider(),
                  _detailTile(
                    icon: Icons.location_on_outlined,
                    label: 'Service location',
                    value: clients.first['address'] ?? 'No address',
                    maxLines: 2,
                  ),
                ],
                _divider(),
                _detailTile(
                  icon: Icons.assignment_outlined,
                  label: 'Date Assigned',
                  value: assignedDate,
                ),
                _divider(),
                _detailTile(
                  icon: Icons.event_outlined,
                  label: 'Date Scheduled',
                  value: schedule,
                  maxLines: 2,
                ),
              ],
            ),

            if (problemDescription.isNotEmpty ||
                clientImages.isNotEmpty) ...[
              const SizedBox(height: 22),

              _sectionLabel(
                'CLIENT PROVIDED INFORMATION',
              ),

              const SizedBox(height: 10),

              _clientProvidedInformationCard(
                problemDescription:
                    problemDescription,
                images:
                    clientImages,
              ),
            ],

            if (widget.job['isMultipleTechnician'] == true) ...[
              const SizedBox(height: 22),
              _sectionLabel('ASSIGNED TEAM'),
              const SizedBox(height: 10),
              _teamCard(),
            ],

            const SizedBox(height: 22),

            _sectionLabel('JOB PROGRESS'),

            const SizedBox(height: 10),

            _progressCard(
              assignedDate: assignedDate,
              startDate: startDate,
              startTime: startTime,
              endDate: endDate,
              endTime: endTime,
            ),

            /* Temporarily disabled with the branch proximity requirement.
            if (status == 'ASSIGNED' && !_isBlockedByLeader) ...[
              const SizedBox(height: 22),
              _sectionLabel('START TRAVEL REQUIREMENT'),
              const SizedBox(height: 10),
              _branchProximityCard(),
            ],
            */

          ],
        ),
      ),
    );
  }

  // ============================================================
  // JOB HEADER
  // ============================================================

  // ============================================================
// SERVICE JOB HEADER
// ============================================================

Widget _jobHeroCard({
  required String service,
}) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppTheme.white,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(
        color: AppTheme.borderGray,
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.025),
          blurRadius: 10,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // ====================================================
        // ICON
        // ====================================================

        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppTheme.primaryRed.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.home_repair_service_outlined,
            color: AppTheme.primaryRed,
            size: 20,
          ),
        ),

        const SizedBox(width: 12),

        // ====================================================
        // SERVICE
        // ====================================================

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'SERVICE JOB',
                style: TextStyle(
                  color: AppTheme.gray,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                service,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 15,
                  height: 1.2,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

  Widget _heroInfoRow({
    required IconData icon,
    required String text,
  }) {
    return Row(
      children: [
        Icon(icon, size: 16, color: AppTheme.gray),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppTheme.black,
              fontSize: 11.5,
              height: 1.3,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _sectionLabel(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 2),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.gray,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.9,
        ),
      ),
    );
  }

  Widget _detailsCard({required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(children: children),
    );
  }

  Widget _clientProvidedInformationCard({
    required String problemDescription,
    required List<String> images,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(17),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          // ====================================================
          // PROBLEM DESCRIPTION
          // ====================================================

          if (problemDescription.isNotEmpty) ...[
            Row(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryRed
                        .withOpacity(0.07),
                    borderRadius:
                        BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.description_outlined,
                    size: 17,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),

                const SizedBox(width: 11),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Problem Description',
                        style: TextStyle(
                          color:
                              AppTheme.gray,
                          fontSize: 9.5,
                          fontWeight:
                              FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 4),

                      Text(
                        problemDescription,
                        style: const TextStyle(
                          color:
                              AppTheme.black,
                          fontSize: 12.5,
                          height: 1.45,
                          fontWeight:
                              FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],

          // ====================================================
          // DIVIDER
          // ====================================================

          if (problemDescription.isNotEmpty &&
              images.isNotEmpty)
            const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 14,
              ),
              child: Divider(
                height: 1,
                color:
                    AppTheme.borderGray,
              ),
            ),

          // ====================================================
          // CLIENT IMAGES
          // ====================================================

          if (images.isNotEmpty) ...[
            Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryRed
                        .withOpacity(0.07),
                    borderRadius:
                        BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.photo_library_outlined,
                    size: 17,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),

                const SizedBox(width: 11),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Client Photos',
                        style: TextStyle(
                          color:
                              AppTheme.gray,
                          fontSize: 9.5,
                          fontWeight:
                              FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 3),

                      Text(
                        images.length == 1
                            ? '1 photo attached'
                            : '${images.length} photos attached',
                        style: const TextStyle(
                          color:
                              AppTheme.black,
                          fontSize: 12.5,
                          fontWeight:
                              FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            SizedBox(
              height: 96,
              child: ListView.separated(
                scrollDirection:
                    Axis.horizontal,
                itemCount:
                    images.length,
                separatorBuilder:
                    (_, __) =>
                        const SizedBox(
                  width: 10,
                ),
                itemBuilder:
                    (context, index) {
                  final imageUrl =
                      images[index];

                  return GestureDetector(
                    onTap: () {
                      _showClientImagePreview(
                        imageUrl,
                      );
                    },
                    child: ClipRRect(
                      borderRadius:
                          BorderRadius.circular(
                        12,
                      ),
                      child: Container(
                        width: 112,
                        height: 96,
                        color:
                            AppTheme.lightGray,
                        child: Image.network(
                          imageUrl,
                          fit:
                              BoxFit.cover,

                          loadingBuilder: (
                            context,
                            child,
                            loadingProgress,
                          ) {
                            if (loadingProgress ==
                                null) {
                              return child;
                            }

                            return const Center(
                              child:
                                  SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth:
                                      2,
                                  color:
                                      AppTheme.primaryRed,
                                ),
                              ),
                            );
                          },

                          errorBuilder: (
                            context,
                            error,
                            stackTrace,
                          ) {
                            return const Center(
                              child: Icon(
                                Icons
                                    .broken_image_outlined,
                                color:
                                    AppTheme.gray,
                                size: 26,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 8),

            const Row(
              children: [
                Icon(
                  Icons.touch_app_outlined,
                  size: 13,
                  color:
                      AppTheme.gray,
                ),

                SizedBox(width: 5),

                Text(
                  'Tap a photo to view it.',
                  style: TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _showClientImagePreview(
    String imageUrl,
  ) async {
    await showDialog<void>(
      context: context,
      barrierColor:
          Colors.black.withOpacity(0.92),
      builder: (
        dialogContext,
      ) {
        return Dialog(
          backgroundColor:
              Colors.transparent,
          insetPadding:
              const EdgeInsets.all(14),
          child: Stack(
            children: [
              Container(
                width:
                    double.infinity,
                constraints:
                    const BoxConstraints(
                  maxHeight: 620,
                ),
                decoration:
                    BoxDecoration(
                  color:
                      Colors.black,
                  borderRadius:
                      BorderRadius.circular(
                    16,
                  ),
                ),
                child:
                    ClipRRect(
                  borderRadius:
                      BorderRadius.circular(
                    16,
                  ),
                  child:
                      InteractiveViewer(
                    minScale: 1,
                    maxScale: 4,
                    child:
                        Image.network(
                      imageUrl,
                      fit:
                          BoxFit.contain,
                      loadingBuilder: (
                        context,
                        child,
                        loadingProgress,
                      ) {
                        if (loadingProgress ==
                            null) {
                          return child;
                        }

                        return const Center(
                          child:
                              CircularProgressIndicator(
                            color:
                                AppTheme.white,
                          ),
                        );
                      },
                      errorBuilder: (
                        context,
                        error,
                        stackTrace,
                      ) {
                        return const Center(
                          child: Column(
                            mainAxisSize:
                                MainAxisSize.min,
                            children: [
                              Icon(
                                Icons
                                    .broken_image_outlined,
                                color:
                                    AppTheme.white,
                                size: 40,
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Text(
                                'Unable to load photo.',
                                style:
                                    TextStyle(
                                  color:
                                      AppTheme.white,
                                  fontSize:
                                      11,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),

              Positioned(
                top: 6,
                right: 6,
                child:
                    IconButton(
                  onPressed: () {
                    Navigator.pop(
                      dialogContext,
                    );
                  },
                  icon:
                      const Icon(
                    Icons.close_rounded,
                    color:
                        AppTheme.white,
                    size: 27,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _detailTile({
    required IconData icon,
    required String label,
    required String value,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 17, color: AppTheme.primaryRed),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  value,
                  maxLines: maxLines,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 12.5,
                    height: 1.3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _multipleClientTiles(List<Map<String, String>> clients) {
    final widgets = <Widget>[];

    for (var index = 0; index < clients.length; index++) {
      final client = clients[index];
      final clientNumber = index + 1;

      if (index > 0) {
        widgets.add(_divider());
      }

      widgets.add(
        _clientGroupTile(
          number: clientNumber,
          name: client['name'] ?? 'Client',
          contact: client['contact'] ?? 'No contact number',
          address: client['address'] ?? 'No address',
        ),
      );
    }

    return widgets;
  }

  Widget _clientGroupTile({
    required int number,
    required String name,
    required String contact,
    required String address,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.people_outline_rounded,
              size: 17,
              color: AppTheme.primaryRed,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Client $number',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  name,
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 12.5,
                    height: 1.3,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                _clientSubInfo(
                  icon: Icons.call_outlined,
                  text: contact,
                ),
                const SizedBox(height: 4),
                _clientSubInfo(
                  icon: Icons.location_on_outlined,
                  text: address,
                  maxLines: 3,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _clientSubInfo({
    required IconData icon,
    required String text,
    int maxLines = 1,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 1),
          child: Icon(icon, size: 13, color: AppTheme.gray),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            text,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppTheme.gray,
              fontSize: 10.5,
              height: 1.3,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _divider() {
    return const Divider(height: 1, color: AppTheme.borderGray);
  }

  // ============================================================
  // BRANCH PROXIMITY CARD
  // OPTION 6 - CIRCULAR GAUGE
  // ============================================================

  Widget _branchProximityCard() {
    // ============================================================
    // CHECKING LOCATION
    // ============================================================

    if (_isCheckingBranchProximity) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(
            color: AppTheme.borderGray,
          ),
        ),
        child: Row(
          children: [
            // ====================================================
            // GAUGE / LOADING
            // ====================================================

            Container(
              width: 74,
              height: 74,
              alignment: Alignment.center,
              child: const SizedBox(
                width: 42,
                height: 42,
                child: CircularProgressIndicator(
                  strokeWidth: 5,
                  color: AppTheme.primaryRed,
                  backgroundColor: AppTheme.lightGray,
                ),
              ),
            ),

            const SizedBox(width: 14),

            // ====================================================
            // MESSAGE
            // ====================================================

            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Checking Your Location',
                    style: TextStyle(
                      color: AppTheme.black,
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      height: 1.2,
                    ),
                  ),

                  SizedBox(height: 5),

                  Text(
                    'Please wait while we check your distance from the branch.',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 11,
                      height: 1.4,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // LOCATION ERROR
    // ============================================================

    if (_branchProximityError != null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(
            color: AppTheme.borderGray,
          ),
        ),
        child: Row(
          children: [
            // ====================================================
            // ERROR GAUGE
            // ====================================================

            SizedBox(
              width: 74,
              height: 74,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 68,
                    height: 68,
                    child: CircularProgressIndicator(
                      value: 1,
                      strokeWidth: 6,
                      color: AppTheme.primaryRed.withOpacity(
                        0.18,
                      ),
                      backgroundColor: AppTheme.lightGray,
                    ),
                  ),

                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryRed.withOpacity(
                        0.08,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.location_off_outlined,
                      color: AppTheme.primaryRed,
                      size: 23,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 14),

            // ====================================================
            // ERROR MESSAGE
            // ====================================================

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Location Unavailable',
                    style: TextStyle(
                      color: AppTheme.black,
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      height: 1.2,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Text(
                    _branchProximityError!,
                    style: const TextStyle(
                      color: AppTheme.gray,
                      fontSize: 11,
                      height: 1.4,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // DISTANCE
    // ============================================================

    final distance =
        _distanceFromBranch ?? 0;

    final ready =
        _isWithinBranchProximity;

    String distanceValue;
    String distanceUnit;

    if (distance >= 1000) {
      distanceValue =
          (distance / 1000).toStringAsFixed(
        1,
      );

      distanceUnit = 'km';
    } else {
      distanceValue =
          distance.toStringAsFixed(
        0,
      );

      distanceUnit = 'm';
    }

    // ============================================================
    // GAUGE VALUE
    // ============================================================

    //
    // 100 meters = full acceptable range.
    //
    // If technician is farther away,
    // the gauge gradually becomes smaller.
    //

    double gaugeValue;

    if (ready) {
      gaugeValue = 1;
    } else if (distance <= 0) {
      gaugeValue = 0;
    } else {
      gaugeValue =
          (100 / distance).clamp(
        0.08,
        1.0,
      );
    }

    // ============================================================
    // MAIN CARD
    // ============================================================

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          17,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.center,
        children: [
          // ======================================================
          // CIRCULAR GAUGE
          // ======================================================

          SizedBox(
            width: 78,
            height: 78,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // =================================================
                // GAUGE
                // =================================================

                SizedBox(
                  width: 72,
                  height: 72,
                  child: CircularProgressIndicator(
                    value: gaugeValue,
                    strokeWidth: 7,
                    strokeCap:
                        StrokeCap.round,
                    color: ready
                        ? Colors.green
                        : AppTheme.primaryRed,
                    backgroundColor:
                        ready
                            ? Colors.green.withOpacity(
                                0.12,
                              )
                            : AppTheme.primaryRed
                                .withOpacity(
                                0.10,
                              ),
                  ),
                ),

                // =================================================
                // DISTANCE INSIDE GAUGE
                // =================================================

                Column(
                  mainAxisSize:
                      MainAxisSize.min,
                  children: [
                    Text(
                      distanceValue,
                      style: TextStyle(
                        color: ready
                            ? Colors.green
                            : AppTheme.primaryRed,
                        fontSize: 18,
                        fontWeight:
                            FontWeight.w900,
                        height: 1,
                      ),
                    ),

                    const SizedBox(height: 2),

                    Text(
                      distanceUnit,
                      style: TextStyle(
                        color: ready
                            ? Colors.green
                            : AppTheme.primaryRed,
                        fontSize: 9.5,
                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(width: 15),

          // ======================================================
          // STATUS INFORMATION
          // ======================================================

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                // =================================================
                // TITLE
                // =================================================

                Text(
                  ready
                      ? 'Ready to Start Travel'
                      : 'Move Closer to the Office',
                  style: TextStyle(
                    color: ready
                        ? Colors.green.shade700
                        : AppTheme.primaryRed,
                    fontSize: 14.5,
                    fontWeight:
                        FontWeight.w900,
                    height: 1.2,
                  ),
                ),

                const SizedBox(height: 5),

                // =================================================
                // DESCRIPTION
                // =================================================

                Text(
                  ready
                      ? 'You are within the required 100-meter range.'
                      : 'You must be within 100 meters of the office.',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 11,
                    height: 1.35,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 9),

                // =================================================
                // STATUS BADGE
                // =================================================

                Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: ready
                        ? Colors.green.withOpacity(
                            0.08,
                          )
                        : AppTheme.primaryRed
                            .withOpacity(
                            0.07,
                          ),
                    borderRadius:
                        BorderRadius.circular(
                      20,
                    ),
                    border: Border.all(
                      color: ready
                          ? Colors.green.withOpacity(
                              0.20,
                            )
                          : AppTheme.primaryRed
                              .withOpacity(
                              0.18,
                            ),
                    ),
                  ),
                  child: Row(
                    mainAxisSize:
                        MainAxisSize.min,
                    children: [
                      Icon(
                        ready
                            ? Icons
                                .check_circle_outline_rounded
                            : Icons
                                .cancel_outlined,
                        size: 13,
                        color: ready
                            ? Colors.green.shade700
                            : AppTheme.primaryRed,
                      ),

                      const SizedBox(width: 5),

                      Text(
                        ready
                            ? 'Within Range'
                            : 'Out of Range',
                        style: TextStyle(
                          color: ready
                              ? Colors.green.shade700
                              : AppTheme.primaryRed,
                          fontSize: 9.5,
                          fontWeight:
                              FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _teamCard() {
    final technicians = List<Map<String, dynamic>>.from(
      widget.job['teamTechnicians'] ?? [],
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        children: technicians.asMap().entries.map((entry) {
          final index = entry.key;
          final tech = entry.value;
          final techId = tech['id'];
          final leaderId = widget.job['leaderId'];
          final isLeader = techId.toString() == leaderId.toString();

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(
                  children: [
                    AppProfileAvatar(
                      imageUrl: tech['profileImage']?.toString(),
                      size: 36,
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Text(
                        tech['name']?.toString() ?? 'Technician',
                        style: const TextStyle(
                          color: AppTheme.black,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    if (isLeader)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryRed.withOpacity(0.07),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'LEADER',
                          style: TextStyle(
                            color: AppTheme.primaryRed,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.4,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              if (index < technicians.length - 1) _divider(),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _progressCard({
    required String assignedDate,
    required String startDate,
    required String startTime,
    required String endDate,
    required String endTime,
  }) {
    final started = status == 'ONGOING' ||
        status == 'ARRIVED' ||
        status == 'DONE SERVICE' ||
        status == 'DONE REPORT';

    final completed = status == 'DONE SERVICE' || status == 'DONE REPORT';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(15, 16, 15, 15),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        children: [
          _progressItem(
            title: 'Job assigned',
            value: assignedDate,
            completed: true,
            showLine: true,
          ),
          _progressItem(
            title: 'Travel started',
            value: started ? '$startDate • $startTime' : 'Not started',
            completed: started,
            showLine: true,
          ),
          _progressItem(
            title: 'Service completed',
            value: completed ? '$endDate • $endTime' : 'Not completed',
            completed: completed,
            showLine: false,
          ),
        ],
      ),
    );
  }

  Widget _progressItem({
    required String title,
    required String value,
    required bool completed,
    required bool showLine,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: completed ? AppTheme.primaryRed : AppTheme.white,
                border: Border.all(
                  color: completed
                      ? AppTheme.primaryRed
                      : AppTheme.borderGray,
                  width: 1.5,
                ),
              ),
              child: completed
                  ? const Icon(
                      Icons.check_rounded,
                      size: 12,
                      color: AppTheme.white,
                    )
                  : null,
            ),
            if (showLine)
              Container(
                width: 1.5,
                height: 42,
                color: completed
                    ? AppTheme.primaryRed.withOpacity(0.28)
                    : AppTheme.borderGray,
              ),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: showLine ? 19 : 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: completed ? AppTheme.black : AppTheme.gray,
                      fontSize: 12.5,
                      fontWeight:
                          completed ? FontWeight.w800 : FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    value,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      color: completed ? AppTheme.black : AppTheme.gray,
                      fontSize: 10.5,
                      height: 1.3,
                      fontWeight:
                          completed ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _actionButtons() {
    if (status == 'ASSIGNED') {
      if (_isBlockedByLeader) {
        return _primaryButton(
          icon: Icons.lock_outline,
          label: 'Service Started by Team Leader',
          onPressed: null,
        );
      }

      if (widget.job['blockStartTravelForActiveJob'] == true) {
        return _primaryButton(
          icon: Icons.lock_outline,
          label: 'Finish Active Job First',
          onPressed: null,
        );
      }

      // Branch proximity restrictions are temporarily disabled.
      // final startTravelDisabled = isStartingTravel ||
      //     _isCheckingBranchProximity ||
      //     !_isWithinBranchProximity;
      final startTravelDisabled = isStartingTravel;

      return _primaryButton(
        // icon: _isWithinBranchProximity
        //     ? Icons.navigation_outlined
        //     : Icons.lock_outline_rounded,
        icon: Icons.navigation_outlined,
        // label: _isCheckingBranchProximity
        //     ? 'Checking Location...'
        //     : 'Start Travel',
        label: 'Start Travel',
        isLoading: isStartingTravel,
        onPressed: startTravelDisabled
            ? null
            : () async {
                setState(() {
                  isStartingTravel = true;
                });

                final success = await _startTravel();

                if (!mounted) return;

                setState(() {
                  isStartingTravel = false;
                });

                if (!success) return;

                await _branchProximitySubscription?.cancel();

                if (!mounted) return;

                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => TechnicianTrackingPage(
                      job: widget.job,
                      email: widget.email,
                    ),
                  ),
                );
              },
      );
    }

    if (status == 'ONGOING' || status == 'ARRIVED') {
      if (widget.job['isMultipleTechnician'] == true &&
          widget.job['isLeader'] == false) {
        return _primaryButton(
          icon: Icons.lock_outline,
          label: 'Service Started by Team Leader',
          onPressed: null,
        );
      }

      return _primaryButton(
        icon: Icons.route_outlined,
        label: 'Go Back to Tracking',
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TechnicianTrackingPage(
                job: widget.job,
                email: widget.email,
              ),
            ),
          );
        },
      );
    }

    if (status == 'DONE SERVICE') {
      if (widget.job['isMultipleTechnician'] == true &&
          widget.job['isLeader'] == false) {
        return _primaryButton(
          icon: Icons.lock_outline,
          label: 'Report Must Be Submitted by Team Leader',
          onPressed: null,
        );
      }

      return const SizedBox.shrink();
    }

    return const SizedBox.shrink();
  }

  Widget _primaryButton({
    required IconData icon,
    required String label,
    required VoidCallback? onPressed,
    bool isLoading = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.primaryRed,
          foregroundColor: AppTheme.white,
          disabledBackgroundColor: Colors.grey.shade300,
          disabledForegroundColor: Colors.grey.shade600,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.4,
                  valueColor: AlwaysStoppedAnimation<Color>(AppTheme.white),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 20),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 13.5,
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
