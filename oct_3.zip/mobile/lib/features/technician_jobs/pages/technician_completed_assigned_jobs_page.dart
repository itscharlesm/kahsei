import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/technician_jobs/pages/technician_job_details_page.dart';
import 'package:mobile_app/features/technician_jobs/widgets/technician_job_card.dart';

import 'package:mobile_app/features/technician_reports/pages/technician_service_report_submission_page.dart';

import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/loading/appointment_skeleton_list.dart';

class TechnicianCompletedAssignedJobsPage extends StatefulWidget {
  final String email;
  final int? focusJobId;

  const TechnicianCompletedAssignedJobsPage({
    super.key,
    required this.email,
    this.focusJobId,
  });

  @override
  State<TechnicianCompletedAssignedJobsPage> createState() =>
      _TechnicianCompletedAssignedJobsPageState();
}

class _TechnicianCompletedAssignedJobsPageState
    extends State<TechnicianCompletedAssignedJobsPage> {
  // ============================================================
  // SCROLL
  // ============================================================

  final ScrollController _scrollController =
      ScrollController();

  // ============================================================
  // DATA
  // ============================================================

  List<Map<String, dynamic>> jobs = [];

  // ============================================================
  // PAGINATION
  // ============================================================

  int currentPage = 1;
  bool hasMore = true;

  // ============================================================
  // LOADING
  // ============================================================

  bool isLoading = true;
  bool isLoadingMore = false;

  // ============================================================
  // ERROR
  // ============================================================

  String? errorMessage;

  // ============================================================
  // FOCUS JOB
  // ============================================================

  bool _focusJobHandled = false;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(
      _handleScroll,
    );

    _loadJobs(
      reset: true,
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _scrollController.removeListener(
      _handleScroll,
    );

    _scrollController.dispose();

    super.dispose();
  }

  // ============================================================
  // MAP API JOB
  // ============================================================

  Map<String, dynamic> _mapJob(
    dynamic item,
  ) {
    return {
      'id':
          item['id'],

      'appointmentId':
          item['appointment_id'],

      'saNumber':
          item['svc_sa_number'] ??
          item['saNumber'] ??
          '-',

      'uuid':
          item['uuid'],

      'addressId':
          item['addressId'],

      'clientLatitude':
          item['clientLatitude'],

      'clientLongitude':
          item['clientLongitude'],

      'branchId':
          item['branchId'],

      'branchName':
          item['branchName'],

      'branchLatitude':
          item['branchLatitude'],

      'branchLongitude':
          item['branchLongitude'],

      'clientName':
          item['clientName'] ??
          'Client',

      'clientMobile':
          item['clientMobile'] ??
          '',

      'clientProfileImage':
          item['clientProfileImage'],

      'service':
          item['service'] ??
          'Pest Control Service',

      'pestType':
          item['pestType'] ??
          'General Pest',

      'fullPestTypes':
          item['fullPestTypes'] ??
          '',

      'isTermite':
          item['isTermite'] ??
          false,

      'svc_is_termite':
          item['svc_is_termite'],

      'address':
          item['address'] ??
          'No address',

      'schedule':
          item['schedule'] ??
          'No schedule',

      'scheduleDate':
          item['scheduleDate'],

      'scheduleTime':
          item['scheduleTime'],

      'approvedDate':
          item['svca_approved_date'],

      'approvedTimeFrom':
          item['svca_approved_time_from'],

      'approvedTimeTo':
          item['svca_approved_time_to'],

      'status':
          item['status'] ??
          'DONE REPORT',

      'assignedDate':
          item['assignedDate'],

      'startDate':
          item['startDate'],

      'startTime':
          item['startTime'],

      'endDate':
          item['endDate'],

      'endTime':
          item['endTime'],

      'travelTime':
          item['travelTime'],

      'serviceTime':
          item['serviceTime'],

      'totalDuration':
          item['totalDuration'],

      'timeFinished':
          item['totalDuration'],

      'technicianCount':
          item['technicianCount'] ??
          1,

      'isMultipleTechnician':
          item['isMultipleTechnician'] ??
          false,

      'teamTechnicians':
          item['teamTechnicians'] ??
          [],

      'leaderId':
          item['leaderId'],

      'isLeader':
          item['isLeader'] ??
          false,
    };
  }

  // ============================================================
  // LOAD COMPLETED JOBS
  // ============================================================

  Future<void> _loadJobs({
    bool reset = false,
  }) async {
    if (isLoadingMore) {
      return;
    }

    if (!reset && !hasMore) {
      return;
    }

    final int page =
        reset
            ? 1
            : currentPage;

    if (!mounted) return;

    setState(() {
      if (reset || jobs.isEmpty) {
        isLoading = true;
      } else {
        isLoadingMore = true;
      }

      errorMessage = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}'
              '/api/mobile/technician/assigned-jobs',
            ),
            headers: {
              'Accept':
                  'application/json',
            },
            body: {
              'email':
                  widget.email,

              'filter':
                  'completed',

              'page':
                  page.toString(),
            },
          )
          .timeout(
            const Duration(
              seconds: 12,
            ),
          );

      final dynamic decodedData =
          jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode == 200 &&
          decodedData is Map &&
          decodedData['success'] == true) {
        final List rawJobs =
            decodedData['data'] ??
            [];

        final newJobs =
            rawJobs
                .map(
                  _mapJob,
                )
                .toList();

        final pagination =
            decodedData['pagination']
                    is Map
                ? Map<String, dynamic>.from(
                    decodedData[
                        'pagination'],
                  )
                : <String, dynamic>{};

        final bool responseHasMore =
            pagination['has_more'] ==
            true;

        final dynamic nextPage =
            pagination['next_page'];

        setState(() {
          if (reset) {
            jobs = newJobs;
          } else {
            jobs.addAll(
              newJobs,
            );
          }

          hasMore =
              responseHasMore;

          if (responseHasMore &&
              nextPage != null) {
            currentPage =
                int.tryParse(
                  nextPage.toString(),
                ) ??
                (page + 1);
          } else {
            currentPage =
                page + 1;
          }

          isLoading = false;
          isLoadingMore = false;
          errorMessage = null;
        });

        _tryOpenFocusedJob();

        return;
      }

      setState(() {
        isLoading = false;
        isLoadingMore = false;

        errorMessage =
            decodedData is Map
                ? decodedData[
                            'message']
                        ?.toString() ??
                    'Unable to load completed jobs.'
                : 'Unable to load completed jobs.';
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        isLoadingMore = false;

        errorMessage =
            'Unable to connect to the server.';
      });

      debugPrint(
        'COMPLETED ASSIGNED JOBS ERROR '
        '[PAGE $page]: $error',
      );
    }
  }

  // ============================================================
  // LOAD MORE
  // ============================================================

  Future<void> _loadMore() async {
    if (!hasMore ||
        isLoading ||
        isLoadingMore) {
      return;
    }

    await _loadJobs();
  }

  // ============================================================
  // SCROLL PAGINATION
  // ============================================================

  void _handleScroll() {
    if (!_scrollController
        .hasClients) {
      return;
    }

    final position =
        _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent -
            180) {
      _loadMore();
    }
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refreshJobs() async {
    currentPage = 1;
    hasMore = true;

    await _loadJobs(
      reset: true,
    );
  }

  // ============================================================
  // FOCUS JOB
  // ============================================================

  void _tryOpenFocusedJob() {
    if (_focusJobHandled ||
        widget.focusJobId ==
            null) {
      return;
    }

    Map<String, dynamic>?
        targetJob;

    for (final job in jobs) {
      if (job['id']
              .toString() ==
          widget.focusJobId
              .toString()) {
        targetJob = job;
        break;
      }
    }

    if (targetJob == null) {
      return;
    }

    _focusJobHandled = true;

    WidgetsBinding.instance
        .addPostFrameCallback(
      (_) {
        if (!mounted) return;

        _openJob(
          targetJob!,
        );
      },
    );
  }

  // ============================================================
  // OPEN JOB
  // ============================================================

  Future<void> _openJob(
    Map<String, dynamic> job,
  ) async {
    final String status =
        job['status']
                ?.toString()
                .trim()
                .toUpperCase() ??
            '';

    // Safety fallback retained from
    // the original Assigned Jobs page.
    //
    // Normally completed jobs should
    // already be DONE REPORT.
    if (status ==
        'DONE SERVICE') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) =>
              TechnicianServiceReportSubmissionPage(
            job: job,
            email: widget.email,
          ),
        ),
      );

      if (!mounted) return;

      await _refreshJobs();

      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TechnicianJobDetailsPage(
          job: job,
          email: widget.email,
        ),
      ),
    );

    if (!mounted) return;

    await _refreshJobs();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      appBar:
          const AppBackHeader(
        title: 'Completed Jobs',
      ),

      bottomNavigationBar:
          TechnicianBottomNavBar(
        currentIndex: 2,
        email: widget.email,
      ),

      body: Padding(
        padding:
            const EdgeInsets.fromLTRB(
          20,
          18,
          20,
          0,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _pageHeader(),

            const SizedBox(
              height: 16,
            ),

            Expanded(
              child:
                  _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // PAGE HEADER
  // ============================================================

  Widget _pageHeader() {
    return const Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Completed Assigned Jobs',
          style: TextStyle(
            color:
                AppTheme.black,
            fontSize: 18,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        SizedBox(
          height: 5,
        ),

        Text(
          'Review completed services and submitted service reports.',
          style: TextStyle(
            color:
                AppTheme.gray,
            fontSize: 13,
            height: 1.35,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget _buildContent() {
    if (isLoading &&
        jobs.isEmpty) {
      return const AppointmentSkeletonList();
    }

    if (errorMessage != null &&
        jobs.isEmpty) {
      return _errorState();
    }

    if (jobs.isEmpty) {
      return RefreshIndicator(
        color:
            AppTheme.primaryRed,
        onRefresh:
            _refreshJobs,
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(
              height: 80,
            ),

            _EmptyCompletedJobsContent(),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _refreshJobs,
      child: ListView.separated(
        controller:
            _scrollController,

        physics:
            const AlwaysScrollableScrollPhysics(),

        padding:
            const EdgeInsets.only(
          bottom: 24,
        ),

        itemCount:
            jobs.length +
            (isLoadingMore
                ? 1
                : 0),

        separatorBuilder:
            (_, __) =>
                const SizedBox(
          height: 12,
        ),

        itemBuilder:
            (context, index) {
          if (index >=
              jobs.length) {
            return const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 14,
              ),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child:
                      CircularProgressIndicator(
                    strokeWidth:
                        2.2,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            );
          }

          final job =
              jobs[index];

          return _buildJobCard(
            job,
          );
        },
      ),
    );
  }

  // ============================================================
  // JOB CARD
  // ============================================================

  Widget _buildJobCard(
    Map<String, dynamic> job,
  ) {
    return TechnicianJobCard(
      saNumber:
          job['saNumber'] ??
          job['svc_sa_number'] ??
          '-',

      clientName:
          job['clientName'] ??
          'Client',

      service:
          job['service'] ??
          'Pest Control Service',

      pestType:
          job['pestType'] ??
          'General Pest',

      address:
          job['address'] ??
          'No address',

      schedule:
          job['schedule'] ??
          'No schedule',

      status:
          job['status'] ??
          'DONE REPORT',

      // Completed records are not
      // automatically disabled in the
      // original tabbed implementation.
      isDisabled:
          false,

      disabledReason:
          '',

      technicianCount:
          job['technicianCount'] ??
          1,

      isMultipleTechnician:
          job['isMultipleTechnician'] ??
          false,

      teamTechnicians:
          List<Map<String, dynamic>>.from(
        job['teamTechnicians'] ??
            [],
      ),

      onViewDetails:
          () async {
        await _openJob(
          job,
        );
      },
    );
  }

  // ============================================================
  // ERROR STATE
  // ============================================================

  Widget _errorState() {
    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _refreshJobs,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(
            height: 85,
          ),

          Column(
            children: [
              Container(
                width: 68,
                height: 68,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  shape:
                      BoxShape.circle,
                ),
                child:
                    const Icon(
                  Icons
                      .wifi_off_rounded,
                  color:
                      AppTheme.primaryRed,
                  size: 32,
                ),
              ),

              const SizedBox(
                height: 16,
              ),

              const Text(
                'Unable to load jobs',
                style:
                    TextStyle(
                  color:
                      AppTheme.black,
                  fontSize: 16,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),

              const SizedBox(
                height: 7,
              ),

              Padding(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 28,
                ),
                child: Text(
                  errorMessage ??
                      'Please try again.',
                  textAlign:
                      TextAlign.center,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 13,
                    height: 1.35,
                  ),
                ),
              ),

              const SizedBox(
                height: 16,
              ),

              OutlinedButton.icon(
                onPressed:
                    _refreshJobs,
                icon:
                    const Icon(
                  Icons.refresh_rounded,
                  size: 18,
                ),
                label:
                    const Text(
                  'Retry',
                ),
                style:
                    OutlinedButton.styleFrom(
                  foregroundColor:
                      AppTheme.primaryRed,
                  side:
                      const BorderSide(
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// EMPTY STATE
// ============================================================

class _EmptyCompletedJobsContent
    extends StatelessWidget {
  const _EmptyCompletedJobsContent();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      mainAxisSize:
          MainAxisSize.min,
      children: [
        Container(
          width: 68,
          height: 68,
          decoration:
              BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            shape:
                BoxShape.circle,
          ),
          child:
              const Icon(
            Icons
                .check_circle_outline_rounded,
            color:
                AppTheme.primaryRed,
            size: 34,
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        const Text(
          'No completed jobs',
          textAlign:
              TextAlign.center,
          style:
              TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        const Padding(
          padding:
              EdgeInsets.symmetric(
            horizontal: 28,
          ),
          child: Text(
            'Completed services with submitted reports will appear here.',
            textAlign:
                TextAlign.center,
            style:
                TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}
