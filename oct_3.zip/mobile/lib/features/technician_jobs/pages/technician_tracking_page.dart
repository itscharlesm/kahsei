import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:mobile_app/config/api_config.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/shared.dart';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:ui';
import 'package:mobile_app/features/technician_jobs/widgets/job_duration_timer.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_report_submission_page.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_success_dialog.dart';
import 'package:mobile_app/features/technician_jobs/widgets/technician_tracking_info_sheet.dart';
import 'package:mobile_app/shared/services/proximity_service.dart';

class TechnicianTrackingPage extends StatefulWidget {
  final Map<String, dynamic> job;
  final String email;

  const TechnicianTrackingPage({
    super.key,
    required this.job,
    required this.email,
  });

  @override
  State<TechnicianTrackingPage> createState() => _TechnicianTrackingPageState();
}

class _TechnicianTrackingPageState extends State<TechnicianTrackingPage> {
  geo.Position? currentPosition;
  bool isLoadingLocation = true;
  bool isFollowingTechnician = false;
  bool isMapReady = false;
  bool isCreatingTechnicianMarker = false;
  bool isRerouting = false;
  bool isMarkingArrived = false;
  bool isSyncingLocation = false;
  bool isCompletingService = false;
  bool isPageDisposed = false;
  bool branchReady = false;
  bool clientReady = false;
  bool technicianReady = false;
  bool routeReady = false;
  bool usedFallbackRoute = false;
  bool _isCheckingClientProximity = true;
  bool _isWithinClientProximity = false;
  MapboxMap? mapboxMap;
  PointAnnotationManager? markerManager;
  PointAnnotation? technicianMarker;
  PointAnnotation? clientMarker;
  PointAnnotation? branchMarker;
  PolylineAnnotationManager? routeLineManager;
  PolylineAnnotation? routeLine;
  StreamSubscription<geo.Position>? positionStream;
  Timer? markerMoveTimer;
  List<Position> fullRouteCoordinates = [];
  DateTime? lastRerouteAt;
  DateTime? offRouteStartedAt;
  DateTime? lastLocationSyncAt;
  String etaText = 'Calculating';
  String? trackingMapError;
  String? _clientProximityError;
  
  double? _distanceFromClient;

  // DEVELOPMENT ONLY
  // Set to false before deployment.
  // static const bool _enableArrivalProximityTest = true;

  static const int locationSyncCooldownSeconds = 10;
  static const double offRouteThresholdMeters = 70;
  static const int offRouteDurationSeconds = 8;
  static const int rerouteCooldownSeconds = 30;
  static const int initialMapSetupMaxAttempts = 3;

  static const String technicianPinAsset = 'assets/images/img_technician_pin.png';
  static const String branchPinAsset = 'assets/images/img_go_pin.png';
  static const String clientPinAsset = 'assets/images/img_client_pin.png';

  static const double technicianPinSize = 0.27;
  static const double branchPinSize = 0.16;
  static const double clientPinSize = 0.16;

  late String trackingStatus;

  @override
  void initState() {
    super.initState();
    trackingStatus = _text(
      widget.job['status'],
      'ONGOING',
    ).toUpperCase();
    _loadCurrentLocation();
  }

  double? _toDouble(dynamic value) {
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  void _updateClientProximity(geo.Position position) {
    final clientLatitude =
        _toDouble(widget.job['clientLatitude']);

    final clientLongitude =
        _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null || clientLongitude == null) {
      if (!mounted) return;

      setState(() {
        _isCheckingClientProximity = false;
        _isWithinClientProximity = false;
        _clientProximityError =
            'The customer location is unavailable.';
      });

      return;
    }

    final result = ProximityService.evaluate(
      technicianPosition: position,
      targetLatitude: clientLatitude,
      targetLongitude: clientLongitude,
    );

    if (!mounted) return;

    setState(() {
      _distanceFromClient = result.distanceInMeters;
      _isWithinClientProximity = result.isWithinRadius;
      _isCheckingClientProximity = false;
      _clientProximityError = null;
    });

    debugPrint(
      'CLIENT PROXIMITY: '
      '${result.distanceInMeters.toStringAsFixed(1)} meters | '
      'within radius: ${result.isWithinRadius}',
    );
  }

  double _distanceBetweenCoordinates({
    required double lat1,
    required double lng1,
    required double lat2,
    required double lng2,
  }) {
    return geo.Geolocator.distanceBetween(
      lat1,
      lng1,
      lat2,
      lng2,
    );
  }

  Position _getNearestRoutePosition(
    geo.Position technicianPosition,
  ) {
    int closestIndex = 0;
    double closestDistance = double.infinity;

    for (int i = 0; i < fullRouteCoordinates.length; i++) {
      final point = fullRouteCoordinates[i];

      final distance = _distanceBetweenCoordinates(
        lat1: technicianPosition.latitude,
        lng1: technicianPosition.longitude,
        lat2: point.lat.toDouble(),
        lng2: point.lng.toDouble(),
      );

      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = i;
      }
    }

    return fullRouteCoordinates[closestIndex];
  }

  List<Position> _decodePolyline6(String encoded) {
    final List<Position> points = [];

    int index = 0;
    int lat = 0;
    int lng = 0;

    while (index < encoded.length) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encoded.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      final deltaLat = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lat += deltaLat;

      shift = 0;
      result = 0;

      do {
        byte = encoded.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      final deltaLng = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lng += deltaLng;

      points.add(
        Position(
          lng / 1000000,
          lat / 1000000,
        ),
      );
    }

    return points;
  }

  String _text(dynamic value, [String fallback = 'N/A']) {
    if (value == null) return fallback;
    final text = value.toString().trim();
    return text.isEmpty ? fallback : text;
  }

  String _formatEta(dynamic duration) {
    final seconds = double.tryParse(duration.toString());

    if (seconds == null || seconds <= 0) {
      return 'Calculating';
    }

    final minutes = (seconds / 60).round();

    if (minutes <= 0) {
      return 'Less than 1 min';
    }

    if (minutes < 60) {
      return '$minutes mins';
    }

    final hours = minutes ~/ 60;
    final remainingMinutes = minutes % 60;

    if (remainingMinutes == 0) {
      return '$hours hr';
    }

    return '$hours hr $remainingMinutes mins';
  }

  String _computeServiceTime(dynamic total, dynamic travel) {
    if (total == null || travel == null) return 'N/A';

    final totalParts = total.toString().split(':');
    final travelParts = travel.toString().split(':');

    if (totalParts.length != 3 || travelParts.length != 3) return 'N/A';

    int toSeconds(List<String> parts) {
      return (int.tryParse(parts[0]) ?? 0) * 3600 +
          (int.tryParse(parts[1]) ?? 0) * 60 +
          (int.tryParse(parts[2]) ?? 0);
    }

    final totalSeconds = toSeconds(totalParts);
    final travelSeconds = toSeconds(travelParts);

    final serviceSeconds =
        (totalSeconds - travelSeconds).clamp(0, totalSeconds);

    final hours = (serviceSeconds ~/ 3600).toString().padLeft(2, '0');
    final minutes =
        ((serviceSeconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final seconds = (serviceSeconds % 60).toString().padLeft(2, '0');

    return '$hours:$minutes:$seconds';
  }

  Future<void> _loadCurrentLocation() async {
    try {
      final position = await geo.Geolocator.getCurrentPosition(
        desiredAccuracy: geo.LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 8),
      );

      if (!mounted) return;

      setState(() {
        currentPosition = position;
        isLoadingLocation = false;
      });

      _updateClientProximity(position);

      await _addTechnicianMarker();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoadingLocation = false;
      });
    }
  }

  Future<void> _ensureCurrentLocation() async {
    if (currentPosition != null) {
      return;
    }

    try {
      final position = await geo.Geolocator.getCurrentPosition(
        desiredAccuracy: geo.LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 8),
      );

      currentPosition = position;
    } catch (e) {
      debugPrint('Unable to get current location before map setup: $e');
    }
  }

  Future<Uint8List> _loadMarkerImage(String assetPath) async {
    final byteData = await rootBundle.load(assetPath);
    return byteData.buffer.asUint8List();
  }

  Future<bool> _addTechnicianMarker() async {
    if (isPageDisposed || !mounted || mapboxMap == null || currentPosition == null) {
      return false;
    }

    if (isCreatingTechnicianMarker) {
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      if (isPageDisposed || !mounted || markerManager == null) {
        return false;
      }

      if (technicianMarker != null) {
        technicianMarker!.geometry = Point(
          coordinates: Position(
            currentPosition!.longitude,
            currentPosition!.latitude,
          ),
        );

        await markerManager!.update(technicianMarker!);
        return true;
      }

      isCreatingTechnicianMarker = true;

      final pinImage = await _loadMarkerImage(technicianPinAsset);

      if (isPageDisposed || !mounted || markerManager == null) {
        return false;
      }

      technicianMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              currentPosition!.longitude,
              currentPosition!.latitude,
            ),
          ),
          image: pinImage,
          iconSize: technicianPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return technicianMarker != null;
    } catch (e) {
      debugPrint('Technician marker skipped: $e');
      return false;
    } finally {
      isCreatingTechnicianMarker = false;
    }
  }

  Future<bool> _addClientMarker() async {
    if (clientMarker != null) return true;

    if (isPageDisposed || !mounted || mapboxMap == null) {
      return false;
    }

    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null || clientLongitude == null) {
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      final pinImage = await _loadMarkerImage(clientPinAsset);

      clientMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              clientLongitude,
              clientLatitude,
            ),
          ),
          image: pinImage,
          iconSize: clientPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return clientMarker != null;
    } catch (e) {
      debugPrint('Client marker failed: $e');
      return false;
    }
  }

  Future<bool> _addBranchMarker() async {
    if (branchMarker != null) return true;

    if (isPageDisposed || !mounted || mapboxMap == null) {
      return false;
    }

    final branchLatitude = _toDouble(widget.job['branchLatitude']);
    final branchLongitude = _toDouble(widget.job['branchLongitude']);

    if (branchLatitude == null || branchLongitude == null) {
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      final pinImage = await _loadMarkerImage(branchPinAsset);

      branchMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              branchLongitude,
              branchLatitude,
            ),
          ),
          image: pinImage,
          iconSize: branchPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return branchMarker != null;
    } catch (e) {
      debugPrint('Branch marker failed: $e');
      return false;
    }
  }

  Future<bool> _loadSharedRouteData() async {
    final scheduleId =
        widget.job['id'] ?? widget.job['schedule_id'] ?? widget.job['scheduleId'];

    if (scheduleId == null) {
      debugPrint('Technician shared route skipped: missing schedule ID.');
      return false;
    }

    debugPrint('TECHNICIAN ROUTE: loading cached route for schedule $scheduleId');
    debugPrint('TECHNICIAN ROUTE: using shared cached route endpoint');

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/tracking/route'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'schedule_id': scheduleId.toString(),
        },
      );

      debugPrint('TECHNICIAN ROUTE STATUS: ${response.statusCode}');
      debugPrint('TECHNICIAN ROUTE BODY: ${response.body}');

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid cached route response: ${response.body}');
        return false;
      }

      if (response.statusCode == 200 && data['success'] == true) {
        final route = data['route'];
        final geometry = route?['geometry'];
        final duration = route?['duration'];

        if (mounted) {
          setState(() {
            etaText = _formatEta(duration);
          });
        }

        if (geometry != null && geometry.toString().isNotEmpty) {
          final drawn = await _drawRouteLine(geometry.toString());

          if (drawn) {
            await Future.delayed(const Duration(milliseconds: 350));
            await _showRouteOverview();
          }

          return drawn;
        }

        return false;
      }

      debugPrint('Technician cached route unavailable: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Technician cached route fetch error: $e');
      return false;
    }
  }

  Future<bool> _drawRouteLine(String encodedPolyline) async {
    widget.job['cachedRouteGeometry'] = encodedPolyline;
    widget.job['cachedRouteMode'] = 'technician_to_client';

    if (mapboxMap == null) {
      return false;
    }

    final coordinates = _decodePolyline6(encodedPolyline);

    if (coordinates.isEmpty) {
      return false;
    }

    try {
      fullRouteCoordinates = coordinates;

      routeLineManager ??=
          await mapboxMap!.annotations.createPolylineAnnotationManager();

      if (routeLine != null) {
        await routeLineManager!.delete(routeLine!);
      }

      routeLine = await routeLineManager!.create(
        PolylineAnnotationOptions(
          geometry: LineString(
            coordinates: coordinates,
          ),
          lineColor: AppTheme.primaryRed.value,
          lineWidth: 4.5,
          lineOpacity: 0.9,
        ),
      );

      return routeLine != null;
    } catch (e) {
      debugPrint('Route line draw failed: $e');
      return false;
    }
  }

  Future<void> _toggleMapView() async {
    if (mapboxMap == null || currentPosition == null) return;

    if (!isFollowingTechnician) {
      setState(() {
        isFollowingTechnician = true;
      });

      await mapboxMap!.flyTo(
        CameraOptions(
          center: Point(
            coordinates: Position(
              currentPosition!.longitude,
              currentPosition!.latitude,
            ),
          ),
          zoom: 16,
        ),
        MapAnimationOptions(duration: 700),
      );
    } else {
      setState(() {
        isFollowingTechnician = false;
      });

      await _showRouteOverview();
    }
  }

  Future<void> _zoomIn() async {
    if (mapboxMap == null) return;

    final camera = await mapboxMap!.getCameraState();

    await mapboxMap!.easeTo(
      CameraOptions(
        zoom: camera.zoom + 1,
      ),
      MapAnimationOptions(duration: 250),
    );
  }

  Future<void> _zoomOut() async {
    if (mapboxMap == null) return;

    final camera = await mapboxMap!.getCameraState();

    await mapboxMap!.easeTo(
      CameraOptions(
        zoom: camera.zoom - 1,
      ),
      MapAnimationOptions(duration: 250),
    );
  }

  Future<void> _loadRouteData() async {
    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null || clientLongitude == null) {
      debugPrint('Missing client coordinates.');
      return;
    }

    if (currentPosition == null) {
      debugPrint('Missing technician current location.');
      return;
    }

    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/api/mobile/technician/route-to-client'),
      headers: {
        'Accept': 'application/json',
      },
      body: {
        'startLatitude': currentPosition!.latitude.toString(),
        'startLongitude': currentPosition!.longitude.toString(),
        'clientLatitude': clientLatitude.toString(),
        'clientLongitude': clientLongitude.toString(),
      },
    );

    Map<String, dynamic>? data;

    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('Invalid JSON response: ${response.body}');
      return;
    } 

    if (response.statusCode == 200 && data['success'] == true) {
      final geometry = data['geometry'];
      final duration = data['duration'];

      if (mounted) {
        setState(() {
          etaText = _formatEta(duration);
        });
      }

      if (geometry != null) {
        await _drawRouteLine(geometry);

        await Future.delayed(const Duration(milliseconds: 350));
        await _showRouteOverview();
      }
    }
  }

  Future<bool> _rerouteAndUpdateSharedCache() async {
    final scheduleId =
        widget.job['id'] ?? widget.job['schedule_id'] ?? widget.job['scheduleId'];

    if (scheduleId == null) {
      debugPrint('Reroute skipped: missing schedule ID.');
      return false;
    }

    if (currentPosition == null) {
      debugPrint('Reroute skipped: missing technician location.');
      return false;
    }

    debugPrint(
      'REROUTE: requesting shared cache update for schedule $scheduleId',
    );

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/tracking/reroute'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'schedule_id': scheduleId.toString(),
          'latitude': currentPosition!.latitude.toString(),
          'longitude': currentPosition!.longitude.toString(),
        },
      );

      debugPrint('REROUTE STATUS: ${response.statusCode}');
      debugPrint('REROUTE BODY: ${response.body}');

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid reroute response: ${response.body}');
        return false;
      }

      if (response.statusCode == 200 && data['success'] == true) {
        final route = data['route'];
        final geometry = route?['geometry'];
        final duration = route?['duration'];

        if (mounted) {
          setState(() {
            etaText = _formatEta(duration);
          });
        }

        if (geometry != null && geometry.toString().isNotEmpty) {
          final drawn = await _drawRouteLine(geometry.toString());

          if (drawn) {
            await Future.delayed(const Duration(milliseconds: 350));
            await _showRouteOverview();
          }

          debugPrint('REROUTE: shared cache route updated successfully.');
          return drawn;
        }

        return false;
      }

      debugPrint('REROUTE failed: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('REROUTE error: $e');
      return false;
    }
  }

  Future<bool> _drawFallbackRouteLine() async {
    if (mapboxMap == null || currentPosition == null) return false;

    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null || clientLongitude == null) return false;

    try {
      routeLineManager ??=
          await mapboxMap!.annotations.createPolylineAnnotationManager();

      final fallbackCoordinates = [
        Position(
          currentPosition!.longitude,
          currentPosition!.latitude,
        ),
        Position(
          clientLongitude,
          clientLatitude,
        ),
      ];

      fullRouteCoordinates = fallbackCoordinates;

      if (routeLine != null) {
        await routeLineManager!.delete(routeLine!);
      }

      routeLine = await routeLineManager!.create(
        PolylineAnnotationOptions(
          geometry: LineString(
            coordinates: fallbackCoordinates,
          ),
          lineColor: AppTheme.primaryRed.value,
          lineWidth: 4.5,
          lineOpacity: 0.55,
        ),
      );

      usedFallbackRoute = true;
      etaText = 'Calculating';

      debugPrint('Fallback straight route drawn.');

      return true;
    } catch (e) {
      debugPrint('Fallback route failed: $e');
      return false;
    }
  }

  Future<void> _showRouteOverview() async {
    if (mapboxMap == null || currentPosition == null) return;

    final branchLatitude = _toDouble(widget.job['branchLatitude']);
    final branchLongitude = _toDouble(widget.job['branchLongitude']);
    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (branchLatitude == null ||
        branchLongitude == null ||
        clientLatitude == null ||
        clientLongitude == null) {
      return;
    }

    final points = [
      Point(
        coordinates: Position(
          currentPosition!.longitude,
          currentPosition!.latitude,
        ),
      ),
      Point(
        coordinates: Position(
          branchLongitude,
          branchLatitude,
        ),
      ),
      Point(
        coordinates: Position(
          clientLongitude,
          clientLatitude,
        ),
      ),
    ];

    final cameraOptions = await mapboxMap!.cameraForCoordinates(
      points,
      MbxEdgeInsets(
        top: 70,
        left: 50,
        bottom: 80,
        right: 90,
      ),
      null,
      null,
    );

    await mapboxMap!.flyTo(
      cameraOptions,
      MapAnimationOptions(duration: 900),
    );
  }

  void _startLocationUpdates() {
    positionStream?.cancel();

    const locationSettings = geo.LocationSettings(
      accuracy: geo.LocationAccuracy.high,
      distanceFilter: 20,
    );

    positionStream = geo.Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((position) async {
      if (isPageDisposed || !mounted) return;

      currentPosition = position;
      _updateClientProximity(position);

      await _syncTechnicianLocation(position);

      if (technicianMarker == null) {
        await _addTechnicianMarker();
      }

      if (fullRouteCoordinates.isNotEmpty) {
        final snappedPosition = _getNearestRoutePosition(position);

        await _animateTechnicianMarkerTo(
          geo.Position(
            latitude: snappedPosition.lat.toDouble(),
            longitude: snappedPosition.lng.toDouble(),
            timestamp: DateTime.now(),
            accuracy: 0,
            altitude: 0,
            altitudeAccuracy: 0,
            heading: 0,
            headingAccuracy: 0,
            speed: 0,
            speedAccuracy: 0,
          ),
        );
      } else {
        await _addTechnicianMarker();
      }

      await _updateRemainingRouteFromTechnician(position);
    });
  }

  Future<void> _animateTechnicianMarkerTo(geo.Position newPosition) async {
    if (
        isPageDisposed ||
        !mounted ||
        technicianMarker == null ||
        markerManager == null) {
      return;
    }

    final oldPoint = technicianMarker!.geometry;

    final oldLng = oldPoint.coordinates.lng.toDouble();
    final oldLat = oldPoint.coordinates.lat.toDouble();

    final newLng = newPosition.longitude;
    final newLat = newPosition.latitude;

    markerMoveTimer?.cancel();

    const steps = 25;
    const duration = Duration(milliseconds: 800);
    final stepDuration = duration.inMilliseconds ~/ steps;

    int currentStep = 0;

    markerMoveTimer = Timer.periodic(
      Duration(milliseconds: stepDuration),
      (timer) async {
        if (
            isPageDisposed ||
            !mounted ||
            technicianMarker == null ||
            markerManager == null) {
          timer.cancel();
          return;
        }

        currentStep++;

        final t = currentStep / steps;

        final interpolatedLng = oldLng + ((newLng - oldLng) * t);
        final interpolatedLat = oldLat + ((newLat - oldLat) * t);

        technicianMarker!.geometry = Point(
          coordinates: Position(
            interpolatedLng,
            interpolatedLat,
          ),
        );

        try {
          await markerManager!.update(technicianMarker!);
        } catch (e) {
          debugPrint('Marker update skipped: $e');
          timer.cancel();
          return;
        }

        if (
            isFollowingTechnician &&
            mapboxMap != null &&
            !isPageDisposed &&
            mounted) {
          try {
            final camera = await mapboxMap!.getCameraState();

            await mapboxMap!.easeTo(
              CameraOptions(
                center: Point(
                  coordinates: Position(
                    interpolatedLng,
                    interpolatedLat,
                  ),
                ),
                zoom: camera.zoom,
              ),
              MapAnimationOptions(duration: 100),
            );
          } catch (e) {
            debugPrint('Camera update skipped: $e');
          }
        }

        if (currentStep >= steps) {
          timer.cancel();
        }
      },
    );
  }

  Future<void> _updateRemainingRouteFromTechnician(
    geo.Position technicianPosition,
  ) async {
    if (isRerouting) return;

    if (mapboxMap == null || routeLineManager == null || routeLine == null) {
      return;
    }

    if (fullRouteCoordinates.isEmpty) return;

    int closestIndex = 0;
    double closestDistance = double.infinity;

    for (int i = 0; i < fullRouteCoordinates.length; i++) {
      final point = fullRouteCoordinates[i];

      final distance = _distanceBetweenCoordinates(
        lat1: technicianPosition.latitude,
        lng1: technicianPosition.longitude,
        lat2: point.lat.toDouble(),
        lng2: point.lng.toDouble(),
      );

      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = i;
      }
    }

    await _checkRerouteNeed(closestDistance);

    if (isRerouting) return;

    if (closestIndex >= fullRouteCoordinates.length) return;

    final remainingRoute =
        fullRouteCoordinates.sublist(closestIndex);

    try {
      routeLine!.geometry = LineString(
        coordinates: remainingRoute,
      );

      await routeLineManager!.update(routeLine!);
      } catch (e) {
        debugPrint('Route update skipped: $e');
      }
  }

  Future<void> _checkRerouteNeed(double closestDistance) async {
    if (isRerouting) return;

    if (closestDistance < offRouteThresholdMeters) {
      offRouteStartedAt = null;
      return;
    }

    final now = DateTime.now();

    offRouteStartedAt ??= now;

    final offRouteSeconds =
        now.difference(offRouteStartedAt!).inSeconds;

    if (offRouteSeconds < offRouteDurationSeconds) return;

    if (lastRerouteAt != null) {
      final secondsSinceLastReroute =
          now.difference(lastRerouteAt!).inSeconds;

      if (secondsSinceLastReroute < rerouteCooldownSeconds) {
        return;
      }
    }

    lastRerouteAt = now;
    offRouteStartedAt = null;

    debugPrint('Rerouting from technician current position...');

    isRerouting = true;

    try {
      await _rerouteAndUpdateSharedCache();
    } finally {
      isRerouting = false;
    }
  }

  Future<void> _syncTechnicianLocation(geo.Position position) async {
    if (isSyncingLocation) return;

    final scheduleId =
      widget.job['id'] ?? widget.job['schedule_id'] ?? widget.job['scheduleId'];

    final now = DateTime.now();

    if (lastLocationSyncAt != null) {
      final secondsSinceLastSync =
          now.difference(lastLocationSyncAt!).inSeconds;

      if (secondsSinceLastSync < locationSyncCooldownSeconds) {
        return;
      }
    }

    if (scheduleId == null) {
      debugPrint('Location sync skipped: missing schedule ID.');
      return;
    }

    isSyncingLocation = true;

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/technician/update-location'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'schedule_id': scheduleId.toString(),
          'latitude': position.latitude.toString(),
          'longitude': position.longitude.toString(),
        },
      );

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid JSON response: ${response.body}');
        return;
      }
      
      if (response.statusCode == 200 && data['success'] == true) {
        lastLocationSyncAt = now;
        debugPrint('Technician location synced.');
      } else {
        debugPrint('Location sync failed: ${response.body}');
      }
    } catch (e) {
      debugPrint('Location sync error: $e');
    } finally {
      isSyncingLocation = false;
    }
  }

  Future<void> _markArrived() async {
    final appointmentId =
        widget.job['appointment_id'] ??
        widget.job['appointmentId'];

    final scheduleId =
        widget.job['id'] ??
        widget.job['schedule_id'] ??
        widget.job['scheduleId'];

    if (appointmentId == null || scheduleId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Missing appointment or schedule ID.',
          ),
        ),
      );
      return;
    }

    final clientLatitude =
        _toDouble(widget.job['clientLatitude']);

    final clientLongitude =
        _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null ||
        clientLongitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'The customer location is unavailable.',
          ),
        ),
      );
      return;
    }

    try {
      final position =
          await ProximityService.getCurrentPosition();

      final proximity =
          ProximityService.evaluate(
        technicianPosition: position,
        targetLatitude: clientLatitude,
        targetLongitude: clientLongitude,
      );

      if (!proximity.isWithinRadius) {
        if (mounted) {
          setState(() {
            currentPosition = position;
            _distanceFromClient =
                proximity.distanceInMeters;
            _isWithinClientProximity = false;
            _isCheckingClientProximity = false;
          });
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'You must be within 100 meters of the customer location to mark arrival.',
            ),
          ),
        );

        return;
      }

      if (!mounted) return;

      setState(() {
        isMarkingArrived = true;
      });

      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/technician/jobs/mark-arrived',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'appointment_id': appointmentId.toString(),
          'schedule_id': scheduleId.toString(),
          'latitude': position.latitude.toString(),
          'longitude': position.longitude.toString(),
        },
      );

      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        widget.job['status'] = 'ARRIVED';
        widget.job['travelTime'] = data['travelTime'];

        if (!mounted) return;

        setState(() {
          trackingStatus = 'ARRIVED';
        });

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AppSuccessDialog(
            title: 'Arrival Confirmed',
            message:
                'You have successfully arrived at the client location.',
            buttonText: 'Continue',
          ),
        );

        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            data['message'] ??
                'Unable to mark as arrived.',
          ),
        ),
      );
    } on ProximityException catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.message)),
      );
    } catch (error) {
      debugPrint('MARK ARRIVED ERROR: $error');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to mark arrival. Please try again.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isMarkingArrived = false;
        });
      }
    }
  }

  Future<void> _doneService() async {
    final appointmentId =
        widget.job['appointment_id'] ?? widget.job['appointmentId'];

    final scheduleId =
        widget.job['id'] ?? widget.job['schedule_id'] ?? widget.job['scheduleId'];

    if (appointmentId == null || scheduleId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Missing appointment or schedule ID.')),
      );
      return;
    }

    setState(() {
      isCompletingService = true;
    });

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/technician/jobs/done-service'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'appointment_id': appointmentId.toString(),
          'schedule_id': scheduleId.toString(),
        },
      );

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid JSON response: ${response.body}');
        return;
      }

      if (response.statusCode == 200 && data['success'] == true) {
        widget.job['status'] = 'DONE SERVICE';
        widget.job['endDate'] = data['endDate'];
        widget.job['endTime'] = data['endTime'];
        widget.job['timeFinished'] = data['timeFinished'];
        widget.job['totalDuration'] = data['timeFinished'];
        widget.job['serviceTime'] = _computeServiceTime(
          widget.job['totalDuration'],
          widget.job['travelTime'],
        );

        positionStream?.cancel();

        if (!mounted) return;

        setState(() {
          trackingStatus = 'DONE SERVICE';
        });

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AppSuccessDialog(
            title: 'Service Completed',
            message:
                'The service has been completed successfully. You may now proceed to the service report.',
            buttonText: 'Proceed to Report',
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => TechnicianServiceReportSubmissionPage(
                    job: widget.job,
                    email: widget.email,
                  ),
                ),
              );
            },
          ),
        );

        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data['message'] ?? 'Unable to complete service.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to connect to server.')),
      );
    } finally {
      if (mounted) {
        setState(() {
          isCompletingService = false;
        });
      }
    }
  }

  Future<void> _prepareAnnotationManagers() async {
    if (mapboxMap == null) return;

    routeLineManager ??=
        await mapboxMap!.annotations.createPolylineAnnotationManager();

    markerManager ??=
        await mapboxMap!.annotations.createPointAnnotationManager();
  }

  @override
  void dispose() {
    isPageDisposed = true;

    markerMoveTimer?.cancel();
    positionStream?.cancel();
    positionStream = null;
    markerMoveTimer = null;
    mapboxMap = null;
    markerManager = null;

    super.dispose();
  }

  Future<bool> _prepareTrackingMap() async {
    trackingMapError = null;

    for (int attempt = 1; attempt <= initialMapSetupMaxAttempts; attempt++) {
      debugPrint('Tracking map setup attempt $attempt');

      if (currentPosition == null) {
        await _ensureCurrentLocation();
      }

      if (!branchReady) {
        branchReady = await _addBranchMarker();
      }

      if (!clientReady) {
        clientReady = await _addClientMarker();
      }

      if (!technicianReady) {
        technicianReady = await _addTechnicianMarker();
      }

      if (!routeReady) {
        final cachedGeometry = widget.job['cachedRouteGeometry'];
        final cachedRouteMode = widget.job['cachedRouteMode'];

        if (cachedGeometry != null &&
            cachedGeometry.toString().isNotEmpty &&
            cachedRouteMode == 'technician_to_client') {
          routeReady = await _drawRouteLine(cachedGeometry.toString());
        } else {
          routeReady = await _loadSharedRouteData();
        }

        if (!routeReady) {
          debugPrint(
            'Cached route unavailable. Requesting shared route refresh.',
          );
          routeReady = await _rerouteAndUpdateSharedCache();
        }
      }

      if (branchReady && clientReady && technicianReady && routeReady) {
        return true;
      }

      if (attempt < initialMapSetupMaxAttempts) {
        await Future.delayed(const Duration(milliseconds: 250));
      }
    }

    if (branchReady && clientReady && technicianReady && !routeReady) {
      routeReady = await _drawFallbackRouteLine();
      return routeReady;
    }

    trackingMapError = 'Unable to load complete tracking map.';
    return false;
  }

  @override
  Widget build(BuildContext context) {
    
    final clientName = _text(widget.job['clientName'], 'Client');
    final address = _text(widget.job['address'], 'No address');

    final longitude = currentPosition?.longitude ?? 125.6131;
    final latitude = currentPosition?.latitude ?? 7.0731;

    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: const AppBackHeader(title: 'Travel Tracking'),

      // floatingActionButton:
      // _enableArrivalProximityTest &&
      // trackingStatus == 'ONGOING'
      //     ? FloatingActionButton.small(
      //         tooltip: 'Test Customer Proximity',
      //         backgroundColor: AppTheme.primaryRed,
      //         foregroundColor: AppTheme.white,
      //         onPressed: () {
      //           setState(() {
      //             _isCheckingClientProximity = false;
      //             _isWithinClientProximity = true;
      //             _distanceFromClient = 50;
      //             _clientProximityError = null;
      //           });

      //           debugPrint(
      //             'TEST MODE: Customer proximity enabled.',
      //           );
      //         },
      //         child: const Icon(
      //           Icons.flag_rounded,
      //           color: AppTheme.white,
      //         ),
      //       )
      //     : null,

      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: MapWidget(
                        cameraOptions: CameraOptions(
                          center: Point(
                            coordinates: Position(
                              longitude,
                              latitude,
                            ),
                          ),
                          zoom: 15,
                        ),
                        onMapCreated: (controller) async {
                          mapboxMap = controller;

                          setState(() {
                            isMapReady = false;
                          });

                          try {
                            await controller.scaleBar.updateSettings(
                              ScaleBarSettings(enabled: false),
                            );

                            await controller.compass.updateSettings(
                              CompassSettings(enabled: true),
                            );

                            await controller.location.updateSettings(
                              LocationComponentSettings(enabled: false),
                            );

                            await _prepareAnnotationManagers();

                            final setupReady = await _prepareTrackingMap();

                            if (isPageDisposed || !mounted || mapboxMap == null) return;

                            if (setupReady) {
                              await Future.delayed(const Duration(milliseconds: 350));
                              await _showRouteOverview();

                              _startLocationUpdates();
                            }

                            if (!mounted) return;

                            if (!setupReady) {
                              debugPrint(trackingMapError ?? 'Tracking map setup failed.');
                              return;
                            }

                            setState(() {
                              isMapReady = true;
                            });
                          } catch (e) {
                            debugPrint('Map setup error: $e');

                            if (!mounted) return;

                            setState(() {
                              isMapReady = true;
                            });
                          }
                        },
                      ),
                    ),

                    if (!isMapReady)
                      _mapGlassLoadingOverlay(),

                    if (isMapReady)
                      Positioned(
                        right: 7,
                        top: 90,
                        child: Column(
                          children: [
                            _mapControlButton(
                              icon: isFollowingTechnician
                                  ? Icons.gps_fixed_rounded
                                  : Icons.my_location_rounded,
                              onTap: _toggleMapView,
                            ),

                            const SizedBox(height: 8),

                            _mapControlButton(
                              icon: Icons.add,
                              onTap: _zoomIn,
                            ),

                            const SizedBox(height: 8),

                            _mapControlButton(
                              icon: Icons.remove,
                              onTap: _zoomOut,
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),

              // Reserved space behind the sheet
              const SizedBox(
                height: 260,
              ),
            ],
          ),

          DraggableScrollableSheet(
            initialChildSize: 0.39,
            minChildSize: 0.39,
            maxChildSize: 0.72,
            snap: true,
            snapSizes: const [
              0.39,
              0.72,
            ],
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: AppTheme.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(24),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 12,
                      offset: Offset(0, -3),
                    ),
                  ],
                ),
                child: ListView(
                  controller: scrollController,
                  padding: EdgeInsets.zero,
                  children: [
                    TechnicianTrackingInfoSheet(
                      job: widget.job,
                      trackingStatus: trackingStatus,
                      etaText: etaText,
                      isMarkingArrived: isMarkingArrived,
                      isCompletingService: isCompletingService,
                      isCheckingClientProximity:
                          _isCheckingClientProximity,

                      isWithinClientProximity:
                          _isWithinClientProximity,

                      distanceFromClient:
                          _distanceFromClient,

                      clientProximityError:
                          _clientProximityError,
                      onPrimaryAction:
                          isMarkingArrived || isCompletingService
                              ? null
                              : trackingStatus == 'DONE SERVICE'
                                  ? () {
                                      Navigator.pop(
                                        context,
                                        'DONE SERVICE',
                                      );
                                    }
                                  : trackingStatus == 'ARRIVED'
                                      ? _doneService
                                      : _markArrived,
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _mapControlButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: AppTheme.black,
      borderRadius: BorderRadius.circular(70),
      elevation: 3,
      shadowColor: Colors.black.withOpacity(0.12),
      child: InkWell(
        borderRadius: BorderRadius.circular(70),
        onTap: onTap,
        child: SizedBox(
          width: 42,
          height: 42,
          child: Icon(
            icon,
            color: AppTheme.white,
            size: 21,
          ),
        ),
      ),
    );
  }

  Widget _mapGlassLoadingOverlay() {
    return Positioned.fill(
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 10,
            sigmaY: 10,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
            ),
          ),
        ),
      ),
    );
  }
}
