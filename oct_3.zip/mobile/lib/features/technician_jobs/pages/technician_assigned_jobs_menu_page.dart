import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_active_assigned_jobs_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_upcoming_assigned_jobs_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_completed_assigned_jobs_page.dart';

class TechnicianAssignedJobsMenuPage extends StatelessWidget {
  final String email;

  const TechnicianAssignedJobsMenuPage({
    super.key,
    required this.email,
  });


  // NAVIGATION
 void _openActiveJobs(
    BuildContext context,
  ) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianActiveAssignedJobsPage(
          email: email,
        ),
      ),
    );
  }

  void _openUpcomingJobs(
    BuildContext context,
  ) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianUpcomingAssignedJobsPage(
          email: email,
        ),
      ),
    );
  }

  void _openCompletedJobs(
    BuildContext context,
  ) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianCompletedAssignedJobsPage(
          email: email,
        ),
      ),
    );
  }

  void _showComingSoon(
    BuildContext context,
    String page,
  ) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            '$page page will be connected next.',
          ),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(
            seconds: 2,
          ),
        ),
      );
  }

  // BUILD
  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 2,
        email: email,
        currentPage:
            'assigned_jobs',
      ),

      appBar: const AppTitleHeader(
        title: 'Assigned Jobs',
      ),

      bottomNavigationBar:
          TechnicianBottomNavBar(
            currentIndex: 2,
            email: email,
          ),

      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding:
              const EdgeInsets.fromLTRB(
            20,
            20,
            20,
            30,
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              // ==================================================
              // PAGE HEADER
              // ==================================================

              _pageHeader(),

              const SizedBox(
                height: 20,
              ),

              // ==================================================
              // ACTIVE JOBS
              // ==================================================

              _JobMenuCard(
                icon:
                    Icons.play_circle_outline_rounded,
                title:
                    'Active Jobs',
                description:
                    'View and manage pest control services assigned to you for today.',
                onTap: () {
                  _openActiveJobs(
                    context,
                  );
                },
              ),

              const SizedBox(
                height: 12,
              ),

              // ==================================================
              // UPCOMING JOBS
              // ==================================================

              _JobMenuCard(
                icon:
                    Icons.calendar_month_outlined,
                title:
                    'Upcoming Jobs',
                description:
                    'View future pest control services already assigned to your schedule.',
                onTap: () {
                  _openUpcomingJobs(
                    context,
                  );
                },
              ),

              const SizedBox(
                height: 12,
              ),

              // ==================================================
              // COMPLETED JOBS
              // ==================================================

              _JobMenuCard(
                icon:
                    Icons.check_circle_outline_rounded,
                title:
                    'Completed Jobs',
                description:
                    'Review completed services and submitted service reports.',
                onTap: () {
                  _openCompletedJobs(
                    context,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // PAGE HEADER
  // ============================================================

  Widget _pageHeader() {
    return const Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Your Assigned Services',
          style: TextStyle(
            color: AppTheme.black,
            fontSize: 18,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        SizedBox(
          height: 5,
        ),

        Text(
          'Select a category to view and manage your assigned pest control services.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.35,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// JOB MENU CARD
// ============================================================

class _JobMenuCard
    extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;

  const _JobMenuCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Material(
      color: AppTheme.white,
      borderRadius:
          BorderRadius.circular(
        16,
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius:
            BorderRadius.circular(
          16,
        ),
        child: Container(
          width: double.infinity,
          padding:
              const EdgeInsets.fromLTRB(
            14,
            15,
            12,
            15,
          ),
          decoration: BoxDecoration(
            borderRadius:
                BorderRadius.circular(
              16,
            ),
            border: Border.all(
              color:
                  AppTheme.borderGray,
            ),
          ),
          child: Row(
            children: [
              // ==================================================
              // ICON
              // ==================================================

              Container(
                width: 46,
                height: 46,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  borderRadius:
                      BorderRadius.circular(
                    13,
                  ),
                ),
                child: Icon(
                  icon,
                  color:
                      AppTheme.primaryRed,
                  size: 23,
                ),
              ),

              const SizedBox(
                width: 13,
              ),

              // ==================================================
              // CONTENT
              // ==================================================

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                  children: [
                    Text(
                      title,
                      style:
                          const TextStyle(
                        color:
                            AppTheme.black,
                        fontSize: 14,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    Text(
                      description,
                      style:
                          const TextStyle(
                        color:
                            AppTheme.gray,
                        fontSize: 11.5,
                        height: 1.35,
                        fontWeight:
                            FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                width: 8,
              ),

              // ==================================================
              // ARROW
              // ==================================================

              const Icon(
                Icons
                    .chevron_right_rounded,
                color: AppTheme.gray,
                size: 23,
              ),
            ],
          ),
        ),
      ),
    );
  }
}