import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/notifications/pages/technician_notifications_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_job_details_page.dart';
import 'package:mobile_app/features/technician_reports/pages/technician_service_report_submission_page.dart';
import 'package:mobile_app/shared/services/notification_service.dart';
import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';
import 'package:mobile_app/shared/widgets/headers/app_home_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/technician_bottom_nav_bar.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_active_assigned_jobs_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_upcoming_assigned_jobs_page.dart';
import 'package:mobile_app/features/technician_jobs/pages/technician_completed_assigned_jobs_page.dart';
import 'package:mobile_app/features/technician_jobs/widgets/technician_job_status_badge.dart';
import 'package:mobile_app/features/profiles/widgets/default_avatar_picker.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

class TechnicianHomePage extends StatefulWidget {
  final String email;

  const TechnicianHomePage({super.key, required this.email});

  @override
  State<TechnicianHomePage> createState() => _TechnicianHomePageState();
}

class _TechnicianHomePageState extends State<TechnicianHomePage> {
  int _unreadNotificationCount = 0;

  bool isLoadingDashboard = true;

  int todaysJobsCount = 0;
  int completedTodayCount = 0;
  int upcomingJobsCount = 0;
  int overdueJobsCount = 0;

  String technicianName = 'Technician';

  Map<String, dynamic>? _technicianProfile;
  String? _profileImagePath;
  bool _profileLoadFinished = false;
  bool _avatarPromptScheduled = false;
  bool _avatarPromptOpen = false;

  Map<String, dynamic>? todaysAssignment;
  List<Map<String, dynamic>> upcomingSchedule = [];

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _loadDashboard();
    _syncSharedProfile();
    AuthSessionService.instance.displayProfile.listenable.addListener(
      _syncSharedProfile,
    );
    _fetchTechnicianProfile();

    _unreadNotificationCount =
        AppNotificationService.instance.technicianUnreadCount.value;

    AppNotificationService.instance.technicianUnreadCount.addListener(
      _updateUnreadNotificationCount,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      AppNotificationService.instance.showTechnicianUnreadSummaryIfNeeded();
    });

    AppNotificationService.instance.onNotificationTap = (payload) {
      if (!mounted) return;

      _openNotifications();
    };
  }

  // ============================================================
  // LOAD TECHNICIAN DASHBOARD
  // ============================================================

  Future<void> _loadDashboard() async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/technician/dashboard'),
        headers: {'Accept': 'application/json'},
        body: {'email': widget.email},
      );

      final data = jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 && data['success'] == true) {
        final dashboard = Map<String, dynamic>.from(data['data'] ?? {});

        setState(() {
          todaysJobsCount = dashboard['todaysJobs'] ?? 0;

          completedTodayCount = dashboard['completedToday'] ?? 0;

          upcomingJobsCount = dashboard['upcoming'] ?? 0;

          overdueJobsCount = dashboard['overdue'] ?? 0;

          final assignment = dashboard['assignment'];

          todaysAssignment = assignment != null
              ? Map<String, dynamic>.from(assignment)
              : null;

          final upcomingData = dashboard['upcomingSchedule'] as List? ?? [];

          upcomingSchedule = upcomingData
              .map((item) => Map<String, dynamic>.from(item))
              .toList();

          isLoadingDashboard = false;
        });
        _scheduleAvatarPromptIfNeeded();
      } else {
        setState(() {
          todaysJobsCount = 0;
          completedTodayCount = 0;
          upcomingJobsCount = 0;
          overdueJobsCount = 0;
          todaysAssignment = null;
          isLoadingDashboard = false;
          upcomingSchedule = [];
        });
        _scheduleAvatarPromptIfNeeded();
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        todaysJobsCount = 0;
        completedTodayCount = 0;
        upcomingJobsCount = 0;
        overdueJobsCount = 0;
        todaysAssignment = null;
        isLoadingDashboard = false;
        upcomingSchedule = [];
      });
      _scheduleAvatarPromptIfNeeded();

      debugPrint('TECHNICIAN DASHBOARD ERROR: $e');
    }
  }

  // ============================================================
  // NOTIFICATIONS
  // ============================================================

  void _updateUnreadNotificationCount() {
    if (!mounted) return;

    setState(() {
      _unreadNotificationCount =
          AppNotificationService.instance.technicianUnreadCount.value;
    });
  }

  void _openNotifications() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TechnicianNotificationsPage(email: widget.email),
      ),
    );
  }

  // ============================================================
  // FORMATTED DATE
  // ============================================================

  String _formattedDate() {
    final now = DateTime.now();

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    const weekdays = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];

    return '${weekdays[now.weekday - 1]}, '
        '${months[now.month - 1]} '
        '${now.day}, ${now.year}';
  }

  String _text(dynamic value, [String fallback = '']) {
    if (value == null) {
      return fallback;
    }

    final text = value.toString().trim();

    return text.isEmpty ? fallback : text;
  }

  String _capitalizeName(String name) {
    if (name.trim().isEmpty) {
      return 'Technician';
    }

    return name
        .trim()
        .toLowerCase()
        .split(' ')
        .map(
          (word) => word.isEmpty
              ? ''
              : '${word[0].toUpperCase()}${word.substring(1)}',
        )
        .join(' ');
  }

  String? get _technicianImageUrl {
    final path = _profileImagePath?.trim() ?? '';
    if (path.isEmpty) return null;

    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }

    final normalizedPath = path.startsWith('/') ? path.substring(1) : path;
    return '${ApiConfig.baseUrl}/$normalizedPath';
  }

  void _syncSharedProfile() {
    if (!mounted) return;
    final store = AuthSessionService.instance.displayProfile;
    final profile = store.value;
    final matches = profile?.email == widget.email && profile?.userType == 2;
    setState(() {
      _profileImagePath = matches ? profile?.avatarPath : null;
      technicianName = matches && profile?.firstName?.trim().isNotEmpty == true
          ? _capitalizeName(profile!.firstName!)
          : 'Technician';
      _technicianProfile = store.avatarSetupFieldsFor(
        email: widget.email,
        userType: 2,
      );
    });
  }

  Future<void> _fetchTechnicianProfile({bool afterUpload = false}) async {
    final store = AuthSessionService.instance.displayProfile;
    if (!store.isActiveAccount(email: widget.email, userType: 2)) return;
    if (afterUpload) {
      await store.refreshAfterEdit();
    } else {
      await store.ensureLoaded(email: widget.email, userType: 2);
    }
    if (!mounted) return;
    _syncSharedProfile();
    setState(() => _profileLoadFinished = true);
    _scheduleAvatarPromptIfNeeded();
  }

  void _scheduleAvatarPromptIfNeeded() {
    if (!mounted ||
        isLoadingDashboard ||
        !_profileLoadFinished ||
        _avatarPromptScheduled ||
        _avatarPromptOpen) {
      return;
    }

    final profile = _technicianProfile;
    if (profile == null) return;

    final imagePath = profile['usr_image_path']?.toString().trim() ?? '';
    if (imagePath.isNotEmpty) return;

    _avatarPromptScheduled = true;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future<void>.delayed(const Duration(milliseconds: 350));

      if (!mounted || ModalRoute.of(context)?.isCurrent != true) {
        _avatarPromptScheduled = false;
        return;
      }

      await _showTechnicianAvatarPicker(profile);
    });
  }

  Future<void> _showTechnicianAvatarPicker(Map<String, dynamic> profile) async {
    if (!mounted || _avatarPromptOpen) return;
    _avatarPromptOpen = true;

    String? avatarPath;
    try {
      avatarPath = await DefaultAvatarPicker.show(
        context,
        avatarPaths: DefaultAvatarPicker.technicianAvatarPaths,
      );
    } catch (error) {
      debugPrint('TECHNICIAN AVATAR SHEET ERROR: $error');
    } finally {
      _avatarPromptOpen = false;
    }

    if (!mounted) return;

    if (avatarPath == null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 6),
            content: const Text(
              'Avatar setup is incomplete. Please choose a profile avatar.',
            ),
            action: SnackBarAction(
              label: 'Choose now',
              textColor: Colors.white,
              onPressed: () {
                if (mounted) {
                  _showTechnicianAvatarPicker(profile);
                }
              },
            ),
          ),
        );
      return;
    }

    final saved = await _uploadTechnicianAvatar(avatarPath, profile);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saved
              ? 'Profile avatar saved.'
              : 'Unable to save the avatar. Please try again later.',
        ),
      ),
    );

    if (saved) {
      await _fetchTechnicianProfile(afterUpload: true);
    }
  }

  Future<bool> _uploadTechnicianAvatar(
    String avatarPath,
    Map<String, dynamic> profile,
  ) async {
    final store = AuthSessionService.instance.displayProfile;
    if (!store.isActiveAccount(email: widget.email, userType: 2)) return false;
    final edit = store.beginEdit();
    if (edit == null) return false;
    try {
      final bytes = await rootBundle.load(avatarPath);
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/profile/update'),
      );

      request.fields.addAll({
        'email': widget.email,
        'first_name': profile['usr_first_name']?.toString() ?? '',
        'middle_name': profile['usr_middle_name']?.toString() ?? '',
        'last_name': profile['usr_last_name']?.toString() ?? '',
        'birth_date': profile['usr_birth_date']?.toString() ?? '',
        'remove_image': '0',
      });

      request.files.add(
        http.MultipartFile.fromBytes(
          'profile_image',
          bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes),
          filename: avatarPath.split('/').last,
        ),
      );

      final response = await http.Response.fromStream(await request.send());
      if (response.statusCode != 200) return false;

      final data = jsonDecode(response.body);
      if (data is! Map || data['success'] != true) return false;
      return store.completeEdit(edit, {
        if (data.containsKey('image_path')) 'usr_image_path': data['image_path'],
      });
    } catch (error) {
      debugPrint('TECHNICIAN AVATAR UPLOAD ERROR: $error');
      return false;
    } finally {
      store.cancelEdit(edit);
    }
  }

  Future<void> _openJob(Map<String, dynamic> job) async {
    final status = _text(job['status'], 'ASSIGNED').toUpperCase();

    if (status == 'DONE SERVICE') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => TechnicianServiceReportSubmissionPage(
            job: job,
            email: widget.email,
          ),
        ),
      );
    } else {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) =>
              TechnicianJobDetailsPage(job: job, email: widget.email),
        ),
      );
    }

    if (!mounted) return;

    await _loadDashboard();
  }

  void _openAssignedJobs(String filter, {int? focusJobId}) {
    Widget page;

    switch (filter) {
      case 'Upcoming':
        page = TechnicianUpcomingAssignedJobsPage(
          email: widget.email,
          focusJobId: focusJobId,
        );
        break;

      case 'Completed':
        page = TechnicianCompletedAssignedJobsPage(
          email: widget.email,
          focusJobId: focusJobId,
        );
        break;

      case 'Active':
      default:
        page = TechnicianActiveAssignedJobsPage(
          email: widget.email,
          focusJobId: focusJobId,
        );
        break;
    }

    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // DISPOSE
  @override
  void dispose() {
    AuthSessionService.instance.displayProfile.listenable.removeListener(
      _syncSharedProfile,
    );
    AppNotificationService.instance.technicianUnreadCount.removeListener(
      _updateUnreadNotificationCount,
    );

    super.dispose();
  }

  Widget _technicianAvatar() {
    return AppProfileAvatar(imageUrl: _technicianImageUrl);
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final assignment = todaysAssignment;

    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(userType: 2, email: widget.email, currentPage: 'home'),

      appBar: AppHomeHeader(
        onNotificationTap: _openNotifications,
        notificationCount: _unreadNotificationCount,
      ),

      bottomNavigationBar: TechnicianBottomNavBar(
        currentIndex: 0,
        email: widget.email,
      ),

      body: RefreshIndicator(
        color: AppTheme.primaryRed,
        onRefresh: _loadDashboard,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ============================================================
              // GREETING
              // ============================================================
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _technicianAvatar(),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Welcome back,',
                          style: TextStyle(
                            color: AppTheme.gray,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 1),
                        Text(
                          '$technicianName!',
                          softWrap: true,
                          style: const TextStyle(
                            color: AppTheme.black,
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                            height: 1.1,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formattedDate(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.gray,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // ============================================================
              // TODAY'S OVERVIEW
              // ============================================================
              _sectionTitle("Today's Overview"),

              const SizedBox(height: 12),

              if (isLoadingDashboard)
                _overviewSkeleton()
              else
                Column(
                  children: [
                    Row(
                      children: [
                        _overviewCard(
                          title: 'Service Now',
                          value: todaysJobsCount.toString(),
                          icon: Icons.play_circle_outline_rounded,
                          onTap: () => _openAssignedJobs('Active'),
                        ),
                        const SizedBox(width: 8),
                        _overviewCard(
                          title: 'Upcoming',
                          value: upcomingJobsCount.toString(),
                          icon: Icons.event_outlined,
                          onTap: () => _openAssignedJobs('Upcoming'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _overviewCard(
                          title: 'Overdue',
                          value: overdueJobsCount.toString(),
                          icon: Icons.warning_amber_rounded,
                          onTap: () => _openAssignedJobs('Active'),
                        ),
                        const SizedBox(width: 8),
                        _overviewCard(
                          title: 'Completed',
                          value: completedTodayCount.toString(),
                          icon: Icons.check_circle_outline_rounded,
                          onTap: () => _openAssignedJobs('Completed'),
                        ),
                      ],
                    ),
                  ],
                ),

              const SizedBox(height: 18),

              // ============================================================
              // TODAY'S ASSIGNMENT
              // ============================================================
              _sectionTitle("Today's Assignment"),

              const SizedBox(height: 12),

              if (isLoadingDashboard)
                _assignmentSkeleton()
              else if (assignment == null)
                _emptyAssignmentCard()
              else
                _assignmentCard(assignment),

              const SizedBox(height: 18),

              // ============================================================
              // UPCOMING SCHEDULE
              // ============================================================
              _sectionTitle('Upcoming Schedule'),

              const SizedBox(height: 12),

              if (isLoadingDashboard)
                _upcomingScheduleSkeleton()
              else
                _upcomingScheduleCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: AppTheme.black,
        fontSize: 14,
        fontWeight: FontWeight.w900,
        letterSpacing: 0.2,
      ),
    );
  }

  // OVERVIEW CARD
  Widget _overviewCard({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          height: 88,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.borderGray),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryRed.withOpacity(0.07),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, size: 16, color: AppTheme.primaryRed),
                  ),

                  const Spacer(),

                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      value,
                      maxLines: 1,
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                        height: 1,
                      ),
                    ),
                  ),
                ],
              ),

              const Spacer(),

              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // ASSIGNMENT CARD
  // ============================================================

  Widget _assignmentCard(Map<String, dynamic> job) {
    final status = _text(job['status'], 'ASSIGNED').toUpperCase();

    final clientName = _text(job['clientName'], 'Client');

    final service = _text(job['service'], 'Pest Control Service');

    final address = _text(job['address'], 'No address available');

    final schedule = _text(job['schedule'], 'No schedule available');

    String buttonLabel = 'View Job';

    if (status == 'ONGOING' || status == 'ARRIVED') {
      buttonLabel = 'Resume Job';
    }

    if (status == 'DONE SERVICE') {
      buttonLabel = 'Submit Report';
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // SERVICE + STATUS
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Text(
                  service,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),

              const SizedBox(width: 10),

              TechnicianJobStatusBadge(
                status: job['status']?.toString().toUpperCase() == 'ASSIGNED'
                    ? (job['scheduleClassification']?.toString() ?? status)
                    : status,
              ),
            ],
          ),

          const SizedBox(height: 18),

          // CLIENT
          _compactAssignmentInfo(
            icon: Icons.person_outline_rounded,
            text: clientName,
          ),

          const SizedBox(height: 10),

          // SCHEDULE
          _compactAssignmentInfo(icon: Icons.schedule_rounded, text: schedule),

          const SizedBox(height: 10),

          // LOCATION
          _compactAssignmentInfo(
            icon: Icons.location_on_outlined,
            text: address,
            maxLines: 1,
          ),

          const SizedBox(height: 18),

          // ACTIONS
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 44,
                  child: ElevatedButton(
                    onPressed: () {
                      _openAssignedJobs('Active');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryRed,
                      foregroundColor: AppTheme.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          buttonLabel,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),

                        const SizedBox(width: 6),

                        const Icon(Icons.arrow_forward_rounded, size: 18),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 10),

              // MORE ACTIONS
              SizedBox(
                width: 48,
                height: 44,
                child: ElevatedButton(
                  onPressed: () {
                    _openAssignedJobs('Active', focusJobId: job['id']);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryRed,
                    foregroundColor: AppTheme.white,
                    elevation: 0,
                    padding: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Icon(
                    Icons.format_list_bulleted_rounded,
                    size: 23,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _compactAssignmentInfo({
    required IconData icon,
    required String text,
    int maxLines = 1,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(icon, size: 18, color: AppTheme.gray),

        const SizedBox(width: 10),

        Expanded(
          child: Text(
            text,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppTheme.black,
              fontSize: 12.5,
              fontWeight: FontWeight.w500,
              height: 1.3,
            ),
          ),
        ),
      ],
    );
  }

  Widget _assignmentInfo({required IconData icon, required String text}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: AppTheme.lightGray,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 16, color: AppTheme.primaryRed),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppTheme.black,
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                height: 1.35,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // JOB INFO
  // ============================================================

  Widget _jobInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 17, color: AppTheme.gray),

        const SizedBox(width: 9),

        Expanded(
          child: RichText(
            text: TextSpan(
              style: const TextStyle(color: AppTheme.black, fontSize: 12.5),
              children: [
                TextSpan(
                  text: '$title: ',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                TextSpan(
                  text: value,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // EMPTY ASSIGNMENT
  // ============================================================

  Widget _emptyAssignmentCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(0.07),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.event_available_outlined,
              size: 25,
              color: AppTheme.primaryRed,
            ),
          ),

          const SizedBox(height: 14),

          const Text(
            'No job scheduled for today',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 6),

          const Text(
            'Your assigned services for today will appear here.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.gray, fontSize: 12, height: 1.4),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SIMPLE LOADING PLACEHOLDERS
  // ============================================================

  Widget _overviewSkeleton() {
    return Row(
      children: List.generate(
        3,
        (index) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: index < 2 ? 8 : 0),
            child: Container(
              height: 105,
              decoration: BoxDecoration(
                color: AppTheme.borderGray.withOpacity(0.35),
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _assignmentSkeleton() {
    return Container(
      width: double.infinity,
      height: 230,
      decoration: BoxDecoration(
        color: AppTheme.borderGray.withOpacity(0.35),
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  Widget _upcomingScheduleCard() {
    if (upcomingSchedule.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderGray),
        ),
        child: const Column(
          children: [
            Icon(
              Icons.event_available_outlined,
              color: AppTheme.gray,
              size: 28,
            ),

            SizedBox(height: 10),

            Text(
              'No upcoming jobs scheduled',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),

            SizedBox(height: 5),

            Text(
              'Future assigned services will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.gray, fontSize: 11),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        children: List.generate(upcomingSchedule.length, (index) {
          final job = upcomingSchedule[index];

          return Column(
            children: [
              _upcomingScheduleItem(job),

              if (index != upcomingSchedule.length - 1)
                Divider(
                  height: 1,
                  thickness: 1,
                  color: AppTheme.borderGray.withOpacity(0.6),
                ),
            ],
          );
        }),
      ),
    );
  }

  Widget _upcomingScheduleSkeleton() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: Column(
        children: List.generate(3, (index) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 13),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: AppTheme.borderGray.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(11),
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 12,
                            width: 150,
                            decoration: BoxDecoration(
                              color: AppTheme.borderGray.withOpacity(0.35),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),

                          const SizedBox(height: 8),

                          Container(
                            height: 9,
                            width: 120,
                            decoration: BoxDecoration(
                              color: AppTheme.borderGray.withOpacity(0.30),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),

                          const SizedBox(height: 7),

                          Container(
                            height: 9,
                            width: 180,
                            decoration: BoxDecoration(
                              color: AppTheme.borderGray.withOpacity(0.30),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              if (index < 2)
                Divider(
                  height: 1,
                  thickness: 1,
                  color: AppTheme.borderGray.withOpacity(0.6),
                ),
            ],
          );
        }),
      ),
    );
  }

  Widget _upcomingScheduleItem(Map<String, dynamic> job) {
    return InkWell(
      onTap: () {
        _openAssignedJobs('Upcoming');
      },
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 13),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: AppTheme.primaryRed.withOpacity(0.07),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(
                Icons.calendar_month_outlined,
                color: AppTheme.primaryRed,
                size: 21,
              ),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    job['service']?.toString() ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        size: 14,
                        color: AppTheme.gray,
                      ),

                      const SizedBox(width: 5),

                      Expanded(
                        child: Text(
                          '${job['date'] ?? ''} • ${job['time'] ?? ''}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.gray,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 4),

                  Row(
                    children: [
                      const Icon(
                        Icons.location_on_outlined,
                        size: 14,
                        color: AppTheme.gray,
                      ),

                      const SizedBox(width: 5),

                      Expanded(
                        child: Text(
                          job['address']?.toString() ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.gray,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(width: 8),

            const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.gray,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}
