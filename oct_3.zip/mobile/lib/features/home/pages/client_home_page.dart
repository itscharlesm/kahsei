import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_app/features/auth/services/auth_session_service.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/bookings/pages/client_booking_location_page.dart';
import 'package:mobile_app/features/notifications/pages/client_notifications_page.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/features/home/widgets/client_promotional_banner.dart';
import 'package:mobile_app/features/home/widgets/client_services_section.dart';
import 'package:mobile_app/features/home/widgets/client_service_details_sheet.dart';
import 'package:mobile_app/shared/services/notification_service.dart';
import 'package:mobile_app/app/app_navigator.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

class ClientHomePage extends StatefulWidget {
  final String email;

  const ClientHomePage({super.key, required this.email});

  @override
  State<ClientHomePage> createState() => _ClientHomePageState();
}

class _ClientHomePageState extends State<ClientHomePage> {
  String? profileImagePath;
  String clientName = 'Client';
  int _unreadNotificationCount = 0;

  final List<Map<String, dynamic>> homeServices = [
    {'name': 'Ants', 'image': 'assets/images/img_ant.png'},
    {'name': 'Bed Bugs', 'image': 'assets/images/img_bedbug.png'},
    {'name': 'Cockroaches', 'image': 'assets/images/img_cockroach.png'},
    {'name': 'Flies', 'image': 'assets/images/img_fly.png'},
    {'name': 'Mosquitoes', 'image': 'assets/images/img_mosquito.png'},
    {'name': 'Rats/Mice', 'image': 'assets/images/img_rat.png'},
    {'name': 'Spiders', 'image': 'assets/images/img_spider.png'},
    {'name': 'Termites', 'image': 'assets/images/img_termites.png'},
    {'name': 'Others', 'image': 'assets/images/img_others.png'},
  ];

  final Map<String, dynamic> upcomingService = {
    'service': 'General Pest Control',
    'date': 'July 21, 2026',
    'time': '9:00 AM',
    'location': 'Matina, Davao City',
    'status': 'SCHEDULED',
  };

  final List<Map<String, dynamic>> recentAppointments = [
    {
      'service': 'Rats',
      'schedule': 'July 10, 2026 • 10:00 AM',
      'status': 'REQUESTED',
      'icon': Icons.pest_control_rodent_rounded,
    },
    {
      'service': 'Cockroaches',
      'schedule': 'July 05, 2026 • 2:00 PM',
      'status': 'COMPLETED',
      'icon': Icons.bug_report_rounded,
    },
    {
      'service': 'Termites',
      'schedule': 'June 18, 2026 • 9:00 AM',
      'status': 'SCHEDULED',
      'icon': Icons.pest_control_rounded,
    },
  ];

  final Map<String, dynamic> currentActivity = {
    'service': 'General Pest Control',
    'status': 'ONGOING',
    'message': 'Your technician is on the way.',
    'date': 'Today',
    'time': '2:00 PM',
  };

  String _capitalizeName(String name) {
    if (name.trim().isEmpty) {
      return 'Client';
    }

    return name
        .trim()
        .toLowerCase()
        .split(' ')
        .map(
          (word) => word.isEmpty
              ? ''
              : '${word[0].toUpperCase()}${word.substring(1)}',
        )
        .join(' ');
  }

  String _capitalizeFirstLetter(String name) {
    if (name.trim().isEmpty) return 'Client';

    final formatted = name.trim().toLowerCase();

    return formatted[0].toUpperCase() + formatted.substring(1);
  }

  void _updateUnreadNotificationCount() {
    if (!mounted) return;

    setState(() {
      _unreadNotificationCount =
          AppNotificationService.instance.unreadCount.value;
    });
  }

  @override
  void initState() {
    super.initState();
    _syncSharedProfile();
    AuthSessionService.instance.displayProfile.listenable.addListener(
      _syncSharedProfile,
    );
    unawaited(
      AuthSessionService.instance.displayProfile.ensureLoaded(
        email: widget.email,
        userType: 3,
      ),
    );

    _unreadNotificationCount =
        AppNotificationService.instance.unreadCount.value;

    AppNotificationService.instance.unreadCount.addListener(
      _updateUnreadNotificationCount,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      AppNotificationService.instance.showUnreadSummaryIfNeeded();
    });

    AppNotificationService.instance.onNotificationTap = (payload) {
      if (payload == null || payload.trim().isEmpty) {
        return;
      }

      navigatorKey.currentState?.push(
        MaterialPageRoute(
          builder: (_) => ClientNotificationsPage(email: payload),
        ),
      );
    };

    // _checkUnreadNotificationsOnOpen();
    // _initializeNotificationPolling();
  }

  @override
  void dispose() {
    AuthSessionService.instance.displayProfile.listenable.removeListener(
      _syncSharedProfile,
    );
    AppNotificationService.instance.unreadCount.removeListener(
      _updateUnreadNotificationCount,
    );

    super.dispose();
  }

  // @override
  // void dispose() {
  //   _notificationTimer?.cancel();
  //   super.dispose();
  // }

  // ============================================================
  // PROFILE
  // ============================================================

  void _syncSharedProfile() {
    if (!mounted) return;
    final profile = AuthSessionService.instance.displayProfile.value;
    final matches = profile?.email == widget.email && profile?.userType == 3;
    setState(() {
      profileImagePath = matches ? profile?.avatarPath : null;
      clientName = matches && profile?.firstName?.trim().isNotEmpty == true
          ? _capitalizeName(profile!.firstName!)
          : 'Client';
    });
  }

  String? get profileImageUrl {
    final path = profileImagePath?.trim() ?? '';
    if (path.isEmpty) {
      return null;
    }

    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }

    return '${ApiConfig.baseUrl}/${path.replaceFirst(RegExp(r'^/+'), '')}';
  }

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _goToBooking() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientBookingLocationPage(email: widget.email),
      ),
    );
  }

  void _openNotifications() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientNotificationsPage(email: widget.email),
      ),
    );
  }

  // TODO:
  // Connect these navigation methods later to existing pages.

  void _viewAllAppointments() {
    // Navigate to Client My Appointments page later.
  }

  void _viewUpcomingService() {
    // Navigate to appointment details later.
  }

  void _trackTechnician() {
    // Navigate to client technician tracking page later.
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      drawer: AppDrawer(userType: 3, email: widget.email, currentPage: 'home'),
      appBar: AppHomeHeader(
        onNotificationTap: _openNotifications,
        notificationCount: _unreadNotificationCount,
      ),
      bottomNavigationBar: ClientBottomNavBar(
        currentIndex: 0,
        email: widget.email,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Welcome / Client greeting
                _welcomeSection(),
                const SizedBox(height: 18),

                ClientPromotionalBanner(onBookTap: _goToBooking),
                const SizedBox(height: 12),

                _servicesHeader(),
                const SizedBox(height: 12),
                _homeServicesMenu(),
                const SizedBox(height: 12),

                ClientServicesSection(
                  onServiceTap: (service) {
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (context) {
                        return ClientServiceDetailsSheet(
                          service: service,
                          onBookTap: () {
                            Navigator.pop(context);
                            _goToBooking();
                          },
                        );
                      },
                    );
                  },
                ),
                // const SizedBox(height: 12),

                // _recentAppointmentsHeader(),
                // const SizedBox(height: 12),
                // _recentAppointmentsCard(),
                // const SizedBox(height: 12),

                // // Client support
                // _sectionTitle('Need Assistance?'),
                // const SizedBox(height: 12),
                // _needAssistanceCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // WELCOME SECTION
  Widget _welcomeSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Profile Image
        AppProfileAvatar(imageUrl: profileImageUrl),

        const SizedBox(width: 13),

        // Welcome Information
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Welcome back,',
                style: TextStyle(
                  color: AppTheme.gray,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),

              const SizedBox(height: 1),

              Text(
                '${_capitalizeFirstLetter(clientName)}!',
                softWrap: true,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                  height: 1.1,
                ),
              ),

              const SizedBox(height: 4),

              const Text(
                'Need help with a pest problem?',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: AppTheme.gray,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SECTION TITLE
  // ============================================================

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: AppTheme.black,
        fontSize: 14,
        fontWeight: FontWeight.w900,
        letterSpacing: 0.2,
      ),
    );
  }

  // ============================================================
  // UPCOMING SERVICE
  // ============================================================

  Widget _upcomingServiceCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray.withOpacity(0.65)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFDEBED),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.calendar_month_rounded,
                    color: AppTheme.primaryRed,
                    size: 27,
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              upcomingService['service'],
                              style: const TextStyle(
                                color: AppTheme.black,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          _statusBadge(upcomingService['status']),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _infoRow(
                        icon: Icons.event_outlined,
                        text:
                            '${upcomingService['date']} • ${upcomingService['time']}',
                      ),
                      const SizedBox(height: 7),
                      _infoRow(
                        icon: Icons.location_on_outlined,
                        text: upcomingService['location'],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider(
            height: 1,
            thickness: 1,
            color: AppTheme.borderGray.withOpacity(0.6),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
            child: Row(
              children: [
                TextButton(
                  onPressed: _viewUpcomingService,
                  style: TextButton.styleFrom(
                    foregroundColor: AppTheme.primaryRed,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 8,
                    ),
                  ),
                  child: const Text(
                    'View Details',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: _trackTechnician,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.primaryRed,
                    side: const BorderSide(color: AppTheme.primaryRed),

                    // Important: override the global full-width button setting
                    minimumSize: const Size(0, 40),

                    padding: const EdgeInsets.symmetric(
                      horizontal: 13,
                      vertical: 9,
                    ),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  icon: const Icon(Icons.navigation_rounded, size: 17),
                  label: const Text(
                    'Track Technician',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow({required IconData icon, required String text}) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.gray, size: 16),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // RECENT APPOINTMENTS
  // ============================================================

  Widget _recentAppointmentsHeader() {
    return Row(
      children: [
        Expanded(child: _sectionTitle('Recent Appointments')),
        InkWell(
          onTap: _viewAllAppointments,
          borderRadius: BorderRadius.circular(8),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            child: Text(
              'View All',
              style: TextStyle(
                color: AppTheme.primaryRed,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _recentAppointmentsCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray.withOpacity(0.65)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: List.generate(recentAppointments.length, (index) {
          final appointment = recentAppointments[index];

          return Column(
            children: [
              _recentAppointmentItem(appointment),
              if (index != recentAppointments.length - 1)
                Divider(
                  height: 1,
                  thickness: 1,
                  indent: 66,
                  color: AppTheme.borderGray.withOpacity(0.55),
                ),
            ],
          );
        }),
      ),
    );
  }

  Widget _recentAppointmentItem(Map<String, dynamic> appointment) {
    return InkWell(
      onTap: () {
        // Navigate to appointment details later.
      },
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 13),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: const BoxDecoration(
                color: Color(0xFFF8EAEC),
                shape: BoxShape.circle,
              ),
              child: Icon(
                appointment['icon'],
                color: AppTheme.primaryRed,
                size: 23,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appointment['service'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    appointment['schedule'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.gray,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            _statusBadge(appointment['status']),
            const SizedBox(width: 5),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.gray,
              size: 21,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _statusBadge(String status) {
    final normalizedStatus = status.toUpperCase();

    Color backgroundColor;
    Color textColor;

    switch (normalizedStatus) {
      case 'REQUESTED':
        backgroundColor = const Color(0xFFE5F0FF);
        textColor = const Color(0xFF2876E8);
        break;

      case 'ASSESSED':
        backgroundColor = const Color(0xFFFFEED8);
        textColor = const Color(0xFFE27A16);
        break;

      case 'SCHEDULED':
        backgroundColor = const Color(0xFFFDE5E8);
        textColor = AppTheme.primaryRed;
        break;

      case 'ONGOING':
        backgroundColor = const Color(0xFFDDF4F1);
        textColor = const Color(0xFF168779);
        break;

      case 'COMPLETED':
      case 'DONE REPORT':
        backgroundColor = const Color(0xFFDCF4E3);
        textColor = const Color(0xFF198B45);
        break;

      case 'FOR APPROVAL':
        backgroundColor = const Color(0xFFFFF1CD);
        textColor = const Color(0xFFB87800);
        break;

      case 'CANCELLED':
        backgroundColor = const Color(0xFFF4E4E4);
        textColor = const Color(0xFF9D3636);
        break;

      default:
        backgroundColor = AppTheme.lightGray;
        textColor = AppTheme.gray;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(7),
      ),
      child: Text(
        normalizedStatus,
        style: TextStyle(
          color: textColor,
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget _servicesHeader() {
    return Row(children: [Expanded(child: _sectionTitle("We Handle"))]);
  }

  Widget _homeServicesMenu() {
    return SizedBox(
      height: 62,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: homeServices.length,
        separatorBuilder: (context, index) {
          return const SizedBox(width: 7.5);
        },
        itemBuilder: (context, index) {
          final service = homeServices[index];

          return _homeServiceItem(service, index);
        },
      ),
    );
  }

  Widget _homeServiceItem(Map<String, dynamic> service, int index) {
    return InkWell(
      onTap: () {
        _goToBooking();
      },
      borderRadius: BorderRadius.circular(11),
      child: Container(
        width: 58,
        padding: const EdgeInsets.fromLTRB(3, 3, 3, 4),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(11),
          border: Border.all(color: AppTheme.gray.withOpacity(0.35), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.035),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            SizedBox(
              height: 38,
              width: double.infinity,
              child: Image.asset(
                service['image'].toString(),
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(
                    Icons.pest_control_rounded,
                    color: AppTheme.primaryRed,
                    size: 24,
                  );
                },
              ),
            ),

            const SizedBox(height: 2),

            Expanded(
              child: Center(
                child: Text(
                  service['name'].toString(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 6.5,
                    fontWeight: FontWeight.w800,
                    height: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _currentActivityCard() {
    final String status =
        currentActivity['status']?.toString().toUpperCase() ?? '';

    final bool isOngoing = status == 'ONGOING';

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray.withOpacity(0.65)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(15),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Activity Icon
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryRed.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(
                    isOngoing
                        ? Icons.local_shipping_outlined
                        : Icons.calendar_month_outlined,
                    color: AppTheme.primaryRed,
                    size: 24,
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              currentActivity['service']?.toString() ?? '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),

                          const SizedBox(width: 8),

                          _statusBadge(status),
                        ],
                      ),

                      const SizedBox(height: 7),

                      Text(
                        currentActivity['message']?.toString() ?? '',
                        style: const TextStyle(
                          color: AppTheme.black,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 7),

                      Row(
                        children: [
                          const Icon(
                            Icons.schedule_rounded,
                            color: AppTheme.gray,
                            size: 15,
                          ),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              '${currentActivity['date']} • '
                              '${currentActivity['time']}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.gray,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Divider(
            height: 1,
            thickness: 1,
            color: AppTheme.borderGray.withOpacity(0.55),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
            child: Row(
              children: [
                InkWell(
                  onTap: _viewUpcomingService,
                  borderRadius: BorderRadius.circular(8),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 3, vertical: 7),
                    child: Text(
                      'View Details',
                      style: TextStyle(
                        color: AppTheme.primaryRed,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),

                const Spacer(),

                if (isOngoing)
                  Material(
                    color: AppTheme.primaryRed,
                    borderRadius: BorderRadius.circular(9),
                    child: InkWell(
                      onTap: _trackTechnician,
                      borderRadius: BorderRadius.circular(9),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 13,
                          vertical: 9,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.navigation_rounded,
                              color: AppTheme.white,
                              size: 15,
                            ),
                            SizedBox(width: 6),
                            Text(
                              'Track Technician',
                              style: TextStyle(
                                color: AppTheme.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _needAssistanceCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray.withOpacity(0.65)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ==================================================
          // HEADER
          // ==================================================
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.primaryRed.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.support_agent_rounded,
                  color: AppTheme.primaryRed,
                  size: 23,
                ),
              ),

              const SizedBox(width: 12),

              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Need help identifying a pest?',
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    SizedBox(height: 3),

                    Text(
                      'Get in touch with our team. We are here to help.',
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 13),

          // ==================================================
          // ACTIONS
          // ==================================================
          Row(
            children: [
              // CONTACT US
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO:
                      // Open branch/contact selection sheet
                    },
                    icon: const Icon(Icons.phone_outlined, size: 15),
                    label: const Text(
                      'Contact Us',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.primaryRed,
                      side: BorderSide(
                        color: AppTheme.primaryRed.withOpacity(0.45),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(9),
                      ),
                      textStyle: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 8),

              // EMAIL US
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // TODO:
                      // Open email application
                    },
                    icon: const Icon(Icons.email_outlined, size: 15),
                    label: const Text(
                      'Email Us',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryRed,
                      foregroundColor: AppTheme.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(9),
                      ),
                      textStyle: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
