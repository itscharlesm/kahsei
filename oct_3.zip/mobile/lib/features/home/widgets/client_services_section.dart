import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class ClientServicesSection extends StatelessWidget {
  final void Function(Map<String, dynamic> service)? onServiceTap;

  const ClientServicesSection({
    super.key,
    this.onServiceTap,
  });

  static final List<Map<String, dynamic>> _services = [
    {
      'name': 'General Pest Control',
      'description':
          'Professional control for common household and commercial pests.',

      'details':
          'General Pest Control is designed to manage common pests that can invade homes and commercial spaces, including cockroaches, ants, mosquitoes, flies, bed bugs, fleas, ticks, and other crawling or flying insects.\n\n'
          'The service begins by assessing the affected areas and identifying signs of pest activity. Based on the situation, appropriate treatment methods are applied to areas where pests commonly hide, breed, or enter the property.\n\n'
          'This service helps reduce pest activity and supports a cleaner, healthier, and more comfortable environment for your home or business.\n\n'
          'Pests can carry bacteria, contaminate food, damage property, and cause discomfort. Professional pest control helps maintain a safer and more hygienic space.',
          
      'image': 'assets/images/img_services_gpc.png',
    },
    {
      'name': 'Termite Control',
      'description':
          'Termite treatment for lasting property protection.',
      'details':
          'Termite Control is designed to protect properties from termites that can silently damage wood and other structural materials.\n\n'
          'The service starts with an assessment of affected and vulnerable areas to identify signs of termite activity. Depending on the condition of the property, treatment may involve methods such as drilling, wood drenching or spraying, chemical injection, cordoning, or mound demolition.\n\n'
          'This service is ideal for properties with visible signs of termite infestation or those that require professional termite management to help reduce the risk of further damage.\n\n'
          'Termites can silently damage wooden structures and weaken parts of a property before the infestation becomes noticeable. Professional termite control helps manage termite activity and reduce the risk of costly structural damage.',
          
      'image': 'assets/images/img_services_termitecontrol.png',
    },
    {
      'name': 'Fogging',
      'description':
          'Fogging treatment for pest control and disinfection applications.',

      'details':
          'Fogging is a treatment method that uses specialized equipment to disperse a fine mist throughout a targeted area, allowing the treatment to cover a wider space and reach areas that may be difficult to treat directly.\n\n'
          'During the service, the area is assessed to determine the appropriate treatment and coverage needed. Fogging equipment is then used to distribute the treatment throughout the designated space. Depending on the application, occupants may be advised to temporarily leave the treated area and follow the technician’s instructions before returning.\n\n'
          'This service is suitable for areas that require broad treatment coverage and may be recommended for certain pest control or disinfection applications based on the condition and needs of the property.\n\n'
          'Some pest problems can affect larger areas and may be difficult to manage through targeted treatment alone. Fogging provides wider treatment coverage, helping address pest activity in spaces where broader application is appropriate.',

      'image': 'assets/images/img_services_fogging.png',
    },
    {
      'name': 'Misting',
      'description':
          'Targeted misting treatment for pest-prone areas.',

      'details':
          'Misting is a pest control treatment that applies a fine spray to targeted areas where pests are commonly active, likely to hide, or may breed. It allows treatment to be focused on specific pest-prone areas based on the condition of the property.\n\n'
          'The service begins by identifying areas that may contribute to pest activity. The appropriate treatment is then applied using misting equipment to provide controlled coverage in the designated locations, which may include outdoor spaces, surrounding areas, or drainage systems depending on the pest problem.\n\n'
          'This service is useful for properties with specific areas that require focused pest management and can complement other pest control methods when additional treatment coverage is needed.\n\n'
          'Pest-prone areas can provide suitable conditions for insects to hide, breed, and increase in number. Targeted misting helps treat these areas and supports better pest management around the property.',

      'image': 'assets/images/img_services_misting.png',
    },
    {
      'name': 'Rodent Control',
      'description':
          'Professional control solutions for rats and mice.',

      'details':
          'Rodent Control is designed to manage rats and mice that may enter homes, businesses, and other properties in search of food, water, and shelter. Rodents can hide in difficult-to-reach areas and may remain unnoticed until signs of activity become visible.\n\n'
          'The service begins with an assessment to identify signs of rodent activity and areas where rodents may be entering, hiding, or moving around the property. Based on the findings, appropriate control methods such as baiting or trapping may be used and strategically placed in affected areas.\n\n'
          'This service is suitable for residential and commercial properties experiencing signs of rodent activity and helps manage the problem using methods appropriate to the affected area and level of activity.'
          'Rats and mice can contaminate food and surfaces, damage property, and create health and sanitation concerns. Professional rodent control helps manage rodent activity and supports a cleaner, safer, and more hygienic environment.',

      'image': 'assets/images/img_services_rodentcontrol.png',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Our Services',
          style: TextStyle(
            color: AppTheme.black,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.2,
          ),
        ),

        const SizedBox(height: 12),

        SizedBox(
          height: 178,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: _services.length,
            separatorBuilder: (context, index) {
              return const SizedBox(width: 10);
            },
            itemBuilder: (context, index) {
              final service = _services[index];

              return _serviceCard(service);
            },
          ),
        ),
      ],
    );
  }

  Widget _serviceCard(
    Map<String, dynamic> service,
  ) {
    return InkWell(
      onTap: () {
        onServiceTap?.call(service);
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 175,
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppTheme.borderGray.withOpacity(0.65),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.035),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ============================================================
            // SERVICE IMAGE
            // ============================================================

            SizedBox(
              width: double.infinity,
              height: 96,
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(13),
                  topRight: Radius.circular(13),
                ),
                child: Container(
                  color: AppTheme.lightGray,
                  child: Image.asset(
                    service['image'].toString(),
                    width: double.infinity,
                    height: double.infinity,
                    fit: BoxFit.cover,
                    alignment: Alignment.center,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return const Icon(
                        Icons.pest_control_rounded,
                        color: AppTheme.primaryRed,
                        size: 36,
                      );
                    },
                  ),
                ),
              ),
            ),

            // ============================================================
            // SERVICE INFORMATION
            // ============================================================

            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  10,
                  8,
                  8,
                  8,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // SERVICE NAME
                    Text(
                      service['name'].toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        height: 1.15,
                      ),
                    ),

                    const SizedBox(height: 4),

                    // DESCRIPTION + ARROW
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          // Description uses most of the available space
                          Expanded(
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                service['description'].toString(),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppTheme.gray,
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w500,
                                  height: 1.25,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(width: 5),

                          // Circular arrow
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: AppTheme.primaryRed.withOpacity(0.10),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.arrow_forward_rounded,
                              color: AppTheme.primaryRed,
                              size: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}