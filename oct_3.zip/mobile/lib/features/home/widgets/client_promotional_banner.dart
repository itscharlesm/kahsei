import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class ClientPromotionalBanner extends StatefulWidget {
  final VoidCallback onBookTap;

  const ClientPromotionalBanner({
    super.key,
    required this.onBookTap,
  });

  @override
  State<ClientPromotionalBanner> createState() =>
      _ClientPromotionalBannerState();
}

class _ClientPromotionalBannerState
    extends State<ClientPromotionalBanner> {
  final PageController _bannerController = PageController(
    viewportFraction: 1.0,
  );

  Timer? _bannerTimer;

  int _currentBannerPage = 0;
  int _currentBannerIndex = 0;

  final List<Map<String, dynamic>> banners = [
    {
      'title': 'Keep Unwanted\nPests Away',
      'subtitle':
          'Professional pest control solutions for a safer and cleaner home.',
      'buttonText': 'Book Now',
      'image': 'assets/images/img_banner_handspray.png',

      // Individual image positioning
      'imageWidth': 600.0,
      'imageRight': -190.0,
      'imageTop': 35.0,
      'imageBottom': -25.0,

      'theme': 'red',
    },
    {
      'title': 'Protect Your Home\nFrom Termites',
      'subtitle':
          'Help protect your property from costly termite damage.',
      'buttonText': 'Schedule Service',
      'image': 'assets/images/img_banner_termite.png',

      // Individual image positioning
      'imageWidth': 350.0,
      'imageRight': -70.0,
      'imageTop': 0.0,
      'imageBottom': 0.0,

      'theme': 'black',
    },
    {
      'title': 'Reliable Pest Control\nWhen You Need It',
      'subtitle':
          'Professional pest control\nfor your home or property.',
      'buttonText': 'Book a Service',
      'image': 'assets/images/img_banner_cleanhome.png',

      // Individual image positioning
      'imageWidth': 200.0,
      'imageRight': -10.0,
      'imageTop': 0.0,
      'imageBottom': 0.0,

      'theme': 'white',
    },
  ];

  @override
  void initState() {
    super.initState();
    _startBannerAutoScroll();
  }

  void _startBannerAutoScroll() {
    _bannerTimer?.cancel();

    _bannerTimer = Timer.periodic(
      const Duration(seconds: 7),
      (_) {
        if (!mounted) return;
        if (!_bannerController.hasClients) return;

        _currentBannerPage++;

        _bannerController.animateToPage(
          _currentBannerPage,
          duration: const Duration(milliseconds: 700),
          curve: Curves.easeInOut,
        );
      },
    );
  }

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _bannerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 190,
          width: double.infinity,
          child: PageView.builder(
            controller: _bannerController,
            onPageChanged: (page) {
              if (!mounted) return;

              setState(() {
                _currentBannerPage = page;
                _currentBannerIndex =
                    page % banners.length;
              });
            },
            itemBuilder: (context, page) {
              final index =
                  page % banners.length;

              return _bannerCard(
                banners[index],
              );
            },
          ),
        ),

        const SizedBox(height: 10),

        _bannerIndicators(),
      ],
    );
  }

  Widget _bannerCard(
    Map<String, dynamic> banner,
  ) {
    final String theme =
        banner['theme']?.toString() ?? 'red';

    final bool isBlack = theme == 'black';
    final bool isWhite = theme == 'white';

    final List<Color> gradientColors;

    if (isBlack) {
      gradientColors = [
        const Color(0xFF111111),
        const Color(0xFF1D1D1D),
        const Color(0xFF2A0B0E),
      ];
    } else if (isWhite) {
      gradientColors = [
        AppTheme.white,
        const Color(0xFFF8F8F8),
        const Color(0xFFFFECEE),
      ];
    } else {
      gradientColors = [
        const Color(0xFFB5121B),
        AppTheme.primaryRed,
        const Color(0xFFE52B35),
      ];
    }

    final Color titleColor =
        isWhite
            ? AppTheme.black
            : AppTheme.white;

    final Color subtitleColor =
        isWhite
            ? AppTheme.gray
            : AppTheme.white.withOpacity(0.86);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(
        horizontal: 6,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradientColors,
        ),
        border: isWhite
            ? Border.all(
                color:
                    AppTheme.borderGray.withOpacity(0.7),
              )
            : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.10),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            if (banner['image'] != null)
              Positioned(
                right:
                    banner['imageRight'] ?? -70.0,
                top:
                    banner['imageTop'] ?? 0.0,
                bottom:
                    banner['imageBottom'] ?? 0.0,
                child: Opacity(
                  opacity: 0.95,
                  child: Image.asset(
                    banner['image'].toString(),
                    width:
                        banner['imageWidth'] ?? 350.0,
                    fit: BoxFit.contain,
                  ),
                ),
              ),

            Padding(
              padding: const EdgeInsets.fromLTRB(
                18,
                16,
                100,
                16,
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  Text(
                    banner['title']?.toString() ?? '',
                    maxLines: 2,
                    overflow:
                        TextOverflow.ellipsis,
                    style: TextStyle(
                      color: titleColor,
                      fontSize: 20,
                      fontWeight:
                          FontWeight.w900,
                      height: 1.08,
                    ),
                  ),

                  const SizedBox(height: 15),

                  Text(
                    banner['subtitle']
                            ?.toString() ??
                        '',
                    maxLines: 2,
                    overflow:
                        TextOverflow.ellipsis,
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 10.5,
                      fontWeight:
                          FontWeight.w500,
                      height: 1.3,
                    ),
                  ),

                  const SizedBox(height: 14),

                  _bannerButton(
                    banner['buttonText']
                            ?.toString() ??
                        'Book Now',
                    theme,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bannerButton(
    String label,
    String theme,
  ) {
    final bool isWhite =
        theme == 'white';

    final bool isBlack =
        theme == 'black';

    return Material(
      color: (isWhite || isBlack)
          ? AppTheme.primaryRed
          : AppTheme.white,
      borderRadius:
          BorderRadius.circular(9),
      child: InkWell(
        onTap: widget.onBookTap,
        borderRadius:
            BorderRadius.circular(9),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 9,
          ),
          child: Row(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  color:
                      (isWhite || isBlack)
                          ? AppTheme.white
                          : AppTheme.primaryRed,
                  fontSize: 11,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),

              const SizedBox(width: 6),

              Icon(
                Icons.arrow_forward_rounded,
                color:
                    (isWhite || isBlack)
                        ? AppTheme.white
                        : AppTheme.primaryRed,
                size: 15,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bannerIndicators() {
    return Row(
      mainAxisAlignment:
          MainAxisAlignment.center,
      children: List.generate(
        banners.length,
        (index) {
          final bool isActive =
              index ==
                  _currentBannerIndex;

          return AnimatedContainer(
            duration:
                const Duration(
              milliseconds: 500,
            ),
            curve: Curves.easeInOut,
            margin:
                const EdgeInsets.symmetric(
              horizontal: 3,
            ),
            width:
                isActive ? 18 : 6,
            height: 6,
            decoration: BoxDecoration(
              color: isActive
                  ? AppTheme.primaryRed
                  : AppTheme.black,
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),
          );
        },
      ),
    );
  }
}