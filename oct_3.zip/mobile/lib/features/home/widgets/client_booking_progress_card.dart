import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

/// Static booking preview. Connect to active booking data in a later iteration.
class ClientBookingProgressCard extends StatelessWidget {
  const ClientBookingProgressCard({super.key});

  static const _stages = [
    'Confirmed',
    'On the way',
    'Arrived',
    'In progress',
    'Completed',
  ];

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.primaryRed,
      elevation: 10,
      shadowColor: const Color(0x44000000),
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                CircleAvatar(
                  radius: 19,
                  backgroundColor: AppTheme.black,
                  child: Icon(
                    Icons.local_shipping_outlined,
                    color: AppTheme.white,
                    size: 22,
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Technician on the way',
                    style: TextStyle(
                      color: AppTheme.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'General Pest Control · Sample booking',
              style: TextStyle(color: AppTheme.white, fontSize: 12),
            ),
            const SizedBox(height: 12),
            Semantics(
              label: 'Service progress: step 2 of 5, technician on the way',
              child: Row(
                children: List.generate(_stages.length, (index) {
                  return Expanded(
                    child: Container(
                      height: 4,
                      margin: EdgeInsets.only(right: index == 4 ? 0 : 5),
                      decoration: BoxDecoration(
                        color: index <= 1 ? AppTheme.white : AppTheme.black,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
