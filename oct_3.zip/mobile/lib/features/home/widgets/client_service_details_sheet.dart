import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class ClientServiceDetailsSheet extends StatelessWidget {
  final Map<String, dynamic> service;
  final VoidCallback? onBookTap;

  const ClientServiceDetailsSheet({
    super.key,
    required this.service,
    this.onBookTap,
  });

  @override
  Widget build(BuildContext context) {
    final String title =
        service['name']?.toString() ?? '';

    final String details =
        service['details']?.toString() ??
        service['description']?.toString() ??
        '';

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(
          maxHeight:
              MediaQuery.of(context).size.height * 0.88,
        ),
        decoration: const BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(24),
          ),
        ),
        child: Column(
          children: [

            // ============================================================
            // TOP BAR - DRAG HANDLE + CLOSE BUTTON
            // ============================================================

            SizedBox(
              height: 46,
              child: Stack(
                children: [
                  // Drag handle
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      margin: const EdgeInsets.only(top: 4),
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppTheme.borderGray,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),

                  // Close button - top right
                  Positioned(
                    top: 8,
                    right: 12,
                    child: Material(
                      color: AppTheme.lightGray,
                      shape: const CircleBorder(),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                        customBorder: const CircleBorder(),
                        child: const SizedBox(
                          width: 34,
                          height: 34,
                          child: Icon(
                            Icons.close_rounded,
                            color: AppTheme.gray,
                            size: 19,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ============================================================
            // SCROLLABLE CONTENT
            // ============================================================

            Expanded(
              child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(
                    bottom: 20,
                  ),
                  child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    // ==================================================
                    // SERVICE IMAGE
                    // ==================================================

                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        height: 180,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.asset(
                            service['image'].toString(),
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.cover,
                            alignment: Alignment.center,
                            errorBuilder: (
                              context,
                              error,
                              stackTrace,
                            ) {
                              return Container(
                                color: AppTheme.lightGray,
                                child: const Center(
                                  child: Icon(
                                    Icons.pest_control_rounded,
                                    color: AppTheme.primaryRed,
                                    size: 55,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 18),

                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                    // ==================================================
                    // SERVICE TITLE
                    // ==================================================

                    Text(
                      title,
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        height: 1.15,
                      ),
                    ),

                    const SizedBox(height: 10),

                    // ==================================================
                    // SERVICE DETAILS
                    // ==================================================

                    Text(
                      details,
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w500,
                        height: 1.6,
                      ),
                    ),
                       ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ============================================================
            // FIXED BOOK BUTTON
            // ============================================================

            Container(
              padding: const EdgeInsets.fromLTRB(
                20,
                12,
                20,
                18,
              ),
              decoration: BoxDecoration(
                color: AppTheme.white,
                border: Border(
                  top: BorderSide(
                    color:
                        AppTheme.borderGray.withOpacity(0.6),
                    width: 1,
                  ),
                ),
              ),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onBookTap,
                  icon: const Icon(
                    Icons.calendar_month_rounded,
                    size: 18,
                  ),
                  label: const Text(
                    'Book This Service',
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        AppTheme.primaryRed,
                    foregroundColor:
                        AppTheme.white,
                    elevation: 0,
                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}