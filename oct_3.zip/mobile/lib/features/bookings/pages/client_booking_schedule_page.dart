import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/bookings/pages/client_booking_review_page.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';
import 'package:mobile_app/features/bookings/widgets/booking_schedule_skeleton_load.dart';
import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';

class ClientBookingSchedulePage extends StatefulWidget {
  final String email;
  final Map<String, dynamic> selectedAddress;
  final List<Map<String, dynamic>> selectedServicePackages;
  final List<Map<String, dynamic>> selectedAreas;
  final Map<String, dynamic>? selectedTermiteSqm;
  final String description;
  final List<XFile> selectedImages;
  final double? termiteInputSqm;

  const ClientBookingSchedulePage({
    super.key,
    required this.email,
    required this.selectedAddress,
    required this.selectedServicePackages,
    required this.selectedAreas,
    required this.selectedTermiteSqm,
    required this.description,
    required this.selectedImages,
    required this.termiteInputSqm,
  });

  @override
  State<ClientBookingSchedulePage> createState() =>
      _ClientBookingSchedulePageState();
}

class _ClientBookingSchedulePageState
    extends State<ClientBookingSchedulePage> {
  bool isLoadingSchedule = true;

  DateTime? selectedDate;
  Map<String, String>? selectedTimeWindow;

  // ============================================================
  // TIME WINDOWS
  // ============================================================

  final List<Map<String, String>> timeWindows = [
    {
      'title': 'Morning',
      'time': '8:00 AM - 12:00 PM',
      'subtitle': 'Best for early home visits',
      'icon': '🌅',
    },
    {
      'title': 'Afternoon',
      'time': '12:00 PM - 5:00 PM',
      'subtitle': 'Ideal for regular service hours',
      'icon': '☀️',
    },
    {
      'title': 'Evening',
      'time': '5:00 PM - 8:00 PM',
      'subtitle': 'For late-day inspection requests',
      'icon': '🌆',
    },
  ];

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();
    _loadScheduleSkeleton();
  }

  // ============================================================
  // LOADING
  // ============================================================

  Future<void> _loadScheduleSkeleton() async {
    await Future.delayed(
      const Duration(
        milliseconds: 900,
      ),
    );

    if (!mounted) return;

    setState(() {
      isLoadingSchedule = false;
    });
  }

  // ============================================================
  // DATE PICKER
  // ============================================================

  Future<void> _pickDate() async {
    final now = DateTime.now();

    final tomorrow = DateTime(
      now.year,
      now.month,
      now.day + 1,
    );

    final date = await showDatePicker(
      context: context,

      // KEEP BOOKING DATE LOGIC
      initialDate: selectedDate ?? tomorrow,
      firstDate: tomorrow,
      lastDate: DateTime(
        now.year + 1,
      ),

      // ============================================================
      // CALENDAR UI - SAME DESIGN AS EDIT PROFILE
      // ============================================================

      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.primaryRed,
              onPrimary: Colors.white,

              // Keep calendar surface clean white.
              surface: Colors.white,
              onSurface: AppTheme.black,

              // Prevent Material 3 pink/red-tinted containers.
              surfaceContainerHigh: Colors.white,
              surfaceContainerHighest: Colors.white,
            ),

            datePickerTheme: DatePickerThemeData(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,

              // Red calendar header.
              headerBackgroundColor: AppTheme.primaryRed,
              headerForegroundColor: Colors.white,

              // Selected day = red circle.
              dayBackgroundColor:
                  WidgetStateProperty.resolveWith(
                (states) {
                  if (states.contains(
                    WidgetState.selected,
                  )) {
                    return AppTheme.primaryRed;
                  }

                  return Colors.transparent;
                },
              ),

              dayForegroundColor:
                  WidgetStateProperty.resolveWith(
                (states) {
                  if (states.contains(
                    WidgetState.selected,
                  )) {
                    return Colors.white;
                  }

                  return AppTheme.black;
                },
              ),

              // Current day = subtle red outline.
              todayBorder: const BorderSide(
                color: AppTheme.primaryRed,
                width: 1,
              ),

              todayForegroundColor:
                  const WidgetStatePropertyAll(
                AppTheme.primaryRed,
              ),

              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(
                  18,
                ),
              ),
            ),

            // CANCEL and OK = red.
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.primaryRed,
                textStyle: const TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          child: child!,
        );
      },
    );

    if (date == null) return;

    setState(() {
      selectedDate = date;
    });
  }

  // ============================================================
  // CONTINUE
  // ============================================================

  void _continueToReview() {
    if (selectedDate == null || selectedTimeWindow == null) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please choose your preferred date and time window.',
          ),
        ),
      );

      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientBookingReviewPage(
          email: widget.email,
          selectedAddress: widget.selectedAddress,
          selectedServicePackages: widget.selectedServicePackages,
          selectedAreas: widget.selectedAreas,
          selectedTermiteSqm: widget.selectedTermiteSqm,
          termiteInputSqm: widget.termiteInputSqm,
          description: widget.description,
          selectedImages: widget.selectedImages,
          selectedDate: selectedDate!,
          selectedTime: selectedTimeWindow!['time']!,
          selectedUrgency: selectedTimeWindow!['title']!,
        ),
      ),
    );
  }

  // ============================================================
  // FORMATTED DATE
  // ============================================================

  String get formattedDate {
    if (selectedDate == null) {
      return 'Choose preferred date';
    }

    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[selectedDate!.month - 1]} '
        '${selectedDate!.day}, '
        '${selectedDate!.year}';
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: const AppBackHeader(
        title: 'Schedule Service',
      ),
      bottomNavigationBar: ClientBottomNavBar(
        currentIndex: 2,
        email: widget.email,
      ),
      body: isLoadingSchedule
          ? const BookingScheduleSkeletonLoad()
          : Column(
              children: [
                // ==================================================
                // STEP INDICATOR
                // ==================================================

                const BookingStepIndicator(
                  currentStep: 3,
                ),

                // ==================================================
                // CONTENT
                // ==================================================

                Expanded(
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(
                      20,
                      18,
                      20,
                      24,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ==========================================
                        // INTRO
                        // ==========================================

                        _introCard(),

                        const SizedBox(
                          height: 16,
                        ),

                        // ==========================================
                        // DATE
                        // ==========================================

                        _sectionLabel(
                          'PREFERRED DATE',
                        ),

                        const SizedBox(
                          height: 10,
                        ),

                        _dateSelector(),

                        const SizedBox(
                          height: 20,
                        ),

                        // ==========================================
                        // TIME
                        // ==========================================

                        _sectionLabel(
                          'TIME WINDOW',
                        ),

                        const SizedBox(
                          height: 10,
                        ),

                        ...timeWindows.map(
                          _timeWindowItem,
                        ),

                        const SizedBox(
                          height: 2,
                        ),

                        // ==========================================
                        // NOTE
                        // ==========================================

                        _scheduleNote(),
                      ],
                    ),
                  ),
                ),

                // ==================================================
                // CONTINUE
                // ==================================================

                _bottomButton(),
              ],
            ),
    );
  }

  // ============================================================
  // INTRO
  // ============================================================

  Widget _introCard() {
    return const Padding(
      padding: EdgeInsets.symmetric(
        horizontal: 2,
        vertical: 4,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'When do you need the service?',
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(
            height: 4,
          ),
          Text(
            'Choose your preferred date and time window for this service appointment.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11,
              height: 1.45,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(String title) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 2,
      ),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.gray,
          fontSize: 10,
          letterSpacing: 0.9,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // DATE SELECTOR
  // ============================================================

  Widget _dateSelector() {
    final bool hasDate = selectedDate != null;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(
          14,
        ),
        onTap: _pickDate,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 180,
          ),
          width: double.infinity,
          padding: const EdgeInsets.all(
            14,
          ),
          decoration: BoxDecoration(
            color: hasDate
                ? const Color(0xFFFFF7F7)
                : AppTheme.white,
            borderRadius: BorderRadius.circular(
              14,
            ),
            border: Border.all(
              color: hasDate
                  ? AppTheme.primaryRed
                  : AppTheme.borderGray,
              width: hasDate ? 1.2 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(
                  0.018,
                ),
                blurRadius: 7,
                offset: const Offset(
                  0,
                  2,
                ),
              ),
            ],
          ),
          child: Row(
            children: [
              // ==================================================
              // CALENDAR ICON
              // ==================================================

              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: hasDate
                      ? AppTheme.primaryRed.withOpacity(0.10)
                      : AppTheme.black.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(
                    12,
                  ),
                ),
                child: const Icon(
                  Icons.calendar_month_outlined,
                  color: AppTheme.primaryRed,
                  size: 22,
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              // ==================================================
              // DATE TEXT
              // ==================================================

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Preferred Date',
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      formattedDate,
                      style: TextStyle(
                        color: hasDate
                            ? AppTheme.black
                            : AppTheme.gray,
                        fontSize: 13,
                        fontWeight: hasDate
                            ? FontWeight.w800
                            : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                width: 8,
              ),

              Icon(
                Icons.chevron_right_rounded,
                color: hasDate
                    ? AppTheme.primaryRed
                    : AppTheme.gray,
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // TIME WINDOW
  // ============================================================

  Widget _timeWindowItem(
    Map<String, String> window,
  ) {
    final bool isSelected =
        selectedTimeWindow?['title'] == window['title'];

    return Padding(
      padding: const EdgeInsets.only(
        bottom: 10,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(
            14,
          ),
          onTap: () {
            setState(() {
              selectedTimeWindow = window;
            });
          },
          child: AnimatedContainer(
            duration: const Duration(
              milliseconds: 180,
            ),
            width: double.infinity,
            padding: const EdgeInsets.all(
              12,
            ),
            decoration: BoxDecoration(
              color: isSelected
                  ? const Color(0xFFFFF7F7)
                  : AppTheme.white,
              borderRadius: BorderRadius.circular(
                14,
              ),
              border: Border.all(
                color: isSelected
                    ? AppTheme.primaryRed
                    : AppTheme.borderGray,
                width: isSelected ? 1.2 : 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(
                    0.018,
                  ),
                  blurRadius: 7,
                  offset: const Offset(
                    0,
                    2,
                  ),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // ==================================================
                // TIME ICON
                // ==================================================

                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.primaryRed.withOpacity(0.10)
                        : AppTheme.black.withOpacity(0.045),
                    borderRadius: BorderRadius.circular(
                      12,
                    ),
                  ),
                  child: Text(
                    window['icon']!,
                    style: const TextStyle(
                      fontSize: 22,
                    ),
                  ),
                ),

                const SizedBox(
                  width: 11,
                ),

                // ==================================================
                // TIME DETAILS
                // ==================================================

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        window['title']!,
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.primaryRed
                              : AppTheme.black,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      Text(
                        window['time']!,
                        style: TextStyle(
                          color: isSelected
                              ? AppTheme.primaryRed
                              : AppTheme.black,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(
                        height: 3,
                      ),
                      Text(
                        window['subtitle']!,
                        style: const TextStyle(
                          color: AppTheme.gray,
                          fontSize: 10.5,
                          height: 1.3,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  width: 8,
                ),

                Icon(
                  Icons.chevron_right_rounded,
                  color: isSelected
                      ? AppTheme.primaryRed
                      : AppTheme.gray,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SCHEDULE NOTE
  // ============================================================

  Widget _scheduleNote() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        13,
      ),
      decoration: BoxDecoration(
        color: AppTheme.black.withOpacity(
          0.035,
        ),
        borderRadius: BorderRadius.circular(
          13,
        ),
        border: Border.all(
          color: AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: AppTheme.black.withOpacity(
                0.06,
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.info_outline_rounded,
              color: AppTheme.primaryRed,
              size: 17,
            ),
          ),

          const SizedBox(
            width: 10,
          ),

          const Expanded(
            child: Text(
              'Final schedule is subject to company approval and technician availability.',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 10.5,
                height: 1.45,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BOTTOM BUTTON
  // ============================================================

  Widget _bottomButton() {
    final bool canContinue =
        selectedDate != null && selectedTimeWindow != null;

    return Container(
      padding: const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(
          top: BorderSide(
            color: AppTheme.borderGray,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton(
            onPressed: canContinue
                ? _continueToReview
                : null,
            child: const Text(
              'Continue',
            ),
          ),
        ),
      ),
    );
  }
}