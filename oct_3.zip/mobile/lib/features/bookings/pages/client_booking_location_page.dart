import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/bookings/pages/client_booking_problem_page.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';
import 'package:mobile_app/features/bookings/widgets/booking_location_skeleton.dart';

import 'package:mobile_app/features/addresses/widgets/add_address_sheet.dart';

import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';

class ClientBookingLocationPage extends StatefulWidget {
  final String email;

  const ClientBookingLocationPage({
    super.key,
    required this.email,
  });

  @override
  State<ClientBookingLocationPage> createState() =>
      _ClientBookingLocationPageState();
}

class _ClientBookingLocationPageState
    extends State<ClientBookingLocationPage> {
  String? selectedSavedAddressId;

  Map<String, dynamic>? selectedAddressData;

  List<Map<String, dynamic>> savedAddresses = [];

  bool isLoadingAddresses = false;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _loadSavedAddresses();
  }

  // ============================================================
  // ADDRESS TYPE
  // ============================================================

  String _addressTypeLabel(
    dynamic addId,
  ) {
    switch (addId.toString()) {
      case '1':
        return 'HOME';

      case '2':
        return 'WORK';

      case '3':
        return 'COMPANY';

      case '4':
        return 'FAVORITE';

      case '5':
        return 'RESIDENTIAL';

      default:
        return 'ADDRESS';
    }
  }

  // ============================================================
  // ADDRESS LABEL
  // ============================================================

  String _formatTypeLabel(
    String type,
  ) {
    switch (type.toUpperCase()) {
      case 'HOME':
        return 'Home';

      case 'WORK':
        return 'Work';

      case 'COMPANY':
        return 'Company';

      case 'FAVORITE':
        return 'Favorite';

      case 'RESIDENTIAL':
        return 'Residential';

      default:
        return type;
    }
  }

  // ============================================================
  // ADDRESS ICON
  // ============================================================

  IconData _addressIcon(
    String type,
  ) {
    switch (type.toUpperCase()) {
      case 'HOME':
        return Icons.home_outlined;

      case 'WORK':
        return Icons.business_center_outlined;

      case 'COMPANY':
        return Icons.apartment_rounded;

      case 'FAVORITE':
        return Icons.star_outline_rounded;

      case 'RESIDENTIAL':
        return Icons.location_city_outlined;

      default:
        return Icons.location_on_outlined;
    }
  }

  // ============================================================
  // ADDRESS ICON BACKGROUND
  // ============================================================

  Color _addressIconBackground(
    String type,
  ) {
    switch (type.toUpperCase()) {
      case 'WORK':
        return const Color(
          0xFFEAF1FF,
        );

      case 'COMPANY':
        return const Color(
          0xFFF1ECFF,
        );

      case 'FAVORITE':
        return const Color(
          0xFFFFF3DF,
        );

      case 'RESIDENTIAL':
        return const Color(
          0xFFEAF7F0,
        );

      default:
        return AppTheme.black.withOpacity(
          0.045,
        );
    }
  }

  // ============================================================
  // ADDRESS ICON COLOR
  // ============================================================

  Color _addressIconColor(
    String type,
  ) {
    switch (type.toUpperCase()) {
      case 'WORK':
        return const Color(
          0xFF4E76B8,
        );

      case 'COMPANY':
        return const Color(
          0xFF7D59C8,
        );

      case 'FAVORITE':
        return const Color(
          0xFFE0A124,
        );

      case 'RESIDENTIAL':
        return const Color(
          0xFF4F9B75,
        );

      default:
        return AppTheme.primaryRed;
    }
  }

  // ============================================================
  // FORMAT ADDRESS
  // ============================================================

  String _formatAddress(
    dynamic item,
  ) {
    final street =
        (item['uadd_street'] ?? '')
            .toString()
            .trim();

    final barangay =
        (item['uadd_barangay'] ?? '')
            .toString()
            .trim();

    final city =
        (item['uadd_city'] ?? '')
            .toString()
            .trim();

    final province =
        (item['uadd_province'] ?? '')
            .toString()
            .trim();

    final region =
        (item['uadd_region'] ?? '')
            .toString()
            .trim();

    final firstLine = [
      street,
      barangay,
    ].where(
      (value) => value.isNotEmpty,
    ).join(', ');

    final secondLine = [
      city,
      province,
      region,
    ].where(
      (value) => value.isNotEmpty,
    ).join(', ');

    final lines = [
      firstLine,
      secondLine,
    ].where(
      (value) => value.isNotEmpty,
    ).toList();

    if (lines.isEmpty) {
      return 'Address details unavailable';
    }

    return lines.join('\n');
  }

  // ============================================================
  // CONTINUE
  // ============================================================

  void _continueToProblem() {
    if (selectedAddressData == null) {
      _showMessage(
        'Please select a service address.',
      );

      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            ClientBookingProblemPage(
          email: widget.email,
          selectedAddress:
              selectedAddressData!,
        ),
      ),
    );
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          message,
        ),
      ),
    );
  }

  // ============================================================
  // ADD ADDRESS
  // ============================================================

  void _openAddAddressSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,

      // Allows rounded sheet corners to display properly.
      backgroundColor: Colors.transparent,

      builder: (_) {
        return AddAddressSheet(
          email: widget.email,
          onSaved: (_) async {
            await _loadSavedAddresses(
              selectNewest: true,
            );
          },
        );
      },
    );
  }

  // ============================================================
  // LOAD SAVED ADDRESSES
  // ============================================================

  Future<void> _loadSavedAddresses({
    bool selectNewest = false,
  }) async {
    if (!mounted) return;

    setState(() {
      isLoadingAddresses = true;
    });

    try {
      final response =
          await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/address/list',
        ),
        headers: const {
          'Content-Type':
              'application/json',
          'Accept':
              'application/json',
        },
        body: jsonEncode({
          'email':
              widget.email,
        }),
      );

      final data =
          jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode ==
              200 &&
          data['success'] ==
              true) {
        final List addressData =
            data['data'] ??
                [];

        final List<
                Map<String, dynamic>>
            mappedAddresses =
            addressData.map<
                Map<String, dynamic>>(
          (
            item,
          ) {
            final type =
                _addressTypeLabel(
              item['add_id'],
            );

            return {
              'id':
                  item['uadd_id'],

              'uadd_id':
                  item['uadd_id'],

              'add_id':
                  item['add_id'],

              'type':
                  type,

              'address':
                  _formatAddress(
                item,
              ),

              'uadd_street':
                  item['uadd_street'] ??
                      '',

              'uadd_barangay':
                  item['uadd_barangay'] ??
                      '',

              'uadd_city':
                  item['uadd_city'] ??
                      '',

              'uadd_province':
                  item['uadd_province'] ??
                      '',

              'uadd_region':
                  item['uadd_region'] ??
                      '',

              'uadd_latitude':
                  item['uadd_latitude'],

              'uadd_longitude':
                  item['uadd_longitude'],
            };
          },
        ).toList();

        setState(() {
          savedAddresses =
              mappedAddresses;

          // ======================================================
          // NO ACTIVE ADDRESSES
          // ======================================================

          if (mappedAddresses
              .isEmpty) {
            selectedSavedAddressId =
                null;

            selectedAddressData =
                null;

            return;
          }

          // ======================================================
          // SELECT NEWEST AFTER ADD
          // ======================================================

          if (selectNewest) {
            final newestAddress =
                mappedAddresses.first;

            selectedSavedAddressId =
                newestAddress['id']
                    .toString();

            selectedAddressData =
                Map<String, dynamic>.from(
              newestAddress,
            );

            return;
          }

          // ======================================================
          // KEEP CURRENT SELECTION
          // ======================================================

          if (selectedSavedAddressId !=
              null) {
            final match =
                mappedAddresses
                    .where(
              (
                address,
              ) =>
                  address['id']
                      .toString() ==
                  selectedSavedAddressId,
            )
                    .toList();

            if (match.isNotEmpty) {
              selectedAddressData =
                  Map<String,
                      dynamic>.from(
                match.first,
              );

              return;
            }
          }

          // ======================================================
          // INITIAL SELECTION
          //
          // This is only the initial selection for this booking.
          // It is NOT a Default/Primary address.
          // ======================================================

          final firstAddress =
              mappedAddresses.first;

          selectedSavedAddressId =
              firstAddress['id']
                  .toString();

          selectedAddressData =
              Map<String, dynamic>.from(
            firstAddress,
          );
        });
      } else {
        setState(() {
          savedAddresses = [];

          selectedSavedAddressId =
              null;

          selectedAddressData =
              null;
        });

        _showMessage(
          data['message'] ??
              'Unable to load saved addresses.',
        );
      }
    } catch (error) {
      debugPrint(
        'BOOKING ADDRESS ERROR: $error',
      );

      if (!mounted) return;

      _showMessage(
        'Unable to load saved addresses.',
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoadingAddresses =
              false;
        });
      }
    }
  }

  // ============================================================
  // SELECT ADDRESS
  // ============================================================

  void _selectAddress(
    Map<String, dynamic> address,
  ) {
    setState(() {
      selectedSavedAddressId =
          address['id']
              .toString();

      selectedAddressData =
          Map<String, dynamic>.from(
        address,
      );
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      drawer:
          AppDrawer(
        userType:
            3,

        email:
            widget.email,

        currentPage:
            'book_service',
      ),

      appBar:
          const AppTitleHeader(
        title:
            'Book Service',
      ),

      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex:
            2,

        email:
            widget.email,
      ),

      body:
          isLoadingAddresses
              ? const BookingLocationSkeletonLoad()
              : Column(
                  children: [
                    // ==================================================
                    // STEP INDICATOR
                    // ==================================================

                    const BookingStepIndicator(
                      currentStep: 1,
                    ),

                    // ==================================================
                    // CONTENT
                    // ==================================================

                    Expanded(
                      child:
                          RefreshIndicator(
                        color:
                            AppTheme.primaryRed,

                        onRefresh:
                            _loadSavedAddresses,

                        child:
                            SingleChildScrollView(
                          physics:
                              const AlwaysScrollableScrollPhysics(),

                          padding:
                              const EdgeInsets.fromLTRB(
                            20,
                            18,
                            20,
                            24,
                          ),

                          child:
                              Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,

                            children: [
                              // ==========================================
                              // INTRO
                              // ==========================================

                              _introCard(),

                              const SizedBox(
                                height:
                                    20,
                              ),

                              // ==========================================
                              // SECTION
                              // ==========================================

                              _sectionLabel(
                                'SERVICE ADDRESS',
                              ),

                              const SizedBox(
                                height:
                                    10,
                              ),

                              // ==========================================
                              // ADDRESSES
                              // ==========================================

                              if (savedAddresses
                                  .isEmpty)
                                _emptyAddressCard()
                              else ...[
                                ...savedAddresses
                                    .map(
                                  (
                                    address,
                                  ) {
                                    return _addressCard(
                                      address,
                                    );
                                  },
                                ),

                                const SizedBox(
                                  height:
                                      2,
                                ),

                                _addAddressButton(),
                              ],

                              // ==========================================
                              // INFO
                              // ==========================================

                              if (selectedAddressData !=
                                  null) ...[
                                const SizedBox(
                                  height:
                                      14,
                                ),

                                _selectedAddressInfo(),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),

                    // ==================================================
                    // CONTINUE
                    // ==================================================

                    _bottomButton(),
                  ],
                ),
    );
  }

  // ============================================================
  // INTRO CARD
  // ============================================================

  Widget _introCard() {
    return const Padding(
      padding: EdgeInsets.symmetric(
        horizontal: 2,
        vertical: 4,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Where do you need the service?',
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),

          SizedBox(height: 4),

          Text(
            'Choose one of your saved addresses for this service appointment.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11,
              height: 1.45,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left:
            2,
      ),

      child:
          Text(
        title,

        style:
            const TextStyle(
          color:
              AppTheme.gray,

          fontSize:
              10,

          letterSpacing:
              0.9,

          fontWeight:
              FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // ADDRESS CARD
  // ============================================================

  Widget _addressCard(
    Map<String, dynamic> address,
  ) {
    final String id =
        address['id']
            .toString();

    final String type =
        address['type'] ??
            'ADDRESS';

    final bool selected =
        selectedSavedAddressId ==
            id;

    return Padding(
      padding:
          const EdgeInsets.only(
        bottom:
            10,
      ),

      child:
          Material(
        color:
            Colors.transparent,

        child:
            InkWell(
          borderRadius:
              BorderRadius.circular(
            14,
          ),

          onTap: () {
            _selectAddress(
              address,
            );
          },

          child:
              AnimatedContainer(
            duration:
                const Duration(
              milliseconds:
                  180,
            ),

            width:
                double.infinity,

            padding:
                const EdgeInsets.all(
              12,
            ),

            decoration: BoxDecoration(
              color: selected
                  ? const Color(0xFFFFF7F7)
                  : AppTheme.white,

              borderRadius:
                  BorderRadius.circular(
                14,
              ),

              border:
                  Border.all(
                color:
                    selected
                        ? AppTheme.primaryRed
                        : AppTheme.borderGray,

                width:
                    selected
                        ? 1.2
                        : 1,
              ),

              boxShadow: [
                BoxShadow(
                  color:
                      Colors.black.withOpacity(
                    0.018,
                  ),

                  blurRadius:
                      7,

                  offset:
                      const Offset(
                    0,
                    2,
                  ),
                ),
              ],
            ),

            child:
                Row(
              crossAxisAlignment:
                  CrossAxisAlignment.center,

              children: [

                // ==================================================
                // ICON
                // ==================================================

                Container(
                  width:
                      42,

                  height:
                      42,

                  decoration:
                      BoxDecoration(
                    color: selected
                    ? AppTheme.primaryRed.withOpacity(0.10)
                    : _addressIconBackground(type),

                    shape:
                        BoxShape.circle,
                  ),

                  child:
                      Icon(
                    _addressIcon(
                      type,
                    ),

                    color: selected
                    ? AppTheme.primaryRed
                    : _addressIconColor(type),

                    size:
                        20,
                  ),
                ),

                const SizedBox(
                  width:
                      11,
                ),

                // ==================================================
                // INFO
                // ==================================================

                Expanded(
                  child:
                      Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,

                    children: [
                      Text(
                        _formatTypeLabel(
                          type,
                        ),

                        style: TextStyle(
                          color: selected
                              ? AppTheme.primaryRed
                              : AppTheme.black,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),

                      const SizedBox(
                        height:
                            4,
                      ),

                      Text(
                        address['address'] ??
                            '',

                        style:
                            const TextStyle(
                          color:
                              AppTheme.black,

                          fontSize:
                              10.5,

                          height:
                              1.4,

                          fontWeight:
                              FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  width:
                      8,
                ),

                Icon(
                  Icons.chevron_right_rounded,
                  color: selected
                      ? AppTheme.primaryRed
                      : AppTheme.gray,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // ADD ADDRESS BUTTON
  // ============================================================

  Widget _addAddressButton() {
    return Material(
      color:
          Colors.transparent,

      child:
          InkWell(
        borderRadius:
            BorderRadius.circular(
          13,
        ),

        onTap:
            _openAddAddressSheet,

        child:
            Container(
          width:
              double.infinity,

          height:
              48,

          decoration:
              BoxDecoration(
            color:
                AppTheme.white,

            borderRadius:
                BorderRadius.circular(
              13,
            ),

            border: Border.all(
              color: AppTheme.black.withOpacity(
                0.12,
              ),
            ),
          ),

          alignment:
              Alignment.center,

          child:
              const Row(
            mainAxisAlignment:
                MainAxisAlignment.center,

            children: [
              Icon(
                Icons.add_rounded,
                color: AppTheme.black,
                size: 20,
              ),

              SizedBox(
                width:
                    7,
              ),

              Text(
                'Add New Address',
                style: TextStyle(
                  color: AppTheme.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================

  Widget _emptyAddressCard() {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.fromLTRB(
        22,
        34,
        22,
        24,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),
      ),

      child:
          Column(
        children: [
          Container(
            width:
                86,

            height:
                86,

            decoration:
                BoxDecoration(
              color:
                  AppTheme.black.withOpacity(
                0.045,
              ),

              shape:
                  BoxShape.circle,
            ),

            child:
                const Icon(
              Icons.add_location_alt_rounded,

              color:
                  AppTheme.primaryRed,

              size:
                  38,
            ),
          ),

          const SizedBox(
            height:
                18,
          ),

          const Text(
            'No Saved Address',

            style:
                TextStyle(
              color:
                  AppTheme.black,

              fontSize:
                  15,

              fontWeight:
                  FontWeight.w900,
            ),
          ),

          const SizedBox(
            height:
                7,
          ),

          const Text(
            'Add an address before continuing with your service booking.',

            textAlign:
                TextAlign.center,

            style:
                TextStyle(
              color:
                  AppTheme.gray,

              fontSize:
                  11,

              height:
                  1.45,

              fontWeight:
                  FontWeight.w500,
            ),
          ),

          const SizedBox(
            height:
                22,
          ),

          SizedBox(
            width:
                double.infinity,

            height:
                48,

            child:
                ElevatedButton.icon(
              onPressed:
                  _openAddAddressSheet,

              icon:
                  const Icon(
                Icons.add_rounded,

                size:
                    19,
              ),

              label:
                  const Text(
                'Add New Address',
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // ============================================================
  // SELECTED ADDRESS INFO
  // ============================================================

  Widget _selectedAddressInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        13,
      ),
      decoration: BoxDecoration(
        color: AppTheme.black.withOpacity(
          0.035,
        ),
        borderRadius: BorderRadius.circular(
          13,
        ),
        border: Border.all(
          color: AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          // ======================================================
          // INFO ICON
          // ======================================================

          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: AppTheme.black.withOpacity(
                0.06,
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.add_rounded,
              color: AppTheme.black,
              size: 20,
            ),
          ),

          const SizedBox(
            width: 10,
          ),

          // ======================================================
          // INFO TEXT
          // ======================================================

          const Expanded(
            child: Text(
              'The selected address will only be used for this service booking.',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 10.5,
                height: 1.45,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BOTTOM BUTTON
  // ============================================================

  Widget _bottomButton() {
    final bool canContinue =
        selectedAddressData !=
            null;

    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),

      decoration: const BoxDecoration(
        color: AppTheme.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                AppTheme.borderGray,

            width:
                1,
          ),
        ),
      ),

      child:
          SafeArea(
        top:
            false,

        child:
            SizedBox(
          width:
              double.infinity,

          height:
              48,

          child:
              ElevatedButton(
            onPressed:
                canContinue
                    ? _continueToProblem
                    : null,

            child:
                const Text(
              'Continue',
            ),
          ),
        ),
      ),
    );
  }
}
