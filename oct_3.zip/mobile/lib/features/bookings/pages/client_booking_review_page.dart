import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/appointments/pages/client_requested_appointments_page.dart';

import 'package:mobile_app/features/bookings/widgets/booking_review_skeleton_load.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';

import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';

class ClientBookingReviewPage extends StatefulWidget {
  final String email;
  final Map<String, dynamic> selectedAddress;
  final List<Map<String, dynamic>> selectedServicePackages;
  final List<Map<String, dynamic>> selectedAreas;
  final Map<String, dynamic>? selectedTermiteSqm;
  final String description;
  final List<XFile> selectedImages;
  final DateTime selectedDate;
  final String selectedTime;
  final String selectedUrgency;
  final double? termiteInputSqm;

  const ClientBookingReviewPage({
    super.key,
    required this.email,
    required this.selectedAddress,
    required this.selectedServicePackages,
    required this.selectedAreas,
    required this.selectedTermiteSqm,
    required this.description,
    required this.selectedImages,
    required this.selectedDate,
    required this.selectedTime,
    required this.selectedUrgency,
    required this.termiteInputSqm,
  });

  @override
  State<ClientBookingReviewPage> createState() =>
      _ClientBookingReviewPageState();
}

class _ClientBookingReviewPageState
    extends State<ClientBookingReviewPage> {
  bool isSubmitting = false;
  bool isLoadingReview = true;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _loadReviewSkeleton();
  }

  // ============================================================
  // LOADING
  // ============================================================

  Future<void> _loadReviewSkeleton() async {
    await Future.delayed(
      const Duration(
        milliseconds: 900,
      ),
    );

    if (!mounted) return;

    setState(() {
      isLoadingReview = false;
    });
  }

  // ============================================================
  // TERMITE CHECK
  // ============================================================

  bool get hasTermitesSelected {
    return widget.selectedServicePackages.any(
      (service) =>
          service['name']
              .toString()
              .toUpperCase() ==
          'TERMITES',
    );
  }

  // ============================================================
  // TIME START
  // ============================================================

  String _timeStart(
    String timeWindow,
  ) {
    if (timeWindow.contains(
      '8:00 AM',
    )) {
      return '08:00:00';
    }

    if (timeWindow.contains(
      '12:00 PM',
    )) {
      return '12:00:00';
    }

    if (timeWindow.contains(
      '5:00 PM',
    )) {
      return '17:00:00';
    }

    return '08:00:00';
  }

  // ============================================================
  // TOTAL PRICE
  // ============================================================

  double get totalPrice {
    if (hasTermitesSelected &&
        widget.selectedTermiteSqm != null) {
      final sqm =
          widget.termiteInputSqm ?? 0;

      final cost =
          double.tryParse(
            widget.selectedTermiteSqm?['cost']
                    .toString() ??
                '0',
          ) ??
          0;

      if (sqm >= 1 && sqm <= 50) {
        return cost;
      }

      return sqm * cost;
    }

    double total = 0;

    for (final area
        in widget.selectedAreas) {
      final value =
          area['cost'] ??
          area['price'] ??
          area['svcpa_cost'] ??
          0;

      total +=
          double.tryParse(
            value.toString(),
          ) ??
          0;
    }

    return total;
  }

  // ============================================================
  // FORMATTED DATE
  // ============================================================

  String get formattedDate {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[widget.selectedDate.month - 1]} '
        '${widget.selectedDate.day}, '
        '${widget.selectedDate.year}';
  }

  // ============================================================
  // FORMAT NAME
  // ============================================================

  String _formatName(
    String text,
  ) {
    return text
        .toLowerCase()
        .split(' ')
        .map(
          (
            word,
          ) {
            if (word.isEmpty) {
              return word;
            }

            return word[0].toUpperCase() +
                word.substring(1);
          },
        )
        .join(' ');
  }

  // ============================================================
  // SUBMIT BOOKING
  // ============================================================

  Future<void> _submitBooking() async {
    if (isSubmitting) return;

    setState(() {
      isSubmitting = true;
    });

    try {
      final uri =
          Uri.parse(
        '${ApiConfig.baseUrl}/api/mobile/service-appointments/store',
      );

      final request =
          http.MultipartRequest(
        'POST',
        uri,
      );

      request.headers['Accept'] =
          'application/json';

      request.fields['email'] =
          widget.email;

      request.fields['uadd_id'] =
          widget.selectedAddress['id']
              .toString();

      request.fields['client_date'] =
          '${widget.selectedDate.year}-'
          '${widget.selectedDate.month.toString().padLeft(2, '0')}-'
          '${widget.selectedDate.day.toString().padLeft(2, '0')}';

      request.fields['client_time'] =
          _timeStart(
        widget.selectedTime,
      );

      request.fields['initial_price'] =
          totalPrice.toStringAsFixed(
        2,
      );

      request.fields['is_termite'] =
          hasTermitesSelected
              ? '1'
              : '0';

      // ========================================================
      // TERMITE
      // ========================================================

      if (hasTermitesSelected &&
          widget.selectedTermiteSqm != null) {
        request.fields['termite_sqm_id'] =
            widget.selectedTermiteSqm!['id']
                .toString();

        request.fields[
                'termite_sqm_input'] =
            widget.termiteInputSqm
                .toString();
      }

      // ========================================================
      // DESCRIPTION
      // ========================================================

      request.fields[
              'problem_description'] =
          widget.description
              .trim()
              .toUpperCase();

      // ========================================================
      // SERVICE PACKAGES
      // ========================================================

      request.fields['service_packages'] =
          jsonEncode(
        widget.selectedServicePackages
            .map(
          (
            service,
          ) {
            return {
              'id':
                  service['id'],
            };
          },
        ).toList(),
      );

      // ========================================================
      // SERVICE AREAS
      // ========================================================

      request.fields['service_areas'] =
          jsonEncode(
        widget.selectedAreas.map(
          (
            area,
          ) {
            return {
              'id':
                  area['id'],
            };
          },
        ).toList(),
      );

      // ========================================================
      // IMAGES
      // ========================================================

      for (final image
          in widget.selectedImages) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'images[]',
            image.path,
          ),
        );
      }

      // ========================================================
      // SEND
      // ========================================================

      final response =
          await request.send();

      final responseBody =
          await response.stream
              .bytesToString();

      final data =
          jsonDecode(
        responseBody,
      );

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        ScaffoldMessenger.of(context)
            .hideCurrentSnackBar();

        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              'Booking request submitted successfully.',
            ),
          ),
        );

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) =>
                ClientRequestedAppointmentsPage(
              email: widget.email,
            ),
          ),
          (
            route,
          ) =>
              false,
        );

        return;
      }

      throw Exception(
        data['error'] ??
            data['message'] ??
            'Unable to submit booking.',
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .hideCurrentSnackBar();

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            'Submission failed: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isSubmitting = false;
        });
      }
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      appBar:
          const AppBackHeader(
        title:
            'Review Booking',
      ),

      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex:
            2,
        email:
            widget.email,
      ),

      body:
          isLoadingReview
              ? const BookingReviewSkeletonLoad()
              : Column(
                  children: [
                    // ==================================================
                    // STEP INDICATOR
                    // ==================================================

                    const BookingStepIndicator(
                      currentStep:
                          4,
                    ),

                    // ==================================================
                    // CONTENT
                    // ==================================================

                    Expanded(
                      child:
                          SingleChildScrollView(
                        physics:
                            const AlwaysScrollableScrollPhysics(),

                        padding:
                            const EdgeInsets.fromLTRB(
                          20,
                          18,
                          20,
                          24,
                        ),

                        child:
                            Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,

                          children: [
                            // ==========================================
                            // INTRO
                            // ==========================================

                            _introCard(),

                            const SizedBox(
                              height:
                                  16,
                            ),

                            // ==========================================
                            // BOOKING DETAILS
                            // ==========================================

                            _sectionLabel(
                              'BOOKING DETAILS',
                            ),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _locationCard(),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _pestCard(),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            hasTermitesSelected
                                ? _termiteSqmCard()
                                : _areasCard(),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _descriptionCard(),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _photosCard(),

                            const SizedBox(
                              height:
                                  20,
                            ),

                            // ==========================================
                            // SCHEDULE
                            // ==========================================

                            _sectionLabel(
                              'SERVICE SCHEDULE',
                            ),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _scheduleCard(),

                            const SizedBox(
                              height:
                                  20,
                            ),

                            // ==========================================
                            // PRICE
                            // ==========================================

                            _sectionLabel(
                              'ESTIMATED PRICE',
                            ),

                            const SizedBox(
                              height:
                                  10,
                            ),

                            _priceCard(),

                            const SizedBox(
                              height:
                                  14,
                            ),

                            // ==========================================
                            // NOTE
                            // ==========================================

                            _nextStepBox(),
                          ],
                        ),
                      ),
                    ),

                    // ==================================================
                    // SUBMIT
                    // ==================================================

                    _bottomButton(),
                  ],
                ),
    );
  }

  // ============================================================
  // INTRO CARD
  // ============================================================

  Widget _introCard() {
    return const Padding(
      padding: EdgeInsets.symmetric(
        horizontal: 2,
        vertical: 4,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Review your request',
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(
            height: 4,
          ),
          Text(
            'Please check your booking information carefully before submitting your request.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11,
              height: 1.45,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left:
            2,
      ),

      child:
          Text(
        title,

        style:
            const TextStyle(
          color:
              AppTheme.gray,

          fontSize:
              10,

          letterSpacing:
              0.9,

          fontWeight:
              FontWeight.w900,
        ),
      ),
    );
  }

  // ============================================================
  // LOCATION
  // ============================================================

  Widget _locationCard() {
    return _summaryBox(
      icon:
          Icons.location_on_outlined,

      title:
          'Service Location',

      children: [
        _MainValue(
          _formatName(
            widget.selectedAddress['type']
                    ?.toString() ??
                'Address',
          ),
        ),

        const SizedBox(
          height:
              5,
        ),

        _SubValue(
          widget.selectedAddress['address']
                  ?.toString() ??
              'No address selected',
        ),
      ],
    );
  }

  // ============================================================
  // PEST PROBLEM
  // ============================================================

  Widget _pestCard() {
    return _summaryBox(
      icon:
          Icons.bug_report_outlined,

      title:
          'Pest Problem',

      children: [
        Wrap(
          spacing:
              7,

          runSpacing:
              7,

          children:
              widget.selectedServicePackages.map(
            (
              service,
            ) {
              return _chip(
                _formatName(
                  service['name']
                          ?.toString() ??
                      '',
                ),
              );
            },
          ).toList(),
        ),
      ],
    );
  }

  // ============================================================
  // AREAS
  // ============================================================

  Widget _areasCard() {
    return _summaryBox(
      icon:
          Icons.home_work_outlined,

      title:
          'Areas to Treat',

      children: [
        Wrap(
          spacing:
              7,

          runSpacing:
              7,

          children:
              widget.selectedAreas.map(
            (
              area,
            ) {
              final cost =
                  area['cost'] ??
                  area['price'] ??
                  area['svcpa_cost'] ??
                  0;

              return _chip(
                '${_formatName(
                  area['area']
                          ?.toString() ??
                      '',
                )} • ₱$cost',
              );
            },
          ).toList(),
        ),
      ],
    );
  }

  // ============================================================
  // TERMITE SIZE
  // ============================================================

  Widget _termiteSqmCard() {
    final termiteSqm =
        widget.selectedTermiteSqm;

    return _summaryBox(
      icon:
          Icons.square_foot_outlined,

      title:
          'Termite Treatment Size',

      children: [
        _MainValue(
          '${widget.termiteInputSqm?.toStringAsFixed(0) ?? '0'} sqm',
        ),

        const SizedBox(
          height:
              5,
        ),

        _SubValue(
          termiteSqm?['sqm_details']
                  ?.toString() ??
              'No matching range',
        ),
      ],
    );
  }

  // ============================================================
  // DESCRIPTION
  // ============================================================

  Widget _descriptionCard() {
    final description =
        widget.description.trim();

    return _summaryBox(
      icon:
          Icons.notes_outlined,

      title:
          'Problem Description',

      children: [
        _SubValue(
          description.isEmpty
              ? 'No additional description provided.'
              : description,
        ),
      ],
    );
  }

  // ============================================================
  // PHOTOS
  // ============================================================

  Widget _photosCard() {
    return _summaryBox(
      icon:
          Icons.photo_library_outlined,

      title:
          'Attached Photos',

      children: [
        if (widget.selectedImages.isEmpty)
          const _SubValue(
            'No photos attached.',
          )
        else
          SizedBox(
            height:
                82,

            child:
                ListView.separated(
              scrollDirection:
                  Axis.horizontal,

              itemCount:
                  widget.selectedImages.length,

              separatorBuilder:
                  (
                _,
                __,
              ) =>
                      const SizedBox(
                width:
                    8,
              ),

              itemBuilder:
                  (
                context,
                index,
              ) {
                final image =
                    widget.selectedImages[index];

                return Container(
                  width:
                      92,

                  height:
                      82,

                  decoration:
                      BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(
                      12,
                    ),

                    border:
                        Border.all(
                      color:
                          AppTheme.borderGray,
                    ),
                  ),

                  clipBehavior:
                      Clip.antiAlias,

                  child:
                      Image.file(
                    File(
                      image.path,
                    ),

                    fit:
                        BoxFit.cover,
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ============================================================
  // SCHEDULE
  // ============================================================

  Widget _scheduleCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        14,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7F7),
        borderRadius: BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color: AppTheme.primaryRed,
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.018,
            ),
            blurRadius: 7,
            offset: const Offset(
              0,
              2,
            ),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(
                0.10,
              ),
              borderRadius: BorderRadius.circular(
                12,
              ),
            ),
            child: const Icon(
              Icons.calendar_month_outlined,
              color: AppTheme.primaryRed,
              size: 21,
            ),
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  formattedDate,
                  style: const TextStyle(
                    color: AppTheme.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(
                  height: 5,
                ),

                Text(
                  widget.selectedUrgency,
                  style: const TextStyle(
                    color: AppTheme.primaryRed,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(
                  height: 2,
                ),

                Text(
                  widget.selectedTime,
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 10.5,
                    height: 1.35,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SUMMARY BOX
  // ============================================================

  Widget _summaryBox({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          // ======================================================
          // TITLE
          // ======================================================

          Row(
            children: [
              Container(
                width:
                    34,

                height:
                    34,

                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.black.withOpacity(
                    0.045,
                  ),

                  borderRadius:
                      BorderRadius.circular(
                    10,
                  ),
                ),

                child:
                    Icon(
                  icon,

                  color:
                      AppTheme.primaryRed,

                  size:
                      18,
                ),
              ),

              const SizedBox(
                width:
                    10,
              ),

              Expanded(
                child:
                    Text(
                  title,

                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,

                    fontSize:
                        12.5,

                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height:
                12,
          ),

          ...children,
        ],
      ),
    );
  }

  // ============================================================
  // CHIP
  // ============================================================

  Widget _chip(
    String text,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal:
            10,

        vertical:
            7,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.black.withOpacity(
          0.035,
        ),

        borderRadius:
            BorderRadius.circular(
          9,
        ),

        border:
            Border.all(
          color:
              AppTheme.black.withOpacity(
            0.07,
          ),
        ),
      ),

      child:
          Text(
        text,

        style:
            const TextStyle(
          color:
              AppTheme.black,

          fontSize:
              11,

          fontWeight:
              FontWeight.w700,
        ),
      ),
    );
  }

  // ============================================================
  // PRICE CARD
  // ============================================================

  Widget _priceCard() {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        16,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.02,
            ),

            blurRadius:
                8,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          Row(
        children: [
          Container(
            width:
                44,

            height:
                44,

            decoration:
                BoxDecoration(
              color:
                  AppTheme.primaryRed.withOpacity(
                0.08,
              ),

              borderRadius:
                  BorderRadius.circular(
                12,
              ),
            ),

            child:
                const Icon(
              Icons.payments_outlined,

              color:
                  AppTheme.primaryRed,

              size:
                  21,
            ),
          ),

          const SizedBox(
            width:
                12,
          ),

          const Expanded(
            child:
                Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  'Estimated Total',

                  style:
                      TextStyle(
                    color:
                        AppTheme.gray,

                    fontSize:
                        10.5,

                    fontWeight:
                        FontWeight.w600,
                  ),
                ),

                SizedBox(
                  height:
                      3,
                ),

                Text(
                  'Initial service estimate',

                  style:
                      TextStyle(
                    color:
                        AppTheme.black,

                    fontSize:
                        11,

                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),

          Text(
            '₱${totalPrice.toStringAsFixed(2)}',

            style:
                const TextStyle(
              color:
                  AppTheme.primaryRed,

              fontSize:
                  18,

              fontWeight:
                  FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // IMPORTANT NOTE
  // ============================================================

  Widget _nextStepBox() {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        13,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.black.withOpacity(
          0.035,
        ),

        borderRadius:
            BorderRadius.circular(
          13,
        ),

        border:
            Border.all(
          color:
              AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),

      child:
          Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width:
                30,

            height:
                30,

            decoration:
                BoxDecoration(
              color:
                  AppTheme.black.withOpacity(
                0.06,
              ),

              shape:
                  BoxShape.circle,
            ),

            child:
                const Icon(
              Icons.info_outline_rounded,

              color:
                  AppTheme.primaryRed,

              size:
                  17,
            ),
          ),

          const SizedBox(
            width:
                10,
          ),

          Expanded(
            child:
                Text(
              'The displayed amount is only an estimated price. Final cost may still change after inspection and additional service fees.',

              style:
                  TextStyle(
                color:
                    AppTheme.black.withOpacity(
                  0.72,
                ),

                fontSize:
                    10.5,

                height:
                    1.45,

                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BOTTOM BUTTON
  // ============================================================

  Widget _bottomButton() {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),

      decoration:
          const BoxDecoration(
        color:
            AppTheme.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                AppTheme.borderGray,

            width:
                1,
          ),
        ),
      ),

      child:
          SafeArea(
        top:
            false,

        child:
            SizedBox(
          width:
              double.infinity,

          height:
              48,

          child:
              ElevatedButton(
            onPressed:
                isSubmitting
                    ? null
                    : _submitBooking,

            child:
                isSubmitting
                    ? const SizedBox(
                        width:
                            18,

                        height:
                            18,

                        child:
                            CircularProgressIndicator(
                          strokeWidth:
                              2,

                          color:
                              AppTheme.white,
                        ),
                      )
                    : const Text(
                        'Submit for Approval',
                      ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// MAIN VALUE
// ============================================================

class _MainValue extends StatelessWidget {
  final String text;

  const _MainValue(
    this.text,
  );

  @override
  Widget build(
    BuildContext context,
  ) {
    return Text(
      text,

      style:
          const TextStyle(
        color:
            AppTheme.black,

        fontSize:
            13,

        fontWeight:
            FontWeight.w800,

        height:
            1.35,
      ),
    );
  }
}

// ============================================================
// SUB VALUE
// ============================================================

class _SubValue extends StatelessWidget {
  final String text;

  const _SubValue(
    this.text,
  );

  @override
  Widget build(
    BuildContext context,
  ) {
    return Text(
      text,

      style:
          const TextStyle(
        color:
            AppTheme.gray,

        fontSize:
            11,

        height:
            1.45,

        fontWeight:
            FontWeight.w500,
      ),
    );
  }
}