import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';

class BookingTermiteSqmInputCard extends StatelessWidget {
  final TextEditingController sqmController;
  final Function(String value) onChanged;
  final String? matchedRange;

  const BookingTermiteSqmInputCard({
    super.key,
    required this.sqmController,
    required this.onChanged,
    this.matchedRange,
  });

  @override
  Widget build(BuildContext context) {
    final hasValidInput = matchedRange != null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Property Size',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppTheme.black,
          ),
        ),

        const SizedBox(height: 6),

        const Text(
          'Enter your estimated treatment area size in square meters (sqm). This helps us prepare the right assessment.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.45,
          ),
        ),

        const SizedBox(height: 16),

        TextField(
          controller: sqmController,
          keyboardType: TextInputType.number,
          onChanged: onChanged,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppTheme.black,
          ),
          decoration: InputDecoration(
            hintText: 'Input sqm of area',
            hintStyle: const TextStyle(
              color: AppTheme.gray,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
            suffixText: 'sqm',
            suffixStyle: const TextStyle(
              color: AppTheme.gray,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
            filled: true,
            fillColor: AppTheme.white,

            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),

            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: AppTheme.borderGray,
              ),
            ),

            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: AppTheme.black,
                width: 1.3,
              ),
            ),
          ),
        ),

        const SizedBox(height: 14),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFEFF7FF),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: const Color(0xFFD7EAFB),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(
                  color: Color(0xFF1684C7),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.info_outline,
                  color: AppTheme.white,
                  size: 15,
                ),
              ),

              const SizedBox(width: 10),

              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Good to know',
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 12.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: 4),

                    Text(
                      'Final quotation will be confirmed after inspection and assesssment',
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 11.5,
                        height: 1.35,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}