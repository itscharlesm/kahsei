import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';

import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class BookingScheduleSkeletonLoad extends StatelessWidget {
  const BookingScheduleSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // ============================================================
        // STEP INDICATOR
        // ============================================================

        const BookingStepIndicator(
          currentStep: 3,
        ),

        // ============================================================
        // CONTENT
        // ============================================================

        Expanded(
          child: SingleChildScrollView(
            physics:
                const AlwaysScrollableScrollPhysics(),

            padding:
                const EdgeInsets.fromLTRB(
              20,
              18,
              20,
              24,
            ),

            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: const [
                // ====================================================
                // INTRO CARD
                // ====================================================

                _IntroCardSkeleton(),

                SizedBox(
                  height: 20,
                ),

                // ====================================================
                // PREFERRED DATE LABEL
                // ====================================================

                _SectionLabelSkeleton(
                  width: 105,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // DATE SELECTOR
                // ====================================================

                _DateSelectorSkeleton(),

                SizedBox(
                  height: 20,
                ),

                // ====================================================
                // TIME WINDOW LABEL
                // ====================================================

                _SectionLabelSkeleton(
                  width: 92,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // TIME WINDOWS
                //
                // Each item contains its own 10px bottom spacing
                // to match the actual page.
                // ====================================================

                _TimeWindowSkeletonItem(),
                _TimeWindowSkeletonItem(),
                _TimeWindowSkeletonItem(),

                // ====================================================
                // EXACT SMALL GAP BEFORE NOTE
                // ====================================================

                SizedBox(
                  height: 2,
                ),

                // ====================================================
                // SCHEDULE NOTE
                // ====================================================

                _ScheduleNoteSkeleton(),
              ],
            ),
          ),
        ),

        // ============================================================
        // BOTTOM CONTINUE BUTTON
        // ============================================================

        const _BottomButtonSkeleton(),
      ],
    );
  }
}

// ============================================================
// INTRO CARD
// ============================================================

class _IntroCardSkeleton extends StatelessWidget {
  const _IntroCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        16,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.02,
            ),

            blurRadius:
                8,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // ICON
            // Actual page: 56 x 56
            // ========================================================

            AppSkeletonLine(
              width: 56,
              height: 56,
              radius: 14,
            ),

            SizedBox(
              width: 13,
            ),

            // ========================================================
            // TEXT
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width: 170,
                    height: 15,
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  AppSkeletonLine(
                    width:
                        double.infinity,
                    height: 11,
                  ),

                  SizedBox(
                    height: 5,
                  ),

                  AppSkeletonLine(
                    width: 210,
                    height: 11,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  final double width;

  const _SectionLabelSkeleton({
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left: 2,
      ),

      child:
          AppShimmer(
        child:
            AppSkeletonLine(
          width:
              width,

          height:
              10,
        ),
      ),
    );
  }
}

// ============================================================
// DATE SELECTOR
// ============================================================

class _DateSelectorSkeleton extends StatelessWidget {
  const _DateSelectorSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Row(
          children: [
            // ========================================================
            // CALENDAR ICON
            // Actual: 44 x 44
            // ========================================================

            AppSkeletonLine(
              width: 44,
              height: 44,
              radius: 12,
            ),

            SizedBox(
              width: 12,
            ),

            // ========================================================
            // DATE TEXT
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width: 88,
                    height: 10,
                  ),

                  SizedBox(
                    height: 6,
                  ),

                  AppSkeletonLine(
                    width: 175,
                    height: 13,
                  ),
                ],
              ),
            ),

            SizedBox(
              width: 8,
            ),

            // ========================================================
            // CHEVRON / CHECK
            // ========================================================

            AppSkeletonLine(
              width: 20,
              height: 20,
              radius: 50,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// TIME WINDOW ITEM
// ============================================================

class _TimeWindowSkeletonItem extends StatelessWidget {
  const _TimeWindowSkeletonItem();

  @override
  Widget build(BuildContext context) {
    return Padding(
      // ============================================================
      // EXACTLY LIKE REAL TIME WINDOW CARD
      // ============================================================

      padding:
          const EdgeInsets.only(
        bottom: 10,
      ),

      child:
          Container(
        width:
            double.infinity,

        padding:
            const EdgeInsets.all(
          12,
        ),

        decoration:
            BoxDecoration(
          color:
              AppTheme.white,

          borderRadius:
              BorderRadius.circular(
            14,
          ),

          border:
              Border.all(
            color:
                AppTheme.borderGray,
          ),

          boxShadow: [
            BoxShadow(
              color:
                  Colors.black.withOpacity(
                0.018,
              ),

              blurRadius:
                  7,

              offset:
                  const Offset(
                0,
                2,
              ),
            ),
          ],
        ),

        child:
            const AppShimmer(
          child:
              Row(
            crossAxisAlignment:
                CrossAxisAlignment.center,

            children: [
              // ======================================================
              // RADIO
              // Actual: 20 x 20
              // ======================================================

              AppSkeletonLine(
                width: 20,
                height: 20,
                radius: 50,
              ),

              SizedBox(
                width: 11,
              ),

              // ======================================================
              // TIME ICON
              // Actual: 44 x 44
              // ======================================================

              AppSkeletonLine(
                width: 44,
                height: 44,
                radius: 12,
              ),

              SizedBox(
                width: 11,
              ),

              // ======================================================
              // TIME DETAILS
              // ======================================================

              Expanded(
                child:
                    Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [
                    AppSkeletonLine(
                      width: 88,
                      height: 13,
                    ),

                    SizedBox(
                      height: 6,
                    ),

                    AppSkeletonLine(
                      width: 145,
                      height: 11,
                    ),

                    SizedBox(
                      height: 5,
                    ),

                    AppSkeletonLine(
                      width: 205,
                      height: 10,
                    ),
                  ],
                ),
              ),

              SizedBox(
                width: 8,
              ),

              // ======================================================
              // CHECK / CHEVRON
              // ======================================================

              AppSkeletonLine(
                width: 20,
                height: 20,
                radius: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SCHEDULE NOTE
// ============================================================

class _ScheduleNoteSkeleton extends StatelessWidget {
  const _ScheduleNoteSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        13,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.black.withOpacity(
          0.035,
        ),

        borderRadius:
            BorderRadius.circular(
          13,
        ),

        border:
            Border.all(
          color:
              AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),

      child:
          const AppShimmer(
        child:
            Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ======================================================
            // INFO ICON CONTAINER
            // Actual: 30 x 30
            // ======================================================

            AppSkeletonLine(
              width: 30,
              height: 30,
              radius: 50,
            ),

            SizedBox(
              width: 10,
            ),

            // ======================================================
            // INFO TEXT
            // ======================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width:
                        double.infinity,
                    height: 10,
                  ),

                  SizedBox(
                    height: 5,
                  ),

                  AppSkeletonLine(
                    width: 220,
                    height: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// BOTTOM CONTINUE BUTTON
// ============================================================

class _BottomButtonSkeleton extends StatelessWidget {
  const _BottomButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),

      decoration:
          const BoxDecoration(
        color:
            AppTheme.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                AppTheme.borderGray,

            width:
                1,
          ),
        ),
      ),

      child:
          SafeArea(
        top:
            false,

        child:
            const AppShimmer(
          child:
              AppSkeletonLine(
            width:
                double.infinity,

            height:
                48,

            radius:
                12,
          ),
        ),
      ),
    );
  }
}