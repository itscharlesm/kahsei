import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class BookingProblemSkeletonLoad extends StatelessWidget {
  const BookingProblemSkeletonLoad({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const BookingStepIndicator(currentStep: 2),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _SkeletonSection(
                  titleWidth: 230,
                  subtitleWidth: 210,
                ),
                SizedBox(height: 14),
                _SkeletonCardRow(),

                SizedBox(height: 22),

                _SkeletonSection(
                  titleWidth: 210,
                  subtitleWidth: 260,
                ),
                SizedBox(height: 14),
                _SkeletonCardRow(),

                SizedBox(height: 22),

                _SkeletonSection(
                  titleWidth: 170,
                  subtitleWidth: 280,
                ),
                SizedBox(height: 12),
                _DescriptionSkeleton(),

                SizedBox(height: 22),

                _SkeletonSection(
                  titleWidth: 110,
                  subtitleWidth: 290,
                ),
                SizedBox(height: 14),
                _PhotoSkeletonRow(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SkeletonSection extends StatelessWidget {
  final double titleWidth;
  final double subtitleWidth;

  const _SkeletonSection({
    required this.titleWidth,
    required this.subtitleWidth,
  });

  @override
  Widget build(BuildContext context) {
    return AppShimmer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppSkeletonLine(width: titleWidth, height: 16),
          const SizedBox(height: 6),
          AppSkeletonLine(width: subtitleWidth, height: 12),
        ],
      ),
    );
  }
}

class _SkeletonCardRow extends StatelessWidget {
  const _SkeletonCardRow();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: 4,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          return Opacity(
            opacity: index == 3 ? 0.45 : 1,
            child: const _ProblemOptionSkeletonCard(),
          );
        },
      ),
    );
  }
}

class _ProblemOptionSkeletonCard extends StatelessWidget {
  const _ProblemOptionSkeletonCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppSkeletonLine(
              width: double.infinity,
              height: 110,
              radius: 8,
            ),
            SizedBox(height: 12),
            AppSkeletonLine(width: 72, height: 15),
            SizedBox(height: 8),
            AppSkeletonLine(width: 95, height: 10),
            SizedBox(height: 5),
            AppSkeletonLine(width: 82, height: 10),
            SizedBox(height: 5),
            AppSkeletonLine(width: 65, height: 10),
          ],
        ),
      ),
    );
  }
}

class _DescriptionSkeleton extends StatelessWidget {
  const _DescriptionSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 126,
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppSkeletonLine(width: double.infinity, height: 12),
            SizedBox(height: 8),
            AppSkeletonLine(width: 260, height: 12),
            Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: AppSkeletonLine(width: 45, height: 10),
            ),
          ],
        ),
      ),
    );
  }
}

class _PhotoSkeletonRow extends StatelessWidget {
  const _PhotoSkeletonRow();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 98,
      child: Align(
        alignment: Alignment.centerLeft,
        child: _PhotoSkeletonCard(),
      ),
    );
  }
}

class _PhotoSkeletonCard extends StatelessWidget {
  const _PhotoSkeletonCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 110,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Center(
          child: AppSkeletonLine(
            width: 54,
            height: 54,
            radius: 12,
          ),
        ),
      ),
    );
  }
}