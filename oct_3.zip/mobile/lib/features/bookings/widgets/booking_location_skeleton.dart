import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class BookingLocationSkeletonLoad extends StatelessWidget {
  const BookingLocationSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // ============================================================
        // STEP INDICATOR
        // ============================================================

        const BookingStepIndicator(
          currentStep: 1,
        ),

        // ============================================================
        // CONTENT
        // ============================================================

        Expanded(
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(
              20,
              18,
              20,
              24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                // ====================================================
                // INTRO CARD
                // ====================================================

                _IntroCardSkeleton(),

                SizedBox(height: 20),

                // ====================================================
                // SERVICE ADDRESS LABEL
                // ====================================================

                _SectionLabelSkeleton(),

                SizedBox(height: 10),

                // ====================================================
                // ADDRESS CARDS
                // ====================================================

                _AddressItemSkeleton(),
                _AddressItemSkeleton(),
                _AddressItemSkeleton(),

                // ====================================================
                // GAP BEFORE ADD ADDRESS
                // ====================================================

                SizedBox(height: 2),

                _AddAddressButtonSkeleton(),

                // ====================================================
                // GAP BEFORE INFO
                // ====================================================

                SizedBox(height: 14),

                _SelectedAddressInfoSkeleton(),
              ],
            ),
          ),
        ),

        // ============================================================
        // BOTTOM CONTINUE BUTTON
        // ============================================================

        const _BottomButtonSkeleton(),
      ],
    );
  }
}

// ============================================================
// INTRO CARD
// ============================================================

class _IntroCardSkeleton extends StatelessWidget {
  const _IntroCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        16,
      ),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          16,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.02,
            ),
            blurRadius: 8,
            offset: const Offset(
              0,
              3,
            ),
          ),
        ],
      ),
      child: const AppShimmer(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ========================================================
            // ICON
            // ========================================================

            AppSkeletonLine(
              width: 56,
              height: 56,
              radius: 14,
            ),

            SizedBox(width: 13),

            // ========================================================
            // TEXT
            // ========================================================

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width: 225,
                    height: 15,
                  ),

                  SizedBox(height: 8),

                  AppSkeletonLine(
                    width: double.infinity,
                    height: 11,
                  ),

                  SizedBox(height: 5),

                  AppSkeletonLine(
                    width: 220,
                    height: 11,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  const _SectionLabelSkeleton();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(
        left: 2,
      ),
      child: AppShimmer(
        child: AppSkeletonLine(
          width: 105,
          height: 10,
        ),
      ),
    );
  }
}

// ============================================================
// ADDRESS ITEM
// ============================================================

class _AddressItemSkeleton extends StatelessWidget {
  const _AddressItemSkeleton();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 10,
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(
          12,
        ),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(
            14,
          ),
          border: Border.all(
            color: AppTheme.borderGray,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(
                0.018,
              ),
              blurRadius: 7,
              offset: const Offset(
                0,
                2,
              ),
            ),
          ],
        ),
        child: const AppShimmer(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ======================================================
              // RADIO
              // ======================================================

              AppSkeletonLine(
                width: 20,
                height: 20,
                radius: 50,
              ),

              SizedBox(width: 11),

              // ======================================================
              // ADDRESS ICON
              // ======================================================

              AppSkeletonLine(
                width: 42,
                height: 42,
                radius: 50,
              ),

              SizedBox(width: 11),

              // ======================================================
              // ADDRESS INFO
              // ======================================================

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppSkeletonLine(
                      width: 72,
                      height: 13,
                    ),

                    SizedBox(height: 5),

                    AppSkeletonLine(
                      width: double.infinity,
                      height: 10,
                    ),

                    SizedBox(height: 4),

                    AppSkeletonLine(
                      width: 185,
                      height: 10,
                    ),
                  ],
                ),
              ),

              SizedBox(width: 8),

              // ======================================================
              // CHEVRON / CHECK
              // ======================================================

              AppSkeletonLine(
                width: 20,
                height: 20,
                radius: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ADD NEW ADDRESS BUTTON
// ============================================================

class _AddAddressButtonSkeleton extends StatelessWidget {
  const _AddAddressButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 48,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(
          13,
        ),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      alignment: Alignment.center,
      child: const AppShimmer(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppSkeletonLine(
              width: 20,
              height: 20,
              radius: 50,
            ),

            SizedBox(width: 7),

            AppSkeletonLine(
              width: 118,
              height: 12,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SELECTED ADDRESS INFO
// ============================================================

class _SelectedAddressInfoSkeleton extends StatelessWidget {
  const _SelectedAddressInfoSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(
        13,
      ),
      decoration: BoxDecoration(
        // ========================================================
        // NEUTRAL INFO CONTAINER
        // Matches newer Location / Schedule / Review pages
        // ========================================================

        color: AppTheme.black.withOpacity(
          0.035,
        ),
        borderRadius: BorderRadius.circular(
          13,
        ),
        border: Border.all(
          color: AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),
      child: const AppShimmer(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ======================================================
            // INFO ICON
            // Actual UI: 30 x 30 neutral circle
            // ======================================================

            AppSkeletonLine(
              width: 30,
              height: 30,
              radius: 50,
            ),

            SizedBox(width: 10),

            // ======================================================
            // INFO TEXT
            // ======================================================

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(
                    width: double.infinity,
                    height: 10,
                  ),

                  SizedBox(height: 5),

                  AppSkeletonLine(
                    width: 225,
                    height: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// BOTTOM CONTINUE BUTTON
// ============================================================

class _BottomButtonSkeleton extends StatelessWidget {
  const _BottomButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(
          top: BorderSide(
            color: AppTheme.borderGray,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: const AppShimmer(
          child: AppSkeletonLine(
            width: double.infinity,
            height: 48,
            radius: 12,
          ),
        ),
      ),
    );
  }
}