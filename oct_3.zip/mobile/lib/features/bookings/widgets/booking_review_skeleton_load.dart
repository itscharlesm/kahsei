import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/bookings/widgets/booking_step_indicator.dart';

import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class BookingReviewSkeletonLoad extends StatelessWidget {
  const BookingReviewSkeletonLoad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // ============================================================
        // STEP INDICATOR
        // ============================================================

        const BookingStepIndicator(
          currentStep: 4,
        ),

        // ============================================================
        // CONTENT
        // ============================================================

        Expanded(
          child: SingleChildScrollView(
            physics:
                const AlwaysScrollableScrollPhysics(),

            padding:
                const EdgeInsets.fromLTRB(
              20,
              18,
              20,
              24,
            ),

            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: const [
                // ====================================================
                // INTRO
                // ====================================================

                _IntroCardSkeleton(),

                SizedBox(
                  height: 20,
                ),

                // ====================================================
                // BOOKING DETAILS
                // ====================================================

                _SectionLabelSkeleton(
                  width: 110,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // SERVICE LOCATION
                // ====================================================

                _SummaryBoxSkeleton(
                  titleWidth: 105,
                  mainWidth: 70,
                  subWidth: double.infinity,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // PEST PROBLEM
                // ====================================================

                _ChipSummaryBoxSkeleton(
                  titleWidth: 90,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // AREAS / TERMITE
                // ====================================================

                _ChipSummaryBoxSkeleton(
                  titleWidth: 95,
                ),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // DESCRIPTION
                // ====================================================

                _DescriptionSummarySkeleton(),

                SizedBox(
                  height: 10,
                ),

                // ====================================================
                // PHOTOS
                // ====================================================

                _PhotosSummaryBoxSkeleton(),

                SizedBox(
                  height: 20,
                ),

                // ====================================================
                // SERVICE SCHEDULE
                // ====================================================

                _SectionLabelSkeleton(
                  width: 115,
                ),

                SizedBox(
                  height: 10,
                ),

                _ScheduleCardSkeleton(),

                SizedBox(
                  height: 20,
                ),

                // ====================================================
                // ESTIMATED PRICE
                // ====================================================

                _SectionLabelSkeleton(
                  width: 105,
                ),

                SizedBox(
                  height: 10,
                ),

                _PriceCardSkeleton(),

                SizedBox(
                  height: 14,
                ),

                // ====================================================
                // IMPORTANT NOTE
                // ====================================================

                _NextStepBoxSkeleton(),
              ],
            ),
          ),
        ),

        // ============================================================
        // SUBMIT BUTTON
        // ============================================================

        const _BottomButtonSkeleton(),
      ],
    );
  }
}

// ============================================================
// INTRO CARD
// ============================================================

class _IntroCardSkeleton extends StatelessWidget {
  const _IntroCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        16,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.02,
            ),

            blurRadius:
                8,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // ICON
            // ========================================================

            AppSkeletonLine(
              width: 56,
              height: 56,
              radius: 14,
            ),

            SizedBox(
              width: 13,
            ),

            // ========================================================
            // TEXT
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width: 165,
                    height: 15,
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  AppSkeletonLine(
                    width:
                        double.infinity,
                    height: 11,
                  ),

                  SizedBox(
                    height: 5,
                  ),

                  AppSkeletonLine(
                    width: 230,
                    height: 11,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SECTION LABEL
// ============================================================

class _SectionLabelSkeleton extends StatelessWidget {
  final double width;

  const _SectionLabelSkeleton({
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left: 2,
      ),

      child:
          AppShimmer(
        child:
            AppSkeletonLine(
          width:
              width,

          height:
              10,
        ),
      ),
    );
  }
}

// ============================================================
// NORMAL SUMMARY BOX
// ============================================================

class _SummaryBoxSkeleton extends StatelessWidget {
  final double titleWidth;
  final double mainWidth;
  final double subWidth;

  const _SummaryBoxSkeleton({
    required this.titleWidth,
    required this.mainWidth,
    required this.subWidth,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          AppShimmer(
        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // HEADER
            // ========================================================

            Row(
              children: [
                const AppSkeletonLine(
                  width: 34,
                  height: 34,
                  radius: 10,
                ),

                const SizedBox(
                  width: 10,
                ),

                AppSkeletonLine(
                  width:
                      titleWidth,

                  height:
                      12,
                ),
              ],
            ),

            const SizedBox(
              height: 12,
            ),

            // ========================================================
            // MAIN VALUE
            // ========================================================

            AppSkeletonLine(
              width:
                  mainWidth,

              height:
                  13,
            ),

            const SizedBox(
              height: 6,
            ),

            // ========================================================
            // SUB VALUE
            // ========================================================

            AppSkeletonLine(
              width:
                  subWidth,

              height:
                  11,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// CHIP SUMMARY BOX
// ============================================================

class _ChipSummaryBoxSkeleton extends StatelessWidget {
  final double titleWidth;

  const _ChipSummaryBoxSkeleton({
    required this.titleWidth,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          AppShimmer(
        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // HEADER
            // ========================================================

            Row(
              children: [
                const AppSkeletonLine(
                  width: 34,
                  height: 34,
                  radius: 10,
                ),

                const SizedBox(
                  width: 10,
                ),

                AppSkeletonLine(
                  width:
                      titleWidth,

                  height:
                      12,
                ),
              ],
            ),

            const SizedBox(
              height: 12,
            ),

            // ========================================================
            // CHIPS
            // ========================================================

            const Wrap(
              spacing:
                  7,

              runSpacing:
                  7,

              children: [
                AppSkeletonLine(
                  width: 82,
                  height: 29,
                  radius: 9,
                ),

                AppSkeletonLine(
                  width: 105,
                  height: 29,
                  radius: 9,
                ),

                AppSkeletonLine(
                  width: 76,
                  height: 29,
                  radius: 9,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// DESCRIPTION SUMMARY
// ============================================================

class _DescriptionSummarySkeleton
    extends StatelessWidget {
  const _DescriptionSummarySkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            Row(
              children: [
                AppSkeletonLine(
                  width: 34,
                  height: 34,
                  radius: 10,
                ),

                SizedBox(
                  width: 10,
                ),

                AppSkeletonLine(
                  width: 125,
                  height: 12,
                ),
              ],
            ),

            SizedBox(
              height: 12,
            ),

            AppSkeletonLine(
              width:
                  double.infinity,
              height: 11,
            ),

            SizedBox(
              height: 5,
            ),

            AppSkeletonLine(
              width: 250,
              height: 11,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// PHOTOS SUMMARY
// ============================================================

class _PhotosSummaryBoxSkeleton
    extends StatelessWidget {
  const _PhotosSummaryBoxSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // HEADER
            // ========================================================

            Row(
              children: [
                AppSkeletonLine(
                  width: 34,
                  height: 34,
                  radius: 10,
                ),

                SizedBox(
                  width: 10,
                ),

                AppSkeletonLine(
                  width: 105,
                  height: 12,
                ),
              ],
            ),

            SizedBox(
              height: 12,
            ),

            // ========================================================
            // PHOTOS
            // ========================================================

            SizedBox(
              height: 82,

              child:
                  Row(
                children: [
                  AppSkeletonLine(
                    width: 92,
                    height: 82,
                    radius: 12,
                  ),

                  SizedBox(
                    width: 8,
                  ),

                  AppSkeletonLine(
                    width: 92,
                    height: 82,
                    radius: 12,
                  ),

                  SizedBox(
                    width: 8,
                  ),

                  AppSkeletonLine(
                    width: 92,
                    height: 82,
                    radius: 12,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SCHEDULE CARD
// ============================================================

class _ScheduleCardSkeleton extends StatelessWidget {
  const _ScheduleCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        14,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          14,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.018,
            ),

            blurRadius:
                7,

            offset:
                const Offset(
              0,
              2,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Row(
          crossAxisAlignment:
              CrossAxisAlignment.center,

          children: [
            // ========================================================
            // CALENDAR ICON
            // ========================================================

            AppSkeletonLine(
              width: 44,
              height: 44,
              radius: 12,
            ),

            SizedBox(
              width: 12,
            ),

            // ========================================================
            // DATE + TIME
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width: 150,
                    height: 13,
                  ),

                  SizedBox(
                    height: 6,
                  ),

                  AppSkeletonLine(
                    width: 190,
                    height: 10,
                  ),
                ],
              ),
            ),

            SizedBox(
              width: 8,
            ),

            AppSkeletonLine(
              width: 20,
              height: 20,
              radius: 50,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// PRICE CARD
// ============================================================

class _PriceCardSkeleton extends StatelessWidget {
  const _PriceCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        16,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.white,

        borderRadius:
            BorderRadius.circular(
          16,
        ),

        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),

        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              0.02,
            ),

            blurRadius:
                8,

            offset:
                const Offset(
              0,
              3,
            ),
          ),
        ],
      ),

      child:
          const AppShimmer(
        child:
            Row(
          children: [
            // ========================================================
            // PRICE ICON
            // ========================================================

            AppSkeletonLine(
              width: 44,
              height: 44,
              radius: 12,
            ),

            SizedBox(
              width: 12,
            ),

            // ========================================================
            // LABEL
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width: 95,
                    height: 10,
                  ),

                  SizedBox(
                    height: 6,
                  ),

                  AppSkeletonLine(
                    width: 135,
                    height: 11,
                  ),
                ],
              ),
            ),

            // ========================================================
            // AMOUNT
            // ========================================================

            AppSkeletonLine(
              width: 92,
              height: 18,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// IMPORTANT NOTE
// ============================================================

class _NextStepBoxSkeleton extends StatelessWidget {
  const _NextStepBoxSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width:
          double.infinity,

      padding:
          const EdgeInsets.all(
        13,
      ),

      decoration:
          BoxDecoration(
        color:
            AppTheme.black.withOpacity(
          0.035,
        ),

        borderRadius:
            BorderRadius.circular(
          13,
        ),

        border:
            Border.all(
          color:
              AppTheme.black.withOpacity(
            0.06,
          ),
        ),
      ),

      child:
          const AppShimmer(
        child:
            Row(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ========================================================
            // INFO ICON
            // ========================================================

            AppSkeletonLine(
              width: 30,
              height: 30,
              radius: 50,
            ),

            SizedBox(
              width: 10,
            ),

            // ========================================================
            // TEXT
            // ========================================================

            Expanded(
              child:
                  Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [
                  AppSkeletonLine(
                    width:
                        double.infinity,
                    height: 10,
                  ),

                  SizedBox(
                    height: 5,
                  ),

                  AppSkeletonLine(
                    width:
                        double.infinity,
                    height: 10,
                  ),

                  SizedBox(
                    height: 5,
                  ),

                  AppSkeletonLine(
                    width: 200,
                    height: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// BOTTOM SUBMIT BUTTON
// ============================================================

class _BottomButtonSkeleton extends StatelessWidget {
  const _BottomButtonSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        12,
        20,
        16,
      ),

      decoration:
          const BoxDecoration(
        color:
            AppTheme.white,

        border:
            Border(
          top:
              BorderSide(
            color:
                AppTheme.borderGray,

            width:
                1,
          ),
        ),
      ),

      child:
          SafeArea(
        top:
            false,

        child:
            const AppShimmer(
          child:
              AppSkeletonLine(
            width:
                double.infinity,

            height:
                48,

            radius:
                12,
          ),
        ),
      ),
    );
  }
}