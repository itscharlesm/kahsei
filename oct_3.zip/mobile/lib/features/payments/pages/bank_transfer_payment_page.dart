import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/features/payments/widgets/payment_success_dialog.dart';
import 'package:mobile_app/shared/shared.dart';

class BankTransferPaymentPage extends StatefulWidget {
  final Map<String, dynamic> appointment;

  const BankTransferPaymentPage({
    super.key,
    required this.appointment,
  });

  @override
  State<BankTransferPaymentPage> createState() =>
      _BankTransferPaymentPageState();
}

class _BankTransferPaymentPageState
    extends State<BankTransferPaymentPage> {
  final TextEditingController referenceController =
      TextEditingController();

  final TextEditingController detailsController =
      TextEditingController();

  final ImagePicker _imagePicker = ImagePicker();

  XFile? proofImage;
  bool isSubmitting = false;

  @override
  void dispose() {
    referenceController.dispose();
    detailsController.dispose();
    super.dispose();
  }

  String _text(dynamic value, [String fallback = '']) {
    if (value == null) return fallback;

    final text = value.toString().trim();

    return text.isEmpty ? fallback : text;
  }

  double _amountValue() {
    final rawPrice = _text(
      widget.appointment['price'],
      '0',
    )
        .replaceAll('₱', '')
        .replaceAll(',', '');

    return double.tryParse(rawPrice) ?? 0;
  }

  String _amountDisplay() {
    return _text(
      widget.appointment['price'],
      '₱0.00',
    );
  }

  int? _serviceId() {
    final value =
        widget.appointment['svc_id'] ??
        widget.appointment['service_id'];

    if (value == null) return null;

    return int.tryParse(value.toString());
  }

  Future<void> _pickProofFromGallery() async {
    final image = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );

    if (image == null) return;

    setState(() {
      proofImage = image;
    });
  }

  void _removeProofImage() {
    setState(() {
      proofImage = null;
    });
  }

  Future<void> _submitBankTransferPayment() async {
    if (isSubmitting) return;

    final svcId = _serviceId();
    final amount = _amountValue();
    final referenceNumber =
        referenceController.text.trim();
    final paymentDetails =
        detailsController.text.trim();

    if (svcId == null) {
      _showMessage(
        'Unable to submit payment. Missing service ID.',
      );
      return;
    }

    if (amount <= 0) {
      _showMessage(
        'Unable to submit payment. Invalid payment amount.',
      );
      return;
    }

    if (referenceNumber.isEmpty) {
      _showMessage(
        'Please enter the transfer reference number.',
      );
      return;
    }

    if (proofImage == null) {
      _showMessage(
        'Please upload your bank transfer receipt.',
      );
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/payments/bank-transfer/submit',
        ),
      );

      request.headers.addAll({
        'Accept': 'application/json',
      });

      request.fields['svc_id'] =
          svcId.toString();

      request.fields['spay_amount'] =
          amount.toString();

      request.fields['spay_reference_number'] =
          referenceNumber;

      request.fields['spay_details'] =
          paymentDetails;

      request.files.add(
        await http.MultipartFile.fromPath(
          'spay_image_proof',
          proofImage!.path,
        ),
      );

      final streamedResponse =
          await request.send();

      final response =
          await http.Response.fromStream(
        streamedResponse,
      );

      debugPrint(
        'BANK TRANSFER STATUS: ${response.statusCode}',
      );

      debugPrint(
        'BANK TRANSFER BODY: ${response.body}',
      );

      Map<String, dynamic> data;

      try {
        data = jsonDecode(response.body)
            as Map<String, dynamic>;
      } catch (_) {
        _showMessage(
          'The server returned an invalid response.',
        );
        return;
      }

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        PaymentSuccessDialog.show(
          context,
          title: 'Bank Transfer Submitted',
          message:
              'Your bank transfer payment has been submitted and is awaiting verification.',
          buttonText: 'Back to Appointments',
          onPressed: () {
            Navigator.of(context).pop();
            Navigator.of(context).pop(true);
          },
        );

        return;
      }

      if (response.statusCode == 422) {
        final errors = data['errors'];

        if (errors is Map &&
            errors.isNotEmpty) {
          final firstError =
              errors.values.first;

          if (firstError is List &&
              firstError.isNotEmpty) {
            _showMessage(
              firstError.first.toString(),
            );
            return;
          }
        }
      }

      _showMessage(
        data['message'] ??
            'Unable to submit bank transfer payment.',
      );
    } catch (e) {
      debugPrint(
        'Submit bank transfer error: $e',
      );

      if (!mounted) return;

      _showMessage(
        'Unable to submit payment. Please check your connection and try again.',
      );
    } finally {
      if (mounted) {
        setState(() {
          isSubmitting = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final amountDue = _amountDisplay();

    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: const AppBackHeader(
        title: 'Bank Transfer',
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                20,
                18,
                20,
                24,
              ),
              child: Column(
                children: [
                  _AmountDueCard(
                    amount: amountDue,
                  ),
                  const SizedBox(height: 14),
                  const _BankTransferInstructionCard(),
                  const SizedBox(height: 14),
                  _ReferenceNumberField(
                    controller:
                        referenceController,
                  ),
                  const SizedBox(height: 14),
                  _UploadProofCard(
                    image: proofImage,
                    onTap:
                        _pickProofFromGallery,
                    onRemove:
                        _removeProofImage,
                  ),
                  const SizedBox(height: 14),
                  _PaymentDetailsCard(
                    controller:
                        detailsController,
                  ),
                  const SizedBox(height: 14),
                  const _PaymentStatusNote(),
                ],
              ),
            ),
          ),
          _bottomButton(),
        ],
      ),
    );
  }

  Widget _bottomButton() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        20,
        14,
        20,
        20,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(
          top: BorderSide(
            color: AppTheme.borderGray,
            width: 1,
          ),
        ),
      ),
      child: ElevatedButton(
        onPressed: isSubmitting
            ? null
            : _submitBankTransferPayment,
        child: Text(
          isSubmitting
              ? 'Submitting...'
              : 'Submit Bank Transfer',
        ),
      ),
    );
  }
}

class _AmountDueCard extends StatelessWidget {
  final String amount;

  const _AmountDueCard({
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'AMOUNT DUE',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.6,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            amount,
            style: const TextStyle(
              color: AppTheme.primaryRed,
              fontSize: 28,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Remaining balance for your completed service.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11.5,
              height: 1.3,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _BankTransferInstructionCard
    extends StatelessWidget {
  const _BankTransferInstructionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: const Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.account_balance_outlined,
            color: AppTheme.primaryRed,
            size: 24,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Bank Transfer Payment',
                  style: TextStyle(
                    color: AppTheme.black,
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Enter your transfer reference number and upload a clear screenshot of your bank transfer receipt for verification.',
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 12,
                    height: 1.35,
                    fontWeight:
                        FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReferenceNumberField
    extends StatelessWidget {
  final TextEditingController controller;

  const _ReferenceNumberField({
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          prefixIcon: const Icon(
            Icons.numbers_rounded,
            color: AppTheme.primaryRed,
            size: 21,
          ),
          labelText:
              'Transfer Reference Number',
          hintText:
              'Enter transaction reference number',
          filled: true,
          fillColor:
              AppTheme.lightGray.withOpacity(
            0.45,
          ),
          labelStyle: const TextStyle(
            color: AppTheme.gray,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
          hintStyle: const TextStyle(
            color: AppTheme.gray,
            fontSize: 12,
          ),
          enabledBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: AppTheme.borderGray,
            ),
          ),
          focusedBorder:
              OutlineInputBorder(
            borderRadius:
                BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: AppTheme.primaryRed,
              width: 1.2,
            ),
          ),
        ),
      ),
    );
  }
}

class _UploadProofCard
    extends StatelessWidget {
  final XFile? image;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _UploadProofCard({
    required this.image,
    required this.onTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final hasImage = image != null;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.image_outlined,
                color: AppTheme.primaryRed,
                size: 20,
              ),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Bank Transfer Receipt',
                  style: TextStyle(
                    color: AppTheme.black,
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          const Text(
            'Upload a clear screenshot of your completed bank transfer.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11.5,
              height: 1.3,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 14),
          if (hasImage)
            Stack(
              children: [
                Center(
                  child: ClipRRect(
                    borderRadius:
                        BorderRadius.circular(
                      14,
                    ),
                    child: SizedBox(
                      width: 170,
                      child: AspectRatio(
                        aspectRatio: 9 / 16,
                        child: Image.file(
                          File(image!.path),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: onRemove,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration:
                          BoxDecoration(
                        color: Colors.black
                            .withOpacity(0.65),
                        shape:
                            BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.close_rounded,
                        color: AppTheme.white,
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ],
            )
          else
            InkWell(
              borderRadius:
                  BorderRadius.circular(14),
              onTap: onTap,
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(
                  vertical: 24,
                  horizontal: 14,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.lightGray
                      .withOpacity(0.45),
                  borderRadius:
                      BorderRadius.circular(
                    14,
                  ),
                  border: Border.all(
                    color:
                        AppTheme.borderGray,
                  ),
                ),
                child: const Column(
                  children: [
                    Icon(
                      Icons
                          .cloud_upload_outlined,
                      color:
                          AppTheme.primaryRed,
                      size: 38,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Tap to Upload Receipt',
                      style: TextStyle(
                        color: AppTheme.black,
                        fontSize: 13,
                        fontWeight:
                            FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Accepted: JPG, PNG, or WEBP',
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11,
                        fontWeight:
                            FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _PaymentDetailsCard
    extends StatelessWidget {
  final TextEditingController controller;

  const _PaymentDetailsCard({
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius:
            BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              _SoftIcon(
                Icons.notes_outlined,
              ),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Payment Details (Optional)',
                  style: TextStyle(
                    color: AppTheme.black,
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Stack(
            children: [
              TextField(
                controller: controller,
                textAlignVertical:
                    TextAlignVertical.top,
                maxLines: 4,
                maxLength: 250,
                decoration:
                    InputDecoration(
                  hintText:
                      'Add bank name or other transfer details...',
                  hintStyle:
                      const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 12,
                  ),
                  counterText: '',
                  filled: true,
                  fillColor:
                      AppTheme.lightGray
                          .withOpacity(0.35),
                  contentPadding:
                      const EdgeInsets
                          .fromLTRB(
                    14,
                    14,
                    14,
                    34,
                  ),
                  enabledBorder:
                      OutlineInputBorder(
                    borderRadius:
                        BorderRadius
                            .circular(14),
                    borderSide:
                        const BorderSide(
                      color: AppTheme
                          .borderGray,
                    ),
                  ),
                  focusedBorder:
                      OutlineInputBorder(
                    borderRadius:
                        BorderRadius
                            .circular(14),
                    borderSide:
                        BorderSide(
                      color: Colors.black
                          .withOpacity(0.18),
                      width: 1.2,
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 12,
                bottom: 10,
                child: AnimatedBuilder(
                  animation: controller,
                  builder: (_, __) {
                    return Text(
                      '${controller.text.length}/250',
                      style:
                          const TextStyle(
                        color:
                            AppTheme.gray,
                        fontSize: 11,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PaymentStatusNote
    extends StatelessWidget {
  const _PaymentStatusNote();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed
            .withOpacity(0.06),
        borderRadius:
            BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.primaryRed
              .withOpacity(0.18),
        ),
      ),
      child: const Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline_rounded,
            color: AppTheme.primaryRed,
            size: 20,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Your payment request will remain For Approval until the transfer details and receipt have been verified.',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 11.5,
                height: 1.35,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SoftIcon extends StatelessWidget {
  final IconData icon;

  const _SoftIcon(this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppTheme.primaryRed
            .withOpacity(0.08),
        borderRadius:
            BorderRadius.circular(10),
      ),
      child: Icon(
        icon,
        color: AppTheme.primaryRed,
        size: 19,
      ),
    );
  }
}