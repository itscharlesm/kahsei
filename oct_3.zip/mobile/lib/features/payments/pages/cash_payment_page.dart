  import 'dart:convert';
  import 'package:flutter/material.dart';
  import 'package:http/http.dart' as http;
  import 'package:mobile_app/app/theme.dart';
  import 'package:mobile_app/config/api_config.dart';
  import 'package:mobile_app/shared/shared.dart';
  import 'package:mobile_app/features/payments/widgets/payment_success_dialog.dart';

  class CashPaymentPage extends StatefulWidget {
    final Map<String, dynamic> appointment;

    const CashPaymentPage({
      super.key,
      required this.appointment,
    });

    @override
    State<CashPaymentPage> createState() => _CashPaymentPageState();
  }

  class _CashPaymentPageState extends State<CashPaymentPage> {
    bool isSubmitting = false;

    final TextEditingController detailsController = TextEditingController();

    String _text(dynamic value, [String fallback = '']) {
      if (value == null) return fallback;
      final text = value.toString().trim();
      return text.isEmpty ? fallback : text;
    }

    double _amountValue() {
      final rawPrice = _text(widget.appointment['price'], '0')
          .replaceAll('₱', '')
          .replaceAll(',', '');

      return double.tryParse(rawPrice) ?? 0;
    }

    String _amountDisplay() {
      return _text(widget.appointment['price'], '₱0.00');
    }

    int? _serviceId() {
      final value = widget.appointment['svc_id'] ?? widget.appointment['service_id'];
      return int.tryParse(value.toString());
    }

    Future<void> _submitCashPayment() async {
      if (isSubmitting) return;

      final svcId = _serviceId();
      final amount = _amountValue();

      if (svcId == null || amount <= 0) {
        _showMessage('Unable to submit payment. Missing payment details.');
        return;
      }

      setState(() {
        isSubmitting = true;
      });

      try {
        final response = await http.post(
          Uri.parse('${ApiConfig.baseUrl}/api/mobile/payments/cash/submit'),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode({
            'svc_id': svcId,
            'spay_amount': amount,
            'spay_details': detailsController.text.trim(),
          }),
        );

        final data = jsonDecode(response.body);

        if (!mounted) return;

        if (data['success'] == true) {
          PaymentSuccessDialog.show(
            context,
            title: 'Collection Request Submitted',
            message: 'Your cash collection request has been submitted. A company representative will contact you to arrange payment.',
            buttonText: 'Back to Appointments',
            onPressed: () {
              Navigator.pop(context, true);
            },
          );
        } else {
          _showMessage(data['message'] ?? 'Unable to submit payment.');
        }
      } catch (e) {
        if (!mounted) return;
        _showMessage('Unable to submit payment. Please try again.');
      } finally {
        if (mounted) {
          setState(() {
            isSubmitting = false;
          });
        }
      }
    }

    void _showMessage(String message) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
    
    @override
    void dispose() {
      detailsController.dispose();
      super.dispose();
    }

    @override
    Widget build(BuildContext context) {
      final amountDue = _amountDisplay();

      return Scaffold(
        backgroundColor: AppTheme.lightGray,
        appBar: const AppBackHeader(
          title: 'Cash Payment',
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
                child: Column(
                  children: [
                    _AmountDueCard(
                      amount: amountDue,
                    ),
                    const SizedBox(height: 14),
                    const _CashInstructionCard(),
                    const SizedBox(height: 14),
                    _PaymentDetailsCard(
                      controller: detailsController,
                    ),
                    const SizedBox(height: 14),
                    const _PaymentStatusNote(),
                  ],
                ),
              ),
            ),
            _bottomButton(),
          ],
        ),
      );
    }

    Widget _bottomButton() {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        decoration: const BoxDecoration(
          color: AppTheme.white,
          border: Border(
            top: BorderSide(
              color: AppTheme.borderGray,
              width: 1,
            ),
          ),
        ),
        child: ElevatedButton(
          onPressed: isSubmitting ? null : _submitCashPayment,
          child: Text(
            isSubmitting
                ? 'Submitting...'
                : 'Submit Collection Request',
          ),
        ),
      );
    }
  }

  class _AmountDueCard extends StatelessWidget {
    final String amount;

    const _AmountDueCard({
      required this.amount,
    });

    @override
    Widget build(BuildContext context) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.borderGray),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'AMOUNT DUE',
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              amount,
              style: const TextStyle(
                color: AppTheme.primaryRed,
                fontSize: 28,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Remaining balance for your completed service.',
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 11.5,
                height: 1.3,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }
  }

  class _CashInstructionCard extends StatelessWidget {
    const _CashInstructionCard();

    @override
    Widget build(BuildContext context) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.borderGray),
        ),
        child: const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              Icons.local_shipping_outlined,
              color: AppTheme.primaryRed,
              size: 24,
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Cash Collection',
                    style: TextStyle(
                      color: AppTheme.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'A company representative will collect your cash payment. Once received, your payment will be reviewed and processed.',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 12,
                      height: 1.35,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }

  class _PaymentStatusNote extends StatelessWidget {
    const _PaymentStatusNote();

    @override
    Widget build(BuildContext context) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: AppTheme.primaryRed.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.primaryRed.withOpacity(0.18),
          ),
        ),
        child: const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              Icons.info_outline_rounded,
              color: AppTheme.primaryRed,
              size: 20,
            ),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Your request will be marked as For Approval until a company representative collects and verifies your payment.',
                style: TextStyle(
                  color: AppTheme.black,
                  fontSize: 11.5,
                  height: 1.35,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

  class _InfoRow extends StatelessWidget {
    final IconData icon;
    final String title;
    final String value;

    const _InfoRow({
      required this.icon,
      required this.title,
      required this.value,
    });

    @override
    Widget build(BuildContext context) {
      return Row(
        children: [
          Icon(icon, color: AppTheme.gray, size: 16),
          const SizedBox(width: 8),
          Text(
            '$title: ',
            style: const TextStyle(
              color: AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: AppTheme.black,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      );
    }
  }

 class _PaymentDetailsCard extends StatelessWidget {
  final TextEditingController controller;

  const _PaymentDetailsCard({
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              _SoftIcon(Icons.notes_outlined),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Payment Details (Optional)',
                  style: TextStyle(
                    color: AppTheme.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Stack(
            children: [
              TextField(
                controller: controller,
                textAlignVertical: TextAlignVertical.top,
                maxLines: 4,
                maxLength: 250,
                decoration: InputDecoration(
                  hintText: 'Add collection instructions (optional)...',
                  hintStyle: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 12,
                  ),
                  counterText: '',
                  filled: true,
                  fillColor: AppTheme.lightGray.withOpacity(0.35),
                  contentPadding: const EdgeInsets.fromLTRB(14, 14, 14, 34),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: AppTheme.borderGray),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(
                      color: Colors.black.withOpacity(0.18),
                      width: 1.2,
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 12,
                bottom: 10,
                child: AnimatedBuilder(
                  animation: controller,
                  builder: (_, __) {
                    return Text(
                      '${controller.text.length}/250',
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SoftIcon extends StatelessWidget {
  final IconData icon;

  const _SoftIcon(this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppTheme.primaryRed.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(
        icon,
        color: AppTheme.primaryRed,
        size: 19,
      ),
    );
  }
}