import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_success_dialog.dart';

class PaymentSuccessDialog {
  static void show(
    BuildContext context, {
    required String title,
    required String message,
    String buttonText = 'Done',
    VoidCallback? onPressed,
    IconData icon = Icons.check_circle_rounded,
    Color iconColor = Colors.green,
    Color buttonColor = AppTheme.primaryRed,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return AppSuccessDialog(
          icon: icon,
          title: title,
          message: message,
          buttonText: buttonText,
          onPressed: onPressed,
          iconColor: iconColor,
          buttonColor: buttonColor,
        );
      },
    );
  }
}