import 'dart:typed_data';
import 'dart:ui';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:mobile_app/config/api_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/client_tracking/widgets/client_tracking_info_sheet.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:mobile_app/shared/widgets/dialogs/app_success_dialog.dart';
import 'package:mobile_app/shared/widgets/dialogs/app_success_confetti_dialog.dart';
import 'package:mobile_app/features/appointments/pages/client_completed_appointments_page.dart';
import 'package:mobile_app/features/appointments/pages/client_appointments_menu_page.dart';

class ClientTrackingPage extends StatefulWidget {
  final Map<String, dynamic> job;
  final String email;

  const ClientTrackingPage({
    super.key,
    required this.job,
    required this.email,
  });

  @override
  State<ClientTrackingPage> createState() => _ClientTrackingPageState();
}

class _ClientTrackingPageState extends State<ClientTrackingPage> {
  bool isMapReady = false;
  bool isPageDisposed = false;
  bool branchReady = false;
  bool clientReady = false;
  bool technicianReady = false;
  bool routeReady = false;
  bool usedFallbackRoute = false;
  bool hasRedirectedAfterCompletion = false;
  bool hasShownArrivedDialog = false;
  bool hasShownCompletedDialog = false;

  Timer? trackingTimer;
  String? lastRouteGeometry;
  String? trackingMapError;

  MapboxMap? mapboxMap;
  PointAnnotationManager? markerManager;

  PointAnnotation? clientMarker;
  PointAnnotation? branchMarker;
  PointAnnotation? technicianMarker;

  PolylineAnnotationManager? routeLineManager;
  PolylineAnnotation? routeLine;

  List<Position> fullRouteCoordinates = [];

  static const String branchPinAsset = 'assets/images/img_go_pin.png';
  static const String clientPinAsset = 'assets/images/img_client_pin.png';
  static const String technicianPinAsset = 'assets/images/img_technician_pin.png';
  
  static const double branchPinSize = 0.16;
  static const double clientPinSize = 0.16;
  static const double technicianPinSize = 0.27;
  static const int initialMapSetupMaxAttempts = 3;

  String etaText = 'Calculating';

  String trackingStatus = 'ONGOING';
  
 @override
  void initState() {
    super.initState();

    trackingStatus =
        widget.job['status']
            ?.toString()
            .trim()
            .toUpperCase() ??
        'ONGOING';
  }
  
  double? _toDouble(dynamic value) {
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  double _distanceBetweenCoordinates({
    required double lat1,
    required double lng1,
    required double lat2,
    required double lng2,
  }) {
    return geo.Geolocator.distanceBetween(
      lat1,
      lng1,
      lat2,
      lng2,
    );
  }

  Future<void> _showStatusDialog({
    required String title,
    required String message,
    required IconData icon,
    Duration autoDismissDuration =
        const Duration(seconds: 5),
    VoidCallback? onDismissed,
    bool showConfetti = false,
  }) async {
    if (!mounted) return;

    bool dialogOpen = true;

    // ============================================================
    // AUTO DISMISS
    // ============================================================

    Future.delayed(
      autoDismissDuration,
      () {
        if (dialogOpen && mounted) {
          Navigator.of(
            context,
            rootNavigator: true,
          ).maybePop();
        }
      },
    );

    // ============================================================
    // SHARED SUCCESS DIALOG
    // ============================================================

    await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        if (showConfetti) {
          return AppSuccessConfettiDialog(
            icon: icon,
            title: title,
            message: message,
            buttonText: 'OK',
            iconColor: AppTheme.primaryRed,
            buttonColor: AppTheme.primaryRed,
          );
        }

        return AppSuccessDialog(
          icon: icon,
          title: title,
          message: message,
          buttonText: 'OK',
          iconColor: AppTheme.primaryRed,
          buttonColor: AppTheme.primaryRed,
        );
      },
    );

    dialogOpen = false;

    // ============================================================
    // RUN ACTION AFTER DIALOG CLOSES
    // Works for both:
    // - OK button
    // - Auto dismiss
    // ============================================================

    if (mounted && onDismissed != null) {
      onDismissed();
    }
  }

  Future<Uint8List> _loadMarkerImage(String assetPath) async {
    final byteData = await rootBundle.load(assetPath);
    return byteData.buffer.asUint8List();
  }

  Future<bool> _addClientMarker() async {
    if (clientMarker != null) return true;

    if (isPageDisposed || !mounted || mapboxMap == null) {
      return false;
    }

    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (clientLatitude == null || clientLongitude == null) {
      debugPrint('Client marker skipped: missing client coordinates.');
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      final pinImage = await _loadMarkerImage(clientPinAsset);

      clientMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              clientLongitude,
              clientLatitude,
            ),
          ),
          image: pinImage,
          iconSize: clientPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return clientMarker != null;
    } catch (e) {
      debugPrint('Client marker failed: $e');
      return false;
    }
  }

  Future<bool> _addBranchMarker() async {
    if (branchMarker != null) return true;

    if (isPageDisposed || !mounted || mapboxMap == null) {
      return false;
    }

    final branchLatitude = _toDouble(widget.job['branchLatitude']);
    final branchLongitude = _toDouble(widget.job['branchLongitude']);

    if (branchLatitude == null || branchLongitude == null) {
      debugPrint('Branch marker skipped: missing branch coordinates.');
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      final pinImage = await _loadMarkerImage(branchPinAsset);

      branchMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              branchLongitude,
              branchLatitude,
            ),
          ),
          image: pinImage,
          iconSize: branchPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return branchMarker != null;
    } catch (e) {
      debugPrint('Branch marker failed: $e');
      return false;
    }
  }

  Future<void> _showMapOverview() async {
    if (mapboxMap == null) return;

    final branchLatitude = _toDouble(widget.job['branchLatitude']);
    final branchLongitude = _toDouble(widget.job['branchLongitude']);

    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    if (branchLatitude == null ||
        branchLongitude == null ||
        clientLatitude == null ||
        clientLongitude == null) {
      return;
    }

    final points = [
      Point(
        coordinates: Position(
          branchLongitude,
          branchLatitude,
        ),
      ),
      Point(
        coordinates: Position(
          clientLongitude,
          clientLatitude,
        ),
      ),
    ];

    final cameraOptions = await mapboxMap!.cameraForCoordinates(
      points,
      MbxEdgeInsets(
        top: 70,
        left: 50,
        bottom: 80,
        right: 90,
      ),
      null,
      null,
    );

    await mapboxMap!.flyTo(
      cameraOptions,
      MapAnimationOptions(duration: 900),
    );
  }

  void _startTechnicianLocationPolling() {
    trackingTimer?.cancel();

    () async {
      await _fetchTechnicianLocation();
      await _loadSharedRoute();
    }();

    trackingTimer = Timer.periodic(
      const Duration(seconds: 10),
      (_) async {
        await _fetchTechnicianLocation();
        await _loadSharedRoute();
      },
    );
  }

  Future<bool> _fetchTechnicianLocation() async {
    final scheduleId =
        widget.job['schedule_id'] ?? widget.job['scheduleId'] ?? widget.job['id'];

    if (scheduleId == null) {
      debugPrint('Client tracking skipped: missing schedule ID.');
      return false;
    }

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/client/tracking/location'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'schedule_id': scheduleId.toString(),
        },
      );

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid technician location response: ${response.body}');
        return false;
      }

      if (response.statusCode == 200 && data['success'] == true) {

        final status = data['status']?.toString() ?? '';

        final normalizedStatus =
            status.trim().toUpperCase();

        if (mounted &&
            normalizedStatus.isNotEmpty &&
            normalizedStatus != trackingStatus) {
          setState(() {
            trackingStatus =
                normalizedStatus;
          });

          debugPrint(
            'CLIENT TRACKING STATUS UPDATED: '
            '$trackingStatus',
          );
        }

        // ============================================================
        // ARRIVED DIALOG
        // ============================================================

        if (normalizedStatus == 'ARRIVED' &&
            !hasShownArrivedDialog) {
          hasShownArrivedDialog = true;

          _showStatusDialog(
            title: 'Technician Arrived',
            message:
                'Your technician has arrived at your service location and will now begin the pest control service.',
            icon: Icons.location_on_rounded,
            autoDismissDuration:
                const Duration(seconds: 5),
          );
        }

        // ============================================================
        // COMPLETED DIALOG
        // ============================================================

        if (normalizedStatus == 'DONE SERVICE' &&
            !hasShownCompletedDialog) {
          hasShownCompletedDialog = true;

          trackingTimer?.cancel();

          await _showStatusDialog(
            title: 'Service Completed',
            message:
                'Your pest control service has been completed successfully.',
            icon: Icons.check_circle_rounded,
            autoDismissDuration:
                const Duration(seconds: 8),
            showConfetti: true,
            onDismissed: () {
              if (!mounted) return;

              final rawServiceId =
                  widget.job['svc_id'];

              final serviceId =
                  int.tryParse(
                rawServiceId?.toString() ?? '',
              );

              debugPrint(
                'TRACKING REDIRECT RAW SVC ID: $rawServiceId',
              );

              debugPrint(
                'TRACKING REDIRECT PARSED SVC ID: $serviceId',
              );

              final navigator =
                  Navigator.of(context);

              navigator.pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (_) =>
                      ClientAppointmentsMenuPage(
                    email: widget.email,
                  ),
                ),
                (route) => false,
              );

              navigator.push(
                MaterialPageRoute(
                  builder: (_) =>
                      ClientCompletedAppointmentsPage(
                    email: widget.email,
                    initialServiceId: serviceId,
                  ),
                ),
              );
            },
          );

          return true;
        }

        _redirectToAppointmentsIfCompleted(status);

        if (hasRedirectedAfterCompletion) {
          return true;
        }

        final latitude = _toDouble(data['technicianLatitude']);
        final longitude = _toDouble(data['technicianLongitude']);

        if (latitude == null || longitude == null) {
          debugPrint('Technician location skipped: invalid coordinates.');
          return false;
        }

        final markerReady = await _addOrUpdateTechnicianMarker(
          latitude: latitude,
          longitude: longitude,
        );

        if (!markerReady) {
          return false;
        }

        await _updateRemainingRouteFromTechnician(
          latitude: latitude,
          longitude: longitude,
        );

        return true;
      }

      debugPrint('Technician location unavailable: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Technician location fetch error: $e');
      return false;
    }
  }

  Future<bool> _addOrUpdateTechnicianMarker({
    required double latitude,
    required double longitude,
  }) async {
    if (isPageDisposed || !mounted || mapboxMap == null) {
      return false;
    }

    try {
      markerManager ??=
          await mapboxMap!.annotations.createPointAnnotationManager();

      if (technicianMarker != null) {
        technicianMarker!.geometry = Point(
          coordinates: Position(
            longitude,
            latitude,
          ),
        );

        await markerManager!.update(technicianMarker!);
        return true;
      }

      final pinImage = await _loadMarkerImage(technicianPinAsset);

      technicianMarker = await markerManager!.create(
        PointAnnotationOptions(
          geometry: Point(
            coordinates: Position(
              longitude,
              latitude,
            ),
          ),
          image: pinImage,
          iconSize: technicianPinSize,
          iconAnchor: IconAnchor.BOTTOM,
        ),
      );

      return technicianMarker != null;
    } catch (e) {
      debugPrint('Technician marker failed: $e');
      return false;
    }
  }

  String _formatEta(dynamic duration) {
    final seconds = double.tryParse(duration.toString());

    if (seconds == null || seconds <= 0) {
      return 'Calculating';
    }

    final minutes = (seconds / 60).round();

    if (minutes <= 0) return 'Less than 1 min';
    if (minutes < 60) return '$minutes mins';

    final hours = minutes ~/ 60;
    final remainingMinutes = minutes % 60;

    if (remainingMinutes == 0) return '~$hours hr';

    return '~$hours hr $remainingMinutes mins';
  }

  List<Position> _decodePolyline6(String encoded) {
    final List<Position> points = [];

    int index = 0;
    int lat = 0;
    int lng = 0;

    while (index < encoded.length) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encoded.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      final deltaLat = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lat += deltaLat;

      shift = 0;
      result = 0;

      do {
        byte = encoded.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      final deltaLng = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lng += deltaLng;

      points.add(
        Position(
          lng / 1000000,
          lat / 1000000,
        ),
      );
    }

    return points;
  }

  Future<bool> _loadSharedRoute() async {
    debugPrint('CLIENT ROUTE: _loadSharedRoute called');

    final scheduleId =
        widget.job['schedule_id'] ?? widget.job['scheduleId'] ?? widget.job['id'];

    debugPrint('CLIENT ROUTE scheduleId: $scheduleId');

    if (scheduleId == null) {
      debugPrint('Shared route skipped: missing schedule ID.');
      return false;
    }

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/tracking/route'),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'schedule_id': scheduleId.toString(),
        },
      );

      Map<String, dynamic>? data;

      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        debugPrint('Invalid shared route response: ${response.body}');
        return false;
      }

      debugPrint('CLIENT ROUTE STATUS: ${response.statusCode}');
      debugPrint('CLIENT ROUTE BODY: ${response.body}');

      if (response.statusCode == 200 && data['success'] == true) {
        final route = data['route'];
        final geometry = route?['geometry'];
        final duration = route?['duration'];

        if (mounted) {
          setState(() {
            etaText = _formatEta(duration);
          });
        }

        if (geometry != null && geometry.toString().isNotEmpty) {
          final newGeometry = geometry.toString();

          if (newGeometry != lastRouteGeometry) {
            lastRouteGeometry = newGeometry;

            debugPrint('CLIENT ROUTE: route changed, redrawing route.');

            return await _drawRouteLine(newGeometry);
          }

          debugPrint('CLIENT ROUTE: route unchanged, skip redraw.');
          return routeLine != null;
        }

        return false;
      }

      debugPrint('Shared route unavailable: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Shared route fetch error: $e');
      return false;
    }
  }

  Future<bool> _drawRouteLine(String encodedPolyline) async {
    if (mapboxMap == null) {
      return false;
    }

    final coordinates = _decodePolyline6(encodedPolyline);

    if (coordinates.isEmpty) {
      return false;
    }

    try {
      fullRouteCoordinates = coordinates;

      routeLineManager ??=
          await mapboxMap!.annotations.createPolylineAnnotationManager();

      if (routeLine != null) {
        await routeLineManager!.delete(routeLine!);
      }

      routeLine = await routeLineManager!.create(
        PolylineAnnotationOptions(
          geometry: LineString(
            coordinates: coordinates,
          ),
          lineColor: AppTheme.primaryRed.value,
          lineWidth: 4.5,
          lineOpacity: 0.9,
        ),
      );

      return routeLine != null;
    } catch (e) {
      debugPrint('Client route draw failed: $e');
      return false;
    }
  }

  Future<bool> _drawFallbackRouteLine() async {
    if (mapboxMap == null) return false;

    final clientLatitude = _toDouble(widget.job['clientLatitude']);
    final clientLongitude = _toDouble(widget.job['clientLongitude']);

    double? technicianLatitude;
    double? technicianLongitude;

    if (technicianMarker != null) {
      technicianLatitude = technicianMarker!.geometry.coordinates.lat.toDouble();
      technicianLongitude = technicianMarker!.geometry.coordinates.lng.toDouble();
    }

    if (technicianLatitude == null || technicianLongitude == null) {
      return false;
    }

    if (clientLatitude == null || clientLongitude == null) {
      return false;
    }

    try {
      routeLineManager ??=
          await mapboxMap!.annotations.createPolylineAnnotationManager();

      final fallbackCoordinates = [
        Position(
          technicianLongitude,
          technicianLatitude,
        ),
        Position(
          clientLongitude,
          clientLatitude,
        ),
      ];

      fullRouteCoordinates = fallbackCoordinates;

      if (routeLine != null) {
        await routeLineManager!.delete(routeLine!);
      }

      routeLine = await routeLineManager!.create(
        PolylineAnnotationOptions(
          geometry: LineString(
            coordinates: fallbackCoordinates,
          ),
          lineColor: AppTheme.primaryRed.value,
          lineWidth: 4.5,
          lineOpacity: 0.55,
        ),
      );

      usedFallbackRoute = true;
      etaText = 'Calculating';

      debugPrint('Client fallback straight route drawn.');

      return true;
    } catch (e) {
      debugPrint('Client fallback route failed: $e');
      return false;
    }
  }

  Future<void> _updateRemainingRouteFromTechnician({
    required double latitude,
    required double longitude,
  }) async {
    if (mapboxMap == null || routeLineManager == null || routeLine == null) {
      return;
    }

    if (fullRouteCoordinates.isEmpty) return;

    int closestIndex = 0;
    double closestDistance = double.infinity;

    for (int i = 0; i < fullRouteCoordinates.length; i++) {
      final point = fullRouteCoordinates[i];

      final distance = _distanceBetweenCoordinates(
        lat1: latitude,
        lng1: longitude,
        lat2: point.lat.toDouble(),
        lng2: point.lng.toDouble(),
      );

      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = i;
      }
    }

    if (closestIndex >= fullRouteCoordinates.length) return;

    final remainingRoute = fullRouteCoordinates.sublist(closestIndex);

    try {
      routeLine!.geometry = LineString(
        coordinates: remainingRoute,
      );

      await routeLineManager!.update(routeLine!);
    } catch (e) {
      debugPrint('Client route trim skipped: $e');
    }
  }

  Future<bool> _prepareTrackingMap() async {
    trackingMapError = null;

    for (int attempt = 1; attempt <= initialMapSetupMaxAttempts; attempt++) {
      debugPrint('Client tracking map setup attempt $attempt');

      if (!branchReady) {
        branchReady = await _addBranchMarker();
      }

      if (!clientReady) {
        clientReady = await _addClientMarker();
      }

      if (!technicianReady) {
        final locationReady = await _fetchTechnicianLocation();

        technicianReady = locationReady && technicianMarker != null;
      }

      if (!routeReady) {
        routeReady = await _loadSharedRoute();
      }

      if (branchReady && clientReady && technicianReady && routeReady) {
        return true;
      }

      if (attempt < initialMapSetupMaxAttempts) {
        await Future.delayed(const Duration(milliseconds: 250));
      }
    }

    if (branchReady && clientReady && technicianReady && !routeReady) {
      routeReady = await _drawFallbackRouteLine();
      return routeReady;
    }

    trackingMapError = 'Unable to load complete client tracking map.';
    return false;
  }

  Future<void> _prepareAnnotationManagers() async {
    if (mapboxMap == null) return;

    routeLineManager ??=
        await mapboxMap!.annotations.createPolylineAnnotationManager();

    markerManager ??=
        await mapboxMap!.annotations.createPointAnnotationManager();
  }

  void _redirectToAppointmentsIfCompleted(String status) {
    final normalizedStatus = status.toUpperCase();

    if (hasRedirectedAfterCompletion) return;

    if (normalizedStatus == 'DONE SERVICE' ||
        normalizedStatus == 'DONE REPORT' ||
        normalizedStatus == 'COMPLETED') {
      hasRedirectedAfterCompletion = true;
      trackingTimer?.cancel();

      if (!mounted) return;

      Navigator.pop(context, true);
    }
  }

  @override
  void dispose() {
    isPageDisposed = true;
    trackingTimer?.cancel();
    mapboxMap = null;
    markerManager = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final clientLatitude = _toDouble(widget.job['clientLatitude']) ?? 7.0731;
    final clientLongitude = _toDouble(widget.job['clientLongitude']) ?? 125.6131;

    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: const AppBackHeader(
        title: 'Track Technician',
      ),
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: MapWidget(
                        cameraOptions: CameraOptions(
                          center: Point(
                            coordinates: Position(
                              clientLongitude,
                              clientLatitude,
                            ),
                          ),
                          zoom: 15,
                        ),
                        onMapCreated: (controller) async {
                          mapboxMap = controller;

                          setState(() {
                            isMapReady = false;
                          });

                          try {
                            await controller.scaleBar.updateSettings(
                              ScaleBarSettings(enabled: false),
                            );

                            await controller.compass.updateSettings(
                              CompassSettings(enabled: true),
                            );

                            await controller.location.updateSettings(
                              LocationComponentSettings(enabled: false),
                            );

                            await _prepareAnnotationManagers();

                            final setupReady = await _prepareTrackingMap();

                            if (isPageDisposed || !mounted || mapboxMap == null) return;

                            if (setupReady) {
                              await Future.delayed(const Duration(milliseconds: 350));
                              await _showMapOverview();

                              _startTechnicianLocationPolling();
                            }

                            if (!mounted) return;

                            if (!setupReady) {
                              debugPrint(trackingMapError ?? 'Client tracking map setup failed.');
                              return;
                            }

                            setState(() {
                              isMapReady = true;
                            });
                          } catch (e) {
                            debugPrint('Client tracking map setup error: $e');

                            if (!mounted) return;

                            trackingMapError = 'Client tracking map setup failed.';
                            return;
                          }
                        },
                      ),
                    ),

                    if (!isMapReady) _mapGlassLoadingOverlay(),
                  ],
                ),
              ),

              const SizedBox(
                height: 260,
              ),
            ],
          ),

          DraggableScrollableSheet(
            initialChildSize: 0.39,
            minChildSize: 0.39,
            maxChildSize: 0.72,
            snap: true,
            snapSizes: const [
              0.39,
              0.72,
            ],
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: AppTheme.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(24),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 12,
                      offset: Offset(0, -3),
                    ),
                  ],
                ),
                child: ListView(
                  controller: scrollController,
                  padding: EdgeInsets.zero,
                  children: [
                    ClientTrackingInfoSheet(
                      job: widget.job,
                      etaText: etaText,
                      trackingStatus: trackingStatus,
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _mapGlassLoadingOverlay() {
    return Positioned.fill(
      child: ClipRect(
        child: BackdropFilter(  
          filter: ImageFilter.blur(
            sigmaX: 10,
            sigmaY: 10,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
            ),
          ),
        ),
      ),
    );
  }
}