import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/app_profile_avatar.dart';

class ClientTrackingInfoSheet extends StatefulWidget {
  final Map<String, dynamic> job;
  final String etaText;
  final String trackingStatus;

  const ClientTrackingInfoSheet({
    super.key,
    required this.job,
    required this.etaText,
    required this.trackingStatus,
  });

  @override
  State<ClientTrackingInfoSheet> createState() =>
      _ClientTrackingInfoSheetState();
}

class _ClientTrackingInfoSheetState
    extends State<ClientTrackingInfoSheet>
    with SingleTickerProviderStateMixin {
  late final AnimationController _travelController;

  // ============================================================
  // LIFECYCLE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _travelController = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 2200,
      ),
    );

    _updateTravelAnimation();
  }

  @override
  void didUpdateWidget(
    ClientTrackingInfoSheet oldWidget,
  ) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.trackingStatus !=
        widget.trackingStatus) {
      _updateTravelAnimation();
    }
  }

  void _updateTravelAnimation() {
    // Animate while traveling OR while service is ongoing.
    // Stop only once the service is completed.

    if (!_isCompleted) {
      if (!_travelController.isAnimating) {
        _travelController.repeat();
      }
    } else {
      _travelController.stop();
      _travelController.value = 0;
    }
  }

  @override
  void dispose() {
    _travelController.dispose();
    super.dispose();
  }

  // ============================================================
  // BASIC HELPERS
  // ============================================================

  String _text(
    dynamic value, [
    String fallback = 'N/A',
  ]) {
    if (value == null) return fallback;

    final text =
        value.toString().trim();

    return text.isEmpty
        ? fallback
        : text;
  }

  String get _normalizedStatus =>
      widget.trackingStatus
          .trim()
          .toUpperCase();

  bool get _isOnTheWay {
    return _normalizedStatus != 'ARRIVED' &&
        _normalizedStatus != 'DONE SERVICE' &&
        _normalizedStatus != 'COMPLETED';
  }

  bool get _hasArrived {
    return _normalizedStatus == 'ARRIVED' ||
        _normalizedStatus == 'DONE SERVICE' ||
        _normalizedStatus == 'COMPLETED';
  }

  bool get _isInProgress {
    return _normalizedStatus == 'ARRIVED' ||
        _normalizedStatus == 'DONE SERVICE' ||
        _normalizedStatus == 'COMPLETED';
  }

  bool get _isCompleted {
    return _normalizedStatus == 'DONE SERVICE' ||
        _normalizedStatus == 'COMPLETED';
  }

  // ============================================================
  // STATUS
  // ============================================================

  String _statusLabel() {
    switch (_normalizedStatus) {
      case 'ARRIVED':
        return 'ARRIVED';

      case 'DONE SERVICE':
      case 'COMPLETED':
        return 'COMPLETED';

      default:
        return 'ON THE WAY';
    }
  }

  String _headerLabel() {
    switch (_normalizedStatus) {
      case 'ARRIVED':
        return 'Current Status';

      case 'DONE SERVICE':
      case 'COMPLETED':
        return 'Current Status';

      default:
        return 'Estimated Arrival';
    }
  }

  String _headerValue() {
    switch (_normalizedStatus) {
      case 'ARRIVED':
        return 'Arrived';

      case 'DONE SERVICE':
      case 'COMPLETED':
        return 'Completed';

      default:
        return widget.etaText;
    }
  }

  String _statusMessage() {
    switch (_normalizedStatus) {
      case 'ARRIVED':
        return 'Your technician has arrived at your service location.';

      case 'DONE SERVICE':
      case 'COMPLETED':
        return 'Your pest control service has been completed successfully.';

      default:
        return 'Your technician is currently traveling to your service location.';
    }
  }

  // ============================================================
  // PEST / SERVICE
  // ============================================================

  String _formatPestName(
    String pest,
  ) {
    final normalized =
        pest.trim().toUpperCase();

    switch (normalized) {
      case 'RATS/MICE':
        return 'Rodent';

      case 'BED BUGS':
        return 'Bed Bug';

      case 'COCKROACHES':
        return 'Cockroach';

      case 'ANTS':
        return 'Ant';

      case 'TERMITES':
        return 'Termite';

      default:
        return normalized
            .toLowerCase()
            .split(' ')
            .map(
              (word) {
                if (word.isEmpty) {
                  return word;
                }

                return word[0].toUpperCase() +
                    word.substring(1);
              },
            )
            .join(' ');
    }
  }

  List<String> _pestList() {
    final fullPestTypes =
        _text(
      widget.job['fullPestTypes'],
      '',
    );

    if (fullPestTypes.isNotEmpty) {
      return fullPestTypes
          .split(',')
          .map(
            (item) =>
                item.trim(),
          )
          .where(
            (item) =>
                item.isNotEmpty,
          )
          .toList();
    }

    final pestType =
        _text(
      widget.job['pestType'],
      '',
    );

    if (pestType.isNotEmpty &&
        pestType != 'N/A') {
      return [pestType];
    }

    return [];
  }

  String _serviceName() {
    final isTermite =
        widget.job['isTermite'] == true ||
            widget.job['svc_is_termite'] == 1 ||
            _text(
              widget.job['service'],
              '',
            )
                .toUpperCase()
                .contains('TERMITE') ||
            _text(
              widget.job['pestType'],
              '',
            )
                .toUpperCase()
                .contains('TERMITE');

    final pests =
        _pestList();

    if (isTermite) {
      return 'Termite Control';
    }

    if (pests.length == 1) {
      return '${_formatPestName(pests.first)} Control';
    }

    if (pests.length >= 2) {
      return 'General Pest Control';
    }

    return _text(
      widget.job['service'],
      'Pest Control Service',
    );
  }

  // ============================================================
  // SCHEDULE
  // ============================================================

  String _scheduleText() {
    final startDate =
        _text(
      widget.job['startDate'],
      '',
    );

    final startTime =
        _text(
      widget.job['startTime'],
      '',
    );

    if (startDate.isEmpty &&
        startTime.isEmpty) {
      return _text(
        widget.job['schedule'],
        'N/A',
      );
    }

    try {
      final parsed =
          DateTime.parse(
        '$startDate $startTime',
      );

      const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ];

      final month =
          months[parsed.month - 1];

      final hour =
          parsed.hour;

      final minute =
          parsed.minute
              .toString()
              .padLeft(
                2,
                '0',
              );

      final period =
          hour >= 12
              ? 'PM'
              : 'AM';

      final displayHour =
          hour == 0
              ? 12
              : hour > 12
                  ? hour - 12
                  : hour;

      return '$month ${parsed.day}, '
          '${parsed.year} • '
          '$displayHour:$minute $period';
    } catch (_) {
      if (startDate.isEmpty) {
        return startTime;
      }

      if (startTime.isEmpty) {
        return startDate;
      }

      return '$startDate • $startTime';
    }
  }

  // ============================================================
  // TECHNICIAN / TEAM
  // ============================================================

  List<Map<String, dynamic>>
      _teamTechnicians() {
    final raw =
        widget.job['teamTechnicians'];

    // ==========================================================
    // MULTIPLE / TEAM DATA
    // ==========================================================

    if (raw is List &&
        raw.isNotEmpty) {
      return raw
          .whereType<Map>()
          .map(
            (item) =>
                Map<String, dynamic>.from(
              item,
            ),
          )
          .where(
            (item) =>
                _text(
                  item['name'],
                  '',
                ).isNotEmpty,
          )
          .toList();
    }

    // ==========================================================
    // SINGLE TECHNICIAN FALLBACK
    // ==========================================================

    final fallbackName =
        _text(
      widget.job['technicianName'] ??
          widget.job['assignedTechnician'] ??
          widget.job['technician'],
      '',
    );

    if (fallbackName.isEmpty) {
      return [];
    }

    return [
      {
        'id':
            widget.job['technicianId'],
        'name':
            fallbackName,
      },
    ];
  }

  Map<String, dynamic>?
      _teamLeader(
    List<Map<String, dynamic>>
        technicians,
  ) {
    if (technicians.isEmpty) {
      return null;
    }

    final leaderId =
        widget.job['leaderId'];

    if (leaderId != null) {
      for (final technician
          in technicians) {
        if (technician['id']
                ?.toString() ==
            leaderId.toString()) {
          return technician;
        }
      }
    }

    return technicians.first;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    final address =
        _text(
      widget.job['address'],
      'No service location available',
    );

    final technicians =
        _teamTechnicians();

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          16,
          10,
          16,
          18,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            // ==================================================
            // HANDLE
            // ==================================================

            _dragHandle(),

            // ==================================================
            // LIVE ETA / STATUS HEADER
            // ==================================================

            _statusHeader(),

            // ==================================================
            // SERVICE STATUS
            // ==================================================

            const SizedBox(height: 16),

            _sectionLabel(
              'SERVICE STATUS',
            ),

            const SizedBox(height: 8),

            _serviceStatusCard(),

            // ==================================================
            // TECHNICIAN / SERVICE TEAM
            // ==================================================

            if (technicians.isNotEmpty) ...[
              const SizedBox(height: 16),

              _sectionLabel(
                technicians.length > 1
                    ? 'YOUR SERVICE TEAM'
                    : 'YOUR TECHNICIAN',
              ),

              const SizedBox(height: 8),

              _technicianCard(
                technicians: technicians,
              ),
            ],

            // ==================================================
            // SERVICE DETAILS
            // ==================================================

            const SizedBox(height: 16),

            _sectionLabel(
              'SERVICE DETAILS',
            ),

            const SizedBox(height: 8),

            _detailsCard(
              service: _serviceName(),
              schedule: _scheduleText(),
              address: address,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // DRAG HANDLE
  // ============================================================

  Widget _dragHandle() {
    return Center(
      child: Container(
        width: 42,
        height: 4,
        margin:
            const EdgeInsets.only(
          bottom: 12,
        ),
        decoration:
            BoxDecoration(
          color:
              AppTheme.borderGray,
          borderRadius:
              BorderRadius.circular(
            20,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LIVE STATUS HEADER
  // ============================================================

  Widget _statusHeader() {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        14,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.primaryRed,
        borderRadius:
            BorderRadius.circular(
          16,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme
                .primaryRed
                .withOpacity(
              0.22,
            ),
            blurRadius: 10,
            offset:
                const Offset(
              0,
              4,
            ),
          ),
        ],
      ),
      child: Row(
        children: [
          // ====================================================
          // LIVE ICON
          // ====================================================

          _headerIcon(),

          const SizedBox(
            width: 12,
          ),

          // ====================================================
          // HEADER VALUE
          // ====================================================

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  _headerLabel(),
                  style:
                      const TextStyle(
                    color:
                        AppTheme.white,
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  _headerValue(),
                  maxLines: 1,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.white,
                    fontSize: 21,
                    fontWeight:
                        FontWeight.w900,
                    letterSpacing:
                        0.3,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(
            width: 8,
          ),

          _statusPill(),
        ],
      ),
    );
  }

  Widget _headerIcon() {
    Widget icon;

    if (_isCompleted) {
      icon = const Icon(
        Icons.check_circle_outline_rounded,
        color:
            AppTheme.white,
        size: 26,
      );
    } else if (_hasArrived) {
      icon = const Icon(
        Icons.location_on_outlined,
        color:
            AppTheme.white,
        size: 26,
      );
    } else {
      icon = const Icon(
        Icons.directions_car_filled_rounded,
        color:
            AppTheme.white,
        size: 23,
      );
    }

    return Container(
      width: 48,
      height: 48,
      decoration:
          BoxDecoration(
        color: AppTheme.white
            .withOpacity(
          0.18,
        ),
        borderRadius:
            BorderRadius.circular(
          14,
        ),
      ),
      child: _isOnTheWay
          ? AnimatedBuilder(
              animation:
                  _travelController,
              child: icon,
              builder: (
                context,
                child,
              ) {
                final offset =
                    (_travelController.value -
                            0.5)
                        .abs();

                final scale =
                    1.0 +
                        (
                          0.06 *
                          (
                            1 -
                            offset *
                                2
                          )
                        );

                return Transform.scale(
                  scale: scale,
                  child: child,
                );
              },
            )
          : icon,
    );
  }

  Widget _statusPill() {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration:
          BoxDecoration(
        border:
            Border.all(
          color: AppTheme.white
              .withOpacity(
            0.45,
          ),
        ),
        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),
      child: Text(
        _statusLabel(),
        style:
            const TextStyle(
          color:
              AppTheme.white,
          fontSize: 8.5,
          fontWeight:
              FontWeight.w900,
          letterSpacing:
              0.4,
        ),
      ),
    );
  }

  // ============================================================
  // SECTION LABEL
  // ============================================================

  Widget _sectionLabel(
    String title,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        left: 2,
      ),
      child: Text(
        title,
        style:
            const TextStyle(
          color:
              AppTheme.gray,
          fontSize: 10,
          fontWeight:
              FontWeight.w900,
          letterSpacing:
              0.8,
        ),
      ),
    );
  }

  // ============================================================
  // TECHNICIAN / MULTIPLE TECHNICIAN CARD
  // ============================================================

  Widget _technicianCard({
    required List<
            Map<String, dynamic>>
        technicians,
  }) {
    final leader =
        _teamLeader(
      technicians,
    );

    if (leader == null) {
      return const SizedBox
          .shrink();
    }

    final leaderName =
        _text(
      leader['name'],
      'Service Technician',
    );

    final isMultiple =
        technicians.length > 1;

    final members =
        technicians
            .where(
              (technician) =>
                  technician['id']
                          ?.toString() !=
                      leader['id']
                          ?.toString(),
            )
            .toList();

    // ============================================================
    // SINGLE TECHNICIAN
    // ============================================================

    if (!isMultiple) {
      return Container(
        width:
            double.infinity,
        padding:
            const EdgeInsets.all(
          14,
        ),
        decoration:
            _cardDecoration(),
        child: Row(
          children: [
            _personAvatar(
              profileImage:
                  leader['profileImage']?.toString(),
            ),

            const SizedBox(
              width: 12,
            ),

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    leaderName,
                    maxLines: 1,
                    overflow:
                        TextOverflow.ellipsis,
                    style:
                        const TextStyle(
                      color:
                          AppTheme.black,
                      fontSize: 13.5,
                      fontWeight:
                          FontWeight.w900,
                    ),
                  ),

                  const SizedBox(
                    height: 3,
                  ),

                  const Text(
                    'Service Technician',
                    style:
                        TextStyle(
                      color:
                          AppTheme.gray,
                      fontSize: 9.5,
                      fontWeight:
                          FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // ============================================================
    // MULTIPLE TECHNICIANS
    // ============================================================

    return Container(
      width: double.infinity,
      decoration: _cardDecoration(),
      child: Column(
        children: [
          // ========================================================
          // TEAM LEADER SUMMARY
          // ========================================================

          Padding(
            padding: const EdgeInsets.fromLTRB(
              14,
              14,
              14,
              13,
            ),
            child: Row(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 56,
                  child: Center(
                    child: _personAvatar(
                      profileImage:
                          leader['profileImage']?.toString(),
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      // ==================================================
                      // ROW 1: NAME + TEAM AVATAR STACK
                      // ==================================================

                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              leaderName,
                              maxLines: 1,
                              overflow:
                                  TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.black,
                                fontSize: 13.5,
                                fontWeight:
                                    FontWeight.w900,
                              ),
                            ),
                          ),

                          const SizedBox(width: 8),

                          _teamAvatarStack(
                            technicians,
                          ),
                        ],
                      ),

                      // ==================================================
                      // ROW 2: SMALL TEAM LEADER BADGE
                      // Same visual size as the old text
                      // ==================================================

                      Container(
                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryRed
                              .withOpacity(0.07),
                          borderRadius:
                              BorderRadius.circular(10),
                        ),
                        child: const Row(
                          mainAxisSize:
                              MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.verified_rounded,
                              color:
                                  AppTheme.primaryRed,
                              size: 9,
                            ),

                            SizedBox(width: 3),

                            Text(
                              'Team Leader',
                              style: TextStyle(
                                color:
                                    AppTheme.primaryRed,
                                fontSize: 9,
                                fontWeight:
                                    FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 3),

                      // ==================================================
                      // ROW 3: ROLE
                      // ==================================================

                      const Text(
                        'Pest Control Technician',
                        style: TextStyle(
                          color: AppTheme.gray,
                          fontSize: 9,
                          fontWeight:
                              FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const Divider(
            height: 1,
            color: AppTheme.borderGray,
          ),

          // ========================================================
          // EXPANDABLE TEAM MEMBERS
          // ========================================================

          Theme(
            data: ThemeData(
              dividerColor:
                  Colors.transparent,
              splashColor:
                  Colors.transparent,
              highlightColor:
                  Colors.transparent,
            ),
            child: ExpansionTile(
              tilePadding:
                  const EdgeInsets.symmetric(
                horizontal: 14,
              ),
              childrenPadding:
                  const EdgeInsets.fromLTRB(
                14,
                0,
                14,
                14,
              ),

              title: Row(
                children: [
                  const Text(
                    'TEAM MEMBERS',
                    style: TextStyle(
                      color: AppTheme.gray,
                      fontSize: 9,
                      fontWeight:
                          FontWeight.w900,
                      letterSpacing: 0.7,
                    ),
                  ),

                  const SizedBox(width: 7),

                  Container(
                    constraints: const BoxConstraints(
                      minWidth: 22,
                      minHeight: 22,
                    ),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                    ),
                    decoration:
                        BoxDecoration(
                      color:
                          AppTheme.lightGray,
                      borderRadius:
                          BorderRadius.circular(
                        20,
                      ),
                    ),
                    child: Text(
                      '${members.length}',
                      style:
                          const TextStyle(
                        color:
                            AppTheme.gray,
                        fontSize: 9,
                        fontWeight:
                            FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),

              trailing: const Icon(
                Icons
                    .keyboard_arrow_down_rounded,
                color: AppTheme.gray,
                size: 22,
              ),

              children: [
                const SizedBox(height: 2),

                ...members
                    .asMap()
                    .entries
                    .map(
                  (entry) {
                    final member =
                        entry.value;

                    final memberName =
                        _text(
                      member['name'],
                      'Service Technician',
                    );

                    return Padding(
                      padding:
                          EdgeInsets.only(
                        bottom: entry.key <
                                members.length -
                                    1
                            ? 11
                            : 0,
                      ),
                      child: Row(
                        children: [
                          _personAvatar(
                            small: true,
                            profileImage:
                                member['profileImage']?.toString(),
                          ),

                          const SizedBox(
                            width: 10,
                          ),

                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment
                                      .start,
                              children: [
                                Text(
                                  memberName,
                                  maxLines: 1,
                                  overflow:
                                      TextOverflow
                                          .ellipsis,
                                  style:
                                      const TextStyle(
                                    color: AppTheme
                                        .black,
                                    fontSize:
                                        11.5,
                                    fontWeight:
                                        FontWeight
                                            .w700,
                                  ),
                                ),

                                const SizedBox(
                                  height: 2,
                                ),

                                const Text(
                                  'Service Technician',
                                  style:
                                      TextStyle(
                                    color: AppTheme
                                        .gray,
                                    fontSize: 9,
                                    fontWeight:
                                        FontWeight
                                            .w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TEAM MEMBER MINI AVATAR STACK
  // ============================================================

  Widget _teamMemberAvatarStack(
    List<Map<String, dynamic>> members,
  ) {
    if (members.isEmpty) {
      return const SizedBox.shrink();
    }

    const double avatarSize = 29;
    const double overlap = 18;

    // Show up to 3 actual technician avatars.
    final visibleMembers =
        members.take(3).toList();

    final remaining =
        members.length -
        visibleMembers.length;

    final displayCount =
        visibleMembers.length +
        (remaining > 0 ? 1 : 0);

    final stackWidth =
        avatarSize +
        ((displayCount - 1) *
            overlap);

    return SizedBox(
      width: stackWidth,
      height: avatarSize,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Draw from the back toward the front.
          // Earlier technician stays visually above
          // the next technician.
          for (
            int i =
                visibleMembers.length - 1;
            i >= 0;
            i--
          )
            Positioned(
              left: i * overlap,
              child: AppProfileAvatar(
                imageUrl: visibleMembers[i]['profileImage']?.toString(),
                size: avatarSize,
              ),
            ),

          // ====================================================
          // REMAINING COUNT
          // ====================================================

          if (remaining > 0)
            Positioned(
              left:
                  visibleMembers.length *
                      overlap,
              child: Container(
                width: avatarSize,
                height: avatarSize,
                alignment:
                    Alignment.center,
                decoration: BoxDecoration(
                  color: AppTheme
                      .primaryRed
                      .withOpacity(0.08),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppTheme.white,
                    width: 2,
                  ),
                ),
                child: Text(
                  '+$remaining',
                  style:
                      const TextStyle(
                    color:
                        AppTheme.primaryRed,
                    fontSize: 8,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // TEAM MINI AVATAR STACK
  // Includes leader + other technicians
  // ============================================================

  Widget _teamAvatarStack(
    List<Map<String, dynamic>> technicians,
  ) {
    if (technicians.isEmpty) {
      return const SizedBox.shrink();
    }

    const double avatarSize = 27;
    const double overlap = 18;

    // Maximum of 3 real technician avatars.
    const int maxVisible = 3;

    final visibleTechnicians =
        technicians.take(maxVisible).toList();

    // Anyone after the first 3 goes into +N.
    final remaining =
        technicians.length - visibleTechnicians.length;

    // Number of circles that will actually appear.
    final circleCount =
        visibleTechnicians.length +
        (remaining > 0 ? 1 : 0);

    final stackWidth =
        avatarSize +
        ((circleCount - 1) * overlap);

    return SizedBox(
      width: stackWidth,
      height: avatarSize,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // ====================================================
          // FIRST 3 TECHNICIANS
          // ====================================================

          for (
            int i = 0;
            i < visibleTechnicians.length;
            i++
          )
            Positioned(
              left: i * overlap,
              child: AppProfileAvatar(
                imageUrl: visibleTechnicians[i]['profileImage']?.toString(),
                size: avatarSize,
              ),
            ),

          // ====================================================
          // +N CIRCLE
          // Appears only when there are more than 3 technicians.
          // ====================================================

          if (remaining > 0)
            Positioned(
              left: visibleTechnicians.length * overlap,
              child: Container(
                width: avatarSize,
                height: avatarSize,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppTheme.borderGray,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppTheme.white,
                    width: 2,
                  ),
                ),
                child: Text(
                  '+$remaining',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 8,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // PROFILE AVATAR
  // ============================================================

  Widget _personAvatar({
    String? profileImage,
    bool small = false,
  }) {
    final size =
        small
            ? 34.0
            : 44.0;

    return AppProfileAvatar(
      imageUrl: profileImage,
      size: size,
    );
  }

  // ============================================================
  // SERVICE DETAILS
  // ============================================================

  Widget _detailsCard({
    required String service,
    required String schedule,
    required String address,
  }) {
    return Container(
      width:
          double.infinity,
      decoration:
          _cardDecoration(),
      child: Column(
        children: [
          _detailRow(
            icon: Icons
                .home_repair_service_outlined,
            label:
                'Service',
            value:
                service,
          ),

          _divider(),

          _detailRow(
            icon: Icons
                .calendar_month_outlined,
            label:
                'Schedule',
            value:
                schedule,
            maxLines:
                2,
          ),

          _divider(),

          _detailRow(
            icon: Icons
                .location_on_outlined,
            label:
                'Service Location',
            value:
                address,
            maxLines:
                2,
          ),
        ],
      ),
    );
  }

  Widget _detailRow({
    required IconData icon,
    required String label,
    required String value,
    int maxLines = 1,
  }) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 13,
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.center,
        children: [
          _softIcon(
            icon,
          ),

          const SizedBox(
            width: 11,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize:
                        9.5,
                    fontWeight:
                        FontWeight.w700,
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  value,
                  maxLines:
                      maxLines,
                  overflow:
                      TextOverflow.ellipsis,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,
                    fontSize:
                        12,
                    height:
                        1.3,
                    fontWeight:
                        FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SERVICE STATUS
  // ============================================================

  Widget _serviceStatusCard() {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(
        15,
      ),
      decoration:
          _cardDecoration(),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          // ====================================================
          // STATUS PROGRESS
          // ====================================================

          Row(
            children: [
              // ========================================================
              // ON THE WAY
              // ========================================================

              _statusNode(
                active: true,
                icon: Icons
                    .directions_car_filled_rounded,
              ),

              Expanded(
                child: _animatedTravelLine(),
              ),

              // ========================================================
              // ARRIVED
              // ========================================================

              _statusNode(
                active: _hasArrived,
                icon: Icons.location_on_rounded,
              ),

              // ========================================================
              // ARRIVED -> IN PROGRESS
              // ========================================================

              Expanded(
                child: _animatedInProgressLine(),
              ),

              // ========================================================
              // IN PROGRESS
              // ========================================================

              _statusNode(
                active: _isInProgress,
                pulse:
                    _normalizedStatus == 'ARRIVED',
                icon: Icons
                    .pest_control_rounded,
              ),

              // ========================================================
              // IN PROGRESS -> COMPLETED
              // ========================================================

              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 1,
                  ),
                  child: _completedLine(),
                ),
              ),

              // ========================================================
              // COMPLETED
              // ========================================================

              _statusNode(
                active: _isCompleted,
                icon: Icons.check_rounded,
              ),
            ],
          ),

          // ====================================================
          // LABELS
          // ====================================================

          const SizedBox(
            height: 8,
          ),

          const Row(
            children: [
              Expanded(
                child: Text(
                  'On the Way',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              Expanded(
                child: Text(
                  'Arrived',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              Expanded(
                child: Text(
                  'In Progress',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              Expanded(
                child: Text(
                  'Completed',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    color: AppTheme.gray,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 14,
          ),

          const Divider(
            height: 1,
            color:
                AppTheme.borderGray,
          ),

          const SizedBox(
            height: 13,
          ),

          // ====================================================
          // STATUS MESSAGE
          // ====================================================

          Row(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              _statusMessageIcon(),

              const SizedBox(
                width: 10,
              ),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      _statusLabel(),
                      style:
                          const TextStyle(
                        color:
                            AppTheme.black,
                        fontSize:
                            11.5,
                        fontWeight:
                            FontWeight.w900,
                      ),
                    ),

                    const SizedBox(
                      height: 4,
                    ),

                    Text(
                      _statusMessage(),
                      style:
                          const TextStyle(
                        color:
                            AppTheme.gray,
                        fontSize:
                            10.5,
                        height:
                            1.4,
                        fontWeight:
                            FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // MOVING VEHICLE LINE
  // ============================================================


  Widget _animatedTravelLine() {
    if (_hasArrived) {
      return Container(
        height: 6,
        color: AppTheme.primaryRed,
      );
    }

    return SizedBox(
      height: 14,
      child: Center(
        child: Stack(
          alignment: Alignment.center,
          children: [
            // ====================================================
            // PERMANENT FAINT TRACK
            // ====================================================

            Container(
              width: double.infinity,
              height: 6,
              color: AppTheme.primaryRed.withOpacity(
                0.10,
              ),
            ),

            // ====================================================
            // MOVING RED PULSE
            // ====================================================

            AnimatedBuilder(
              animation: _travelController,
              builder: (
                context,
                child,
              ) {
                final progress =
                    _travelController.value;

                // Fade only the moving pulse near the end.
                double pulseOpacity = 1.0;

                if (progress > 0.82) {
                  pulseOpacity =
                      1.0 -
                      ((progress - 0.82) / 0.18);
                }

                return Opacity(
                  opacity: pulseOpacity.clamp(
                    0.0,
                    1.0,
                  ),
                  child: Container(
                    width: double.infinity,
                    height: 6,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment(
                          -2.2 +
                              (progress * 3.4),
                          0,
                        ),
                        end: Alignment(
                          -0.1 +
                              (progress * 3.4),
                          0,
                        ),
                        colors: [
                          AppTheme.primaryRed,
                          AppTheme.primaryRed,

                          AppTheme.primaryRed
                              .withOpacity(
                            0.95,
                          ),

                          AppTheme.primaryRed
                              .withOpacity(
                            0.75,
                          ),

                          AppTheme.primaryRed
                              .withOpacity(
                            0.45,
                          ),

                          AppTheme.primaryRed
                              .withOpacity(
                            0.18,
                          ),

                          Colors.transparent,
                        ],
                        stops: const [
                          0.00,
                          0.20,
                          0.38,
                          0.56,
                          0.72,
                          0.88,
                          1.00,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ARRIVED -> IN PROGRESS
  // ============================================================

  Widget _animatedInProgressLine() {
    // ==========================================================
    // SERVICE COMPLETED
    // LINE BECOMES SOLID RED
    // ==========================================================

    if (_isCompleted) {
      return Container(
        height: 6,
        color: AppTheme.primaryRed,
      );
    }

    // ==========================================================
    // NOT YET ARRIVED
    // ==========================================================

    if (!_hasArrived) {
      return Container(
        height: 6,
        color: AppTheme.borderGray,
      );
    }

    // ==========================================================
    // ARRIVED
    // ANIMATE TOWARD IN PROGRESS
    // ==========================================================

    return SizedBox(
      height: 14,
      child: Center(
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Faint permanent track
            Container(
              width: double.infinity,
              height: 6,
              color: AppTheme.primaryRed
                  .withOpacity(0.10),
            ),

            // Moving gradient
            AnimatedBuilder(
              animation: _travelController,
              builder: (
                context,
                child,
              ) {
                final progress =
                    _travelController.value;

                double pulseOpacity = 1.0;

                if (progress > 0.82) {
                  pulseOpacity =
                      1.0 -
                      ((progress - 0.82) /
                          0.18);
                }

                return Opacity(
                  opacity:
                      pulseOpacity.clamp(
                    0.0,
                    1.0,
                  ),
                  child: Container(
                    width: double.infinity,
                    height: 6,
                    decoration: BoxDecoration(
                      gradient:
                          LinearGradient(
                        begin: Alignment(
                          -2.2 +
                              (progress *
                                  3.4),
                          0,
                        ),
                        end: Alignment(
                          -0.1 +
                              (progress *
                                  3.4),
                          0,
                        ),
                        colors: [
                          AppTheme
                              .primaryRed,
                          AppTheme
                              .primaryRed,
                          AppTheme.primaryRed
                              .withOpacity(
                            0.95,
                          ),
                          AppTheme.primaryRed
                              .withOpacity(
                            0.75,
                          ),
                          AppTheme.primaryRed
                              .withOpacity(
                            0.45,
                          ),
                          AppTheme.primaryRed
                              .withOpacity(
                            0.18,
                          ),
                          Colors.transparent,
                        ],
                        stops: const [
                          0.00,
                          0.20,
                          0.38,
                          0.56,
                          0.72,
                          0.88,
                          1.00,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // IN PROGRESS -> COMPLETED
  // ============================================================

  Widget _completedLine() {
    if (_isCompleted) {
      return Container(
        height: 6,
        color: AppTheme.primaryRed,
      );
    }

    return Container(
      height: 6,
      color: AppTheme.borderGray,
    );
  }

  // ============================================================
  // STATUS NODE
  // ============================================================

  Widget _statusNode({
    required bool active,
    required IconData icon,
    bool pulse = false,
  }) {
    final node = Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: active
            ? AppTheme.primaryRed
            : AppTheme.white,
        shape: BoxShape.circle,
        border: Border.all(
          color: active
              ? AppTheme.primaryRed
              : AppTheme.borderGray,
          width: 1.5,
        ),
      ),
      child: Icon(
        icon,
        size: 16,
        color: active
            ? AppTheme.white
            : AppTheme.gray,
      ),
    );

    if (!pulse) {
      return node;
    }

    return TweenAnimationBuilder<double>(
      tween: Tween(
        begin: 0.92,
        end: 1.08,
      ),
      duration: const Duration(
        milliseconds: 850,
      ),
      curve: Curves.easeInOut,
      builder: (
        context,
        scale,
        child,
      ) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: node,
    );
  }

  Widget _statusMessageIcon() {
    if (_isCompleted) {
      return const Icon(
        Icons
            .check_circle_outline_rounded,
        color:
            AppTheme.primaryRed,
        size:
            20,
      );
    }

    if (_hasArrived) {
      return const Icon(
        Icons
            .location_on_outlined,
        color:
            AppTheme.primaryRed,
        size:
            20,
      );
    }

    return const Icon(
      Icons
          .directions_car_outlined,
      color:
          AppTheme.primaryRed,
      size:
          20,
    );
  }

  // ============================================================
  // GENERAL UI HELPERS
  // ============================================================

  Widget _softIcon(
    IconData icon,
  ) {
    return Container(
      width:
          34,
      height:
          34,
      decoration:
          BoxDecoration(
        color: AppTheme.primaryRed
            .withOpacity(
          0.07,
        ),
        borderRadius:
            BorderRadius.circular(
          10,
        ),
      ),
      child:
          Icon(
        icon,
        color:
            AppTheme.primaryRed,
        size:
            17,
      ),
    );
  }

  BoxDecoration
      _cardDecoration() {
    return BoxDecoration(
      color:
          AppTheme.white,
      borderRadius:
          BorderRadius.circular(
        17,
      ),
      border:
          Border.all(
        color:
            AppTheme.borderGray,
      ),
    );
  }

  Widget _divider() {
    return const Padding(
      padding:
          EdgeInsets.symmetric(
        horizontal:
            14,
      ),
      child:
          Divider(
        height:
            1,
        color:
            AppTheme.borderGray,
      ),
    );
  }
}
