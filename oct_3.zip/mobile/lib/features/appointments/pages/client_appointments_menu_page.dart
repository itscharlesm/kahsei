import 'package:flutter/material.dart';

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/features/appointments/pages/client_assessed_appointments_page.dart';
import 'package:mobile_app/features/appointments/pages/client_completed_appointments_page.dart';
import 'package:mobile_app/features/appointments/pages/client_ongoing_appointments_page.dart';
import 'package:mobile_app/features/appointments/pages/client_scheduled_appointments_page.dart';
import 'package:mobile_app/shared/shared.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';
import 'package:mobile_app/features/appointments/pages/client_requested_appointments_page.dart';

class ClientAppointmentsMenuPage extends StatelessWidget {
  final String email;

  const ClientAppointmentsMenuPage({
    super.key,
    required this.email,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      drawer: AppDrawer(
        userType: 3,
        email: email,
        currentPage: 'appointments',
      ),

      appBar: const AppTitleHeader(
        title: 'My Appointments',
      ),

      bottomNavigationBar: ClientBottomNavBar(
        currentIndex: 3,
        email: email,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          20,
          18,
          20,
          30,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Appointment Status',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Choose a category to view and manage your service appointments.',
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 13,
                height: 1.35,
              ),
            ),

            const SizedBox(height: 20),

            _appointmentMenuCard(
              context: context,
              icon: Icons.description_outlined,
              title: 'Requested',
              description:
                  'View newly submitted service requests waiting for review.',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        ClientRequestedAppointmentsPage(
                      email: email,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 12),

            _appointmentMenuCard(
              context: context,
              icon: Icons.fact_check_outlined,
              title: 'Assessed',
              description:
                  'View requests that have already been reviewed and assessed.',
             onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ClientAssessedAppointmentsPage(
                      email: email,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 12),

            _appointmentMenuCard(
              context: context,
              icon: Icons.calendar_month_outlined,
              title: 'Scheduled',
              description:
                  'View approved appointments with confirmed service schedules.',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ClientScheduledAppointmentsPage(
                      email: email,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 12),

            _appointmentMenuCard(
              context: context,
              icon: Icons.route_outlined,
              title: 'Ongoing',
              description:
                  'Track pest control services that are currently in progress.',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ClientOngoingAppointmentsPage(
                      email: email,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 12),

            _appointmentMenuCard(
              context: context,
              icon: Icons.check_circle_outline_rounded,
              title: 'Completed',
              description:
                  'Review completed services, payments, reports, and ratings.',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ClientCompletedAppointmentsPage(
                      email: email,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _appointmentMenuCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String description,
    required VoidCallback onTap,
  }) {
    return Material(
      color: AppTheme.white,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: const Color(0xFF616161).withOpacity(0.20),
        highlightColor: const Color(0xFF616161).withOpacity(0.12),
        child: Ink(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.borderGray,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: AppTheme.primaryRed.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primaryRed,
                  size: 23,
                ),
              ),

              const SizedBox(width: 13),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: AppTheme.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),

                    const SizedBox(height: 5),

                    Text(
                      description,
                      style: const TextStyle(
                        color: AppTheme.gray,
                        fontSize: 11.5,
                        height: 1.35,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 10),

              const Icon(
                Icons.chevron_right_rounded,
                color: AppTheme.gray,
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }
}