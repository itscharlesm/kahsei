import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';

import 'package:mobile_app/features/appointments/widgets/client_appointment_card.dart';
import 'package:mobile_app/shared/widgets/loading/appointment_skeleton_list.dart';

class ClientRequestedAppointmentsPage extends StatefulWidget {
  final String email;

  const ClientRequestedAppointmentsPage({
    super.key,
    required this.email,
  });

  @override
  State<ClientRequestedAppointmentsPage> createState() =>
      _ClientRequestedAppointmentsPageState();
}

class _ClientRequestedAppointmentsPageState
    extends State<ClientRequestedAppointmentsPage> {
  // ============================================================
  // SCROLL
  // ============================================================

  final ScrollController _scrollController =
      ScrollController();

  // ============================================================
  // DATA
  // ============================================================

  List<Map<String, dynamic>> appointments = [];

  // ============================================================
  // PAGINATION
  // ============================================================

  int currentPage = 1;
  bool hasMore = true;

  // ============================================================
  // LOADING
  // ============================================================

  bool isLoading = true;
  bool isLoadingMore = false;

  // ============================================================
  // ERROR
  // ============================================================

  String? errorMessage;

  // ============================================================
  // INITIALIZE
  // ============================================================

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(
      _handleScroll,
    );

    _loadAppointments(
      reset: true,
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _scrollController.removeListener(
      _handleScroll,
    );

    _scrollController.dispose();

    super.dispose();
  }

  // ============================================================
  // LOAD REQUESTED APPOINTMENTS
  // ============================================================

  Future<void> _loadAppointments({
    bool reset = false,
  }) async {
    if (isLoadingMore) {
      return;
    }

    if (!reset && !hasMore) {
      return;
    }

    final page = reset
        ? 1
        : currentPage;

    if (!mounted) return;

    setState(() {
      if (reset || appointments.isEmpty) {
        isLoading = true;
      } else {
        isLoadingMore = true;
      }

      errorMessage = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}/api/mobile/appointments/client',
            ),
            headers: {
              'Accept': 'application/json',
            },
            body: {
              'email': widget.email,
              'status': 'REQUESTED',
              'page': page.toString(),
            },
          )
          .timeout(
            const Duration(seconds: 12),
          );

      final data = jsonDecode(
        response.body,
      );

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final List appointmentData =
            data['data'] ?? [];

        final newAppointments =
            appointmentData
                .map(_mapAppointment)
                .toList();

        final pagination =
            data['pagination'] is Map
                ? Map<String, dynamic>.from(
                    data['pagination'],
                  )
                : <String, dynamic>{};

        final responseHasMore =
            pagination['has_more'] == true;

        final nextPage =
            pagination['next_page'];

        setState(() {
          if (reset) {
            appointments =
                newAppointments;
          } else {
            appointments.addAll(
              newAppointments,
            );
          }

          hasMore =
              responseHasMore;

          if (responseHasMore &&
              nextPage != null) {
            currentPage =
                int.tryParse(
                      nextPage.toString(),
                    ) ??
                    (page + 1);
          } else {
            currentPage =
                page + 1;
          }

          isLoading = false;
          isLoadingMore = false;
          errorMessage = null;
        });
      } else {
        setState(() {
          isLoading = false;
          isLoadingMore = false;

          errorMessage =
              data['message']
                      ?.toString() ??
                  'Unable to load requested appointments.';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        isLoadingMore = false;

        errorMessage =
            'Unable to connect to the server.';
      });

      debugPrint(
        'REQUESTED APPOINTMENTS ERROR '
        '[PAGE $page]: $e',
      );
    }
  }

  // ============================================================
  // MAP APPOINTMENT
  // ============================================================

  Map<String, dynamic> _mapAppointment(
    dynamic item,
  ) {
    return {
      'id': item['svcas_id'],

      'schedule_id':
          item['svcas_id'],

      'scheduleId':
          item['svcas_id'],

      'appointment_id':
          item['svca_id'],

      'appointmentId':
          item['svca_id'],

      'status':
          item['svca_status'] ??
          'REQUESTED',

      'service':
          item['svc_is_termite'] == 1
              ? 'Termite Treatment'
              : 'General Pest Control',

      'schedule':
          '${_formatDate(item['svca_client_date'])} • '
          '${_formatTime(item['svca_client_time'])}',

      'startDate':
          item['svcas_start_date'],

      'startTime':
          item['svcas_start_time'],

      'locationType':
          'SERVICE LOCATION',

      'address':
          _formatAddress(
        Map<String, dynamic>.from(
          item,
        ),
      ),

      'price':
          '₱${_formatPrice(item['svc_balance'])}',

      'requestedDate':
          'Requested on '
          '${_formatDate(item['svca_date_created'])}',

      'isTermite':
          item['svc_is_termite'] == 1,

      'sqmDetails':
          item['svcpat_sqm_details'],

      'fullPestTypes':
          item['fullPestTypes'],

      'areaTypes':
          item['areaTypes'],

      'clientLatitude':
          item['uadd_latitude'],

      'clientLongitude':
          item['uadd_longitude'],

      'branchId':
          item['branch_id'],

      'branchName':
          item['branch_name'],

      'branchLatitude':
          item['branch_latitude'],

      'branchLongitude':
          item['branch_longitude'],

      'technicianName':
          item['technicianName'],

      'technicianMobile':
          item['technicianMobile'],

      'svc_id':
          item['svc_id'],

      'svc_sa_number':
          item['svc_sa_number'],

      'rating':
          item['svc_rating'],

      'dateRated':
          item['svc_date_rated'],

      'paymentId':
          item['spay_id'],

      'paymentTypeId':
          item['typ_id'],

      'paymentStatus':
          item['spay_status'],

      'paymentAmount':
          item['spay_amount'],

      'paymentDate':
          item['spay_date'],
    };
  }

  // ============================================================
  // SCROLL PAGINATION
  // ============================================================

  void _handleScroll() {
    if (!_scrollController.hasClients) {
      return;
    }

    final position =
        _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent - 180) {
      _loadMore();
    }
  }

  Future<void> _loadMore() async {
    if (!hasMore ||
        isLoading ||
        isLoadingMore) {
      return;
    }

    await _loadAppointments();
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refreshAppointments() async {
    currentPage = 1;
    hasMore = true;

    await _loadAppointments(
      reset: true,
    );
  }

  // ============================================================
  // REFRESH AFTER CARD ACTION
  // ============================================================

  Future<void>
      _refreshAfterAppointmentChange() async {
    await _refreshAppointments();
  }

  // ============================================================
  // FORMAT ADDRESS
  // ============================================================

  String _formatAddress(
    Map<String, dynamic> item,
  ) {
    final parts = [
      item['uadd_street'],
      item['uadd_barangay'],
      item['uadd_city'],
      item['uadd_province'],
    ];

    final address = parts
        .where(
          (part) =>
              part != null &&
              part
                  .toString()
                  .trim()
                  .isNotEmpty,
        )
        .join(', ');

    return address.isNotEmpty
        ? address
        : 'No address available';
  }

  // ============================================================
  // FORMAT PRICE
  // ============================================================

  String _formatPrice(
    dynamic value,
  ) {
    final price =
        double.tryParse(
              value?.toString() ??
                  '',
            ) ??
            0;

    return price.toStringAsFixed(
      2,
    );
  }

  // ============================================================
  // FORMAT DATE
  // ============================================================

  String _formatDate(
    dynamic value,
  ) {
    if (value == null) {
      return 'No date';
    }

    final date =
        DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[date.month - 1]} '
        '${date.day}, '
        '${date.year}';
  }

  // ============================================================
  // FORMAT TIME
  // ============================================================

  String _formatTime(
    dynamic value,
  ) {
    if (value == null) {
      return 'No time';
    }

    final time =
        value.toString();

    if (time.startsWith('08:00')) {
      return '8:00 AM - 12:00 PM';
    }

    if (time.startsWith('12:00')) {
      return '12:00 PM - 5:00 PM';
    }

    if (time.startsWith('17:00')) {
      return '5:00 PM - 8:00 PM';
    }

    return time;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      // Back button returns to
      // the Appointments Menu page.
      appBar: const AppBackHeader(
        title: 'Requested',
      ),

      // We are temporarily using
      // bottom-nav index 3 for the
      // Appointments Menu.
      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex: 3,
        email: widget.email,
      ),

      body: Padding(
        padding:
            const EdgeInsets.fromLTRB(
          20,
          18,
          20,
          0,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _pageHeader(),

            const SizedBox(
              height: 16,
            ),

            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _pageHeader() {
    return const Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Requested Appointments',
          style: TextStyle(
            color: AppTheme.black,
            fontSize: 18,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        SizedBox(height: 5),

        Text(
          'View newly submitted service requests that are waiting for review.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.35,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget _buildContent() {
    if (isLoading &&
        appointments.isEmpty) {
      return _appointmentsSkeleton();
    }

    if (errorMessage != null &&
        appointments.isEmpty) {
      return _errorState();
    }

    if (appointments.isEmpty) {
      return RefreshIndicator(
        color:
            AppTheme.primaryRed,
        onRefresh:
            _refreshAppointments,
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 90),

            _EmptyRequestedAppointments(),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _refreshAppointments,
      child: ListView.separated(
        controller:
            _scrollController,
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.only(
          bottom: 24,
        ),
        itemCount:
            appointments.length +
            (isLoadingMore ? 1 : 0),
        separatorBuilder:
            (_, __) =>
                const SizedBox(
          height: 12,
        ),
        itemBuilder:
            (context, index) {
          if (index >=
              appointments.length) {
            return const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 14,
              ),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child:
                      CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            );
          }

          return ClientAppointmentCard(
            appointment:
                appointments[index],
            email:
                widget.email,
            onRefresh:
                _refreshAfterAppointmentChange,
          );
        },
      ),
    );
  }

  // ============================================================
  // SKELETON
  // ============================================================

  Widget _appointmentsSkeleton() {
    return const AppointmentSkeletonList();
  }

  // ============================================================
  // ERROR STATE
  // ============================================================

  Widget _errorState() {
    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _refreshAppointments,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 85),

          Column(
            children: [
              Container(
                width: 68,
                height: 68,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  shape:
                      BoxShape.circle,
                ),
                child:
                    const Icon(
                  Icons.wifi_off_rounded,
                  color:
                      AppTheme.primaryRed,
                  size: 32,
                ),
              ),

              const SizedBox(
                height: 16,
              ),

              const Text(
                'Unable to load requests',
                style:
                    TextStyle(
                  color:
                      AppTheme.black,
                  fontSize: 16,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),

              const SizedBox(
                height: 7,
              ),

              Padding(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 28,
                ),
                child: Text(
                  errorMessage ??
                      'Please try again.',
                  textAlign:
                      TextAlign.center,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.gray,
                    fontSize: 13,
                    height: 1.35,
                  ),
                ),
              ),

              const SizedBox(
                height: 16,
              ),

              OutlinedButton.icon(
                onPressed: () {
                  _refreshAppointments();
                },
                icon:
                    const Icon(
                  Icons.refresh_rounded,
                  size: 18,
                ),
                label:
                    const Text(
                  'Retry',
                ),
                style:
                    OutlinedButton
                        .styleFrom(
                  foregroundColor:
                      AppTheme.primaryRed,
                  side:
                      const BorderSide(
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// EMPTY STATE
// ============================================================

class _EmptyRequestedAppointments
    extends StatelessWidget {
  const _EmptyRequestedAppointments();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      mainAxisSize:
          MainAxisSize.min,
      children: [
        Container(
          width: 68,
          height: 68,
          decoration:
              BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            shape:
                BoxShape.circle,
          ),
          child:
              const Icon(
            Icons.description_outlined,
            color:
                AppTheme.primaryRed,
            size: 34,
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        const Text(
          'No requested appointments',
          textAlign:
              TextAlign.center,
          style:
              TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        const Padding(
          padding:
              EdgeInsets.symmetric(
            horizontal: 28,
          ),
          child: Text(
            'New service requests that you submit will appear here.',
            textAlign:
                TextAlign.center,
            style:
                TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}
