import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';

class ClientCompletedAppointmentsServiceReport extends StatefulWidget {
  final String email;
  final int serviceId;

  const ClientCompletedAppointmentsServiceReport({
    super.key,
    required this.email,
    required this.serviceId,
  });

  @override
  State<ClientCompletedAppointmentsServiceReport> createState() =>
      _ClientCompletedAppointmentsServiceReportState();
}

class _ClientCompletedAppointmentsServiceReportState
    extends State<ClientCompletedAppointmentsServiceReport> {
  bool isLoading = true;

  Map<String, dynamic> reportData = {};

  @override
  void initState() {
    super.initState();
    _loadServiceReport();
  }

  // ============================================================
  // LOAD REPORT
  // ============================================================

  Future<void> _loadServiceReport() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}'
          '/api/mobile/client/service-report',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
          'svc_id': widget.serviceId.toString(),
        },
      );

      debugPrint(
        'CLIENT COMPLETED REPORT STATUS: ${response.statusCode}',
      );

      debugPrint(
        'CLIENT COMPLETED REPORT BODY: ${response.body}',
      );

      final dynamic decoded =
          jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 &&
          decoded is Map &&
          decoded['success'] == true) {
        final dynamic rawData =
            decoded['data'];

        final Map<String, dynamic> mappedData =
            rawData is Map
                ? Map<String, dynamic>.from(
                    rawData,
                  )
                : <String, dynamic>{};

        setState(() {
          reportData = mappedData;
          isLoading = false;
        });

        debugPrint(
          'REPORT SCHEDULE ID: ${reportData['scheduleId']}',
        );

        debugPrint(
          'REPORT APPOINTMENT ID: ${reportData['appointment_id']}',
        );

        debugPrint(
          'REPORT START: '
          '${reportData['svcas_start_date']} '
          '${reportData['svcas_start_time']}',
        );

        debugPrint(
          'REPORT END: '
          '${reportData['svcas_end_date']} '
          '${reportData['svcas_end_time']}',
        );

        debugPrint(
          'REPORT TRAVEL RAW: '
          '${reportData['travelTime']}',
        );

        debugPrint(
          'REPORT SERVICE RAW: '
          '${reportData['serviceTime']}',
        );

        debugPrint(
          'REPORT TOTAL RAW: '
          '${reportData['totalDuration']}',
        );

        debugPrint(
          'REPORT SUBMITTED RAW: '
          '${reportData['submittedDate']}',
        );
        return;
      }

      setState(() {
        reportData = {};
        isLoading = false;
      });
    } catch (error) {
      debugPrint(
        'CLIENT COMPLETED REPORT ERROR: $error',
      );

      if (!mounted) return;

      setState(() {
        reportData = {};
        isLoading = false;
      });
    }
  }

  // ============================================================
  // VALUE HELPERS
  // ============================================================

  dynamic _value(
    List<String> keys,
  ) {
    // Check the top level first.
    for (final key in keys) {
      final value = reportData[key];

      if (_hasUsableValue(value)) {
        return value;
      }
    }

    // Search all nested maps and lists.
    return _findNestedValue(
      reportData,
      keys,
    );
  }

  bool _hasUsableValue(
    dynamic value,
  ) {
    if (value == null) {
      return false;
    }

    if (value is String) {
      return value.trim().isNotEmpty;
    }

    return true;
  }

  dynamic _findNestedValue(
    dynamic source,
    List<String> keys,
  ) {
    if (source is Map) {
      for (final key in keys) {
        final value = source[key];

        if (_hasUsableValue(value) &&
            value is! Map &&
            value is! List) {
          return value;
        }
      }

      for (final value in source.values) {
        final result = _findNestedValue(
          value,
          keys,
        );

        if (_hasUsableValue(result)) {
          return result;
        }
      }
    }

    if (source is List) {
      for (final item in source) {
        final result = _findNestedValue(
          item,
          keys,
        );

        if (_hasUsableValue(result)) {
          return result;
        }
      }
    }

    return null;
  }

  String _text(
    dynamic value, [
    String fallback = 'Not available',
  ]) {
    if (value == null) {
      return fallback;
    }

    final String text =
        value.toString().trim();

    return text.isEmpty
        ? fallback
        : text;
  }

  bool _isTrue(
    dynamic value,
  ) {
    if (value is bool) {
      return value;
    }

    final String normalized =
        value
            ?.toString()
            .trim()
            .toLowerCase() ??
        '';

    return normalized == '1' ||
        normalized == 'true' ||
        normalized == 'yes';
  }

  int _intValue(
    List<String> keys,
  ) {
    return int.tryParse(
          _value(keys)?.toString() ?? '',
        ) ??
        0;
  }

  // ============================================================
  // REAL DISPLAY VALUES
  // ============================================================

  String get _saNumber {
    final String raw =
        _text(
          _value([
            'svc_sa_number',
            'saNumber',
            'sa_number',
          ]),
          '',
        );

    if (raw.isEmpty) {
      return 'Not available';
    }

    if (raw.toUpperCase().startsWith('SA-')) {
      return raw;
    }

    return 'SA-${raw.padLeft(6, '0')}';
  }

  String get _clientName {
    final dynamic direct =
        _value([
          'clientName',
          'client_name',
          'user_full_name',
          'full_name',
        ]);

    if (direct != null) {
      return _titleCase(
        direct.toString(),
      );
    }

    final String firstName =
        _text(
          _value([
            'usr_first_name',
            'user_first_name',
            'first_name',
          ]),
          '',
        );

    final String middleName =
        _text(
          _value([
            'usr_middle_name',
            'user_middle_name',
            'middle_name',
          ]),
          '',
        );

    final String lastName =
        _text(
          _value([
            'usr_last_name',
            'user_last_name',
            'last_name',
          ]),
          '',
        );

    final String name = [
      firstName,
      middleName,
      lastName,
    ].where(
      (part) => part.isNotEmpty,
    ).join(' ');

    return name.isEmpty
        ? 'Not available'
        : _titleCase(name);
  }

  String get _technicianName {
    final dynamic direct =
        _value([
          'technicianName',
          'technician_name',
          'assignedTechnician',
          'assigned_technician',
          'employee_name',
        ]);

    if (direct != null) {
      return _titleCase(
        direct.toString(),
      );
    }

    final dynamic technicians =
        reportData['teamTechnicians'] ??
        reportData['technicians'];

    if (technicians is List &&
        technicians.isNotEmpty) {
      final List<String> names =
          technicians
              .map(
                (item) {
                  if (item is Map) {
                    return _text(
                      item['name'] ??
                          item['technicianName'],
                      '',
                    );
                  }

                  return _text(
                    item,
                    '',
                  );
                },
              )
              .where(
                (name) => name.isNotEmpty,
              )
              .toList();

      if (names.isNotEmpty) {
        return names
            .map(_titleCase)
            .join(', ');
      }
    }

    return 'Not available';
  }

  String get _serviceName {
    final dynamic direct =
        _value([
          'service',
          'serviceName',
          'service_name',
        ]);

    if (direct != null &&
        direct is! Map) {
      return _titleCase(
        direct.toString(),
      );
    }

    return _isTrue(
      _value([
        'svc_is_termite',
        'isTermite',
      ]),
    )
        ? 'Termite Control'
        : 'General Pest Control';
  }

  String get _pestTypes {
    return _titleCase(
      _text(
        _value([
          'fullPestTypes',
          'pestType',
          'pestTypes',
          'pest_types',
        ]),
      ),
    );
  }

  String get _serviceAddress {
    final dynamic direct =
        _value([
          'address',
          'serviceAddress',
          'service_address',
          'full_address',
        ]);

    if (direct != null) {
      return _titleCase(
        direct.toString(),
      );
    }

    final List<dynamic> parts = [
      _value([
        'uadd_street',
        'street',
      ]),
      _value([
        'uadd_barangay',
        'barangay',
      ]),
      _value([
        'uadd_city',
        'city',
      ]),
      _value([
        'uadd_province',
        'province',
      ]),
    ];

    final String address =
        parts
            .where(
              (part) =>
                  part != null &&
                  part
                      .toString()
                      .trim()
                      .isNotEmpty,
            )
            .map(
              (part) => _titleCase(
                part.toString(),
              ),
            )
            .join(', ');

    return address.isEmpty
        ? 'Not available'
        : address;
  }

  String get _schedule {
    final dynamic direct =
        _value([
          'schedule',
          'approvedSchedule',
          'approved_schedule',
        ]);

    if (direct != null) {
      return direct.toString();
    }

    final String date =
        _formatDate(
          _value([
            'svca_approved_date',
            'svcas_start_date',
            'svca_client_date',
            'scheduleDate',
            'service_date',
          ]),
        );

    final String from =
        _formatTime(
          _value([
            'svca_approved_time_from',
            'svcas_start_time',
            'svca_client_time',
            'scheduleTime',
          ]),
        );

    final String to =
        _formatTime(
          _value([
            'svca_approved_time_to',
            'svcas_end_time',
          ]),
        );

    if (date == 'Not available' &&
        from == 'Not available') {
      return 'Not available';
    }

    String timeText = '';

    if (from != 'Not available' &&
        to != 'Not available') {
      timeText = '$from - $to';
    } else if (from != 'Not available') {
      timeText = from;
    }

    if (date != 'Not available' &&
        timeText.isNotEmpty) {
      return '$date • $timeText';
    }

    if (date != 'Not available') {
      return date;
    }

    return timeText;
  }

  int? _durationToSeconds(
    dynamic value,
  ) {
    if (value == null) {
      return null;
    }

    final text = value.toString().trim();

    if (text.isEmpty ||
        text.toUpperCase() == 'N/A' ||
        text == '-') {
      return null;
    }

    // Supports numeric seconds.
    final numericValue = double.tryParse(text);

    if (numericValue != null &&
        !text.contains(':')) {
      return numericValue.round();
    }

    // Supports HH:mm:ss and HH:mm.
    final parts = text.split(':');

    if (parts.length == 3) {
      final hours = int.tryParse(parts[0]);
      final minutes = int.tryParse(parts[1]);
      final seconds = double.tryParse(parts[2]);

      if (hours == null ||
          minutes == null ||
          seconds == null) {
        return null;
      }

      return (hours * 3600) +
          (minutes * 60) +
          seconds.round();
    }

    if (parts.length == 2) {
      final hours = int.tryParse(parts[0]);
      final minutes = int.tryParse(parts[1]);

      if (hours == null ||
          minutes == null) {
        return null;
      }

      return (hours * 3600) +
          (minutes * 60);
    }

    return null;
  }

  String _formatDurationValue(
    dynamic value,
  ) {
    final seconds = _durationToSeconds(
      value,
    );

    if (seconds == null) {
      return _text(value);
    }

    return _formatDurationSeconds(
      seconds,
    );
  }

  String _formatDurationSeconds(
    int totalSeconds,
  ) {
    final safeSeconds =
        totalSeconds < 0
            ? 0
            : totalSeconds;

    final hours =
        safeSeconds ~/ 3600;

    final minutes =
        (safeSeconds % 3600) ~/ 60;

    final seconds =
        safeSeconds % 60;

    final parts = <String>[];

    if (hours > 0) {
      parts.add(
        '$hours ${hours == 1 ? 'hour' : 'hours'}',
      );
    }

    if (minutes > 0) {
      parts.add(
        '$minutes ${minutes == 1 ? 'minute' : 'minutes'}',
      );
    }

    if (seconds > 0 ||
        parts.isEmpty) {
      parts.add(
        '$seconds ${seconds == 1 ? 'second' : 'seconds'}',
      );
    }

    return parts.join(' ');
  }

  String _computeServiceDuration({
    required dynamic totalDuration,
    required dynamic travelDuration,
  }) {
    final totalSeconds =
        _durationToSeconds(
      totalDuration,
    );

    final travelSeconds =
        _durationToSeconds(
      travelDuration,
    );

    if (totalSeconds == null) {
      return 'Not available';
    }

    if (travelSeconds == null) {
      return _formatDurationSeconds(
        totalSeconds,
      );
    }

    return _formatDurationSeconds(
      totalSeconds - travelSeconds,
    );
  }

  String get _travelTime {
    final dynamic value =
        reportData['travelTime'] ??
        reportData['svcas_time_travel'];

    return _formatDurationValue(value);
  }

  String get _serviceTime {
    final dynamic directValue =
        reportData['serviceTime'];

    if (_hasUsableValue(directValue)) {
      return _formatDurationValue(
        directValue,
      );
    }

    return _computeServiceDuration(
      totalDuration:
          reportData['totalDuration'] ??
          reportData['svcas_time_finished'],
      travelDuration:
          reportData['travelTime'] ??
          reportData['svcas_time_travel'],
    );
  }

  String get _totalDuration {
    final dynamic value =
        reportData['totalDuration'] ??
        reportData['svcas_time_finished'];

    return _formatDurationValue(value);
  }

  String get _submittedDate {
    return _formatDateTime(
      reportData['submittedDate'],
    );
  }

  String get _status {
    final String status =
        _text(
          _value([
            'status',
            'svca_status',
            'svc_status',
          ]),
          'DONE REPORT',
        ).toUpperCase();

    return status;
  }

  String get _recommendation {
    return _sentenceCase(
      _text(
        _value([
          'recommendation',
          'svc_technician_recommendation',
          'technicianRecommendation',
          'technician_recommendation',
        ]),
      ),
    );
  }

  String get _finalCost {
    final dynamic raw =
        _value([
          'svc_balance',
          'finalCost',
          'final_cost',
          'serviceCost',
          'service_cost',
          'spay_amount',
        ]);

    final double? amount =
        double.tryParse(
          raw?.toString() ?? '',
        );

    if (amount == null) {
      return 'Not available';
    }

    final List<String> parts =
        amount
            .toStringAsFixed(2)
            .split('.');

    final String whole =
        parts[0].replaceAllMapped(
      RegExp(
        r'\B(?=(\d{3})+(?!\d))',
      ),
      (_) => ',',
    );

    return '₱$whole.${parts[1]}';
  }

  String get _paymentStatus {
    final String status =
        _text(
          _value([
            'spay_status',
            'paymentStatus',
            'payment_status',
          ]),
          'Not submitted',
        ).toUpperCase();

    switch (status) {
      case 'FOR APPROVAL':
      case 'UNDER APPROVAL':
        return 'Payment Under Approval';

      case 'APPROVED':
        return 'Payment Approved';

      case 'REJECTED':
        return 'Payment Rejected';

      default:
        return _titleCase(status);
    }
  }

  String get _paymentDate {
    return _formatDate(
      _value([
        'spay_date',
        'paymentDate',
        'payment_date',
      ]),
    );
  }

  String _formatDateTime(
    dynamic value,
  ) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final DateTime? date =
        DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const List<String> months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    final int hour =
        date.hour == 0
            ? 12
            : date.hour > 12
                ? date.hour - 12
                : date.hour;

    final String period =
        date.hour >= 12
            ? 'PM'
            : 'AM';

    final String minute =
        date.minute
            .toString()
            .padLeft(2, '0');

    return '${months[date.month - 1]} '
        '${date.day}, ${date.year} • '
        '$hour:$minute $period';
  }

  // ============================================================
  // CAPTURED PESTS
  // ============================================================

  int get _ratsCaptured {
    return _intValue([
      'ratCaptured',
      'rat_captured',
      'svc_rat_captured',
    ]);
  }

  int get _snakesCaptured {
    return _intValue([
      'snakeCaptured',
      'snake_captured',
      'svc_snake_captured',
    ]);
  }

  int get _lizardsCaptured {
    return _intValue([
      'lizardCaptured',
      'lizard_captured',
      'svc_lizard_captured',
    ]);
  }

  int get _kittensCaptured {
    return _intValue([
      'kittenCaptured',
      'kitten_captured',
      'svc_kitten_captured',
    ]);
  }

  int get _othersCaptured {
    return _intValue([
      'otherCaptured',
      'other_captured',
      'svc_other_captured',
    ]);
  }

  int get _totalCaptured {
    return _ratsCaptured +
        _snakesCaptured +
        _lizardsCaptured +
        _kittensCaptured +
        _othersCaptured;
  }

  // ============================================================
  // CHEMICALS
  // ============================================================

  List<Map<String, dynamic>>
      get _chemicals {
    final List<dynamic> candidates = [
      reportData['chemicals'],
      reportData['service_chemicals'],
      reportData['report_chemicals'],
    ];

    final dynamic nestedReport =
        reportData['report'];

    if (nestedReport is Map) {
      candidates.add(
        nestedReport['chemicals'],
      );
    }

    for (final dynamic candidate
        in candidates) {
      if (candidate is List) {
        return candidate
            .whereType<Map>()
            .map(
              (item) =>
                  Map<String, dynamic>.from(
                item,
              ),
            )
            .toList();
      }
    }

    return [];
  }

  String _chemicalName(
    Map<String, dynamic> chemical,
  ) {
    return _titleCase(
      _text(
        chemical['name'] ??
            chemical['chem_name'] ??
            chemical['chemical_name'],
        'Chemical',
      ),
    );
  }

  String _chemicalExpected(
    Map<String, dynamic> chemical,
  ) {
    final String quantity =
        _text(
          chemical[
                  'expectedQuantity'] ??
              chemical[
                  'svcch_expected_quantity'],
          '',
        );

    final String unit =
        _text(
          chemical['unit'] ??
              chemical['svcch_unit'],
          '',
        );

    final String value = [
      quantity,
      unit,
    ].where(
      (part) => part.isNotEmpty,
    ).join(' ');

    return value.isEmpty
        ? 'Not available'
        : value;
  }

  String _chemicalActual(
    Map<String, dynamic> chemical,
  ) {
    final String quantity =
        _text(
          chemical[
                  'actualQuantity'] ??
              chemical[
                  'svcch_actual_quantity'] ??
              chemical['quantity'],
          '',
        );

    final String unit =
        _text(
          chemical['unit'] ??
              chemical['svcch_unit'],
          '',
        );

    final String value = [
      quantity,
      unit,
    ].where(
      (part) => part.isNotEmpty,
    ).join(' ');

    return value.isEmpty
        ? 'Not available'
        : value;
  }

  // ============================================================
  // IMAGES
  // ============================================================

  List<String> get _imageUrls {
    final List<dynamic> candidates = [
      reportData['images'],
      reportData['photos'],
      reportData['area_photos'],
      reportData['service_photos'],
    ];

    final dynamic nestedReport =
        reportData['report'];

    if (nestedReport is Map) {
      candidates.add(
        nestedReport['images'],
      );
    }

    for (final dynamic candidate
        in candidates) {
      if (candidate is List) {
        return candidate
            .map(
              (item) {
                if (item is String) {
                  return item;
                }

                if (item is Map) {
                  return _text(
                    item['url'] ??
                        item['image_url'] ??
                        item['photo_url'] ??
                        item['path'],
                    '',
                  );
                }

                return '';
              },
            )
            .where(
              (url) => url.isNotEmpty,
            )
            .map(_resolveImageUrl)
            .toList();
      }
    }

    return [];
  }

  String _resolveImageUrl(
    String value,
  ) {
    if (value.startsWith('http://') ||
        value.startsWith('https://')) {
      return value;
    }

    final String cleaned =
        value.startsWith('/')
            ? value.substring(1)
            : value;

    return '${ApiConfig.baseUrl}/$cleaned';
  }

  // ============================================================
  // FORMATTERS
  // ============================================================

  String _formatDate(
    dynamic value,
  ) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final DateTime? date =
        DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const List<String> months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[date.month - 1]} '
        '${date.day}, ${date.year}';
  }

  String _formatTime(
    dynamic value,
  ) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final String text =
        value.toString().trim();

    final List<String> parts =
        text.split(':');

    if (parts.length < 2) {
      return text;
    }

    final int? hour =
        int.tryParse(parts[0]);

    final int? minute =
        int.tryParse(parts[1]);

    if (hour == null ||
        minute == null) {
      return text;
    }

    final int displayHour =
        hour == 0
            ? 12
            : hour > 12
                ? hour - 12
                : hour;

    final String period =
        hour >= 12
            ? 'PM'
            : 'AM';

    return '$displayHour:'
        '${minute.toString().padLeft(2, '0')} '
        '$period';
  }

  String _titleCase(
    String value,
  ) {
    final String text =
        value.trim();

    if (text.isEmpty ||
        text == 'Not available') {
      return text;
    }

    return text
        .toLowerCase()
        .split(
          RegExp(r'\s+'),
        )
        .map(
          (word) {
            if (word.isEmpty) {
              return word;
            }

            return word[0].toUpperCase() +
                word.substring(1);
          },
        )
        .join(' ');
  }

  String _sentenceCase(
    String value,
  ) {
    final String text =
        value.trim();

    if (text.isEmpty ||
        text == 'Not available') {
      return text;
    }

    final String lower =
        text.toLowerCase();

    return lower[0].toUpperCase() +
        lower.substring(1);
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      appBar: const AppBackHeader(
        title: 'Service Report',
      ),

      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex: 3,
        email: widget.email,
      ),

      body:
          isLoading
              ? _loadingContent()
              : _reportContent(),
    );
  }

  Widget _reportContent() {
    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _loadServiceReport,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.fromLTRB(
          20,
          18,
          20,
          30,
        ),
        children: [
          _headerCard(),

          const SizedBox(height: 14),

          _sectionCard(
            title:
                'SERVICE SUMMARY',
            icon:
                Icons.assignment_turned_in_outlined,
            children: [
              _ReportRow(
                icon:
                    Icons.confirmation_number_outlined,
                label:
                    'SA Number',
                value:
                    _saNumber,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.person_outline_rounded,
                label:
                    'Client',
                value:
                    _clientName,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.engineering_outlined,
                label:
                    'Technician',
                value:
                    _technicianName,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.pest_control_outlined,
                label:
                    'Service Type',
                value:
                    _serviceName,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.bug_report_outlined,
                label:
                    'Pest Type',
                value:
                    _pestTypes,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.location_on_outlined,
                label:
                    'Service Address',
                value:
                    _serviceAddress,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.calendar_month_outlined,
                label:
                    'Service Schedule',
                value:
                    _schedule,
              ),
            ],
          ),

          const SizedBox(height: 14),

          _sectionCard(
            title:
                'SERVICE DURATION',
            icon:
                Icons.timer_outlined,
            children: [
              _ReportRow(
                icon:
                    Icons.route_outlined,
                label:
                    'Travel Time',
                value:
                    _travelTime,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.home_repair_service_outlined,
                label:
                    'Service Time',
                value:
                    _serviceTime,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.schedule_outlined,
                label:
                    'Total Duration',
                value:
                    _totalDuration,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.event_available_outlined,
                label:
                    'Submitted Date',
                value:
                    _submittedDate,
              ),
            ],
          ),

          const SizedBox(height: 14),

          _capturedPestsSection(),

          const SizedBox(height: 14),

          _chemicalsSection(),

          const SizedBox(height: 14),

          _evidenceSection(),

          const SizedBox(height: 14),

          _sectionCard(
            title:
                'TECHNICIAN RECOMMENDATION',
            icon:
                Icons.tips_and_updates_outlined,
            children: [
              _RecommendationBox(
                text:
                    _recommendation,
              ),
            ],
          ),

          const SizedBox(height: 14),

          _sectionCard(
            title:
                'PAYMENT INFORMATION',
            icon:
                Icons.payments_outlined,
            children: [
              _ReportRow(
                icon:
                    Icons.receipt_long_outlined,
                label:
                    'Final Service Cost',
                value:
                    _finalCost,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.verified_outlined,
                label:
                    'Payment Status',
                value:
                    _paymentStatus,
              ),

              const _ReportDivider(),

              _ReportRow(
                icon:
                    Icons.calendar_today_outlined,
                label:
                    'Payment Date',
                value:
                    _paymentDate,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _headerCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        16,
        16,
        16,
        15,
      ),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ============================================================
          // ICON + REPORT TITLE + SERVICE NAME
          // ============================================================

          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.description_outlined,
                  color: AppTheme.white,
                  size: 22,
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'COMPLETED SERVICE REPORT',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppTheme.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.25,
                      ),
                    ),

                    const SizedBox(height: 5),

                    Text(
                      _serviceName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        height: 1.15,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ============================================================
          // DESCRIPTION
          // ============================================================

          Text(
            'Review the technician’s completed service report, '
            'including service results, captured pests, image evidence, '
            'and recommendations.',
            style: TextStyle(
              color: AppTheme.white.withOpacity(0.88),
              fontSize: 12,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CAPTURED PESTS
  // ============================================================

  Widget _capturedPestsSection() {
    final List<Map<String, dynamic>>
        items = [
      {
        'label': 'Rats',
        'value': _ratsCaptured,
        'icon':
            Icons.pest_control_rodent,
      },
      {
        'label': 'Snakes',
        'value': _snakesCaptured,
        'icon':
            Icons.waves_outlined,
      },
      {
        'label': 'Lizards',
        'value': _lizardsCaptured,
        'icon':
            Icons.cruelty_free_outlined,
      },
      {
        'label': 'Kittens',
        'value': _kittensCaptured,
        'icon':
            Icons.pets_outlined,
      },
      {
        'label': 'Others',
        'value': _othersCaptured,
        'icon':
            Icons.more_horiz_rounded,
      },
    ];

    return _sectionCard(
      title:
          'CAPTURED PESTS',
      icon:
          Icons.catching_pokemon_outlined,
      children: [
        Container(
          width:
              double.infinity,
          padding:
              const EdgeInsets.all(12),
          decoration:
              BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(0.06),
            borderRadius:
                BorderRadius.circular(12),
          ),
          child:
              Row(
            children: [
              const Icon(
                Icons.numbers_rounded,
                color:
                    AppTheme.primaryRed,
                size: 20,
              ),

              const SizedBox(
                width: 10,
              ),

              const Expanded(
                child:
                    Text(
                  'Total Captured',
                  style:
                      TextStyle(
                    color:
                        AppTheme.black,
                    fontSize: 12,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ),

              Text(
                _totalCaptured
                    .toString(),
                style:
                    const TextStyle(
                  color:
                      AppTheme.primaryRed,
                  fontSize: 17,
                  fontWeight:
                      FontWeight.w900,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        Wrap(
          spacing: 8,
          runSpacing: 8,
          children:
              items.map(
            (item) {
              return SizedBox(
                width:
                    (MediaQuery.of(context)
                                .size
                                .width -
                            64) /
                        2,
                child:
                    _CapturedPestCard(
                  label:
                      item['label']
                          as String,
                  value:
                      item['value']
                          as int,
                  icon:
                      item['icon']
                          as IconData,
                ),
              );
            },
          ).toList(),
        ),
      ],
    );
  }

  // ============================================================
  // CHEMICALS
  // ============================================================

  Widget _chemicalsSection() {
    return _sectionCard(
      title: 'CHEMICALS USED',
      icon: Icons.science_outlined,
      children: [
        if (_chemicals.isEmpty)
          const _EmptyReportSection(
            icon: Icons.science_outlined,
            text:
                'No chemicals were recorded for this service.',
          )
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _chemicals.map(
              (chemical) {
                return Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryRed
                        .withOpacity(0.06),
                    borderRadius:
                        BorderRadius.circular(10),
                    border: Border.all(
                      color: AppTheme.primaryRed
                          .withOpacity(0.14),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.science_outlined,
                        size: 16,
                        color: AppTheme.primaryRed,
                      ),

                      const SizedBox(width: 7),

                      Flexible(
                        child: Text(
                          _chemicalName(
                            chemical,
                          ),
                          style: const TextStyle(
                            color: AppTheme.black,
                            fontSize: 12,
                            fontWeight:
                                FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ).toList(),
          ),
      ],
    );
  }

  // ============================================================
  // EVIDENCE
  // ============================================================

  Widget _evidenceSection() {
    return _sectionCard(
      title:
          'SERVICE PHOTOS',
      icon:
          Icons.photo_library_outlined,
      children: [
        if (_imageUrls.isEmpty)
          const _EmptyReportSection(
            icon:
                Icons.photo_library_outlined,
            text:
                'No service photos are currently available.',
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics:
                const NeverScrollableScrollPhysics(),
            itemCount:
                _imageUrls.length,
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1.15,
            ),
            itemBuilder:
                (
              context,
              index,
            ) {
              final String url =
                  _imageUrls[index];

              return GestureDetector(
                onTap: () {
                  _openImage(
                    url,
                  );
                },
                child:
                    ClipRRect(
                  borderRadius:
                      BorderRadius.circular(
                    12,
                  ),
                  child:
                      Image.network(
                    url,
                    fit:
                        BoxFit.cover,
                    errorBuilder:
                        (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return Container(
                        color:
                            AppTheme.lightGray,
                        alignment:
                            Alignment.center,
                        child:
                            const Icon(
                          Icons.broken_image_outlined,
                          color:
                              AppTheme.gray,
                          size: 28,
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          ),
      ],
    );
  }

  void _openImage(
    String url,
  ) {
    showDialog(
      context:
          context,
      builder:
          (_) {
        return Dialog(
          backgroundColor:
              Colors.transparent,
          insetPadding:
              const EdgeInsets.all(18),
          child:
              Stack(
            children: [
              ClipRRect(
                borderRadius:
                    BorderRadius.circular(
                  16,
                ),
                child:
                    InteractiveViewer(
                  child:
                      Image.network(
                    url,
                    fit:
                        BoxFit.contain,
                  ),
                ),
              ),

              Positioned(
                top: 8,
                right: 8,
                child:
                    Material(
                  color:
                      Colors.black
                          .withOpacity(
                    0.55,
                  ),
                  shape:
                      const CircleBorder(),
                  child:
                      IconButton(
                    onPressed:
                        () {
                      Navigator.pop(
                        context,
                      );
                    },
                    icon:
                        const Icon(
                      Icons.close_rounded,
                      color:
                          Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ============================================================
  // COMMON UI
  // ============================================================

  Widget _sectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(15),
      decoration:
          BoxDecoration(
        color:
            AppTheme.white,
        borderRadius:
            BorderRadius.circular(18),
        border:
            Border.all(
          color:
              AppTheme.borderGray,
        ),
      ),
      child:
          Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration:
                    BoxDecoration(
                  color:
                      AppTheme.primaryRed
                          .withOpacity(
                    0.08,
                  ),
                  borderRadius:
                      BorderRadius.circular(
                    9,
                  ),
                ),
                child:
                    Icon(
                  icon,
                  color:
                      AppTheme.primaryRed,
                  size: 17,
                ),
              ),

              const SizedBox(
                width: 9,
              ),

              Expanded(
                child:
                    Text(
                  title,
                  style:
                      const TextStyle(
                    color:
                        AppTheme.black,
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w900,
                    letterSpacing:
                        0.45,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 13,
          ),

          ...children,
        ],
      ),
    );
  }

  Widget _loadingContent() {
    return ListView.separated(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        18,
        20,
        30,
      ),
      itemCount: 6,
      separatorBuilder:
          (_, __) =>
              const SizedBox(
        height: 14,
      ),
      itemBuilder:
          (
        context,
        index,
      ) {
        return Container(
          height:
              index == 0
                  ? 125
                  : 180,
          decoration:
              BoxDecoration(
            color:
                AppTheme.borderGray
                    .withOpacity(
              0.35,
            ),
            borderRadius:
                BorderRadius.circular(
              18,
            ),
          ),
        );
      },
    );
  }
}

class _ReportRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _ReportRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color:
              AppTheme.gray,
          size: 18,
        ),

        const SizedBox(
          width: 10,
        ),

        Expanded(
          child:
              Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style:
                    const TextStyle(
                  color:
                      AppTheme.gray,
                  fontSize: 9,
                  fontWeight:
                      FontWeight.w800,
                  letterSpacing:
                      0.25,
                ),
              ),

              const SizedBox(
                height: 4,
              ),

              Text(
                value,
                style:
                    const TextStyle(
                  color:
                      AppTheme.black,
                  fontSize: 12.5,
                  height: 1.35,
                  fontWeight:
                      FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ReportDivider
    extends StatelessWidget {
  const _ReportDivider();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        vertical: 12,
      ),
      child:
          Divider(
        height: 1,
        thickness: 1,
        color:
            AppTheme.borderGray
                .withOpacity(
          0.7,
        ),
      ),
    );
  }
}

class _CapturedPestCard
    extends StatelessWidget {
  final String label;
  final int value;
  final IconData icon;

  const _CapturedPestCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(11),
      decoration:
          BoxDecoration(
        color:
            AppTheme.lightGray
                .withOpacity(
          0.55,
        ),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child:
          Row(
        children: [
          Icon(
            icon,
            color:
                AppTheme.gray,
            size: 18,
          ),

          const SizedBox(
            width: 8,
          ),

          Expanded(
            child:
                Text(
              label,
              style:
                  const TextStyle(
                color:
                    AppTheme.black,
                fontSize: 11,
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),

          Text(
            value.toString(),
            style:
                const TextStyle(
              color:
                  AppTheme.primaryRed,
              fontSize: 14,
              fontWeight:
                  FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _ChemicalItem
    extends StatelessWidget {
  final String name;
  final String expectedQuantity;
  final String actualQuantity;

  const _ChemicalItem({
    required this.name,
    required this.expectedQuantity,
    required this.actualQuantity,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration:
              BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            borderRadius:
                BorderRadius.circular(
              10,
            ),
          ),
          child:
              const Icon(
            Icons.science_rounded,
            color:
                AppTheme.primaryRed,
            size: 18,
          ),
        ),

        const SizedBox(
          width: 10,
        ),

        Expanded(
          child:
              Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style:
                    const TextStyle(
                  color:
                      AppTheme.black,
                  fontSize: 12.5,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),

              const SizedBox(
                height: 5,
              ),

              Text(
                'Expected: $expectedQuantity',
                style:
                    const TextStyle(
                  color:
                      AppTheme.gray,
                  fontSize: 10.5,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),

              const SizedBox(
                height: 2,
              ),

              Text(
                'Actual used: $actualQuantity',
                style:
                    const TextStyle(
                  color:
                      AppTheme.primaryRed,
                  fontSize: 10.5,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _RecommendationBox
    extends StatelessWidget {
  final String text;

  const _RecommendationBox({
    required this.text,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.all(12),
      decoration:
          BoxDecoration(
        color:
            AppTheme.lightGray
                .withOpacity(
          0.55,
        ),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child:
          Text(
        text,
        style:
            const TextStyle(
          color:
              AppTheme.black,
          fontSize: 12,
          height: 1.45,
          fontWeight:
              FontWeight.w600,
        ),
      ),
    );
  }
}

class _EmptyReportSection
    extends StatelessWidget {
  final IconData icon;
  final String text;

  const _EmptyReportSection({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width:
          double.infinity,
      padding:
          const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 16,
      ),
      decoration:
          BoxDecoration(
        color:
            AppTheme.lightGray
                .withOpacity(
          0.55,
        ),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child:
          Row(
        children: [
          Icon(
            icon,
            color:
                AppTheme.gray,
            size: 19,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child:
                Text(
              text,
              style:
                  const TextStyle(
                color:
                    AppTheme.gray,
                fontSize: 11.5,
                height: 1.35,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
