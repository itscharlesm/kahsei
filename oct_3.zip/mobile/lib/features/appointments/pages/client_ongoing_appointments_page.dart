import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/features/appointments/widgets/client_appointment_card.dart';

import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
import 'package:mobile_app/shared/widgets/loading/appointment_skeleton_list.dart';

class ClientOngoingAppointmentsPage extends StatefulWidget {
  final String email;

  const ClientOngoingAppointmentsPage({
    super.key,
    required this.email,
  });

  @override
  State<ClientOngoingAppointmentsPage> createState() =>
      _ClientOngoingAppointmentsPageState();
}

class _ClientOngoingAppointmentsPageState
    extends State<ClientOngoingAppointmentsPage> {
  final ScrollController _scrollController =
      ScrollController();

  List<Map<String, dynamic>> appointments = [];

  int currentPage = 1;
  bool hasMore = true;

  bool isLoading = true;
  bool isLoadingMore = false;

  String? errorMessage;

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(
      _handleScroll,
    );

    _loadAppointments(
      reset: true,
    );
  }

  @override
  void dispose() {
    _scrollController.removeListener(
      _handleScroll,
    );

    _scrollController.dispose();

    super.dispose();
  }

  // ============================================================
  // LOAD ONGOING APPOINTMENTS
  // ============================================================

  Future<void> _loadAppointments({
    bool reset = false,
  }) async {
    if (isLoadingMore) {
      return;
    }

    if (!reset && !hasMore) {
      return;
    }

    final page = reset
        ? 1
        : currentPage;

    if (!mounted) return;

    setState(() {
      if (reset || appointments.isEmpty) {
        isLoading = true;
      } else {
        isLoadingMore = true;
      }

      errorMessage = null;
    });

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}'
          '/api/mobile/appointments/client',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
          'status': 'ONGOING',
          'page': page.toString(),
        },
      );
      dynamic decodedData;

      try {
        decodedData = jsonDecode(
          response.body,
        );
      } catch (_) {
        throw const FormatException(
          'Invalid response from the server.',
        );
      }

      if (!mounted) return;

      if (response.statusCode == 200 &&
          decodedData is Map &&
          decodedData['success'] == true) {
        final List rawAppointments =
            decodedData['data'] ?? [];

        final newAppointments =
            rawAppointments
                .map(_mapAppointment)
                .toList();

        final pagination =
            decodedData['pagination'] is Map
                ? Map<String, dynamic>.from(
                    decodedData['pagination'],
                  )
                : <String, dynamic>{};

        final responseHasMore =
            pagination['has_more'] == true;

        final nextPage =
            pagination['next_page'];

        setState(() {
          if (reset) {
            appointments =
                newAppointments;
          } else {
            appointments.addAll(
              newAppointments,
            );
          }

          hasMore =
              responseHasMore;

          if (responseHasMore &&
              nextPage != null) {
            currentPage =
                int.tryParse(
                      nextPage.toString(),
                    ) ??
                    (page + 1);
          } else {
            currentPage =
                page + 1;
          }

          isLoading = false;
          isLoadingMore = false;
          errorMessage = null;
        });

        return;
      }

      setState(() {
        isLoading = false;
        isLoadingMore = false;

        errorMessage =
            decodedData is Map
                ? decodedData['message']
                        ?.toString() ??
                    'Unable to load ongoing appointments.'
                : 'Unable to load ongoing appointments.';
      });
    } catch (error) {
      if (!mounted) return;

      debugPrint(
        'ONGOING APPOINTMENTS ERROR '
        '[PAGE $page]: $error',
      );

      // Keep the loading state while retrying.
      await Future.delayed(
        const Duration(seconds: 2),
      );

      if (!mounted) return;

      await _loadAppointments(
        reset: reset,
      );
    }
  }

  // ============================================================
  // MAP APPOINTMENT
  // ============================================================

  Map<String, dynamic> _mapAppointment(
    dynamic rawItem,
  ) {
    final item =
        Map<String, dynamic>.from(
      rawItem as Map,
    );

    final scheduleId =
        item['svcas_id'];

    return {
      'id':
          scheduleId ??
          item['svca_id'],

      // Required by ClientTrackingPage.
      'schedule_id':
          scheduleId,

      'scheduleId':
          scheduleId,

      'svcas_id':
          scheduleId,

      'appointment_id':
          item['svca_id'],

      'appointmentId':
          item['svca_id'],

      'svca_id':
          item['svca_id'],

      'svc_id':
          item['svc_id'],

      'svc_sa_number':
          item['svc_sa_number'],

      // ============================================================
      // ASSIGNED TECHNICIANS
      // ============================================================

      'technicianCount':
          int.tryParse(
            item['technicianCount']
                    ?.toString() ??
                '0',
          ) ??
          0,

      'isMultipleTechnician':
          _isTrue(
            item['isMultipleTechnician'],
          ),

      'teamTechnicians':
          item['teamTechnicians']
                  is List
              ? List<Map<String, dynamic>>.from(
                  (item['teamTechnicians'] as List)
                      .whereType<Map>()
                      .map(
                        (technician) =>
                            Map<String, dynamic>.from(
                          technician,
                        ),
                      ),
                )
              : <Map<String, dynamic>>[],

      'leaderId':
          item['leaderId'] ??
          item['svcas_modified_by'],

      'status':
          item['svca_status'] ??
          'ONGOING',

      'service':
          _isTrue(
            item['svc_is_termite'],
          )
              ? 'Termite Control'
              : 'General Pest Control',

      // Display the approved appointment schedule on the card.
      'schedule':
          _formatApprovedSchedule(
        date:
            item['svca_approved_date'],
        timeFrom:
            item['svca_approved_time_from'],
        timeTo:
            item['svca_approved_time_to'],
      ),

      'scheduledDate':
          item['svca_approved_date'],

      'scheduledTimeFrom':
          item['svca_approved_time_from'],

      'scheduledTimeTo':
          item['svca_approved_time_to'],

      'approvedDate':
          item['svca_approved_date'],

      'approvedTimeFrom':
          item['svca_approved_time_from'],

      'approvedTimeTo':
          item['svca_approved_time_to'],

      'dateApproved':
          item['svca_date_approved'],

      // Preserve the actual technician activity start values
      // for tracking and the future Ongoing details page.
      'startDate':
          item['svcas_start_date'],

      'startTime':
          item['svcas_start_time'],

      'clientRequestedDate':
          item['svca_client_date'],

      'clientRequestedTime':
          item['svca_client_time'],

      'locationType':
          'SERVICE LOCATION',

      'address':
          _formatAddress(item),

      'price':
          '₱${_formatPrice(item['svc_balance'])}',

      'requestedDate':
          'Requested on '
          '${_formatDate(item['svca_date_created'])}',

      'isTermite':
          _isTrue(
            item['svc_is_termite'],
          ),

      'sqmDetails':
          item['svcpat_sqm_details'],

      'fullPestTypes':
          item['fullPestTypes'],

      'areaTypes':
          item['areaTypes'],

      // Client location used on tracking map.
      'clientLatitude':
          item['uadd_latitude'],

      'clientLongitude':
          item['uadd_longitude'],

      'latitude':
          item['uadd_latitude'],

      'longitude':
          item['uadd_longitude'],

      'branchId':
          item['branch_id'],

      'branchName':
          item['branch_name'],

      'branchLatitude':
          item['branch_latitude'],

      'branchLongitude':
          item['branch_longitude'],

      // These will work once the controller includes technician data.
      'technicianName':
          item['technicianName'],

      'technicianMobile':
          item['technicianMobile'],

      'technicianId':
          item['technicianId'],

      'rating':
          item['svc_rating'],

      'dateRated':
          item['svc_date_rated'],

      'paymentId':
          item['spay_id'],

      'paymentTypeId':
          item['typ_id'],

      'paymentStatus':
          item['spay_status'],

      'paymentAmount':
          item['spay_amount'],

      'paymentDate':
          item['spay_date'],
    };
  }

  // ============================================================
  // SCROLL PAGINATION
  // ============================================================

  void _handleScroll() {
    if (!_scrollController.hasClients) {
      return;
    }

    final position =
        _scrollController.position;

    if (position.pixels >=
        position.maxScrollExtent - 180) {
      _loadMore();
    }
  }

  Future<void> _loadMore() async {
    if (!hasMore ||
        isLoading ||
        isLoadingMore) {
      return;
    }

    await _loadAppointments();
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refreshAppointments() async {
    currentPage = 1;
    hasMore = true;

    await _loadAppointments(
      reset: true,
    );
  }

  Future<void>
      _refreshAfterAppointmentChange() async {
    await _refreshAppointments();
  }

  // ============================================================
  // HELPERS
  // ============================================================

  bool _isTrue(
    dynamic value,
  ) {
    if (value is bool) {
      return value;
    }

    final normalized =
        value
            ?.toString()
            .trim()
            .toLowerCase();

    return normalized == '1' ||
        normalized == 'true';
  }

  // ============================================================
  // FORMAT SCHEDULE
  // ============================================================

  String _formatApprovedSchedule({
    required dynamic date,
    required dynamic timeFrom,
    required dynamic timeTo,
  }) {
    final dateText =
        _formatDate(date);

    final fromText =
        _formatSingleTime(timeFrom);

    final toText =
        _formatSingleTime(timeTo);

    final hasDate =
        dateText != 'No date';

    final hasFrom =
        fromText != 'No time';

    final hasTo =
        toText != 'No time';

    if (!hasDate &&
        !hasFrom &&
        !hasTo) {
      return 'Schedule not available';
    }

    String timeText = '';

    if (hasFrom && hasTo) {
      timeText =
          '$fromText - $toText';
    } else if (hasFrom) {
      timeText = fromText;
    } else if (hasTo) {
      timeText = toText;
    }

    if (hasDate &&
        timeText.isNotEmpty) {
      return '$dateText • $timeText';
    }

    if (hasDate) {
      return dateText;
    }

    return timeText;
  }

  // ============================================================
  // FORMAT ADDRESS
  // ============================================================

  String _formatAddress(
    Map<String, dynamic> item,
  ) {
    final parts = [
      item['uadd_street'],
      item['uadd_barangay'],
      item['uadd_city'],
      item['uadd_province'],
    ];

    final address = parts
        .where(
          (part) =>
              part != null &&
              part
                  .toString()
                  .trim()
                  .isNotEmpty,
        )
        .map(
          (part) =>
              part.toString().trim(),
        )
        .join(', ');

    return address.isNotEmpty
        ? address
        : 'No address available';
  }

  // ============================================================
  // FORMAT PRICE
  // ============================================================

  String _formatPrice(
    dynamic value,
  ) {
    final price =
        double.tryParse(
              value?.toString() ??
                  '',
            ) ??
            0;

    final wholePart =
        price.truncate().toString();

    final decimals =
        price
            .toStringAsFixed(2)
            .split('.')[1];

    final formattedWhole =
        wholePart.replaceAllMapped(
      RegExp(
        r'\B(?=(\d{3})+(?!\d))',
      ),
      (match) => ',',
    );

    return '$formattedWhole.$decimals';
  }

  // ============================================================
  // FORMAT DATE
  // ============================================================

  String _formatDate(
    dynamic value,
  ) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'No date';
    }

    final date =
        DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[date.month - 1]} '
        '${date.day}, '
        '${date.year}';
  }

  // ============================================================
  // FORMAT TIME
  // ============================================================

  String _formatSingleTime(
    dynamic value,
  ) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'No time';
    }

    final text =
        value.toString().trim();

    final parts =
        text.split(':');

    if (parts.length < 2) {
      return text;
    }

    final hour =
        int.tryParse(parts[0]);

    final minute =
        int.tryParse(parts[1]);

    if (hour == null ||
        minute == null) {
      return text;
    }

    final displayHour =
        hour == 0
            ? 12
            : hour > 12
                ? hour - 12
                : hour;

    final period =
        hour >= 12
            ? 'PM'
            : 'AM';

    return '$displayHour:'
        '${minute.toString().padLeft(2, '0')} '
        '$period';
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          AppTheme.lightGray,

      appBar: const AppBackHeader(
        title: 'Ongoing',
      ),

      bottomNavigationBar:
          ClientBottomNavBar(
        currentIndex: 3,
        email: widget.email,
      ),

      body: Padding(
        padding:
            const EdgeInsets.fromLTRB(
          20,
          18,
          20,
          0,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _pageHeader(),

            const SizedBox(
              height: 16,
            ),

            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _pageHeader() {
    return const Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Ongoing Appointments',
          style: TextStyle(
            color: AppTheme.black,
            fontSize: 18,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        SizedBox(height: 5),

        Text(
          'Track service appointments that are currently in progress.',
          style: TextStyle(
            color: AppTheme.gray,
            fontSize: 13,
            height: 1.35,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget _buildContent() {
    if (isLoading &&
        appointments.isEmpty) {
      return _appointmentsSkeleton();
    }

    if (appointments.isEmpty) {
      return RefreshIndicator(
        color:
            AppTheme.primaryRed,
        onRefresh:
            _refreshAppointments,
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 90),

            _EmptyOngoingAppointments(),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color:
          AppTheme.primaryRed,
      onRefresh:
          _refreshAppointments,
      child: ListView.separated(
        controller:
            _scrollController,
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.only(
          bottom: 24,
        ),
        itemCount:
            appointments.length +
            (isLoadingMore ? 1 : 0),
        separatorBuilder:
            (_, __) =>
                const SizedBox(
          height: 12,
        ),
        itemBuilder:
            (context, index) {
          if (index >=
              appointments.length) {
            return const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 14,
              ),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child:
                      CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color:
                        AppTheme.primaryRed,
                  ),
                ),
              ),
            );
          }

          return ClientAppointmentCard(
            appointment:
                appointments[index],
            email:
                widget.email,
            onRefresh:
                _refreshAfterAppointmentChange,
          );
        },
      ),
    );
  }

  // ============================================================
  // SKELETON
  // ============================================================

  Widget _appointmentsSkeleton() {
    return const AppointmentSkeletonList();
  }
}

// ============================================================
// EMPTY STATE
// ============================================================

class _EmptyOngoingAppointments
    extends StatelessWidget {
  const _EmptyOngoingAppointments();

  @override
  Widget build(
    BuildContext context,
  ) {
    return Column(
      mainAxisSize:
          MainAxisSize.min,
      children: [
        Container(
          width: 68,
          height: 68,
          decoration:
              BoxDecoration(
            color:
                AppTheme.primaryRed
                    .withOpacity(
              0.08,
            ),
            shape:
                BoxShape.circle,
          ),
          child:
              const Icon(
            Icons.route_outlined,
            color:
                AppTheme.primaryRed,
            size: 34,
          ),
        ),

        const SizedBox(
          height: 16,
        ),

        const Text(
          'No ongoing appointments',
          textAlign:
              TextAlign.center,
          style:
              TextStyle(
            color:
                AppTheme.black,
            fontSize: 16,
            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(
          height: 7,
        ),

        const Padding(
          padding:
              EdgeInsets.symmetric(
            horizontal: 28,
          ),
          child: Text(
            'Appointments will appear here when a technician has started traveling or servicing the client location.',
            textAlign:
                TextAlign.center,
            style:
                TextStyle(
              color:
                  AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}
