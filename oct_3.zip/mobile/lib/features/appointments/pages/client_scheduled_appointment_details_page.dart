import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

import 'package:mobile_app/shared/widgets/headers/app_back_header.dart';
import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';

class ClientScheduledAppointmentDetailsPage extends StatefulWidget {
  final String email;
  final int serviceId;

  const ClientScheduledAppointmentDetailsPage({
    super.key,
    required this.email,
    required this.serviceId,
  });

  @override
  State<ClientScheduledAppointmentDetailsPage> createState() =>
      _ClientScheduledAppointmentDetailsPageState();
}

class _ClientScheduledAppointmentDetailsPageState
    extends State<ClientScheduledAppointmentDetailsPage> {
  bool isLoading = true;

  String? errorMessage;

  Map<String, dynamic>? appointment;

  @override
  void initState() {
    super.initState();

    _loadAppointmentDetails();
  }

  // ============================================================
  // LOAD DETAILS
  // ============================================================

  Future<void> _loadAppointmentDetails() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse(
              '${ApiConfig.baseUrl}'
              '/api/mobile/appointments/client/details',
            ),
            headers: {
              'Accept': 'application/json',
            },
            body: {
              'email': widget.email,
              'svc_id': widget.serviceId.toString(),
            },
          )
          .timeout(
            const Duration(seconds: 15),
          );

      dynamic decodedData;

      try {
        decodedData = jsonDecode(response.body);
      } catch (_) {
        throw const FormatException(
          'Invalid server response.',
        );
      }

      if (!mounted) return;

      if (response.statusCode == 200 &&
          decodedData is Map &&
          decodedData['success'] == true &&
          decodedData['data'] is Map) {
        setState(() {
          appointment = Map<String, dynamic>.from(
            decodedData['data'],
          );

          isLoading = false;
          errorMessage = null;
        });

        return;
      }

      setState(() {
        isLoading = false;

        errorMessage = decodedData is Map
            ? decodedData['message']?.toString() ??
                'Unable to load appointment details.'
            : 'Unable to load appointment details.';
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        errorMessage =
            'Unable to connect to the server. Please try again.';
      });

      debugPrint(
        'SCHEDULED APPOINTMENT DETAILS ERROR: $error',
      );
    }
  }

  // ============================================================
  // BASIC HELPERS
  // ============================================================

  String _text(
    dynamic value, [
    String fallback = 'Not available',
  ]) {
    if (value == null) {
      return fallback;
    }

    final text = value.toString().trim();

    return text.isEmpty ? fallback : text;
  }

  bool _isTrue(dynamic value) {
    if (value is bool) {
      return value;
    }

    final normalized = value
        ?.toString()
        .trim()
        .toLowerCase();

    return normalized == '1' ||
        normalized == 'true';
  }

  List<String> _stringList(dynamic value) {
    if (value is List) {
      return value
          .map(
            (item) => item.toString().trim(),
          )
          .where(
            (item) => item.isNotEmpty,
          )
          .toList();
    }

    if (value is String &&
        value.trim().isNotEmpty) {
      return value
          .split(',')
          .map(
            (item) => item.trim(),
          )
          .where(
            (item) => item.isNotEmpty,
          )
          .toList();
    }

    return [];
  }

  List<Map<String, dynamic>> _imageList(
    dynamic value,
  ) {
    if (value is! List) {
      return [];
    }

    return value
        .whereType<Map>()
        .map(
          (item) => Map<String, dynamic>.from(
            item,
          ),
        )
        .toList();
  }

  // ============================================================
  // DISPLAY HELPERS
  // ============================================================

  String _formatSaNumber(dynamic value) {
    final rawNumber = _text(
      value,
      '',
    );

    if (rawNumber.isEmpty) {
      return 'SA------';
    }

    return 'SA-${rawNumber.padLeft(6, '0')}';
  }

  String _clientName(
    Map<String, dynamic> data,
  ) {
    final firstName = _text(
      data['usr_first_name'],
      '',
    );

    final lastName = _text(
      data['usr_last_name'],
      '',
    );

    final fullName = [
      firstName,
      lastName,
    ].where(
      (name) => name.isNotEmpty,
    ).join(' ');

    return fullName.isEmpty
        ? 'Client'
        : _titleCase(fullName);
  }

  String _titleCase(String value) {
    return value
        .trim()
        .toLowerCase()
        .split(RegExp(r'\s+'))
        .map(
          (word) {
            if (word.isEmpty) {
              return word;
            }

            return word[0].toUpperCase() +
                word.substring(1);
          },
        )
        .join(' ');
  }

  String _formatDate(dynamic value) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final date = DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${months[date.month - 1]} '
        '${date.day}, ${date.year}';
  }

  String _formatDateTime(dynamic value) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final date = DateTime.tryParse(
      value.toString(),
    );

    if (date == null) {
      return value.toString();
    }

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    final hour = date.hour;

    final displayHour = hour == 0
        ? 12
        : hour > 12
            ? hour - 12
            : hour;

    final minute = date.minute
        .toString()
        .padLeft(
          2,
          '0',
        );

    final period = hour >= 12
        ? 'PM'
        : 'AM';

    return '${months[date.month - 1]} '
        '${date.day}, ${date.year} • '
        '$displayHour:$minute $period';
  }

  String _formatRequestedTime(dynamic value) {
    if (value == null ||
        value.toString().trim().isEmpty) {
      return 'Not available';
    }

    final time = value
        .toString()
        .trim();

    if (time.startsWith('08:00')) {
      return '8:00 AM - 12:00 PM';
    }

    if (time.startsWith('12:00')) {
      return '12:00 PM - 5:00 PM';
    }

    if (time.startsWith('17:00')) {
      return '5:00 PM - 8:00 PM';
    }

    return _formatSingleTime(time);
  }

  String _formatSingleTime(String value) {
    final parts = value.split(':');

    if (parts.length < 2) {
      return value;
    }

    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);

    if (hour == null || minute == null) {
      return value;
    }

    final displayHour = hour == 0
        ? 12
        : hour > 12
            ? hour - 12
            : hour;

    final period = hour >= 12
        ? 'PM'
        : 'AM';

    return '$displayHour:'
        '${minute.toString().padLeft(2, '0')} '
        '$period';
  }

  String _formatSingleTimeDynamic(
    dynamic value,
  ) {
    final time = value?.toString().trim() ?? '';

    if (time.isEmpty) {
      return 'Not available';
    }

    return _formatSingleTime(time);
  }

  String _formatApprovedTimeRange(
    dynamic timeFrom,
    dynamic timeTo,
  ) {
    final from = _text(
      timeFrom,
      '',
    );

    final to = _text(
      timeTo,
      '',
    );

    if (from.isEmpty && to.isEmpty) {
      return 'Not available';
    }

    if (from.isNotEmpty && to.isNotEmpty) {
      return '${_formatSingleTime(from)} - '
          '${_formatSingleTime(to)}';
    }

    if (from.isNotEmpty) {
      return _formatSingleTime(from);
    }

    return _formatSingleTime(to);
  }

  String _formatMoney(dynamic value) {
    final amount = double.tryParse(
          value?.toString() ?? '',
        ) ??
        0;

    final wholePart = amount
        .truncate()
        .toString();

    final decimals = amount
        .toStringAsFixed(2)
        .split('.')[1];

    final formattedWhole = wholePart.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );

    return '₱$formattedWhole.$decimals';
  }

  String _formatDistance(dynamic value) {
    final distance = double.tryParse(
      value?.toString() ?? '',
    );

    if (distance == null) {
      return 'Not available';
    }

    if (distance == distance.roundToDouble()) {
      return '${distance.toInt()} km';
    }

    return '${distance.toStringAsFixed(1)} km';
  }

  String _formatAddress(
    Map<String, dynamic> data,
  ) {
    final parts = [
      data['uadd_street'],
      data['uadd_barangay'],
      data['uadd_city'],
      data['uadd_province'],
    ];

    final address = parts
        .where(
          (part) =>
              part != null &&
              part.toString().trim().isNotEmpty,
        )
        .map(
          (part) => part.toString().trim(),
        )
        .join(', ');

    return address.isEmpty
        ? 'No service address available'
        : address;
  }

  String _formatPestName(String value) {
    final normalized = value
        .trim()
        .toUpperCase();

    switch (normalized) {
      case 'RATS/MICE':
        return 'Rodent';

      case 'BED BUGS':
        return 'Bed Bug';

      case 'COCKROACHES':
        return 'Cockroach';

      case 'ANTS':
        return 'Ant';

      case 'TERMITES':
        return 'Termite';

      default:
        return _titleCase(normalized);
    }
  }

  String _serviceName(
    Map<String, dynamic> data,
  ) {
    if (_isTrue(
      data['svc_is_termite'],
    )) {
      return 'Termite Control';
    }

    final pests = _stringList(
      data['pestTypes'],
    );

    if (pests.length == 1) {
      return '${_formatPestName(pests.first)} Control';
    }

    if (pests.length > 1) {
      return 'General Pest Control';
    }

    return 'Pest Control Service';
  }

  String _sentenceCase(String text) {
    final value = text.trim();

    if (value.isEmpty) {
      return value;
    }

    final lower = value.toLowerCase();

    return lower[0].toUpperCase() + lower.substring(1);
  }

  String _statusLabel(dynamic value) {
    final status = _text(
      value,
      'REQUESTED',
    ).toUpperCase();

    if (status == 'DONE REPORT') {
      return 'COMPLETED';
    }

    return status;
  }

  // ============================================================
  // IMAGE URL
  // ============================================================

  String _baseImageUrl() {
    var baseUrl = ApiConfig.baseUrl.trim();

    while (baseUrl.endsWith('/')) {
      baseUrl = baseUrl.substring(
        0,
        baseUrl.length - 1,
      );
    }

    return baseUrl;
  }

  String _imageUrl(String fileName) {
    return '${_baseImageUrl()}'
        '/images/client_images/'
        '${Uri.encodeComponent(fileName)}';
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,

      appBar: const AppBackHeader(
        title: 'Schedule Details',
      ),

      bottomNavigationBar: ClientBottomNavBar(
        currentIndex: 3,
        email: widget.email,
      ),

      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (isLoading) {
      return _buildSkeleton();
    }

    if (errorMessage != null ||
        appointment == null) {
      return _buildErrorState();
    }

    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _loadAppointmentDetails,
      child: _buildDetails(
        appointment!,
      ),
    );
  }

  // ============================================================
  // DETAILS
  // ============================================================

  Widget _buildDetails(
    Map<String, dynamic> data,
  ) {
    final pests = _stringList(
      data['pestTypes'],
    );

    final areas = _stringList(
      data['areaTypes'],
    );

    final images = _imageList(
      data['images'],
    );

    final isTermite = _isTrue(
      data['svc_is_termite'],
    );

    final saNumber = _formatSaNumber(
      data['svc_sa_number'],
    );

    final status = _statusLabel(
      data['svc_status'] ??
          data['svca_status'],
    );

    final serviceName = _serviceName(
      data,
    );

    return ListView(
      physics:
          const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(
        20,
        18,
        20,
        30,
      ),
      children: [
        _referenceHeader(
          saNumber: saNumber,
          status: status,
          serviceName: serviceName,
        ),

        const SizedBox(height: 14),

        // ========================================================
        // REQUEST INFORMATION
        // ========================================================

        _detailsSection(
          title: 'REQUEST INFORMATION',
          icon: Icons.description_outlined,
          children: [
            _readOnlyRow(
              icon: Icons.person_outline_rounded,
              label: 'Client Name',
              value: _clientName(data),
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.confirmation_number_outlined,
              label: 'SA Number',
              value: saNumber,
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.access_time_rounded,
              label: 'Requested On',
              value: _formatDateTime(
                data['svc_date_created'] ??
                    data['svca_date_created'],
              ),
            ),
          ],
        ),

        const SizedBox(height: 14),

        // ========================================================
        // CONFIRMED SERVICE SCHEDULE
        // ========================================================

        _detailsSection(
          title: 'CONFIRMED SERVICE SCHEDULE',
          icon: Icons.event_available_outlined,
          children: [
            _readOnlyRow(
              icon: Icons.calendar_month_outlined,
              label: 'Service Date',
              value: _formatDate(
                data['svca_approved_date'],
              ),
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.schedule_outlined,
              label: 'Service Time',
              value: _formatApprovedTimeRange(
                data['svca_approved_time_from'],
                data['svca_approved_time_to'],
              ),
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.fact_check_outlined,
              label: 'Approved On',
              value: _formatDateTime(
                data['svca_date_approved'],
              ),
            ),
          ],
        ),

        const SizedBox(height: 14),

        // ========================================================
        // SERVICE INFORMATION
        // ========================================================

        _detailsSection(
          title: 'SERVICE INFORMATION',
          icon: Icons.pest_control_outlined,
          children: [
            _readOnlyRow(
              icon:
                  Icons.cleaning_services_outlined,
              label: 'Service',
              value: serviceName,
            ),

            _sectionDivider(),

            _badgeInformation(
              icon: Icons.bug_report_outlined,
              label: 'Pest Types',
              values: pests.isEmpty
                  ? const ['NOT SPECIFIED']
                  : pests,
            ),

            _sectionDivider(),

            if (isTermite)
              _readOnlyRow(
                icon: Icons.square_foot_outlined,
                label: 'Property Size',
                value: _text(
                  data['svcpat_sqm_details'] ??
                      data['svc_sqm_initial'],
                ),
              )
            else
              _badgeInformation(
                icon: Icons.home_work_outlined,
                label: 'Service Areas',
                values: areas.isEmpty
                    ? const ['Not specified']
                    : areas,
              ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.payments_outlined,
              label: 'Scheduled Cost',
              value: _formatMoney(
                data['svc_balance'],
              ),
              helperText:
                  'This is the current service amount for the scheduled appointment.',
            ),
          ],
        ),

        const SizedBox(height: 14),

        // ========================================================
        // PROBLEM DESCRIPTION
        // ========================================================

        _detailsSection(
          title: 'PROBLEM DESCRIPTION',
          icon: Icons.notes_outlined,
          children: [
            _descriptionBox(
              _sentenceCase(
                _text(
                  data['svc_problem_description'],
                  'No problem description was provided.',
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 14),

        // ========================================================
        // SERVICE LOCATION
        // ========================================================

        _detailsSection(
          title: 'SERVICE LOCATION',
          icon: Icons.location_on_outlined,
          children: [
            _readOnlyRow(
              icon: Icons.home_outlined,
              label: 'Complete Address',
              value: _formatAddress(data),
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.apartment_outlined,
              label: 'Assigned Branch',
              value: _titleCase(
                _text(
                  data['branch_name'],
                ),
              ),
            ),

            _sectionDivider(),

            _readOnlyRow(
              icon: Icons.route_outlined,
              label: 'Estimated Travel Distance',
              value: _formatDistance(
                data['svc_km_distance'],
              ),
            ),
          ],
        ),

        const SizedBox(height: 14),

        // ========================================================
        // UPLOADED PHOTOS
        // ========================================================

        _detailsSection(
          title: 'UPLOADED PHOTOS',
          icon: Icons.photo_library_outlined,
          children: [
            if (images.isEmpty)
              _emptyImages()
            else
              _imageGallery(images),
          ],
        ),

        const SizedBox(height: 14),

        _scheduledStatusBox(
          status: status,
        ),
      ],
    );
  }

  // ============================================================
  // REFERENCE HEADER
  // ============================================================

  Widget _referenceHeader({
    required String saNumber,
    required String status,
    required String serviceName,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                saNumber,
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.4,
                ),
              ),

              const Spacer(),

              _statusBadge(
                status,
              ),
            ],
          ),

          const SizedBox(height: 13),

          Text(
            serviceName,
            style: const TextStyle(
              color: AppTheme.black,
              fontSize: 18,
              height: 1.2,
              fontWeight: FontWeight.w900,
            ),
          ),

          const SizedBox(height: 6),

          const Text(
            'Your appointment has a confirmed service schedule.',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11.5,
              height: 1.35,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusBadge(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: AppTheme.primaryRed
            .withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: const TextStyle(
          color: AppTheme.primaryRed,
          fontSize: 9.5,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  // ============================================================
  // SECTION CONTAINER
  // ============================================================

  Widget _detailsSection({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              15,
              14,
              15,
              11,
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: AppTheme.lightGray,
                    borderRadius:
                        BorderRadius.circular(9),
                  ),
                  child: Icon(
                    icon,
                    color: AppTheme.black,
                    size: 16,
                  ),
                ),

                const SizedBox(width: 10),

                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: AppTheme.black,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ],
            ),
          ),

          Container(
            height: 1,
            color: AppTheme.borderGray,
          ),

          Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // READ-ONLY ROW
  // ============================================================

  Widget _readOnlyRow({
    required IconData icon,
    required String label,
    required String value,
    String? helperText,
  }) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 17,
          color: AppTheme.gray,
        ),

        const SizedBox(width: 10),

        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.45,
                ),
              ),

              const SizedBox(height: 5),

              Text(
                value,
                style: const TextStyle(
                  color: AppTheme.black,
                  fontSize: 12,
                  height: 1.35,
                  fontWeight: FontWeight.w700,
                ),
              ),

              if (helperText != null) ...[
                const SizedBox(height: 4),

                Text(
                  helperText,
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 9,
                    height: 1.3,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _badgeInformation({
    required IconData icon,
    required String label,
    required List<String> values,
  }) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 17,
          color: AppTheme.gray,
        ),

        const SizedBox(width: 10),

        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: AppTheme.gray,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.45,
                ),
              ),

              const SizedBox(height: 8),

              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: values.map(
                  (value) {
                    return Container(
                      padding:
                          const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryRed.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        value,
                        style: const TextStyle(
                          color: AppTheme.black,
                          fontSize: 9.5,
                          fontWeight:
                              FontWeight.w700,
                        ),
                      ),
                    );
                  },
                ).toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _descriptionBox(
    String description,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.lightGray
            .withOpacity(0.55),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        description,
        style: const TextStyle(
          color: AppTheme.black,
          fontSize: 11.5,
          height: 1.45,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _sectionDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 13,
      ),
      child: Container(
        height: 1,
        color: AppTheme.borderGray
            .withOpacity(0.75),
      ),
    );
  }

  // ============================================================
  // IMAGES
  // ============================================================

  Widget _imageGallery(
    List<Map<String, dynamic>> images,
  ) {
    return GridView.builder(
      shrinkWrap: true,
      physics:
          const NeverScrollableScrollPhysics(),
      itemCount: images.length,
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 9,
        mainAxisSpacing: 9,
        childAspectRatio: 1.15,
      ),
      itemBuilder: (
        context,
        index,
      ) {
        final fileName = _text(
          images[index]['svcap_image'],
          '',
        );

        if (fileName.isEmpty) {
          return _brokenImage();
        }

        final imageUrl = _imageUrl(
          fileName,
        );

        return Material(
          color: AppTheme.lightGray,
          borderRadius:
              BorderRadius.circular(14),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () {
              _openImagePreview(
                imageUrl,
              );
            },
            child: Ink(
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.borderGray,
                ),
              ),
              child: Image.network(
                imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (
                  context,
                  error,
                  stackTrace,
                ) {
                  return _brokenImage();
                },
                loadingBuilder: (
                  context,
                  child,
                  loadingProgress,
                ) {
                  if (loadingProgress == null) {
                    return child;
                  }

                  return const Center(
                    child: SizedBox(
                      width: 22,
                      height: 22,
                      child:
                          CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.gray,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _emptyImages() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      decoration: BoxDecoration(
        color: AppTheme.lightGray
            .withOpacity(0.55),
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Column(
        children: [
          Icon(
            Icons.image_not_supported_outlined,
            color: AppTheme.gray,
            size: 28,
          ),

          SizedBox(height: 9),

          Text(
            'No uploaded photos',
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _brokenImage() {
    return Container(
      color: AppTheme.lightGray,
      child: const Center(
        child: Icon(
          Icons.broken_image_outlined,
          color: AppTheme.gray,
          size: 30,
        ),
      ),
    );
  }

  void _openImagePreview(
    String imageUrl,
  ) {
    showDialog<void>(
      context: context,
      builder: (
        dialogContext,
      ) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(18),
          child: Stack(
            children: [
              InteractiveViewer(
                minScale: 0.8,
                maxScale: 4,
                child: Container(
                  constraints: BoxConstraints(
                    maxHeight:
                        MediaQuery.of(context)
                                .size
                                .height *
                            0.78,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.black,
                    borderRadius:
                        BorderRadius.circular(18),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.network(
                    imageUrl,
                    fit: BoxFit.contain,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return const SizedBox(
                        height: 260,
                        child: Center(
                          child: Icon(
                            Icons
                                .broken_image_outlined,
                            color: AppTheme.white,
                            size: 44,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              Positioned(
                top: 8,
                right: 8,
                child: Material(
                  color: Colors.black
                      .withOpacity(0.65),
                  shape: const CircleBorder(),
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(
                        dialogContext,
                      );
                    },
                    icon: const Icon(
                      Icons.close_rounded,
                      color: AppTheme.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ============================================================
  // STATUS
  // ============================================================

  Widget _scheduledStatusBox({
    required String status,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.borderGray,
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.lightGray,
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(
              Icons.fact_check_outlined,
              color: AppTheme.black,
              size: 20,
            ),
          ),

          const SizedBox(width: 11),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'Schedule Status',
                  style: TextStyle(
                    color: AppTheme.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  status == 'SCHEDULED'
                      ? 'Your service visit has been scheduled. Please be available at the confirmed date and time.'
                      : 'Current appointment status: $status',
                  style: const TextStyle(
                    color: AppTheme.gray,
                    fontSize: 10.5,
                    height: 1.35,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LOADING
  // ============================================================

  Widget _buildSkeleton() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(
        20,
        18,
        20,
        30,
      ),
      children: [
        _skeletonBox(115),

        const SizedBox(height: 14),

        _skeletonBox(270),

        const SizedBox(height: 14),

        _skeletonBox(210),

        const SizedBox(height: 14),

        _skeletonBox(290),

        const SizedBox(height: 14),

        _skeletonBox(130),

        const SizedBox(height: 14),

        _skeletonBox(190),
      ],
    );
  }

  Widget _skeletonBox(double height) {
    return Container(
      width: double.infinity,
      height: height,
      decoration: BoxDecoration(
        color: AppTheme.borderGray
            .withOpacity(0.38),
        borderRadius: BorderRadius.circular(18),
      ),
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget _buildErrorState() {
    return RefreshIndicator(
      color: AppTheme.primaryRed,
      onRefresh: _loadAppointmentDetails,
      child: ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
        ),
        children: [
          const SizedBox(height: 110),

          const Icon(
            Icons.wifi_off_rounded,
            color: AppTheme.gray,
            size: 50,
          ),

          const SizedBox(height: 17),

          const Text(
            'Unable to load details',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            errorMessage ??
                'Please try again.',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AppTheme.gray,
              fontSize: 13,
              height: 1.4,
            ),
          ),

          const SizedBox(height: 18),

          Center(
            child: OutlinedButton.icon(
              onPressed:
                  _loadAppointmentDetails,
              icon: const Icon(
                Icons.refresh_rounded,
                size: 18,
              ),
              label: const Text(
                'Retry',
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor:
                    AppTheme.black,
                side: const BorderSide(
                  color: AppTheme.borderGray,
                ),
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}