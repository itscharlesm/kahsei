// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// import 'package:mobile_app/app/theme.dart';
// import 'package:mobile_app/config/api_config.dart';

// import 'package:mobile_app/shared/shared.dart';
// import 'package:mobile_app/shared/widgets/bottom_bar/client_bottom_nav_bar.dart';
// import 'package:mobile_app/shared/widgets/navigation/app_drawer.dart';

// import 'package:mobile_app/features/appointments/widgets/client_appointment_card.dart';

// class ClientAppointmentsPage extends StatefulWidget {
//   final String email;
//   final String initialFilter;

//   const ClientAppointmentsPage({
//     super.key,
//     required this.email,
//     this.initialFilter = 'Requested',
//   });

//   @override
//   State<ClientAppointmentsPage> createState() =>
//       _ClientAppointmentsPageState();
// }

// class _ClientAppointmentsPageState
//     extends State<ClientAppointmentsPage> {
//   // ============================================================
//   // TABS
//   // ============================================================

//   final List<String> filters = [
//     'Requested',
//     'Assessed',
//     'Scheduled',
//     'Ongoing',
//     'Completed',
//   ];

//   late String selectedFilter;

//   // ============================================================
//   // SCROLL
//   // ============================================================

//   final ScrollController _scrollController =
//       ScrollController();

//   // ============================================================
//   // APPOINTMENTS PER TAB
//   // ============================================================

//   final Map<String, List<Map<String, dynamic>>>
//       _appointmentsByFilter = {
//     'Requested': [],
//     'Assessed': [],
//     'Scheduled': [],
//     'Ongoing': [],
//     'Completed': [],
//   };

//   // ============================================================
//   // PAGE PER TAB
//   // ============================================================

//   final Map<String, int> _pageByFilter = {
//     'Requested': 1,
//     'Assessed': 1,
//     'Scheduled': 1,
//     'Ongoing': 1,
//     'Completed': 1,
//   };

//   // ============================================================
//   // HAS MORE PER TAB
//   // ============================================================

//   final Map<String, bool> _hasMoreByFilter = {
//     'Requested': true,
//     'Assessed': true,
//     'Scheduled': true,
//     'Ongoing': true,
//     'Completed': true,
//   };

//   // ============================================================
//   // LOADED / CACHE STATE
//   // ============================================================

//   final Map<String, bool> _loadedByFilter = {
//     'Requested': false,
//     'Assessed': false,
//     'Scheduled': false,
//     'Ongoing': false,
//     'Completed': false,
//   };

//   // ============================================================
//   // INITIAL LOADING
//   // ============================================================

//   final Map<String, bool> _loadingByFilter = {
//     'Requested': false,
//     'Assessed': false,
//     'Scheduled': false,
//     'Ongoing': false,
//     'Completed': false,
//   };

//   // ============================================================
//   // PAGINATION LOADING
//   // ============================================================

//   final Map<String, bool> _loadingMoreByFilter = {
//     'Requested': false,
//     'Assessed': false,
//     'Scheduled': false,
//     'Ongoing': false,
//     'Completed': false,
//   };

//   // ============================================================
//   // ERRORS
//   // ============================================================

//   final Map<String, String?> _errorByFilter = {
//     'Requested': null,
//     'Assessed': null,
//     'Scheduled': null,
//     'Ongoing': null,
//     'Completed': null,
//   };

//   // ============================================================
//   // INIT
//   // ============================================================

//   @override
//   void initState() {
//     super.initState();

//     selectedFilter =
//         filters.contains(widget.initialFilter)
//             ? widget.initialFilter
//             : 'Requested';

//     _scrollController.addListener(
//       _handleScroll,
//     );

//     // Only the selected tab loads.
//     _loadAppointments(
//       selectedFilter,
//       reset: true,
//     );
//   }

//   // ============================================================
//   // DISPOSE
//   // ============================================================

//   @override
//   void dispose() {
//     _scrollController.removeListener(
//       _handleScroll,
//     );

//     _scrollController.dispose();

//     super.dispose();
//   }

//   // ============================================================
//   // ACTIVE TAB HELPERS
//   // ============================================================

//   List<Map<String, dynamic>>
//       get currentAppointments {
//     return _appointmentsByFilter[
//             selectedFilter] ??
//         [];
//   }

//   bool get isCurrentTabLoading {
//     return _loadingByFilter[
//             selectedFilter] ??
//         false;
//   }

//   bool get isCurrentTabLoadingMore {
//     return _loadingMoreByFilter[
//             selectedFilter] ??
//         false;
//   }

//   bool get currentTabHasMore {
//     return _hasMoreByFilter[
//             selectedFilter] ??
//         false;
//   }

//   String? get currentTabError {
//     return _errorByFilter[
//         selectedFilter];
//   }

//   // ============================================================
//   // STATUS FOR BACKEND
//   // ============================================================

//   String _databaseStatus(
//     String filter,
//   ) {
//     switch (filter) {
//       case 'Assessed':
//         return 'ASSESSED';

//       case 'Scheduled':
//         return 'SCHEDULED';

//       case 'Ongoing':
//         return 'ONGOING';

//       case 'Completed':
//         return 'DONE REPORT';

//       case 'Requested':
//       default:
//         return 'REQUESTED';
//     }
//   }

//   // ============================================================
//   // MAP APPOINTMENT
//   // ============================================================

//   Map<String, dynamic> _mapAppointment(
//     dynamic item,
//   ) {
//     return {
//       'id': item['svcas_id'],

//       'schedule_id':
//           item['svcas_id'],

//       'scheduleId':
//           item['svcas_id'],

//       'appointment_id':
//           item['svca_id'],

//       'appointmentId':
//           item['svca_id'],

//       'status':
//           item['svca_status'] ??
//           'REQUESTED',

//       'service':
//           item['svc_is_termite'] == 1
//               ? 'Termite Treatment'
//               : 'General Pest Control',

//       'schedule':
//           '${_formatDate(item['svca_client_date'])} • '
//           '${_formatTime(item['svca_client_time'])}',

//       'startDate':
//           item['svcas_start_date'],

//       'startTime':
//           item['svcas_start_time'],

//       'locationType':
//           'SERVICE LOCATION',

//       'address':
//           _formatAddress(
//         Map<String, dynamic>.from(
//           item,
//         ),
//       ),

//       'price':
//           '₱${_formatPrice(item['svc_balance'])}',

//       'requestedDate':
//           'Requested on '
//           '${_formatDate(item['svca_date_created'])}',

//       'isTermite':
//           item['svc_is_termite'] == 1,

//       'sqmDetails':
//           item['svcpat_sqm_details'],

//       'fullPestTypes':
//           item['fullPestTypes'],

//       'areaTypes':
//           item['areaTypes'],

//       'clientLatitude':
//           item['uadd_latitude'],

//       'clientLongitude':
//           item['uadd_longitude'],

//       'branchId':
//           item['branch_id'],

//       'branchName':
//           item['branch_name'],

//       'branchLatitude':
//           item['branch_latitude'],

//       'branchLongitude':
//           item['branch_longitude'],

//       'technicianName':
//           item['technicianName'],

//       'technicianMobile':
//           item['technicianMobile'],

//       'svc_id':
//           item['svc_id'],

//       'rating':
//           item['svc_rating'],

//       'dateRated':
//           item['svc_date_rated'],

//       'paymentId':
//           item['spay_id'],

//       'paymentTypeId':
//           item['typ_id'],

//       'paymentStatus':
//           item['spay_status'],

//       'paymentAmount':
//           item['spay_amount'],

//       'paymentDate':
//           item['spay_date'],
//     };
//   }

//   // ============================================================
//   // LOAD APPOINTMENTS
//   // ============================================================

//   Future<void> _loadAppointments(
//     String filter, {
//     bool reset = false,
//   }) async {
//     final currentlyLoading =
//         _loadingByFilter[filter] ??
//         false;

//     final currentlyLoadingMore =
//         _loadingMoreByFilter[filter] ??
//         false;

//     if (currentlyLoading ||
//         currentlyLoadingMore) {
//       return;
//     }

//     if (!reset &&
//         !(_hasMoreByFilter[filter] ??
//             true)) {
//       return;
//     }

//     final page = reset
//         ? 1
//         : (_pageByFilter[filter] ??
//             1);

//     if (!mounted) return;

//     setState(() {
//       if (reset ||
//           (_appointmentsByFilter[filter]
//                   ?.isEmpty ??
//               true)) {
//         _loadingByFilter[filter] =
//             true;
//       } else {
//         _loadingMoreByFilter[filter] =
//             true;
//       }

//       _errorByFilter[filter] =
//           null;
//     });

//     try {
//       final response = await http
//           .post(
//             Uri.parse(
//               '${ApiConfig.baseUrl}/api/mobile/appointments/client',
//             ),
//             headers: {
//               'Accept':
//                   'application/json',
//             },
//             body: {
//               'email':
//                   widget.email,

//               'status':
//                   _databaseStatus(
//                 filter,
//               ),

//               'page':
//                   page.toString(),
//             },
//           )
//           .timeout(
//             const Duration(
//               seconds: 12,
//             ),
//           );

//       final data =
//           jsonDecode(
//         response.body,
//       );

//       if (!mounted) return;

//       if (response.statusCode == 200 &&
//           data['success'] == true) {
//         final List appointmentData =
//             data['data'] ?? [];

//         final newAppointments =
//             appointmentData
//                 .map(
//                   _mapAppointment,
//                 )
//                 .toList();

//         final pagination =
//             data['pagination'] is Map
//                 ? Map<String, dynamic>.from(
//                     data[
//                         'pagination'],
//                   )
//                 : <String, dynamic>{};

//         final hasMore =
//             pagination[
//                     'has_more'] ==
//                 true;

//         final nextPage =
//             pagination[
//                 'next_page'];

//         setState(() {
//           if (reset) {
//             _appointmentsByFilter[
//                     filter] =
//                 newAppointments;
//           } else {
//             _appointmentsByFilter[
//                     filter]!
//                 .addAll(
//               newAppointments,
//             );
//           }

//           _loadedByFilter[filter] =
//               true;

//           _hasMoreByFilter[filter] =
//               hasMore;

//           if (hasMore &&
//               nextPage != null) {
//             _pageByFilter[filter] =
//                 int.tryParse(
//                       nextPage
//                           .toString(),
//                     ) ??
//                     (page + 1);
//           } else {
//             _pageByFilter[filter] =
//                 page + 1;
//           }

//           _loadingByFilter[filter] =
//               false;

//           _loadingMoreByFilter[
//                   filter] =
//               false;

//           _errorByFilter[filter] =
//               null;
//         });
//       } else {
//         setState(() {
//           _loadingByFilter[filter] =
//               false;

//           _loadingMoreByFilter[
//                   filter] =
//               false;

//           _errorByFilter[filter] =
//               data['message']
//                       ?.toString() ??
//                   'Unable to load appointments.';
//         });
//       }
//     } catch (e) {
//       if (!mounted) return;

//       setState(() {
//         _loadingByFilter[filter] =
//             false;

//         _loadingMoreByFilter[
//                 filter] =
//             false;

//         _errorByFilter[filter] =
//             'Unable to connect to the server.';
//       });

//       debugPrint(
//         'CLIENT APPOINTMENTS ERROR '
//         '[$filter PAGE $page]: $e',
//       );
//     }
//   }

//   // ============================================================
//   // SCROLL PAGINATION
//   // ============================================================

//   void _handleScroll() {
//     if (!_scrollController.hasClients) {
//       return;
//     }

//     final position =
//         _scrollController.position;

//     if (position.pixels >=
//         position.maxScrollExtent -
//             180) {
//       _loadMore();
//     }
//   }

//   Future<void> _loadMore() async {
//     if (!currentTabHasMore ||
//         isCurrentTabLoading ||
//         isCurrentTabLoadingMore) {
//       return;
//     }

//     await _loadAppointments(
//       selectedFilter,
//     );
//   }

//   // ============================================================
//   // SELECT TAB
//   // ============================================================

//   Future<void> _selectFilter(
//     String filter,
//   ) async {
//     if (selectedFilter == filter) {
//       return;
//     }

//     setState(() {
//       selectedFilter =
//           filter;
//     });

//     if (_scrollController.hasClients) {
//       _scrollController.jumpTo(
//         0,
//       );
//     }

//     // Load only if this tab has
//     // never been opened before.
//     if (!(_loadedByFilter[filter] ??
//         false)) {
//       await _loadAppointments(
//         filter,
//         reset: true,
//       );
//     }
//   }

//   // ============================================================
//   // REFRESH CURRENT TAB ONLY
//   // ============================================================

//   Future<void>
//       _refreshCurrentTab() async {
//     final filter =
//         selectedFilter;

//     _pageByFilter[filter] = 1;
//     _hasMoreByFilter[filter] =
//         true;

//     await _loadAppointments(
//       filter,
//       reset: true,
//     );
//   }

//   // ============================================================
//   // CARD REFRESH
//   // ============================================================

//   Future<void>
//       _refreshAfterAppointmentChange() async {
//     // The appointment may have moved
//     // to another status/tab.
//     //
//     // Refresh the current tab and mark
//     // the other caches stale.

//     for (final filter in filters) {
//       if (filter !=
//           selectedFilter) {
//         _loadedByFilter[filter] =
//             false;

//         _appointmentsByFilter[
//                 filter] =
//             [];

//         _pageByFilter[filter] =
//             1;

//         _hasMoreByFilter[filter] =
//             true;
//       }
//     }

//     await _refreshCurrentTab();
//   }

//   // ============================================================
//   // FORMAT ADDRESS
//   // ============================================================

//   String _formatAddress(
//     Map<String, dynamic> item,
//   ) {
//     final parts = [
//       item['uadd_street'],
//       item['uadd_barangay'],
//       item['uadd_city'],
//       item['uadd_province'],
//     ];

//     return parts
//         .where(
//           (part) =>
//               part != null &&
//               part
//                   .toString()
//                   .trim()
//                   .isNotEmpty,
//         )
//         .join(', ');
//   }

//   // ============================================================
//   // FORMAT PRICE
//   // ============================================================

//   String _formatPrice(
//     dynamic value,
//   ) {
//     final price =
//         double.tryParse(
//               value?.toString() ??
//                   '',
//             ) ??
//             0;

//     return price.toStringAsFixed(
//       2,
//     );
//   }

//   // ============================================================
//   // FORMAT DATE
//   // ============================================================

//   String _formatDate(
//     dynamic value,
//   ) {
//     if (value == null) {
//       return 'No date';
//     }

//     final date =
//         DateTime.tryParse(
//       value.toString(),
//     );

//     if (date == null) {
//       return value.toString();
//     }

//     const months = [
//       'January',
//       'February',
//       'March',
//       'April',
//       'May',
//       'June',
//       'July',
//       'August',
//       'September',
//       'October',
//       'November',
//       'December',
//     ];

//     return '${months[date.month - 1]} '
//         '${date.day}, '
//         '${date.year}';
//   }

//   // ============================================================
//   // FORMAT TIME
//   // ============================================================

//   String _formatTime(
//     dynamic value,
//   ) {
//     if (value == null) {
//       return 'No time';
//     }

//     final time =
//         value.toString();

//     if (time.startsWith(
//       '08:00',
//     )) {
//       return '8:00 AM - 12:00 PM';
//     }

//     if (time.startsWith(
//       '12:00',
//     )) {
//       return '12:00 PM - 5:00 PM';
//     }

//     if (time.startsWith(
//       '17:00',
//     )) {
//       return '5:00 PM - 8:00 PM';
//     }

//     return time;
//   }

//   // ============================================================
//   // BUILD
//   // ============================================================

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     return Scaffold(
//       backgroundColor:
//           AppTheme.lightGray,

//       drawer: AppDrawer(
//         userType: 3,
//         email: widget.email,
//         currentPage:
//             'appointments',
//       ),

//       appBar:
//           const AppTitleHeader(
//         title:
//             'My Appointments',
//       ),

//       bottomNavigationBar:
//           ClientBottomNavBar(
//         currentIndex: 1,
//         email: widget.email,
//       ),

//       body: Padding(
//         padding:
//             const EdgeInsets.all(
//           20,
//         ),
//         child: Column(
//           crossAxisAlignment:
//               CrossAxisAlignment.start,
//           children: [
//             _pageHeader(),

//             const SizedBox(
//               height: 16,
//             ),

//             _filterChips(),

//             const SizedBox(
//               height: 16,
//             ),

//             Expanded(
//               child:
//                   _buildTabContent(),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // ============================================================
//   // TAB CONTENT
//   // ============================================================

//   Widget _buildTabContent() {
//     // ============================================================
//     // INITIAL LOAD
//     // ============================================================

//     if (isCurrentTabLoading &&
//         currentAppointments
//             .isEmpty) {
//       return _appointmentsSkeleton();
//     }

//     // ============================================================
//     // ERROR
//     // ============================================================

//     if (currentTabError != null &&
//         currentAppointments
//             .isEmpty) {
//       return _errorState();
//     }

//     // ============================================================
//     // EMPTY
//     // ============================================================

//     if (currentAppointments
//         .isEmpty) {
//       return RefreshIndicator(
//         color:
//             AppTheme.primaryRed,

//         onRefresh:
//             _refreshCurrentTab,

//         child: ListView(
//           physics:
//               const AlwaysScrollableScrollPhysics(),

//           children: [
//             const SizedBox(
//               height: 80,
//             ),

//             _EmptyAppointmentsContent(
//               filter:
//                   selectedFilter,
//             ),
//           ],
//         ),
//       );
//     }

//     // ============================================================
//     // APPOINTMENTS
//     // ============================================================

//     return RefreshIndicator(
//       color:
//           AppTheme.primaryRed,

//       onRefresh:
//           _refreshCurrentTab,

//       child: ListView.separated(
//         controller:
//             _scrollController,

//         physics:
//             const AlwaysScrollableScrollPhysics(),

//         padding:
//             const EdgeInsets.only(
//           bottom: 24,
//         ),

//         itemCount:
//             currentAppointments
//                     .length +
//                 (isCurrentTabLoadingMore
//                     ? 1
//                     : 0),

//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           height: 12,
//         ),

//         itemBuilder:
//             (context, index) {
//           // ========================================================
//           // PAGINATION SPINNER
//           // ========================================================

//           if (index >=
//               currentAppointments
//                   .length) {
//             return const Padding(
//               padding:
//                   EdgeInsets.symmetric(
//                 vertical: 14,
//               ),
//               child: Center(
//                 child: SizedBox(
//                   width: 22,
//                   height: 22,
//                   child:
//                       CircularProgressIndicator(
//                     strokeWidth:
//                         2.2,
//                     color:
//                         AppTheme.primaryRed,
//                   ),
//                 ),
//               ),
//             );
//           }

//           final appointment =
//               currentAppointments[
//                   index];

//           return ClientAppointmentCard(
//             appointment:
//                 appointment,

//             email:
//                 widget.email,

//             onRefresh:
//                 _refreshAfterAppointmentChange,
//           );
//         },
//       ),
//     );
//   }

//   // ============================================================
//   // SIMPLE SKELETON
//   // ============================================================

//   Widget _appointmentsSkeleton() {
//     return ListView.separated(
//       physics:
//           const NeverScrollableScrollPhysics(),

//       itemCount: 3,

//       separatorBuilder:
//           (_, __) =>
//               const SizedBox(
//         height: 12,
//       ),

//       itemBuilder:
//           (_, __) {
//         return Container(
//           width:
//               double.infinity,

//           height: 180,

//           decoration:
//               BoxDecoration(
//             color:
//                 AppTheme.borderGray
//                     .withOpacity(
//               0.35,
//             ),

//             borderRadius:
//                 BorderRadius.circular(
//               16,
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // ============================================================
//   // ERROR STATE
//   // ============================================================

//   Widget _errorState() {
//     return RefreshIndicator(
//       color:
//           AppTheme.primaryRed,

//       onRefresh:
//           _refreshCurrentTab,

//       child: ListView(
//         physics:
//             const AlwaysScrollableScrollPhysics(),

//         children: [
//           const SizedBox(
//             height: 85,
//           ),

//           Column(
//             children: [
//               Container(
//                 width: 68,
//                 height: 68,

//                 decoration:
//                     BoxDecoration(
//                   color:
//                       AppTheme.primaryRed
//                           .withOpacity(
//                     0.08,
//                   ),

//                   shape:
//                       BoxShape.circle,
//                 ),

//                 child:
//                     const Icon(
//                   Icons
//                       .wifi_off_rounded,

//                   color:
//                       AppTheme.primaryRed,

//                   size: 32,
//                 ),
//               ),

//               const SizedBox(
//                 height: 16,
//               ),

//               const Text(
//                 'Unable to load appointments',
//                 style:
//                     TextStyle(
//                   color:
//                       AppTheme.black,

//                   fontSize: 16,

//                   fontWeight:
//                       FontWeight.bold,
//                 ),
//               ),

//               const SizedBox(
//                 height: 7,
//               ),

//               Padding(
//                 padding:
//                     const EdgeInsets.symmetric(
//                   horizontal: 28,
//                 ),

//                 child: Text(
//                   currentTabError ??
//                       'Please try again.',

//                   textAlign:
//                       TextAlign.center,

//                   style:
//                       const TextStyle(
//                     color:
//                         AppTheme.gray,

//                     fontSize: 13,

//                     height: 1.35,
//                   ),
//                 ),
//               ),

//               const SizedBox(
//                 height: 16,
//               ),

//               OutlinedButton.icon(
//                 onPressed: () {
//                   _refreshCurrentTab();
//                 },

//                 icon:
//                     const Icon(
//                   Icons
//                       .refresh_rounded,

//                   size: 18,
//                 ),

//                 label:
//                     const Text(
//                   'Retry',
//                 ),

//                 style:
//                     OutlinedButton
//                         .styleFrom(
//                   foregroundColor:
//                       AppTheme.primaryRed,

//                   side:
//                       const BorderSide(
//                     color:
//                         AppTheme.primaryRed,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // ============================================================
//   // PAGE HEADER
//   // ============================================================

//   Widget _pageHeader() {
//     return const Column(
//       crossAxisAlignment:
//           CrossAxisAlignment.start,

//       children: [
//         Text(
//           'Your Service Requests',

//           style:
//               TextStyle(
//             color:
//                 AppTheme.black,

//             fontSize: 18,

//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         SizedBox(
//           height: 5,
//         ),

//         Text(
//           'View and track your submitted appointment requests.',

//           style:
//               TextStyle(
//             color:
//                 AppTheme.gray,

//             fontSize: 13,

//             height: 1.35,
//           ),
//         ),
//       ],
//     );
//   }

//   // ============================================================
//   // FILTER CHIPS
//   // ============================================================

//   Widget _filterChips() {
//     return SizedBox(
//       height: 38,

//       child:
//           ListView.separated(
//         scrollDirection:
//             Axis.horizontal,

//         itemCount:
//             filters.length,

//         separatorBuilder:
//             (_, __) =>
//                 const SizedBox(
//           width: 8,
//         ),

//         itemBuilder:
//             (context, index) {
//           final filter =
//               filters[index];

//           final isSelected =
//               selectedFilter ==
//                   filter;

//           return GestureDetector(
//             onTap: () {
//               _selectFilter(
//                 filter,
//               );
//             },

//             child: Container(
//               padding:
//                   const EdgeInsets
//                       .symmetric(
//                 horizontal: 14,
//               ),

//               alignment:
//                   Alignment.center,

//               decoration:
//                   BoxDecoration(
//                 color:
//                     isSelected
//                         ? AppTheme.primaryRed
//                         : AppTheme.white,

//                 borderRadius:
//                     BorderRadius.circular(
//                   20,
//                 ),

//                 border:
//                     Border.all(
//                   color:
//                       isSelected
//                           ? AppTheme.primaryRed
//                           : AppTheme.borderGray,
//                 ),
//               ),

//               child: Text(
//                 filter,

//                 style:
//                     TextStyle(
//                   color:
//                       isSelected
//                           ? AppTheme.white
//                           : AppTheme.black,

//                   fontSize: 12,

//                   fontWeight:
//                       FontWeight.w700,
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// // ============================================================
// // EMPTY STATE
// // ============================================================

// class _EmptyAppointmentsContent
//     extends StatelessWidget {
//   final String filter;

//   const _EmptyAppointmentsContent({
//     required this.filter,
//   });

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     String title;
//     String message;
//     IconData icon;

//     switch (filter) {
//       case 'Assessed':
//         title =
//             'No assessed appointments';

//         message =
//             'Appointments that have been assessed will appear here.';

//         icon =
//             Icons.fact_check_outlined;

//         break;

//       case 'Scheduled':
//         title =
//             'No scheduled appointments';

//         message =
//             'Approved appointments with confirmed schedules will appear here.';

//         icon =
//             Icons.event_outlined;

//         break;

//       case 'Ongoing':
//         title =
//             'No ongoing appointments';

//         message =
//             'Services currently in progress will appear here.';

//         icon =
//             Icons.route_outlined;

//         break;

//       case 'Completed':
//         title =
//             'No completed appointments';

//         message =
//             'Completed services will appear here.';

//         icon =
//             Icons.check_circle_outline_rounded;

//         break;

//       case 'Requested':
//       default:
//         title =
//             'No requested appointments';

//         message =
//             'New service requests that you submit will appear here.';

//         icon =
//             Icons.calendar_month_outlined;

//         break;
//     }

//     return Column(
//       mainAxisSize:
//           MainAxisSize.min,

//       children: [
//         Container(
//           width: 68,
//           height: 68,

//           decoration:
//               BoxDecoration(
//             color:
//                 AppTheme.primaryRed
//                     .withOpacity(
//               0.08,
//             ),

//             shape:
//                 BoxShape.circle,
//           ),

//           child: Icon(
//             icon,

//             color:
//                 AppTheme.primaryRed,

//             size: 34,
//           ),
//         ),

//         const SizedBox(
//           height: 16,
//         ),

//         Text(
//           title,

//           textAlign:
//               TextAlign.center,

//           style:
//               const TextStyle(
//             color:
//                 AppTheme.black,

//             fontSize: 16,

//             fontWeight:
//                 FontWeight.bold,
//           ),
//         ),

//         const SizedBox(
//           height: 7,
//         ),

//         Padding(
//           padding:
//               const EdgeInsets.symmetric(
//             horizontal: 28,
//           ),

//           child: Text(
//             message,

//             textAlign:
//                 TextAlign.center,

//             style:
//                 const TextStyle(
//               color:
//                   AppTheme.gray,

//               fontSize: 13,

//               height: 1.35,
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }