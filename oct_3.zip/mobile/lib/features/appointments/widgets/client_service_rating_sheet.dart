import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';

class ClientServiceRatingSheet extends StatefulWidget {
  final String email;
  final int serviceId;

  const ClientServiceRatingSheet({
    super.key,
    required this.email,
    required this.serviceId,
  });

  static Future<bool?> show(
    BuildContext context, {
    required String email,
    required int serviceId,
  }) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ClientServiceRatingSheet(
        email: email,
        serviceId: serviceId,
      ),
    );
  }

  @override
  State<ClientServiceRatingSheet> createState() =>
      _ClientServiceRatingSheetState();
}

class _ClientServiceRatingSheetState
    extends State<ClientServiceRatingSheet> {
  int selectedRating = 0;
  bool isSubmitting = false;

  String get ratingLabel {
    switch (selectedRating) {
      case 1:
        return 'Poor';
      case 2:
        return 'Fair';
      case 3:
        return 'Good';
      case 4:
        return 'Very Good';
      case 5:
        return 'Excellent';
      default:
        return 'Select your rating';
    }
  }

  Future<void> _submitRating() async {
    if (selectedRating == 0 || isSubmitting) {
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    try {
      final response = await http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/api/mobile/service/rate',
        ),
        headers: {
          'Accept': 'application/json',
        },
        body: {
          'email': widget.email,
          'svc_id': widget.serviceId.toString(),
          'rating': selectedRating.toString(),
        },
      );

      final data = jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        Navigator.pop(context, true);
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            data['message'] ??
                'Unable to submit service rating.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to connect to the server.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isSubmitting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        22,
        12,
        22,
        MediaQuery.of(context).padding.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(24),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.borderGray,
              borderRadius: BorderRadius.circular(20),
            ),
          ),

          const SizedBox(height: 22),

          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppTheme.primaryRed.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.star_rounded,
              size: 32,
              color: AppTheme.primaryRed,
            ),
          ),

          const SizedBox(height: 14),

          const Text(
            'Rate Your Service',
            style: TextStyle(
              color: AppTheme.black,
              fontSize: 19,
              fontWeight: FontWeight.w900,
            ),
          ),

          const SizedBox(height: 7),

          const Text(
            'How would you rate the service you received?',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.gray,
              fontSize: 13,
              height: 1.35,
            ),
          ),

          const SizedBox(height: 22),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (index) {
              final star = index + 1;

              return IconButton(
                onPressed: isSubmitting
                    ? null
                    : () {
                        setState(() {
                          selectedRating = star;
                        });
                      },
                icon: Icon(
                  star <= selectedRating
                      ? Icons.star_rounded
                      : Icons.star_border_rounded,
                  size: 38,
                  color: const Color(0xFFFFB300),
                ),
              );
            }),
          ),

          const SizedBox(height: 5),

          Text(
            ratingLabel,
            style: TextStyle(
              color: selectedRating == 0
                  ? AppTheme.gray
                  : AppTheme.black,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 24),

          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed:
                  selectedRating == 0 || isSubmitting
                      ? null
                      : _submitRating,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryRed,
                foregroundColor: AppTheme.white,
                disabledBackgroundColor:
                    AppTheme.borderGray,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(14),
                ),
              ),
              child: isSubmitting
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.white,
                      ),
                    )
                  : const Text(
                      'Submit Rating',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
            ),
          ),

          const SizedBox(height: 10),

          TextButton(
            onPressed: isSubmitting
                ? null
                : () {
                    Navigator.pop(context);
                  },
            child: const Text(
              'Maybe Later',
              style: TextStyle(
                color: AppTheme.gray,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}