import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/appointment_skeleton_card.dart';

class ClientAppointmentPagination extends StatelessWidget {
  final int visibleCount;
  final int totalCount;
  final bool isLoadingMore;
  final bool hasMore;

  const ClientAppointmentPagination({
    super.key,
    required this.visibleCount,
    required this.totalCount,
    required this.isLoadingMore,
    required this.hasMore,
  });

  @override
  Widget build(BuildContext context) {
    if (totalCount <= 10) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        children: [
          Text(
            'Showing $visibleCount of $totalCount appointments',
            style: const TextStyle(
              color: AppTheme.gray,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          if (isLoadingMore) ...[
            const AppointmentSkeletonCard(),
            const SizedBox(height: 10),
            const AppointmentSkeletonCard(),
          ] else if (!hasMore)
            const Text(
              'You’ve reached the end',
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 12,
              ),
            ),
        ],
      ),
    );
  }
}