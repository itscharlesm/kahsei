import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/config/api_config.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class PaymentTypeOptionSheet extends StatefulWidget {
  final Function(Map<String, dynamic> paymentType) onPaymentTypeSelected;

  const PaymentTypeOptionSheet({
    super.key,
    required this.onPaymentTypeSelected,
  });

  static void show(
    BuildContext context, {
    required Function(Map<String, dynamic> paymentType) onPaymentTypeSelected,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return PaymentTypeOptionSheet(
          onPaymentTypeSelected: onPaymentTypeSelected,
        );
      },
    );
  }

  @override
  State<PaymentTypeOptionSheet> createState() => _PaymentTypeOptionSheetState();
}

class _PaymentTypeOptionSheetState extends State<PaymentTypeOptionSheet> {
  bool isLoading = true;
  List<Map<String, dynamic>> paymentTypes = [];

  @override
  void initState() {
    super.initState();
    _loadPaymentTypes();
  }

  Future<void> _loadPaymentTypes() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/api/mobile/payment-types'),
        headers: {
          'Accept': 'application/json',
        },
      );

      if (!mounted) return;

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        final List items = data['data'] ?? [];

        if (!mounted) return;

        setState(() {
          paymentTypes = items.map((item) {
            return {
              'typ_id': item['typ_id'],
              'typ_name': item['typ_name'],
            };
          }).toList();

          isLoading = false;
        });
      } else {
        if (!mounted) return;

        setState(() {
          paymentTypes = [];
          isLoading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        paymentTypes = [];
        isLoading = false;
      });
    }
  }

  IconData _iconForPaymentType(String name) {
    switch (name.toUpperCase()) {
      case 'CASH':
        return Icons.payments_outlined;
      case 'E-WALLET':
        return Icons.account_balance_wallet_outlined;
      default:
        return Icons.payment_outlined;
    }
  }

  String _titleForPaymentType(String name) {
    return name
        .toLowerCase()
        .split(' ')
        .map((word) {
          return word
              .split('-')
              .map((part) {
                if (part.isEmpty) return part;
                return part[0].toUpperCase() + part.substring(1);
              })
              .join('-');
        })
        .join(' ');
  }

  String _subtitleForPaymentType(String name) {
    switch (name.toUpperCase()) {
      case 'CASH':
        return 'A representative will collect your payment.';

      case 'CHECK':
        return 'Submit check details for review.';

      case 'E-WALLET':
        return 'Upload proof and reference.';

      case 'BANK TRANSFER':
        return 'Submit transfer details for review.';

      default:
        return 'Proceed with this payment method.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(24),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: AppTheme.borderGray,
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          const SizedBox(height: 18),
          if (isLoading)
            const _PaymentSheetHeaderSkeleton()
          else ...[
            const Text(
              'Choose Payment Method',
              style: TextStyle(
                color: AppTheme.black,
                fontSize: 17,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Select how you would like to settle your payment.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.gray,
                fontSize: 12,
                height: 1.35,
              ),
            ),
          ],

          const SizedBox(height: 20),

          if (isLoading)
          const _PaymentTypeSkeletonLoad()
          else if (paymentTypes.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 18),
              child: Text(
                'No payment methods available.',
                style: TextStyle(
                  color: AppTheme.gray,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          else
            ...paymentTypes.map((paymentType) {
              final name = paymentType['typ_name'].toString();

              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _PaymentOptionTile(
                  icon: _iconForPaymentType(name),
                  title: _titleForPaymentType(name),
                  subtitle: _subtitleForPaymentType(name),
                  onTap: () {
                    Navigator.pop(context);
                    widget.onPaymentTypeSelected(paymentType);
                  },
                ),
              );
            }).toList(),
        ],
      ),
    );
  }
}

class _PaymentOptionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _PaymentOptionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.lightGray.withOpacity(0.45),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderGray),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.primaryRed, size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: AppTheme.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: AppTheme.gray,
                      fontSize: 10.5,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.gray,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentTypeSkeletonLoad extends StatelessWidget {
  const _PaymentTypeSkeletonLoad();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _PaymentTypeTileSkeleton(),
        SizedBox(height: 10),
        _PaymentTypeTileSkeleton(),
        SizedBox(height: 10),
        _PaymentTypeTileSkeleton(),
        SizedBox(height: 10),
        _PaymentTypeTileSkeleton(),
      ],
    );
  }
}

class _PaymentTypeTileSkeleton extends StatelessWidget {
  const _PaymentTypeTileSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Row(
          children: [
            AppSkeletonLine(width: 24, height: 24, radius: 50),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppSkeletonLine(width: 80, height: 12),
                  SizedBox(height: 8),
                  AppSkeletonLine(width: double.infinity, height: 9),
                  SizedBox(height: 6),
                  AppSkeletonLine(width: 150, height: 9),
                ],
              ),
            ),
            SizedBox(width: 12),
            AppSkeletonLine(width: 18, height: 18, radius: 50),
          ],
        ),
      ),
    );
  }
}

class _PaymentSheetHeaderSkeleton extends StatelessWidget {
  const _PaymentSheetHeaderSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child: Column(
        children: [
          AppSkeletonLine(width: 180, height: 17),
          SizedBox(height: 8),
          AppSkeletonLine(width: 260, height: 11),
        ],
      ),
    );
  }
}