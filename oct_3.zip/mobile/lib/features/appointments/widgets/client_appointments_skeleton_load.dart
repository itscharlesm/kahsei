import 'package:flutter/material.dart';
import 'package:mobile_app/app/theme.dart';
import 'package:mobile_app/shared/widgets/loading/app_shimmer.dart';
import 'package:mobile_app/shared/widgets/loading/app_skeleton_line.dart';

class ClientAppointmentsSkeletonLoad extends StatelessWidget {
  const ClientAppointmentsSkeletonLoad({super.key});

  static const int skeletonCardCount = 6;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _AppointmentHeaderSkeleton(),
          const SizedBox(height: 16),
          const _FilterChipsSkeleton(),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: List.generate(
                  skeletonCardCount,
                  (index) => Padding(
                    padding: EdgeInsets.only(
                      bottom: index == skeletonCardCount - 1 ? 0 : 12,
                    ),
                    child: const _AppointmentCardSkeleton(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AppointmentHeaderSkeleton extends StatelessWidget {
  const _AppointmentHeaderSkeleton();

  @override
  Widget build(BuildContext context) {
    return const AppShimmer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppSkeletonLine(width: 185, height: 18),
          SizedBox(height: 8),
          AppSkeletonLine(width: 285, height: 12),
        ],
      ),
    );
  }
}

class _FilterChipsSkeleton extends StatelessWidget {
  const _FilterChipsSkeleton();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 38,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const NeverScrollableScrollPhysics(),
        child: AppShimmer(
          child: Row(
            children: const [
              AppSkeletonLine(width: 58, height: 38, radius: 20),
              SizedBox(width: 8),
              AppSkeletonLine(width: 92, height: 38, radius: 20),
              SizedBox(width: 8),
              AppSkeletonLine(width: 84, height: 38, radius: 20),
              SizedBox(width: 8),
              AppSkeletonLine(width: 96, height: 38, radius: 20),
              SizedBox(width: 8),
              AppSkeletonLine(width: 96, height: 38, radius: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppointmentCardSkeleton extends StatelessWidget {
  const _AppointmentCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.borderGray),
      ),
      child: const AppShimmer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AppSkeletonLine(width: 82, height: 24, radius: 20),
                Spacer(),
                AppSkeletonLine(width: 75, height: 18),
              ],
            ),

            SizedBox(height: 16),

            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppSkeletonLine(width: 190, height: 17),
                      SizedBox(height: 12),

                      _InfoRowSkeleton(width: 230),
                      SizedBox(height: 8),
                      _InfoRowSkeleton(width: double.infinity),
                    ],
                  ),
                ),
                SizedBox(width: 10),
                AppSkeletonLine(width: 24, height: 24, radius: 50),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRowSkeleton extends StatelessWidget {
  final double width;

  const _InfoRowSkeleton({
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const AppSkeletonLine(width: 15, height: 15, radius: 50),
        const SizedBox(width: 7),
        Expanded(
          child: AppSkeletonLine(width: width, height: 12),
        ),
      ],
    );
  }
}