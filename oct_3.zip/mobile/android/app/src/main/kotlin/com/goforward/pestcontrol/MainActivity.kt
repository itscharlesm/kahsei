package com.goforward.pestcontrol

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
