@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Clients</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Profiling</li>
                        <li class="breadcrumb-item active">Clients</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <div class="col-md-12">
                            @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('PROFILING OFFICER') == '1')
                                <a class="btn btn-danger btn-md mb-3" href="{{ url('profiling/clients/deleted') }}">
                                    <span class="fa fa-archive"></span> Deleted Clients
                                </a>

                                <button type="button" class="btn btn-success mb-3" data-toggle="modal"
                                    data-target="#addClientModal">
                                    <span class="fa fa-plus"></span> Add Client
                                </button>

                                <button type="button" class="btn btn-primary mb-3" data-toggle="modal"
                                    data-target="#batchUploadClientModal">
                                    <span class="fa fa-upload"></span> Batch Upload Client
                                </button>

                                <a class="btn btn-secondary mb-3" href="{{ asset('images/client_csv_format.csv') }}" download>
                                    <span class="fa fa-download"></span> CSV Format
                                </a>
                            @endif
                        </div>
                    </div>

                    <div class="row">
                        <!-- Table Column -->
                        <div class="col-lg-12 col-md-7">
                            <form method="GET" action="{{ url('profiling/clients/active') }}" class="mb-3">
                                <div class="input-group">
                                    <input type="text" name="search" id="searchInput" class="form-control"
                                        placeholder="Search clients..." value="{{ request('search') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <span class="fa fa-search"></span> Search
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <table id="profilingTable" class="table table-hover table-bordered table-sm responsive">
                                <thead>
                                    <tr>
                                        <th style="vertical-align: middle; text-align: center">Name</th>
                                        <th style="vertical-align: middle; text-align: center">Branch</th>
                                        <th style="vertical-align: middle; text-align: center" width="110px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($clients as $client)
                                        <tr>
                                            <td style="vertical-align: middle; text-align: left">
                                                {{ $client->usr_last_name }}, {{ $client->usr_first_name }}
                                                {{ $client->usr_middle_name }}
                                                <br />
                                                <small>{{ $client->usr_email }}</small>
                                                <br />
                                                <em><small>Last login: {{ getLastLogin($client->usr_id) }}</small></em>
                                            </td>
                                            <td style="vertical-align: middle; text-align: center">
                                                {{ $client->branch_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center">
                                                <a class="btn btn-primary btn-sm mb-1" href="javascript:void(0)"
                                                    data-toggle="modal"
                                                    data-target="#viewClientModal-{{ $client->usr_id }}">
                                                    <span class="fa fa-eye"></span>
                                                </a>
                                                <a class="btn btn-warning btn-sm mb-1" href="javascript:void(0)"
                                                    data-toggle="modal" data-target="#updateBranchModal-{{ $client->usr_id }}">
                                                    <span class="fa fa-edit"></span>
                                                </a>
                                                <a class="btn btn-success btn-sm mb-1" href="javascript:void(0)"
                                                    data-toggle="modal" data-target="#addressModal-{{ $client->usr_id }}">
                                                    <span class="fa fa-home"></span>
                                                </a>
                                                <a class="btn btn-info btn-sm mb-1" href="javascript:void(0)"
                                                    data-toggle="modal" data-target="#resetModal-{{ $client->usr_id }}">
                                                    <span class="fa fa-key"></span>
                                                </a>
                                                <a class="btn btn-dark btn-sm mb-1 btn-view-contracts" href="javascript:void(0)"
                                                    data-id="{{ $client->usr_id }}"
                                                    data-name="{{ $client->usr_first_name }} {{ $client->usr_last_name }}"
                                                    title="Contracts">
                                                    <span class="fa fa-file-contract"></span>
                                                </a>
                                                @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1')
                                                    <a class="btn btn-danger btn-sm mb-1" href="javascript:void(0)"
                                                        data-toggle="modal"
                                                        data-target="#deleteModal-{{ $client->usr_id }}">
                                                        <span class="fa fa-trash"></span>
                                                    </a>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Add Client Modal --}}
    <div class="modal fade" id="addClientModal" tabindex="-1" role="dialog" aria-labelledby="addClientModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <form action="{{ url('profiling/clients/add') }}" method="POST">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title text-white" id="addClientModalLabel">
                            <span class="fa fa-plus text-white"></span> Add Client
                        </h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            {{-- First Name --}}
                            <div class="col-md-4 mb-3">
                                <label for="add_client_first_name">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="add_client_first_name" name="usr_first_name"
                                    placeholder="First Name" required>
                            </div>

                            {{-- Middle Name --}}
                            <div class="col-md-4 mb-3">
                                <label for="add_client_middle_name">Middle Name</label>
                                <input type="text" class="form-control" id="add_client_middle_name" name="usr_middle_name"
                                    placeholder="Middle Name">
                            </div>

                            {{-- Last Name --}}
                            <div class="col-md-4 mb-3">
                                <label for="add_client_last_name">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="add_client_last_name" name="usr_last_name"
                                    placeholder="Last Name" required>
                            </div>

                            {{-- Email --}}
                            <div class="col-md-6 mb-3">
                                <label for="add_client_email">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="add_client_email" name="usr_email"
                                    placeholder="Email" required>
                            </div>

                            {{-- Mobile --}}
                            <div class="col-md-6 mb-3">
                                <label for="add_client_mobile">
                                    Mobile Number
                                    <small class="text-muted">(9123456789)</small>
                                </label>
                                <input type="number" class="form-control" id="add_client_mobile" name="usr_mobile"
                                    placeholder="Mobile Number" oninput="this.value=this.value.slice(0,10)">
                            </div>

                            {{-- Branch --}}
                            <div class="col-md-12 mb-3">
                                <label for="add_client_branch_id">Branch <span class="text-danger">*</span></label>
                                <select class="form-control" id="add_client_branch_id" name="branch_id" required>
                                    @foreach ($branches as $branch)
                                        @if ($branch->branch_id != 1)
                                            <option value="{{ $branch->branch_id }}">
                                                {{ $branch->branch_name }}
                                            </option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                        <button type="submit" class="btn btn-success">
                            <span class="fa fa-save"></span> Save Client
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    {{-- Batch Upload Client Modal --}}
    <div class="modal fade" id="batchUploadClientModal" tabindex="-1" role="dialog"
        aria-labelledby="batchUploadClientModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="{{ url('profiling/clients/import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title text-white" id="batchUploadClientModalLabel">
                            <span class="fa fa-upload"></span> Batch Upload Client
                        </h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="csv_file">CSV File <span class="text-danger">*</span></label>
                            <input type="file" class="form-control-file" id="csv_file" name="csv_file"
                                accept=".csv,text/csv" required>
                            <small class="text-muted d-block mt-2">
                                Columns: First Name, Middle Name, Last Name, Email, Mobile Number.
                                <a href="{{ asset('images/client_csv_format.csv') }}" download>Download format</a>
                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <span class="fa fa-upload"></span> Upload
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    @foreach ($clients as $client)
        {{-- View Client Modal --}}
        <div class="modal fade" id="viewClientModal-{{ $client->usr_id }}" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Client Details</h5>
                        <button type="button" class="close text-white" data-dismiss="modal">
                            &times;
                        </button>
                    </div>

                    <div class="modal-body">

                        {{-- PERSONAL INFO --}}
                        <h6 class="font-weight-bold text-black">Personal Information
                        </h6>
                        <hr class="mt-1 mb-2">

                        <div class="row mb-2">
                            <div class="col-md-4">
                                <small class="text-muted">First Name</small>
                                <div>{{ $client->usr_first_name }}</div>
                            </div>
                            <div class="col-md-4">
                                <small class="text-muted">Middle Name</small>
                                <div>{{ $client->usr_middle_name ?? '-' }}</div>
                            </div>
                            <div class="col-md-4">
                                <small class="text-muted">Last Name</small>
                                <div>{{ $client->usr_last_name }}</div>
                            </div>
                        </div>

                        <div class="row mb-2">
                            <div class="col-md-4">
                                <small class="text-muted">Branch</small>
                                <div>{{ $client->branch_name }}</div>
                            </div>
                            <div class="col-md-4">
                                <small class="text-muted">Email</small>
                                <div>{{ $client->usr_email }}</div>
                            </div>
                            <div class="col-md-4">
                                <small class="text-muted">Mobile</small>
                                <div>{{ $client->usr_mobile }}</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <small class="text-muted">Birthdate</small>
                                <div>
                                    {{ $client->usr_birth_date ?? '-' }}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <small class="text-muted">Age</small>
                                <div>
                                    @if ($client->usr_birth_date)
                                        {{ \Carbon\Carbon::parse($client->usr_birth_date)->age }}
                                        years old
                                    @else
                                        -
                                    @endif
                                </div>
                            </div>
                        </div>

                        {{-- ADDRESSES --}}
                        <h6 class="font-weight-bold text-black">Addresses</h6>
                        <hr class="mt-1 mb-2">

                        <div class="row">
                            @php
                                $clientAddresses = $addresses[$client->usr_id] ?? collect();
                            @endphp

                            @if ($clientAddresses->isEmpty())
                                <div class="col-12">
                                    <div class="alert alert-light text-center mb-0">
                                        No address registered
                                    </div>
                                </div>
                            @else
                                @foreach ($clientAddresses as $addr)
                                    <div class="col-md-6 mb-2">
                                        <div
                                            class="card border {{ $addr->uadd_active ? 'border-success' : 'border-secondary' }}">
                                            <div class="card-body p-2">

                                                <strong>
                                                    {{ $addr->add_name ?? 'Address' }}
                                                </strong>

                                                @if ($addr->uadd_street)
                                                    <div class="small">
                                                        {{ $addr->uadd_street }}
                                                    </div>
                                                @endif

                                                @php
                                                    $location = collect([
                                                        $addr->uadd_barangay,
                                                        $addr->uadd_city,
                                                        $addr->uadd_province,
                                                    ])
                                                        ->filter()
                                                        ->implode(', ');
                                                @endphp

                                                @if ($location)
                                                    <div class="small">
                                                        {{ $location }}</div>
                                                @endif

                                                @if ($addr->uadd_region)
                                                    <div class="small text-muted">
                                                        {{ $addr->uadd_region }}
                                                    </div>
                                                @endif

                                                <div class="mt-1">
                                                    <span
                                                        class="badge {{ $addr->uadd_active ? 'badge-success' : 'badge-secondary' }}">
                                                        {{ $addr->uadd_active ? 'Active' : 'Inactive' }}
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                    </div>

                </div>
            </div>
        </div>

        {{-- Update Branch Modal --}}
        <div class="modal fade" id="updateBranchModal-{{ $client->usr_id }}" tabindex="-1" role="dialog"
            aria-labelledby="updateBranchModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="{{ url('profiling/clients/update/branch', $client->usr_id) }}" method="POST">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header bg-warning text-white">
                            <h5 class="modal-title text-black" id="updateBranchModalLabel">
                                Update Branch
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Name: <span style="color:black;">{{ $client->usr_first_name }}
                                        {{ $client->usr_last_name }}</span></label>
                            </div>
                            <div class="form-group">
                                <label for="branch_id-{{ $client->usr_id }}">Branch <span class="text-danger">*</span></label>
                                <select class="form-control" id="branch_id-{{ $client->usr_id }}" name="branch_id" required>
                                    @foreach ($branches as $branch)
                                        @if ($branch->branch_id != 1)
                                            <option value="{{ $branch->branch_id }}"
                                                @if ($branch->branch_id == $client->branch_id) selected @endif>
                                                {{ $branch->branch_name }}
                                            </option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-warning">
                                <span class="fa fa-save"></span> Update
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        {{-- Addresses Modal --}}
        <div class="modal fade" id="addressModal-{{ $client->usr_id }}" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title text-white">
                            <span class="fa fa-home"></span> Addresses - {{ $client->usr_first_name }} {{ $client->usr_last_name }}
                        </h5>
                        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                    </div>

                    <div class="modal-body">
                        @php $clientAddresses = $addresses[$client->usr_id] ?? collect(); @endphp

                        {{-- Existing addresses --}}
                        @forelse ($clientAddresses as $addr)
                            <div class="card border {{ $addr->uadd_active ? 'border-success' : 'border-secondary' }} mb-2">
                                <div class="card-body p-2">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <strong>{{ $addr->add_name ?? 'Address' }}</strong>
                                            <div class="small">{{ $addr->uadd_street }}</div>
                                            <div class="small">
                                                {{ collect([$addr->uadd_barangay, $addr->uadd_city, $addr->uadd_province, $addr->uadd_region])->filter()->implode(', ') }}
                                            </div>
                                            <span class="badge {{ $addr->uadd_active ? 'badge-success' : 'badge-secondary' }}">
                                                {{ $addr->uadd_active ? 'Active' : 'Inactive' }}
                                            </span>
                                        </div>
                                        <div>
                                            <button type="button" class="btn btn-warning btn-sm"
                                                data-toggle="collapse" data-target="#editAddr-{{ $addr->uadd_id }}">
                                                <span class="fa fa-edit"></span> Edit
                                            </button>
                                        </div>
                                    </div>

                                    {{-- Edit form --}}
                                    <div class="collapse mt-2" id="editAddr-{{ $addr->uadd_id }}">
                                        <form method="POST" action="{{ url('profiling/clients/address/edit', $client->usr_id) }}">
                                            @csrf
                                            <input type="hidden" name="uadd_id" value="{{ $addr->uadd_id }}">
                                            <div class="row loc-group">
                                                <div class="col-md-6 mb-2">
                                                    <label class="small font-weight-bold">Label</label>
                                                    <select name="add_id" class="form-control form-control-sm label-select">
                                                        <option value="">-- KEEP CURRENT --</option>
                                                        @foreach ($address_labels as $al)
                                                            <option value="{{ $al->add_id }}" {{ $addr->add_id == $al->add_id ? 'selected' : '' }}>
                                                                {{ $al->add_name }}
                                                            </option>
                                                        @endforeach
                                                        <option value="__new__">+ Create new label...</option>
                                                    </select>
                                                    <input type="text" name="new_add_name"
                                                        class="form-control form-control-sm mt-1 new-label-input d-none"
                                                        placeholder="New label name (e.g. Office)" maxlength="100">
                                                </div>
                                                <div class="col-md-6 mb-2">
                                                    <label class="small font-weight-bold">Street / House No.</label>
                                                    <input type="text" name="street" class="form-control form-control-sm"
                                                        value="{{ $addr->uadd_street }}">
                                                </div>

                                                <div class="col-md-3 mb-2">
                                                    <label class="small font-weight-bold">Region</label>
                                                    <select class="form-control form-control-sm loc-region">
                                                        <option value="">-- KEEP CURRENT --</option>
                                                        @foreach ($regions as $r)
                                                            <option value="{{ $r->reg_id }}" data-name="{{ $r->reg_name }}">{{ $r->reg_name }}</option>
                                                        @endforeach
                                                    </select>
                                                    <input type="hidden" name="region" class="h-region">
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label class="small font-weight-bold">Province</label>
                                                    <select class="form-control form-control-sm loc-province" disabled>
                                                        <option value="">-- SELECT PROVINCE --</option>
                                                    </select>
                                                    <input type="hidden" name="province" class="h-province">
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label class="small font-weight-bold">Municipality</label>
                                                    <select class="form-control form-control-sm loc-municipality" disabled>
                                                        <option value="">-- SELECT MUNICIPALITY --</option>
                                                    </select>
                                                    <input type="hidden" name="municipality" class="h-municipality">
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label class="small font-weight-bold">Barangay</label>
                                                    <select class="form-control form-control-sm loc-barangay" disabled>
                                                        <option value="">-- SELECT BARANGAY --</option>
                                                    </select>
                                                    <input type="hidden" name="barangay" class="h-barangay">
                                                </div>

                                                <div class="col-md-4 mb-2">
                                                    <label class="small font-weight-bold">Latitude</label>
                                                    <input type="text" name="latitude" class="form-control form-control-sm"
                                                        value="{{ $addr->uadd_latitude }}">
                                                </div>
                                                <div class="col-md-4 mb-2">
                                                    <label class="small font-weight-bold">Longitude</label>
                                                    <input type="text" name="longitude" class="form-control form-control-sm"
                                                        value="{{ $addr->uadd_longitude }}">
                                                </div>
                                                <div class="col-md-4 mb-2 d-flex align-items-end">
                                                    <div class="custom-control custom-switch">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="active_{{ $addr->uadd_id }}" name="uadd_active" value="1"
                                                            {{ $addr->uadd_active ? 'checked' : '' }}>
                                                        <label class="custom-control-label" for="active_{{ $addr->uadd_id }}">Active</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-warning btn-sm">
                                                <span class="fa fa-save"></span> Update Address
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="alert alert-light text-center">No address registered</div>
                        @endforelse

                        {{-- Add address --}}
                        <hr>
                        <button type="button" class="btn btn-success btn-sm mb-2"
                            data-toggle="collapse" data-target="#addAddr-{{ $client->usr_id }}">
                            <span class="fa fa-plus"></span> Add Address
                        </button>

                        <div class="collapse" id="addAddr-{{ $client->usr_id }}">
                            <form method="POST" action="{{ url('profiling/clients/address/add', $client->usr_id) }}">
                                @csrf
                                <div class="row loc-group">
                                    <div class="col-md-6 mb-2">
                                        <label class="small font-weight-bold">Label</label>
                                        <select name="add_id" class="form-control form-control-sm label-select">
                                            @foreach ($address_labels as $al)
                                                <option value="{{ $al->add_id }}">{{ $al->add_name }}</option>
                                            @endforeach
                                            <option value="__new__">+ Create new label...</option>
                                        </select>
                                        <input type="text" name="new_add_name"
                                            class="form-control form-control-sm mt-1 new-label-input d-none"
                                            placeholder="New label name (e.g. Office)" maxlength="100">
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <label class="small font-weight-bold">Street / House No.</label>
                                        <input type="text" name="street" class="form-control form-control-sm">
                                    </div>

                                    <div class="col-md-3 mb-2">
                                        <label class="small font-weight-bold">Region</label>
                                        <select class="form-control form-control-sm loc-region">
                                            <option value="">-- SELECT REGION --</option>
                                            @foreach ($regions as $r)
                                                <option value="{{ $r->reg_id }}" data-name="{{ $r->reg_name }}">{{ $r->reg_name }}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" name="region" class="h-region">
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <label class="small font-weight-bold">Province</label>
                                        <select class="form-control form-control-sm loc-province" disabled>
                                            <option value="">-- SELECT PROVINCE --</option>
                                        </select>
                                        <input type="hidden" name="province" class="h-province">
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <label class="small font-weight-bold">Municipality</label>
                                        <select class="form-control form-control-sm loc-municipality" disabled>
                                            <option value="">-- SELECT MUNICIPALITY --</option>
                                        </select>
                                        <input type="hidden" name="municipality" class="h-municipality">
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <label class="small font-weight-bold">Barangay</label>
                                        <select class="form-control form-control-sm loc-barangay" disabled>
                                            <option value="">-- SELECT BARANGAY --</option>
                                        </select>
                                        <input type="hidden" name="barangay" class="h-barangay">
                                    </div>

                                    <div class="col-md-6 mb-2">
                                        <label class="small font-weight-bold">Latitude</label>
                                        <input type="text" name="latitude" class="form-control form-control-sm">
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <label class="small font-weight-bold">Longitude</label>
                                        <input type="text" name="longitude" class="form-control form-control-sm">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success btn-sm">
                                    <span class="fa fa-save"></span> Save Address
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {{-- Reset Password Modal --}}
        <div class="modal fade" id="resetModal-{{ $client->usr_id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form method="POST"
                        action="{{ action('App\Http\Controllers\ProfilingController@clients_reset_password', [$client->usr_id]) }}">
                        @csrf
                        <div class="modal-header bg-info text-white">
                            <h5 class="modal-title text-black" id="exampleModalLabel">
                                Please Confirm
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to RESET this client's password
                                to
                                <strong>123456</strong>?
                            </p>
                            <small>{{ $client->usr_first_name }}
                                {{ $client->usr_last_name }}<br>{{ $client->usr_email }}</small>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-info">
                                <span class="fa fa-refresh"></span> Confirm Reset
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        {{-- Delete Modal --}}
        <div class="modal fade" id="deleteModal-{{ $client->usr_id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form method="POST"
                        action="{{ action('App\Http\Controllers\ProfilingController@clients_delete', [$client->usr_id]) }}">
                        @csrf
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title text-white" id="exampleModalLabel">
                                Please Confirm
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to <strong>DELETE</strong> client
                                <strong>{{ $client->usr_first_name }}
                                    {{ $client->usr_last_name }}</strong>?
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-danger">
                                <span class="fa fa-trash"></span> Confirm Delete
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    {{-- Client Contracts Modal (lazy loaded) --}}
    <div class="modal fade" id="clientContractsModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title text-white">
                        <span class="fa fa-file-contract"></span> Contracts - <span id="contractsClientName"></span>
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" id="clientContractsBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <span class="fa fa-close"></span> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const body = document.getElementById('clientContractsBody');
            const nameEl = document.getElementById('contractsClientName');

            const routeMap = {
                'REQUESTED': 'service/order/appointments/requested/',
                'CONFIRM ASSESSMENT': 'service/order/appointments/requested/',
                'ASSESSED': 'service/order/appointments/assessed/',
                'SCHEDULED': 'service/order/appointments/scheduled/',
                'ONGOING': 'service/order/appointments/ongoing/',
                'DONE REPORT': 'service/order/appointments/finished/',
                'COMPLETED': 'service/order/appointments/completed/'
            };

            function esc(s) {
                const d = document.createElement('div');
                d.textContent = s ?? '';
                return d.innerHTML;
            }

            function freqLabel(type) {
                const m = /^MONTHLY-(\d)X$/.exec(type || '');
                if (m) {
                    const l = {'2': 'Twice', '3': 'Thrice', '4': '4 Times'};
                    return 'MONTHLY (' + (l[m[1]] || m[1] + 'x') + ' a month)';
                }
                return type === 'BIMONTHLY' ? 'EVERY OTHER MONTH' : (type || '');
            }

            document.addEventListener('click', async function(e) {
                const btn = e.target.closest('.btn-view-contracts');
                if (!btn) return;

                nameEl.textContent = btn.dataset.name;
                body.innerHTML = '<div class="text-center text-muted py-3"><span class="fa fa-spinner fa-spin"></span> Loading...</div>';
                $('#clientContractsModal').modal('show');

                try {
                    const res = await fetch(`${window.location.origin}/profiling/clients/contracts/${btn.dataset.id}`, {
                        headers: {'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest'}
                    });
                    if (!res.ok) throw new Error();
                    const contracts = await res.json();

                    if (!contracts.length) {
                        body.innerHTML = '<div class="alert alert-light text-center mb-0">No contracts found for this client.</div>';
                        return;
                    }

                    body.innerHTML = contracts.map(c => {
                        const jos = c.job_orders.map(j => {
                            const prefix = routeMap[j.status];
                            const label = esc(j.sa_number) + (prefix ? '' : ' (' + esc(j.status) + ')');
                            const cls = j.is_initiated ? 'badge-warning' : (prefix ? 'badge-primary' : 'badge-secondary');
                            const star = j.is_initiated ? '<span class="fa fa-star"></span> ' : '';
                            const tag = j.is_initiated ? ' <small class="text-muted">(Contract initiated here)</small>' : '';
                            const badge = prefix
                                ? `<a href="${window.location.origin}/${prefix}${j.svc_id}" target="_blank" class="badge ${cls} p-2" style="font-size:0.85rem;">${star}${label}</a>`
                                : `<span class="badge ${cls} p-2" style="font-size:0.85rem;">${star}${label}</span>`;
                            return `<div class="mb-1">${badge}${tag} <small class="text-muted">${esc(j.status)}</small></div>`;
                        }).join('');

                        return `
                            <div class="card border mb-3">
                                <div class="card-header p-2">
                                    <strong>${esc(freqLabel(c.type))}</strong>
                                    <span class="text-muted">| ${esc(c.duration)} | ${esc(c.total_services)} services</span>
                                    ${c.file ? `<a href="${c.file}" download target="_blank" class="badge badge-info p-2 float-right"><span class="fa fa-download"></span> Contract</a>` : ''}
                                </div>
                                <div class="card-body p-2">${jos || '<span class="text-muted">No job orders.</span>'}</div>
                            </div>`;
                    }).join('');
                } catch (err) {
                    body.innerHTML = '<div class="alert alert-danger text-center mb-0">Failed to load contracts.</div>';
                }
            });
        });
    </script>

    {{-- Dynamic Search While Typing --}}
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function() {
            let value = this.value.toLowerCase();

            // Select all tables with ID containing "Table"
            let tables = document.querySelectorAll('table[id*="Table"]');

            tables.forEach(function(table) {
                let rows = table.querySelectorAll("tbody tr");

                rows.forEach(function(row) {
                    let text = row.innerText.toLowerCase();
                    row.style.display = text.includes(value) ? "" : "none";
                });
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const baseUrl = window.location.origin;
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

            // level => [next level, endpoint suffix, text key, value key]
            const levels = {
                region:       { next: 'province',     url: 'provinces',      text: 'prov_name', val: 'prov_id' },
                province:     { next: 'municipality', url: 'municipalities', text: 'mun_name',  val: 'mun_id' },
                municipality: { next: 'barangay',     url: 'barangays',      text: 'brg_name',  val: 'brg_id' },
                barangay:     null
            };
            const order = ['region', 'province', 'municipality', 'barangay'];

            function reset(group, level) {
                const el = group.querySelector('.loc-' + level);
                el.innerHTML = `<option value="">-- SELECT ${level.toUpperCase()} --</option>`;
                el.disabled = true;
                group.querySelector('.h-' + level).value = '';
            }

            document.addEventListener('change', async function(e) {
                const select = e.target;
                const group = select.closest('.loc-group');
                if (!group) return;

                const level = order.find(l => select.classList.contains('loc-' + l));
                if (!level) return;

                // save selected name into hidden input
                group.querySelector('.h-' + level).value =
                    select.options[select.selectedIndex]?.getAttribute('data-name') || '';

                // reset everything below this level
                order.slice(order.indexOf(level) + 1).forEach(l => reset(group, l));

                const cfg = levels[level];
                if (!cfg || !select.value) return;

                const nextEl = group.querySelector('.loc-' + cfg.next);
                nextEl.innerHTML = '<option value="">Loading...</option>';
                try {
                    const res = await fetch(`${baseUrl}/locations/${select.value}/${cfg.url}`, {
                        headers: {
                            'X-CSRF-TOKEN': csrfToken,
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    if (!res.ok) throw new Error();
                    const data = await res.json();
                    nextEl.innerHTML = `<option value="">-- SELECT ${cfg.next.toUpperCase()} --</option>`;
                    data.forEach(item => {
                        nextEl.insertAdjacentHTML('beforeend',
                            `<option value="${item[cfg.val]}" data-name="${item[cfg.text]}">${item[cfg.text]}</option>`);
                    });
                    nextEl.disabled = false;
                } catch (err) {
                    nextEl.innerHTML = '<option value="">Error loading</option>';
                }
            });
        });
    </script>

    {{-- Create new address label inline --}}
    <script>
        document.addEventListener('change', function(e) {
            if (!e.target.classList.contains('label-select')) return;
            const input = e.target.parentElement.querySelector('.new-label-input');
            const isNew = e.target.value === '__new__';
            input.classList.toggle('d-none', !isNew);
            input.required = isNew;
            if (isNew) {
                input.focus();
            } else {
                input.value = '';
            }
        });
    </script>
@endsection