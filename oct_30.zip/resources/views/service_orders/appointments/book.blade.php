@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Book Appointment</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item active">Book Appointment</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <!-- Table Column -->
                        <div class="col-lg-12 col-md-7">
                            <form method="GET" action="{{ url('service/order/appointments/clients') }}" class="mb-3">
                                <div class="input-group">
                                    <input type="text" name="search" id="searchInput" class="form-control"
                                        placeholder="Search clients..." value="{{ request('search') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <span class="fa fa-search"></span> Search
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <table id="profilingTable" class="table table-hover table-bordered table-sm responsive">
                                <thead>
                                    <tr>
                                        <th style="vertical-align: middle; text-align: center">Name</th>
                                        <th style="vertical-align: middle; text-align: center">Branch</th>
                                        <th style="vertical-align: middle; text-align: center">Address(es)</th>
                                        <th style="vertical-align: middle; text-align: center" width="110px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($clients as $client)
                                        <tr>
                                            <td style="vertical-align: middle; text-align: left">
                                                {{ $client->usr_last_name }}, {{ $client->usr_first_name }}
                                                {{ $client->usr_middle_name }}
                                                <br />
                                                <small>{{ $client->usr_email }}</small>
                                                <br />
                                                <small>0{{ $client->usr_mobile }}</small>
                                            </td>
                                            <td style="vertical-align: middle; text-align: center">
                                                {{ $client->branch_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: left">
                                                @if (isset($addresses[$client->usr_id]) && count($addresses[$client->usr_id]) > 0)
                                                    <ul style="padding-left: 18px; margin-bottom: 0;">
                                                        @foreach ($addresses[$client->usr_id] as $address)
                                                            <li>
                                                                {{ $address->uadd_street }},
                                                                {{ $address->uadd_barangay }},
                                                                {{ $address->uadd_city }},
                                                                {{ $address->uadd_province }},
                                                                {{ $address->uadd_region }}

                                                                @if (!empty($address->uadd_longitude) && !empty($address->uadd_latitude))
                                                                    ({{ $address->uadd_longitude }},
                                                                    {{ $address->uadd_latitude }})
                                                                @endif

                                                                - {{ $address->add_name }}
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                @else
                                                    <small class="text-muted">No active address</small>
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center">
                                                <a class="btn btn-success btn-sm mb-1" href="javascript:void(0)"
                                                    data-toggle="modal"
                                                    data-target="#bookAppointmentModal-{{ $client->usr_id }}">
                                                    <span class="fa fa-calendar"></span>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @foreach ($clients as $client)
        {{-- Book Appointment Modal --}}
        <div class="modal fade" id="bookAppointmentModal-{{ $client->usr_id }}" tabindex="-1" role="dialog"
            aria-labelledby="bookAppointmentModal-{{ $client->usr_id }}" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form method="POST" action="{{ url('service/order/appointments/clients/book') }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title text-white" id="bookAppointmentModal-{{ $client->usr_id }}">
                                Book Appointment for {{ $client->usr_last_name }},
                                {{ $client->usr_first_name }}
                                {{ $client->usr_middle_name }}
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <input type="hidden" name="usr_id" value="{{ $client->usr_id }}">

                            {{-- ADDRESS --}}
                            <div class="form-group">
                                <label>Address: <span class="text-danger">*</span></label>
                                <select class="form-control" name="uadd_id" required>
                                    @if (isset($addresses[$client->usr_id]) && count($addresses[$client->usr_id]) > 0)
                                        @foreach ($addresses[$client->usr_id] as $address)
                                            <option value="{{ $address->uadd_id }}">
                                                {{ $address->add_name }} —
                                                {{ $address->uadd_street }},
                                                {{ $address->uadd_barangay }},
                                                {{ $address->uadd_city }},
                                                {{ $address->uadd_province }}
                                            </option>
                                        @endforeach
                                    @else
                                        <option disabled>No active address available
                                        </option>
                                    @endif
                                </select>
                            </div>

                            {{-- ASSIGN BRANCH --}}
                            <div class="form-group">
                                <label>Assign Branch: <span class="text-danger">*</span></label>
                                <select class="form-control book-branch-select" name="branch_id"
                                    data-client="{{ $client->usr_id }}" required>
                                    @foreach ($branches as $branch)
                                        @if ($branch->branch_id != 1)
                                            <option value="{{ $branch->branch_id }}">
                                                {{ $branch->branch_name }}
                                            </option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>

                            <hr>

                            {{-- PROBLEM TYPE --}}
                            <div class="form-group">
                                <label>Problem Type <span class="text-danger">*</span></label>
                                <select class="form-control book-pest-select" name="svcp_id" data-client="{{ $client->usr_id }}"
                                    required>
                                    <option value="">— Select Problem Type —</option>
                                    @foreach ($servicePackages as $pkg)
                                        <option value="{{ $pkg->svcp_id }}">
                                            {{ $pkg->svcp_pest_type }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            {{-- Extra Problem Types (added via +, independent of Location) --}}
                            <div class="book-extra-pests-{{ $client->usr_id }}"></div>
                            <div class="form-group">
                                <button type="button" class="btn btn-outline-success btn-sm book-add-pest"
                                    data-client="{{ $client->usr_id }}">
                                    <span class="fa fa-plus"></span> Add Problem Type
                                </button>
                            </div>

                            {{-- IS PACKAGE — hidden when termite is selected --}}
                            <div class="form-group book-package-group-{{ $client->usr_id }}">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="isPackage-{{ $client->usr_id }}"
                                        name="is_package" value="1">
                                    <label class="custom-control-label" for="isPackage-{{ $client->usr_id }}">
                                        Is package?
                                    </label>
                                </div>
                            </div>

                            {{-- Location (area) — shown when svcp_id != 8 (termite) --}}
                            <div class="form-group book-area-group-{{ $client->usr_id }}" style="display:none;">
                                <label>Location <span class="text-danger">*</span></label>
                                <select class="form-control book-area-select" name="svcpa_id"
                                    data-client="{{ $client->usr_id }}" required>
                                    <option value="">— Select Branch First —</option>

                                    {{-- Pre-render all areas grouped by branch as data attributes --}}
                                    @foreach ($servicePackageAreas as $branchId => $areas)
                                        @foreach ($areas as $area)
                                            <option value="{{ $area->svcpa_id }}" data-branch="{{ $branchId }}"
                                                data-cost="{{ $area->svcpa_cost }}" style="display:none;">
                                                {{ $area->svcpa_area }}
                                            </option>
                                        @endforeach
                                    @endforeach
                                </select>
                                <small class="text-muted book-area-cost-{{ $client->usr_id }}"></small>
                            </div>

                            {{-- Termite Treatment Size — shown when svcp_id == 8 (termite) --}}
                            <div class="form-group book-termite-group-{{ $client->usr_id }}" style="display:none;">
                                <label>Termite Treatment Size <span class="text-danger">*</span></label>
                                <select class="form-control book-termite-select" name="svcpat_id"
                                    data-client="{{ $client->usr_id }}">
                                    <option value="">— Select Branch First —</option>

                                    @foreach ($termiteAreas as $branchId => $tAreas)
                                        @foreach ($tAreas as $t)
                                            <option value="{{ $t->svcpat_id }}" data-branch="{{ $branchId }}" style="display:none;">
                                                {{ $t->svcpat_sqm_details }}
                                                (₱{{ number_format($t->svcpat_cost, 2) }})
                                            </option>
                                        @endforeach
                                    @endforeach
                                </select>
                            </div>

                            {{-- Extra Locations (added via +, independent of Problem Type) --}}
                            <div class="book-extra-locs-{{ $client->usr_id }}"></div>
                            <div class="form-group">
                                <button type="button" class="btn btn-outline-success btn-sm book-add-loc"
                                    data-client="{{ $client->usr_id }}">
                                    <span class="fa fa-plus"></span> Add Location
                                </button>
                            </div>
                            <div class="font-weight-bold mb-3 book-loc-total-{{ $client->usr_id }}"></div>

                            {{-- Problem Description --}}
                            <div class="form-group">
                                <label><strong>Problem Description <span class="text-muted">(Optional)</span></strong></label>
                                <textarea class="form-control" name="svc_problem_description" rows="3"
                                    placeholder="Describe the problem..."></textarea>
                            </div>

                            <hr>

                            {{-- SCHEDULE --}}
                            <div class="form-group">
                                <label>Preferred Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="svca_client_date"
                                    value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}"
                                    min="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" required>
                            </div>

                            <div class="form-group">
                                <label>Time Window <span class="text-danger">*</span></label>
                                <select class="form-control" name="svca_client_time" required>
                                    <option value="">— Select Time Window —</option>
                                    <option value="08:00">Morning (8:00 AM – 12:00 PM)
                                    </option>
                                    <option value="12:00">Afternoon (12:00 PM – 5:00 PM)
                                    </option>
                                    <option value="17:00">Evening (5:00 PM – 8:00 PM)
                                    </option>
                                </select>
                            </div>

                            <hr>

                            {{-- INITIATE CONTRACT --}}
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input book-initiate-contract"
                                        id="initiateContract-{{ $client->usr_id }}" data-client="{{ $client->usr_id }}"
                                        name="initiate_contract" value="1">
                                    <label class="custom-control-label" for="initiateContract-{{ $client->usr_id }}">
                                        Initiate Contract
                                    </label>
                                </div>
                            </div>

                            <div class="book-contract-fields-{{ $client->usr_id }}" style="display:none;">
                                {{-- FINAL PRICE (saved to svc_initial_price and svc_final_price) --}}
                                <div class="form-group">
                                    <label>Final Price <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" name="svc_final_price" step="0.01" min="0"
                                        placeholder="0.00">
                                </div>

                                <div class="form-group">
                                    <label>Frequency <span class="text-danger">*</span></label>
                                    <select class="form-control book-contract-frequency" data-client="{{ $client->usr_id }}"
                                        name="svcc_base_frequency">
                                        <option value="WEEKLY">WEEKLY</option>
                                        <option value="MONTHLY">MONTHLY</option>
                                        <option value="BIMONTHLY">EVERY OTHER MONTH (BI-MONTHLY)</option>
                                        <option value="QUARTERLY">QUARTERLY</option>
                                        <option value="SEMI-ANNUAL">SEMI-ANNUAL</option>
                                        <option value="ANNUAL">ANNUAL</option>
                                    </select>
                                </div>

                                <div class="form-group book-contract-occurrence-wrapper-{{ $client->usr_id }}"
                                    style="display:none;">
                                    <label>How many times per month?</label>
                                    <select class="form-control book-contract-occurrence" data-client="{{ $client->usr_id }}"
                                        name="svcc_occurrence">
                                        <option value="1">Once</option>
                                        <option value="2">Twice</option>
                                        <option value="3">Thrice</option>
                                        <option value="4">4 Times</option>
                                    </select>
                                </div>

                                <input type="hidden" class="book-contract-type" data-client="{{ $client->usr_id }}"
                                    name="svcc_type">

                                <div class="form-group">
                                    <label>Contract Duration <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="svcc_total_years"
                                        placeholder="e.g. 1.5, 3.11, 0.3" pattern="^\d+(\.\d{1,2})?$">
                                    <small class="form-text text-muted">
                                        Format: <strong>years.months</strong> — e.g. <code>1.5</code> = 1 year 5
                                        months, <code>3.11</code> = 3 years 11 months, <code>0.3</code> = 3 months.
                                        (Months portion must be 0–11)
                                    </small>
                                </div>

                                <div class="form-group">
                                    <label>Contract Attachment <span class="text-danger">*</span></label>
                                    <input type="file" class="form-control-file" name="svcc_contract"
                                        accept=".jpg,.jpeg,.png,.pdf,.docx">
                                    <small class="form-text text-muted">Accepted: JPG, PNG, PDF, DOCX. Max
                                        10MB.</small>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-success">
                                <span class="fa fa-check"></span> Book Appointment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    {{-- Dynamic Search While Typing --}}
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let value = this.value.toLowerCase();

            // Select all tables with ID containing "Table"
            let tables = document.querySelectorAll('table[id*="Table"]');

            tables.forEach(function (table) {
                let rows = table.querySelectorAll("tbody tr");

                rows.forEach(function (row) {
                    let text = row.innerText.toLowerCase();
                    row.style.display = text.includes(value) ? "" : "none";
                });
            });
        });
    </script>

    <script>
        (function () {
            const TERMITE_ID = 8;

            function filterOptionsByBranch(select, branchId) {
                const options = select.querySelectorAll('option[data-branch]');
                let hasVisible = false;

                options.forEach(function (opt) {
                    if (opt.dataset.branch == branchId) {
                        opt.style.display = '';
                        hasVisible = true;
                    } else {
                        opt.style.display = 'none';
                        opt.selected = false;
                    }
                });

                // Reset to placeholder
                select.value = '';
                select.querySelector('option:not([data-branch])').textContent =
                    hasVisible ? '— Select —' : '— No options for this branch —';
            }

            function toggleAreaTermite(clientId, pestId, branchId) {
                const areaGroup = document.querySelector('.book-area-group-' + clientId);
                const termiteGroup = document.querySelector('.book-termite-group-' + clientId);
                const packageGroup = document.querySelector('.book-package-group-' + clientId);
                const packageChk = document.getElementById('isPackage-' + clientId);

                if (!pestId) {
                    areaGroup.style.display = 'none';
                    termiteGroup.style.display = 'none';
                    packageGroup.style.display = 'block';
                    return;
                }

                if (parseInt(pestId) === TERMITE_ID) {
                    areaGroup.style.display = 'none';
                    termiteGroup.style.display = 'block';

                    // Hide and reset the package checkbox for termite
                    packageGroup.style.display = 'none';
                    packageChk.checked = false;

                    if (branchId) {
                        filterOptionsByBranch(
                            document.querySelector('.book-termite-select[data-client="' + clientId + '"]'),
                            branchId
                        );
                    }
                } else {
                    termiteGroup.style.display = 'none';
                    areaGroup.style.display = 'block';
                    packageGroup.style.display = 'block';

                    if (branchId) {
                        filterOptionsByBranch(
                            document.querySelector('.book-area-select[data-client="' + clientId + '"]'),
                            branchId
                        );
                    }
                }
            }

            // Branch change
            document.querySelectorAll('.book-branch-select').forEach(function (branchSel) {
                branchSel.addEventListener('change', function () {
                    const clientId = this.dataset.client;
                    const branchId = this.value;
                    const pestId = document.querySelector('.book-pest-select[data-client="' + clientId +
                        '"]').value;

                    toggleAreaTermite(clientId, pestId, branchId);
                });
            });

            // Pest type change
            document.querySelectorAll('.book-pest-select').forEach(function (pestSel) {
                pestSel.addEventListener('change', function () {
                    const clientId = this.dataset.client;
                    const pestId = this.value;
                    const branchId = document.querySelector('.book-branch-select[data-client="' +
                        clientId + '"]').value;

                    toggleAreaTermite(clientId, pestId, branchId);
                });
            });

            // Area cost hint
            document.querySelectorAll('.book-area-select').forEach(function (areaSel) {
                areaSel.addEventListener('change', function () {
                    const clientId = this.dataset.client;
                    const selected = this.options[this.selectedIndex];
                    const costEl = document.querySelector('.book-area-cost-' + clientId);

                    costEl.textContent = selected && selected.dataset.cost ?
                        'Cost: ₱' + parseFloat(selected.dataset.cost).toLocaleString('en-PH', {
                            minimumFractionDigits: 2
                        }) :
                        '';
                });
            });
        })();
    </script>

    {{-- Initiate Contract toggle (book appointment modal) --}}
    <script>
        (function () {
            function syncContractType(clientId) {
                const freqSel = document.querySelector('.book-contract-frequency[data-client="' + clientId + '"]');
                const occSel = document.querySelector('.book-contract-occurrence[data-client="' + clientId + '"]');
                const typeInput = document.querySelector('.book-contract-type[data-client="' + clientId + '"]');
                const occWrapper = document.querySelector('.book-contract-occurrence-wrapper-' + clientId);

                if (!freqSel || !occSel || !typeInput || !occWrapper) return;

                occWrapper.style.display = freqSel.value === 'MONTHLY' ? 'block' : 'none';
                typeInput.value = (freqSel.value === 'MONTHLY' && occSel.value !== '1') ?
                    'MONTHLY-' + occSel.value + 'X' :
                    freqSel.value;
            }

            document.querySelectorAll('.book-initiate-contract').forEach(function (chk) {
                const clientId = chk.dataset.client;
                syncContractType(clientId); // initialize hidden svcc_type on load

                chk.addEventListener('change', function () {
                    const fieldsDiv = document.querySelector('.book-contract-fields-' + clientId);
                    const priceInput = fieldsDiv.querySelector('input[name="svc_final_price"]');
                    const durationInput = fieldsDiv.querySelector('input[name="svcc_total_years"]');
                    const contractInput = fieldsDiv.querySelector('input[name="svcc_contract"]');

                    fieldsDiv.style.display = this.checked ? 'block' : 'none';
                    priceInput.required = this.checked;
                    durationInput.required = this.checked;
                    contractInput.required = this.checked;
                });
            });

            document.querySelectorAll('.book-contract-frequency, .book-contract-occurrence').forEach(function (
                sel) {
                sel.addEventListener('change', function () {
                    syncContractType(this.dataset.client);
                });
            });
        })();
    </script>

    {{-- Add / remove extra Problem Types and extra Locations (independent) --}}
    <script>
        (function () {
            const TERMITE_ID = 8;

            function peso(n) {
                return '₱' + n.toLocaleString('en-PH', {
                    minimumFractionDigits: 2
                });
            }

            function filterByBranch(select, branchId) {
                const options = select.querySelectorAll('option[data-branch]');
                let hasVisible = false;

                options.forEach(function (opt) {
                    if (opt.dataset.branch == branchId) {
                        opt.style.display = '';
                        hasVisible = true;
                    } else {
                        opt.style.display = 'none';
                        opt.selected = false;
                    }
                });

                select.value = '';
                select.querySelector('option:not([data-branch])').textContent =
                    hasVisible ? '— Select —' : '— No options for this branch —';
            }

            function isTermiteMode(modalBody) {
                return parseInt(modalBody.querySelector('.book-pest-select').value) === TERMITE_ID;
            }

            function optCost(select) {
                const opt = select.options[select.selectedIndex];
                return opt && opt.dataset.cost ? parseFloat(opt.dataset.cost) : 0;
            }

            // Total of the main Location + all extra Locations (shown only when extras exist)
            function updateTotal(modalBody) {
                const clientId = modalBody.querySelector('.book-pest-select').dataset.client;
                const totalEl = modalBody.querySelector('.book-loc-total-' + clientId);
                const extraSels = modalBody.querySelectorAll('.book-extra-loc-row select');

                if (!extraSels.length) {
                    totalEl.textContent = '';
                    return;
                }

                let total = optCost(modalBody.querySelector('.book-area-select'));
                extraSels.forEach(function (sel) {
                    total += optCost(sel);
                });

                totalEl.textContent = 'Total Cost: ' + peso(total);
            }

            function buildRemoveRow(select, rowClass, modalBody, withCost) {
                const row = document.createElement('div');
                row.className = 'mb-2 ' + rowClass;

                const group = document.createElement('div');
                group.className = 'input-group';

                const append = document.createElement('div');
                append.className = 'input-group-append';
                append.innerHTML = '<button type="button" class="btn btn-danger book-remove-row">' +
                    '<span class="fa fa-minus"></span></button>';

                group.appendChild(select);
                group.appendChild(append);
                row.appendChild(group);

                if (withCost) {
                    const cost = document.createElement('small');
                    cost.className = 'text-muted book-extra-loc-cost';
                    row.appendChild(cost);
                }

                append.querySelector('.book-remove-row').addEventListener('click', function () {
                    row.remove();
                    updateTotal(modalBody);
                });

                return row;
            }

            // + Problem Type (never offers TERMITES)
            document.querySelectorAll('.book-add-pest').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    const clientId = this.dataset.client;
                    const modalBody = this.closest('.modal-body');
                    const container = modalBody.querySelector('.book-extra-pests-' + clientId);

                    const sel = modalBody.querySelector('.book-pest-select').cloneNode(true);
                    sel.className = 'form-control';
                    sel.name = 'extra_svcp_id[]';
                    sel.removeAttribute('data-client');
                    sel.required = true;

                    Array.from(sel.options).forEach(function (opt) {
                        if (parseInt(opt.value) === TERMITE_ID) opt.remove();
                    });
                    sel.value = '';

                    container.appendChild(buildRemoveRow(sel, 'book-extra-pest-row', modalBody, false));
                });
            });

            // + Location (area select, with the same cost hint as the main Location)
            document.querySelectorAll('.book-add-loc').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    const clientId = this.dataset.client;
                    const modalBody = this.closest('.modal-body');
                    const container = modalBody.querySelector('.book-extra-locs-' + clientId);

                    if (!modalBody.querySelector('.book-pest-select').value) {
                        alert('Please select a Problem Type first.');
                        return;
                    }

                    const sel = modalBody.querySelector('.book-area-select').cloneNode(true);
                    sel.className = 'form-control';
                    sel.name = 'extra_svcpa_id[]';
                    sel.removeAttribute('data-client');
                    sel.required = true;

                    const row = buildRemoveRow(sel, 'book-extra-loc-row', modalBody, true);
                    container.appendChild(row);

                    filterByBranch(sel, modalBody.querySelector('.book-branch-select').value);

                    sel.addEventListener('change', function () {
                        const costEl = row.querySelector('.book-extra-loc-cost');
                        const selected = this.options[this.selectedIndex];

                        costEl.textContent = selected && selected.dataset.cost ?
                            'Cost: ' + peso(parseFloat(selected.dataset.cost)) :
                            '';
                        updateTotal(modalBody);
                    });

                    updateTotal(modalBody);
                });
            });

            // Main Location change -> refresh total
            document.querySelectorAll('.book-area-select').forEach(function (areaSel) {
                areaSel.addEventListener('change', function () {
                    updateTotal(this.closest('.modal-body'));
                });
            });

            // Branch change: re-filter extra Location rows
            document.querySelectorAll('.book-branch-select').forEach(function (branchSel) {
                branchSel.addEventListener('change', function () {
                    const modalBody = this.closest('.modal-body');
                    modalBody.querySelectorAll('.book-extra-loc-row').forEach(function (row) {
                        filterByBranch(row.querySelector('select'), branchSel.value);
                        row.querySelector('.book-extra-loc-cost').textContent = '';
                    });
                    updateTotal(modalBody);
                });
            });

            // Main Problem Type change: TERMITES hides both + buttons and removes extra rows
            document.querySelectorAll('.book-pest-select').forEach(function (pestSel) {
                pestSel.addEventListener('change', function () {
                    const modalBody = this.closest('.modal-body');
                    const termite = isTermiteMode(modalBody);

                    modalBody.querySelectorAll('.book-add-pest, .book-add-loc').forEach(function (b) {
                        b.closest('.form-group').style.display = termite ? 'none' : '';
                    });

                    if (termite) {
                        modalBody.querySelectorAll('.book-extra-pest-row, .book-extra-loc-row')
                            .forEach(function (row) {
                                row.remove();
                            });
                    }

                    updateTotal(modalBody);
                });
            });
        })();
    </script>
@endsection