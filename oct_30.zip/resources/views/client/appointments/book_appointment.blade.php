@extends('layouts.themes.main')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Book Appointment</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\ClientController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item active">Book Appointment</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ url('client/service/order/book/save') }}" id="bookAppointmentForm">
                        @csrf

                        {{-- ADDRESS --}}
                        <div class="form-group">
                            <label>Address: <span class="text-danger">*</span></label>
                            <select class="form-control" name="uadd_id" required>
                                @if ($addresses->count() > 0)
                                    @foreach ($addresses as $address)
                                        <option value="{{ $address->uadd_id }}">
                                            {{ $address->add_name }} —
                                            {{ $address->uadd_street }}, {{ $address->uadd_barangay }},
                                            {{ $address->uadd_city }}, {{ $address->uadd_province }}
                                        </option>
                                    @endforeach
                                @else
                                    <option disabled selected>No active address available</option>
                                @endif
                            </select>
                        </div>

                        <hr>

                        {{-- PROBLEM TYPE --}}
                        <div class="form-group">
                            <label>Problem Type <span class="text-danger">*</span></label>
                            <select class="form-control" id="pestSelect" name="svcp_id" required>
                                <option value="">— Select Problem Type —</option>
                                @foreach ($servicePackages as $pkg)
                                    <option value="{{ $pkg->svcp_id }}">{{ $pkg->svcp_pest_type }}</option>
                                @endforeach
                            </select>
                        </div>

                        {{-- Extra Problem Types (added via +) --}}
                        <div id="extraPestRows"></div>
                        <div class="form-group" id="addPestGroup">
                            <button type="button" class="btn btn-outline-success btn-sm" id="addPestRow">
                                <span class="fa fa-plus"></span> Add Problem Type
                            </button>
                        </div>

                        {{-- LOCATIONS (non-termite) --}}
                        <div class="form-group" id="areaGroup" style="display:none;">
                            <label>Location(s) <span class="text-danger">*</span></label>
                            <div id="areaRows"></div>
                            <button type="button" class="btn btn-outline-success btn-sm mt-1" id="addAreaRow">
                                <span class="fa fa-plus"></span> Add Location
                            </button>
                        </div>

                        {{-- TERMITE SIZE --}}
                        <div class="form-group" id="termiteGroup" style="display:none;">
                            <label>Termite Treatment Size <span class="text-danger">*</span></label>
                            <select class="form-control termite-select" id="termiteSelect" name="svcpat_id">
                                <option value="">— Select —</option>
                                @foreach ($termiteOptionsForJs as $t)
                                    <option value="{{ $t['id'] }}" data-cost="{{ $t['cost'] }}">{{ $t['label'] }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="text-right font-weight-bold" id="runningTotal" style="display:none;">
                            Estimated Total: ₱<span id="runningTotalValue">0.00</span>
                        </div>

                        <hr>

                        {{-- PROBLEM DESCRIPTION --}}
                        <div class="form-group">
                            <label><strong>Problem Description <span class="text-muted">(Optional)</span></strong></label>
                            <textarea class="form-control" name="svc_problem_description" rows="3"
                                placeholder="Describe the problem..."></textarea>
                        </div>

                        <hr>

                        {{-- SCHEDULE --}}
                        <div class="form-group">
                            <label>Preferred Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="svca_client_date"
                                value="{{ \Carbon\Carbon::tomorrow()->format('Y-m-d') }}"
                                min="{{ \Carbon\Carbon::tomorrow()->format('Y-m-d') }}" required>
                        </div>

                        <div class="form-group">
                            <label>Time Window <span class="text-danger">*</span></label>
                            <select class="form-control" name="svca_client_time" required>
                                <option value="">— Select Time Window —</option>
                                <option value="08:00">Morning (8:00 AM – 12:00 PM)</option>
                                <option value="12:00">Afternoon (12:00 PM – 5:00 PM)</option>
                                <option value="17:00">Evening (5:00 PM – 8:00 PM)</option>
                            </select>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-success">
                                <span class="fa fa-check"></span> Book Appointment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script>
        const TERMITE_ID = 8;

        const areaOptions = @json($areaOptionsForJs);
        const termiteOptions = @json($termiteOptionsForJs);

        (function () {
            const pestSelect = document.getElementById('pestSelect');
            const areaGroup = document.getElementById('areaGroup');
            const termiteGroup = document.getElementById('termiteGroup');
            const areaRows = document.getElementById('areaRows');
            const termiteSelect = document.getElementById('termiteSelect');
            const runningTotal = document.getElementById('runningTotal');
            const runningTotalValue = document.getElementById('runningTotalValue');

            function buildOptionsHtml(options) {
                let html = '<option value="">— Select —</option>';
                options.forEach(function (o) {
                    html += `<option value="${o.id}" data-cost="${o.cost}">${o.label}</option>`;
                });
                return html;
            }

            function makeAreaRow(options) {
                const row = document.createElement('div');
                row.className = 'input-group mb-2 area-row';

                const select = document.createElement('select');
                select.className = 'form-control area-select';
                select.name = 'svcpa_id[]';
                select.required = true;
                select.innerHTML = buildOptionsHtml(options);
                select.addEventListener('change', recalcTotal);

                const btnWrap = document.createElement('div');
                btnWrap.className = 'input-group-append';

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'btn btn-outline-danger remove-row-btn';
                removeBtn.innerHTML = '<span class="fa fa-minus"></span>';
                removeBtn.addEventListener('click', function () {
                    if (areaRows.querySelectorAll('.area-row').length > 1) {
                        row.remove();
                        recalcTotal();
                        toggleRemoveButtons();
                    }
                });

                btnWrap.appendChild(removeBtn);
                row.appendChild(select);
                row.appendChild(btnWrap);
                return row;
            }

            function toggleRemoveButtons() {
                const rows = areaRows.querySelectorAll('.area-row');
                rows.forEach(function (r) {
                    r.querySelector('.remove-row-btn').disabled = (rows.length <= 1);
                });
            }

            function addAreaRow() {
                areaRows.appendChild(makeAreaRow(areaOptions));
                toggleRemoveButtons();
            }

            function resetAreaRows() {
                areaRows.innerHTML = '';
                addAreaRow();
            }

            function recalcTotal() {
                let total = 0;
                document.querySelectorAll('.area-select, .termite-select').forEach(function (sel) {
                    const opt = sel.options[sel.selectedIndex];
                    if (opt && opt.dataset.cost) total += parseFloat(opt.dataset.cost);
                });
                if (total > 0) {
                    runningTotal.style.display = 'block';
                    runningTotalValue.textContent = total.toLocaleString('en-PH', { minimumFractionDigits: 2 });
                } else {
                    runningTotal.style.display = 'none';
                }
            }

            document.getElementById('addAreaRow').addEventListener('click', addAreaRow);
            termiteSelect.addEventListener('change', recalcTotal);

            pestSelect.addEventListener('change', function () {
                const pestId = this.value;

                if (!pestId) {
                    areaGroup.style.display = 'none';
                    termiteGroup.style.display = 'none';
                    runningTotal.style.display = 'none';
                    return;
                }

                if (parseInt(pestId) === TERMITE_ID) {
                    areaGroup.style.display = 'none';
                    document.querySelectorAll('.area-select').forEach(s => s.required = false);

                    termiteGroup.style.display = 'block';
                    termiteSelect.required = true;
                    termiteSelect.value = '';
                } else {
                    termiteGroup.style.display = 'none';
                    termiteSelect.required = false;
                    termiteSelect.value = '';

                    areaGroup.style.display = 'block';
                    resetAreaRows();
                }
                recalcTotal();
            });
        })();
    </script>

    {{-- Add / remove extra Problem Types --}}
    <script>
        (function () {
            const TERMITE_ID = 8;

            const pestSelect = document.getElementById('pestSelect');
            const extraPestRows = document.getElementById('extraPestRows');
            const addPestGroup = document.getElementById('addPestGroup');

            document.getElementById('addPestRow').addEventListener('click', function () {
                const row = document.createElement('div');
                row.className = 'input-group mb-2 extra-pest-row';

                // Same Problem Type options as the main select, but never TERMITES
                const select = pestSelect.cloneNode(true);
                select.removeAttribute('id');
                select.className = 'form-control';
                select.name = 'extra_svcp_id[]';
                select.required = true;
                Array.from(select.options).forEach(function (o) {
                    if (parseInt(o.value) === TERMITE_ID) o.remove();
                });
                select.value = '';

                const btnWrap = document.createElement('div');
                btnWrap.className = 'input-group-append';

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'btn btn-outline-danger';
                removeBtn.innerHTML = '<span class="fa fa-minus"></span>';
                removeBtn.addEventListener('click', function () {
                    row.remove();
                });

                btnWrap.appendChild(removeBtn);
                row.appendChild(select);
                row.appendChild(btnWrap);
                extraPestRows.appendChild(row);
            });

            // Main Problem Type = TERMITES: hide Add Problem Type and drop extra rows
            pestSelect.addEventListener('change', function () {
                const termite = parseInt(this.value) === TERMITE_ID;

                addPestGroup.style.display = termite ? 'none' : '';
                if (termite) {
                    extraPestRows.innerHTML = '';
                }
            });
        })();
    </script>
@endsection