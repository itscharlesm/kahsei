@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Payment Approval</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Accounting</li>
                        <li class="breadcrumb-item active">Payments</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <div class="col-lg-12 col-md-7">
                            <form method="GET" action="{{ url('accounting/payments') }}" class="mb-3">
                                <div class="input-group">
                                    <input type="text" name="search" id="searchInput" class="form-control"
                                        placeholder="Search client..." value="{{ request('search') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <span class="fa fa-search"></span> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="paymentsTable">
                            <thead>
                                <tr style="background-color: #f5f5f5;">
                                    <th class="text-center">Payment Date</th>
                                    <th class="text-center">SA Number</th>
                                    <th class="text-center">Client Name</th>
                                    <th class="text-center">Payment Type</th>
                                    <th class="text-center">Reference Number</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($payments as $payment)
                                    <tr>
                                        <td style="vertical-align: middle; text-align: center">{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}</td>
                                        <td style="vertical-align: middle; text-align: center">SA-{{ str_pad($payment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->usr_first_name }} {{ $payment->usr_last_name }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name ?? '-' }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '-' }}</td>
                                        <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_amount ?? 0, 2) }}</td>
                                        <td style="vertical-align: middle; text-align: center">
                                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal"
                                                data-target="#paymentDetailsModal"
                                                onclick="loadPaymentDetails({{ $payment->spay_id }})">
                                                <span class="fa fa-check"></span>
                                            </button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">No payments for approval.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    {{ $payments->links() }}
                </div>
            </div>
        </div>
    </section>

    {{-- Payment Details Modal --}}
    <div class="modal fade" id="paymentDetailsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Service Order Details</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="paymentDetailsBody">
                    <div class="text-center py-5">
                        <span class="fa fa-spinner fa-spin"></span> Loading...
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <span class="fa fa-close"></span> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- Dynamic Search While Typing --}}
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let value = this.value.toLowerCase();
            let table = document.getElementById("paymentsTable");
            let rows = table.querySelectorAll("tbody tr");

            rows.forEach(function (row) {
                let text = row.innerText.toLowerCase();
                row.style.display = text.includes(value) ? "" : "none";
            });
        });

        function loadPaymentDetails(spayId) {
            const body = document.getElementById('paymentDetailsBody');
            body.innerHTML = '<div class="text-center py-5"><span class="fa fa-spinner fa-spin"></span> Loading...</div>';

            fetch(`/accounting/payments/${spayId}/details`)
                .then(response => response.text())
                .then(html => {
                    body.innerHTML = html;
                })
                .catch(() => {
                    body.innerHTML = '<p class="text-center text-danger py-4">Failed to load details.</p>';
                });
        }
    </script>

    <script>
        (function () {
            const isVatableCheckbox = document.getElementById('svc_is_vatable');
            const vatFieldsWrapper = document.getElementById('vatFieldsWrapper');
            const vatTypeSelect = document.getElementById('svc_vatable_type');
            const vatPercentageWrapper = document.getElementById('vatPercentageWrapper');
            const vatAmountWrapper = document.getElementById('vatAmountWrapper');
            const vatPercentageInput = document.getElementById('spay_vatable_percentage');
            const vatAmountInput = document.getElementById('svc_vatable_amount');
            const vatAmountHint = document.getElementById('vatAmountHint');
            const spayAmountInput = document.getElementById('spay_amount');

            function clearVatFields() {
                vatTypeSelect.value = '';
                vatPercentageInput.value = '';
                vatAmountInput.value = '';
                vatPercentageWrapper.style.display = 'none';
                vatAmountWrapper.style.display = 'none';
                vatAmountHint.textContent = '';
                vatTypeSelect.required = false;
                vatPercentageInput.required = false;
                vatAmountInput.required = false;
            }

            function computePercentageAmount() {
                const amount = parseFloat(spayAmountInput.value) || 0;
                const pct = parseFloat(vatPercentageInput.value) || 0;
                const computed = amount * (pct / 100);
                vatAmountInput.value = computed.toFixed(2);
                vatAmountHint.textContent = 'Auto-computed from ' + pct + '% of ₱' + amount.toFixed(2);
            }

            isVatableCheckbox.addEventListener('change', function () {
                if (this.checked) {
                    vatFieldsWrapper.style.display = 'flex';
                    vatTypeSelect.required = true;
                } else {
                    // Wipe anything already typed so it never gets submitted
                    clearVatFields();
                    vatFieldsWrapper.style.display = 'none';
                }
            });

            vatTypeSelect.addEventListener('change', function () {
                vatPercentageInput.value = '';
                vatAmountInput.value = '';
                vatAmountHint.textContent = '';

                if (this.value === 'PERCENTAGE') {
                    vatPercentageWrapper.style.display = 'block';
                    vatAmountWrapper.style.display = 'block';
                    vatPercentageInput.required = true;
                    vatAmountInput.required = false;
                    vatAmountInput.readOnly = true;
                    document.getElementById('vatAmountRequiredMark').style.display = 'none';
                } else if (this.value === 'WHOLE AMOUNT') {
                    vatPercentageWrapper.style.display = 'none';
                    vatAmountWrapper.style.display = 'block';
                    vatPercentageInput.required = false;
                    vatAmountInput.required = true;
                    vatAmountInput.readOnly = false;
                    document.getElementById('vatAmountRequiredMark').style.display = 'inline';
                } else {
                    vatPercentageWrapper.style.display = 'none';
                    vatAmountWrapper.style.display = 'none';
                }
            });

            vatPercentageInput.addEventListener('input', function () {
                if (vatTypeSelect.value === 'PERCENTAGE') {
                    computePercentageAmount();
                }
            });

            spayAmountInput.addEventListener('input', function () {
                if (vatTypeSelect.value === 'PERCENTAGE' && vatPercentageInput.value) {
                    computePercentageAmount();
                }
            });

            // Reset everything whenever the modal is reopened
            document.getElementById('addPaymentModal').addEventListener('hidden.bs.modal', function () {
                isVatableCheckbox.checked = false;
                clearVatFields();
            });
        })();
    </script>

    <script>
        (function () {
            function computePercentageAmount(modal) {
                const amount = parseFloat(modal.querySelector('.approve-final-amount').value) || 0;
                const pct = parseFloat(modal.querySelector('.approve-vat-percentage').value) || 0;
                const amtInput = modal.querySelector('.approve-vat-amount');
                amtInput.value = (amount * (pct / 100)).toFixed(2);
                modal.querySelector('.approve-vat-amount-hint').textContent =
                    'Auto-computed from ' + pct + '% of ₱' + amount.toFixed(2);
            }

            function clearVatFields(modal) {
                modal.querySelector('.approve-vat-type').value = '';
                modal.querySelector('.approve-vat-percentage').value = '';
                modal.querySelector('.approve-vat-amount').value = '';
                modal.querySelector('.approve-vat-percentage-wrapper').style.display = 'none';
                modal.querySelector('.approve-vat-amount-wrapper').style.display = 'none';
                modal.querySelector('.approve-vat-amount-hint').textContent = '';
            }

            document.addEventListener('change', function (e) {
                const modal = e.target.closest('.modal');
                if (!modal) return;

                if (e.target.classList.contains('approve-is-vatable')) {
                    const wrapper = modal.querySelector('.approve-vat-fields-wrapper');
                    if (e.target.checked) {
                        wrapper.style.display = 'flex';
                    } else {
                        clearVatFields(modal);
                        wrapper.style.display = 'none';
                    }
                }

                if (e.target.classList.contains('approve-vat-type')) {
                    const pctWrap = modal.querySelector('.approve-vat-percentage-wrapper');
                    const amtWrap = modal.querySelector('.approve-vat-amount-wrapper');
                    const pctInput = modal.querySelector('.approve-vat-percentage');
                    const amtInput = modal.querySelector('.approve-vat-amount');
                    const requiredMark = modal.querySelector('.approve-vat-required-mark');

                    pctInput.value = '';
                    amtInput.value = '';
                    modal.querySelector('.approve-vat-amount-hint').textContent = '';

                    if (e.target.value === 'PERCENTAGE') {
                        pctWrap.style.display = 'block';
                        amtWrap.style.display = 'block';
                        amtInput.readOnly = true;
                        requiredMark.style.display = 'none';
                    } else if (e.target.value === 'WHOLE AMOUNT') {
                        pctWrap.style.display = 'none';
                        amtWrap.style.display = 'block';
                        amtInput.readOnly = false;
                        requiredMark.style.display = 'inline';
                    } else {
                        pctWrap.style.display = 'none';
                        amtWrap.style.display = 'none';
                    }
                }
            });

            document.addEventListener('input', function (e) {
                const modal = e.target.closest('.modal');
                if (!modal) return;

                if (e.target.classList.contains('approve-vat-percentage') || e.target.classList.contains('approve-final-amount')) {
                    const vatType = modal.querySelector('.approve-vat-type');
                    if (vatType && vatType.value === 'PERCENTAGE' && modal.querySelector('.approve-vat-percentage').value) {
                        computePercentageAmount(modal);
                    }
                }
            });
        })();
    </script>
@endsection