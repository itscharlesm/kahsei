{{-- Payment Review Card --}}
<div class="card mb-4">
    <div class="card-header bg-light">
        <strong>Payment Review for SA-{{ str_pad($display->svc_sa_number ?? 0, 6, '0', STR_PAD_LEFT) }}</strong>
    </div>

    <form id="paymentReviewForm" method="POST"
        action="{{ url('accounting/payments/' . $display->svc_id . '/details/approve') }}">
        @csrf

        <div class="card-body">
            <input type="hidden" name="spay_id" value="{{ $payment->spay_id }}">

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="font-weight-bold">Receipt Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="spay_receipt_number" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="font-weight-bold">Payment Date</label>
                    <input type="text" class="form-control"
                        value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="font-weight-bold">Payment Type <span class="text-danger">*</span></label>
                    <select class="form-control" name="typ_id" id="typ_id">
                        @forelse ($paymentTypes as $type)
                            <option value="{{ $type->typ_id }}" {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                {{ $type->typ_name }}
                            </option>
                        @empty
                            <option value="">No payment types available</option>
                        @endforelse
                    </select>
                </div>

                <div class="col-md-4 mb-3">
                    <label class="font-weight-bold">Reference Number</label>
                    <input type="text" class="form-control" name="spay_reference_number"
                        value="{{ $payment->spay_reference_number }}">
                </div>

                <div class="col-md-4 mb-3">
                    <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" class="form-control approve-final-amount" name="spay_final_amount"
                            value="{{ $payment->spay_amount }}">
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input approve-is-vatable"
                            id="approve_is_vatable_{{ $payment->spay_id }}" name="spay_is_vatable" value="1"
                            {{ $payment->spay_is_vatable ? 'checked' : '' }}>
                        <label class="custom-control-label font-weight-bold" for="approve_is_vatable_{{ $payment->spay_id }}">
                            This payment is VATable
                        </label>
                    </div>
                </div>
            </div>

            <div class="row approve-vat-fields-wrapper" style="display: {{ $payment->spay_is_vatable ? 'flex' : 'none' }};">
                <div class="col-md-4 mb-3">
                    <label class="font-weight-bold">VAT Type <span class="text-danger">*</span></label>
                    <select class="form-control approve-vat-type" name="spay_vatable_type">
                        <option value="" disabled {{ !$payment->spay_vatable_type ? 'selected' : '' }}>Select VAT Type</option>
                        <option value="WHOLE AMOUNT" {{ $payment->spay_vatable_type == 'WHOLE AMOUNT' ? 'selected' : '' }}>Whole Amount</option>
                        <option value="PERCENTAGE" {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'selected' : '' }}>Percentage</option>
                    </select>
                </div>

                <div class="col-md-4 mb-3 approve-vat-percentage-wrapper"
                    style="display: {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'block' : 'none' }};">
                    <label class="font-weight-bold">VAT Percentage <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" min="0.01" max="100" class="form-control approve-vat-percentage"
                        name="spay_vatable_percentage" value="{{ $payment->spay_vatable_percentage }}" placeholder="e.g. 5, 0.5, 20">
                </div>

                <div class="col-md-4 mb-3 approve-vat-amount-wrapper"
                    style="display: {{ $payment->spay_vatable_type ? 'block' : 'none' }};">
                    <label class="font-weight-bold">
                        VAT Amount
                        <span class="text-danger approve-vat-required-mark"
                            style="display: {{ $payment->spay_vatable_type == 'WHOLE AMOUNT' ? 'inline' : 'none' }};">*</span>
                    </label>
                    <input type="number" step="0.01" min="0" class="form-control approve-vat-amount"
                        name="svc_vatable_amount" value="{{ $payment->spay_vatable_amount }}"
                        {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'readonly' : '' }} placeholder="0.00">
                    <small class="form-text text-muted approve-vat-amount-hint"></small>
                </div>
            </div>

            {{-- Proof of Payment --}}
            @if (!empty($payment->spay_image_proof))
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="font-weight-bold">Proof of Payment</label>
                        <div>
                            <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                target="_blank"
                                style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                    alt="Technician Report Image"
                                    style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                            </a>
                        </div>
                    </div>
                </div>
            @endif

            @if(!empty($payment->spay_details))
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="font-weight-bold">Client Details</label>
                        <textarea class="form-control" rows="4" readonly>
                            {{ $payment->spay_details ?? '-' }}
                        </textarea>
                    </div>
                </div>
            @endif

            <div class="row">
                <div class="col-md-12 mb-3">
                    <label class="font-weight-bold">Admin Details <span class="text-muted">(optional)</span></label>
                    <textarea class="form-control" name="spay_admin_details"
                        rows="4">{{ $payment->spay_admin_details ?? '' }}</textarea>
                </div>
            </div>

            <div class="text-right">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    <span class="fa fa-close"></span> Close
                </button>
                <button type="submit" class="btn btn-success">
                    <span class="fa fa-save"></span> Save
                </button>
            </div>
        </div>
    </form>
</div>

<div class="card mb-4">
    <div class="text-center mb-2">
        <h5 style="margin: 10px; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
        <p style="margin: 0;">{{ $display->branch_name ?? '-' }}</p>
    </div>

    <div class="mb-4 position-relative text-center">
        <strong style="color: red;">SERVICE ORDER</strong>
        <strong style="position: absolute; right: 10px; top: 0;">
            SA-{{ str_pad($display->svc_sa_number ?? 0, 6, '0', STR_PAD_LEFT) }}
        </strong>
    </div>

    {{-- Section A: Appointment Information --}}
    <div class="table-responsive overflow-auto" id="sectionA">
        <table class="table table-bordered text-left align-middle">
            <tbody>
                <tr>
                    <th colspan="6" class="text-center table-light">CLIENT INFORMATION</th>
                </tr>

                <tr>
                    <td style="font-weight: bold;">CLIENT NAME</td>
                    <td>{{ $display->usr_first_name ?? '' }} {{ $display->usr_last_name ?? '' }}</td>
                    <td style="font-weight: bold;">EMAIL</td>
                    <td>{{ $display->usr_email ?? '-' }}</td>
                    <td style="font-weight: bold;">MOBILE</td>
                    <td>{{ $display->usr_mobile ?? '-' }}</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">ADDRESS</td>
                    <td colspan="3">
                        {{ implode(', ', array_filter([
                            $display->uadd_street ?? null,
                            $display->uadd_barangay ?? null,
                            $display->uadd_city ?? null,
                            $display->uadd_province ?? null,
                            $display->uadd_region ?? null,
                        ])) ?: '-' }}
                    </td>
                    <td style="font-weight: bold;">ADDRESS TYPE</td>
                    <td>{{ $display->add_name ?? '-' }}</td>
                </tr>

                <tr>
                    <th colspan="6" class="text-center table-light">SERVICE INFORMATION</th>
                </tr>

                <tr>
                    <td style="font-weight: bold;">BRANCH</td>
                    <td>{{ $display->branch_name ?? '-' }}</td>
                    <td style="font-weight: bold;">STATUS</td>
                    <td>{{ $display->svc_status ?? '-' }}</td>
                    <td style="font-weight: bold;">PAYMENT STATUS</td>
                    <td>{{ $display->svc_payment_status ?? '-' }}</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">PROPERTY TYPE</td>
                    <td>{{ $display->svc_property_type ?? '-' }}</td>
                    <td style="font-weight: bold;">INFESTATION</td>
                    <td>{{ $display->svc_infestation ?? '-' }}</td>
                    <td style="font-weight: bold;">DISTANCE</td>
                    <td>{{ $display->svc_km_distance ?? '0' }} KM</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">IS TERMITE</td>
                    <td>{{ $display->svc_is_termite ? 'YES' : 'NO' }}</td>
                    <td style="font-weight: bold;">IS PACKAGE</td>
                    <td colspan="3">{{ $display->svc_is_package ? 'YES' : 'NO' }}</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">INITIAL SQM</td>
                    <td>{{ $display->svc_sqm_initial ?? 'N/A' }}</td>
                    <td style="font-weight: bold;">FINAL SQM</td>
                    <td colspan="3">{{ $display->svc_sqm_final ?? 'N/A' }}</td>
                </tr>

                @if (!empty($display->svc_problem_description))
                    <tr>
                        <th colspan="6" class="text-center table-light">PROBLEM DESCRIPTION / CLIENT REQUEST</th>
                    </tr>
                    <tr>
                        <td colspan="6" style="text-align: justify">{{ $display->svc_problem_description }}</td>
                    </tr>
                @endif

                <tr>
                    <th colspan="6" class="text-center table-light">PRICING</th>
                </tr>

                <tr>
                    <td style="font-weight: bold;">INITIAL PRICE</td>
                    <td>₱{{ number_format($display->svc_initial_price ?? 0, 2) }}</td>
                    <td style="font-weight: bold;">LOCATION PRICE</td>
                    <td>₱{{ number_format($display->svc_location_price ?? 0, 2) }}</td>
                    <td style="font-weight: bold;">FIXED PRICE</td>
                    <td>₱{{ number_format($display->svc_fixed_price ?? 0, 2) }}</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">FINAL PRICE</td>
                    <td>₱{{ number_format($display->svc_final_price ?? 0, 2) }}</td>
                    <td style="font-weight: bold;">BALANCE</td>
                    <td colspan="3">₱{{ number_format($display->svc_balance ?? 0, 2) }}</td>
                </tr>

                @if ($display->svc_is_termite)
                    <tr>
                        <th colspan="6" class="text-center table-light">TERMITE CASE</th>
                    </tr>
                    <tr>
                        <td style="font-weight: bold;">TREATMENT TYPE</td>
                        <td>{{ $display->svc_type_treatment ?? '-' }}</td>
                        <td style="font-weight: bold;">INITIAL SQM</td>
                        <td>{{ $display->svc_sqm_initial ?? '-' }}</td>
                        <td style="font-weight: bold;">FINAL SQM</td>
                        <td>{{ $display->svc_sqm_final ?? '-' }}</td>
                    </tr>
                    <tr>
                        <td style="font-weight: bold;">WITH DEVICE</td>
                        <td>{{ $display->svc_with_device ? 'YES' : 'NO' }}</td>
                        <td style="font-weight: bold;">DEVICE COUNT</td>
                        <td colspan="3">{{ $display->svc_device_count ?? 'N/A' }}</td>
                    </tr>
                @endif

                <tr>
                    <th colspan="6" class="text-center table-light">CHEMICAL</th>
                </tr>

                @forelse ($serviceChemicals as $chem)
                    <tr>
                        <td style="font-weight: bold;">CHEMICAL</td>
                        <td>{{ $chem->chem_name }}</td>
                        <td style="font-weight: bold;">EXPECTED QUANTITY</td>
                        <td>{{ $chem->svcch_expected_quantity }}</td>
                        <td style="font-weight: bold;">METRIC</td>
                        <td>{{ $chem->svcch_unit }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">No chemicals recorded.</td>
                    </tr>
                @endforelse

                @if (!empty($display->svc_assessment_recommendation))
                    <tr>
                        <th colspan="6" class="text-center table-light">ASSESSMENT RECOMMENDATION</th>
                    </tr>
                    <tr>
                        <td colspan="6" style="text-align: justify">{{ $display->svc_assessment_recommendation }}</td>
                    </tr>
                @endif

                <tr>
                    <th colspan="6" class="text-center table-light">SCHEDULE</th>
                </tr>

                <tr>
                    <td style="font-weight: bold;">DATE REQUESTED</td>
                    <td>{{ $display->svca_client_date ? \Carbon\Carbon::parse($display->svca_client_date)->format('m/d/Y') : '-' }}
                    </td>
                    <td style="font-weight: bold;">TIME REQUESTED</td>
                    <td colspan="3">
                        {{ $display->svca_client_time ? \Carbon\Carbon::parse($display->svca_client_time)->format('h:i A') : '-' }}
                    </td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">DATE APPROVED</td>
                    <td>{{ $display->svca_date_approved ? \Carbon\Carbon::parse($display->svca_date_approved)->format('m/d/Y') : '-' }}
                    </td>
                    <td style="font-weight: bold;">TIME APPROVED</td>
                    <td>{{ $display->svca_approved_time_from ? \Carbon\Carbon::parse($display->svca_approved_time_from)->format('h:i A') : '-' }}
                        -
                        {{ $display->svca_approved_time_to ? \Carbon\Carbon::parse($display->svca_approved_time_to)->format('h:i A') : '-' }}
                    </td>
                    <td style="font-weight: bold;">APPROVED BY</td>
                    <td>{{ $display->approved_first_name ?? '' }} {{ $display->approved_last_name ?? '' }}</td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">DATE ASSIGNED</td>
                    <td>{{ $display->svcas_date_assigned ? \Carbon\Carbon::parse($display->svcas_date_assigned)->format('m/d/Y | h:i A') : '-' }}
                    </td>
                    <td style="font-weight: bold;">ASSIGNED TO</td>
                    <td colspan="3">
                        {{ $display->assigned_to_label ?? 'N/A' }}
                    </td>
                </tr>

                <tr>
                    <td style="font-weight: bold;">DATE STARTED</td>
                    <td>{{ $display->svcas_start_date ? \Carbon\Carbon::parse($display->svcas_start_date)->format('m/d/Y') : '-' }}
                    </td>
                    <td style="font-weight: bold;">TIME</td>
                    <td>
                        {{ $display->svcas_start_time ? \Carbon\Carbon::parse($display->svcas_start_time)->format('h:i A') : '-' }}
                        -
                        {{ $display->svcas_end_time ? \Carbon\Carbon::parse($display->svcas_end_time)->format('h:i A') : '-' }}
                    </td>
                    <td style="font-weight: bold;">TRAVEL TIME / ELAPSED TIME</td>
                    <td>
                        @php
                            if (!function_exists('formatPaymentDuration')) {
                                function formatPaymentDuration($time)
                                {
                                    [$h, $m] = explode(':', $time ?? '00:00:00');
                                    $h = (int) $h;
                                    $m = (int) $m;

                                    if ($h == 0 && $m == 0)
                                        return '-';
                                    if ($h > 0 && $m > 0) {
                                        return "{$h} hr" . ($h > 1 ? 's' : '') . " {$m} min" . ($m > 1 ? 's' : '');
                                    }
                                    if ($h > 0) {
                                        return "{$h} hr" . ($h > 1 ? 's' : '');
                                    }
                                    return "{$m} min" . ($m > 1 ? 's' : '');
                                }
                            }
                        @endphp
                        {{ formatPaymentDuration($display->svcas_time_travel ?? null) }}
                        /
                        {{ formatPaymentDuration($display->svcas_time_finished ?? null) }}
                    </td>
                </tr>

                @if (!empty($display->svc_rating))
                    <tr>
                        <td colspan="6" class="text-center" style="padding: 20px 0;">
                            <div>
                                <strong>CUSTOMER SATISFACTION</strong>
                            </div>

                            <div style="margin-top: 5px;">
                                @for ($i = 1; $i <= 5; $i++)
                                    <i class="fa fa-star" style="font-size: 24px; color: {{ $i <= $display->svc_rating ? '#ffc107' : '#d3d3d3' }};"></i>
                                @endfor
                            </div>

                            <div style="margin-top: 5px; font-weight: bold;">
                                {{ $display->svc_rating }}/5
                            </div>

                            @if (!empty($display->svc_date_rated))
                                <div style="margin-top: 3px; color: #6c757d;">
                                    {{ \Carbon\Carbon::parse($display->svc_date_rated)->format('h:i A - m/d/Y') }}
                                </div>
                            @endif
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

    {{-- Section B: Service Order --}}
    <div class="table-responsive" id="sectionB">
        <hr>
        @if ($display->svc_is_termite == 0)
            @if ($pestTypes->count() > 0 || $serviceAreas->count() > 0)
                <div class="row">
                    @if ($pestTypes->count() > 0)
                        <div class="col-md-6">
                            <table class="table table-bordered text-center mb-2">
                                <thead>
                                    <tr style="background-color: #f5f5f5;">
                                        <th colspan="3"><strong>PEST TYPE</strong></th>
                                    </tr>
                                    <tr style="background-color: #f5f5f5;">
                                        <th style="width: 50px;">No.</th>
                                        <th>Pest</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($pestTypes as $index => $type)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $type->svcp_pest_type ?? '-' }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif

                    @if ($serviceAreas->count() > 0)
                        <div class="col-md-6">
                            <table class="table table-bordered text-center mb-2">
                                <thead>
                                    <tr style="background-color: #f5f5f5;">
                                        <th colspan="4"><strong>SERVICE ORDER</strong></th>
                                    </tr>
                                    <tr style="background-color: #f5f5f5;">
                                        <th style="width: 50px;">No.</th>
                                        <th>Service</th>
                                        <th>Cost</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($serviceAreas as $index => $area)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $area->svcpa_area ?? '-' }}</td>
                                            <td>₱{{ number_format($area->svcpa_cost ?? 0, 2) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            @else
                <p class="text-center text-muted">No service order details available.</p>
            @endif
        @elseif ($display->svc_is_termite == 1)
            <div class="col-md-12">
                <table class="table table-bordered text-center mb-2">
                    <thead>
                        <tr style="background-color: #f5f5f5;">
                            <th colspan="5"><strong>TERMITE DETAILS</strong></th>
                        </tr>
                        <tr style="background-color: #f5f5f5;">
                            <th style="width: 50px;">No.</th>
                            <th>SQM Details</th>
                            <th>Cost</th>
                            <th>Computation</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($termiteAreas as $index => $area)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $area->svcpat_sqm_details ?? '-' }}</td>
                                <td>₱{{ number_format($area->svcpat_cost ?? 0, 2) }}</td>
                                <td>
                                    @if ($display->svc_type_treatment == 'STANDARD TREATMENT')
                                        <p>STANDARD TREATMENT: sqm × cost</p>
                                    @elseif ($display->svc_type_treatment == 'HYBRID TREATMENT')
                                        <p>HYBRID TREATMENT: sqm × cost + device</p>
                                    @else
                                        <p>{{ $display->svc_type_treatment ?? '-' }}: sqm × cost</p>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted">No termite areas added.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        @endif
    </div>

    {{-- Section C: Client Appointment Images --}}
    @if ($appointmentImages->count() > 0)
        <div class="table-responsive" id="sectionC">
            <table class="table table-bordered text-center mb-2">
                <thead>
                    <tr style="background-color: #f5f5f5;">
                        <th colspan="5">
                            <strong>CLIENT APPOINTMENT IMAGES</strong>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5" style="padding: 10px;">
                            <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                @foreach ($appointmentImages as $img)
                                    <div class="p-2" style="width:20%;">
                                        <a href="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                            target="_blank"
                                            style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                alt="Mapping Image"
                                                style="width:100%; height:100%; object-fit:cover; display:block;">
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    @endif

    {{-- Section D: Mapping Images --}}
    @if ($mappingImages->count() > 0)
        <div class="table-responsive" id="sectionD">
            <table class="table table-bordered text-center mb-2">
                <thead>
                    <tr style="background-color: #f5f5f5;">
                        <th colspan="5">
                            <strong>MAPPING IMAGES</strong>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5" style="padding: 10px;">
                            <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                @foreach ($mappingImages as $img)
                                    <div class="p-2" style="width:20%;">
                                        <a href="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                            target="_blank"
                                            style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                                alt="Mapping Image"
                                                style="width:100%; height:100%; object-fit:cover; display:block;">
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    @endif

    {{-- Section E: Technician Report --}}
    <div class="table-responsive" id="sectionE">
        <table class="table table-bordered mb-2">
            <thead>
                <tr style="background-color: #f5f5f5;">
                    <th class="text-center">
                        <strong>TECHNICIAN REPORT</strong>
                    </th>
                </tr>
            </thead>
            <tbody>
                {{-- Recommendation --}}
                <tr>
                    <td>
                        <div class="mb-2" style="font-weight: bold; color: #495057;">
                            RECOMMENDATION / FINDINGS
                        </div>
                        <p style="text-align: justify; margin-bottom: 0;">
                            {{ $display->svc_technician_recommendation ?? 'No recommendation provided.' }}
                        </p>
                    </td>
                </tr>

                {{-- Chemical Used --}}
                <tr>
                    <td>
                        <div class="mb-2" style="font-weight: bold; color: #495057;">
                            CHEMICAL USED
                        </div>

                        @forelse ($serviceChemicals as $chem)
                            <p class="mb-1">
                                {{ $chem->svcch_actual_quantity ?? 'N/A' }} {{ $chem->svcch_unit }} - {{ $chem->chem_name }} 
                                (EXPECTED: {{ $chem->svcch_expected_quantity }} {{ $chem->svcch_unit }})
                            </p>
                        @empty
                            <p class="mb-0 text-muted">No chemicals recorded.</p>
                        @endforelse
                    </td>
                </tr>

                {{-- Captured Animals --}}
                <tr>
                    <td>
                        <div class="mb-2" style="font-weight: bold; color: #495057;">
                            CAPTURED PESTS
                        </div>

                        <div class="row text-center">
                            <div class="col">
                                <div><strong>Rats</strong></div>
                                <div>{{ $display->svc_rat_captured ?? 0 }}</div>
                            </div>

                            <div class="col">
                                <div><strong>Snakes</strong></div>
                                <div>{{ $display->svc_snake_captured ?? 0 }}</div>
                            </div>

                            <div class="col">
                                <div><strong>Lizards</strong></div>
                                <div>{{ $display->svc_lizard_captured ?? 0 }}</div>
                            </div>

                            <div class="col">
                                <div><strong>Kittens</strong></div>
                                <div>{{ $display->svc_kitten_captured ?? 0 }}</div>
                            </div>

                            <div class="col">
                                <div><strong>Others</strong></div>
                                <div>{{ $display->svc_other_captured ?? 0 }}</div>
                            </div>
                        </div>
                    </td>
                </tr>

                {{-- Site Documentation --}}
                @if ($technicianImages->count() > 0)
                    <tr>
                        <td style="padding-top: 20px;">
                            <div class="mb-2" style="font-weight: bold; color: #495057;">
                                SITE DOCUMENTATION
                                ({{ $technicianImages->count() }}
                                {{ $technicianImages->count() == 1 ? 'photo' : 'photos' }})
                            </div>

                            <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                @foreach ($technicianImages as $img)
                                    <div class="col-6 p-2">
                                        <a href="{{ asset('images/technician_images/' . $img->svcasp_image) }}"
                                            target="_blank"
                                            style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/technician_images/' . $img->svcasp_image) }}"
                                                alt="Technician Report Image"
                                                style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </td>
                    </tr>
                @else
                    <tr>
                        <td style="padding-top: 10px;">
                            <div class="mb-2" style="font-weight: bold; color: #495057;">
                                SITE DOCUMENTATION
                            </div>
                            <p class="text-muted text-center mb-0" style="padding: 10px 0;">
                                No images attached.
                            </p>
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

    {{-- Section F: Service Contract --}}
    @if ($contracts->count() > 0)
        <div class="table-responsive" id="sectionF">
            <table class="table table-bordered mb-2">
                <thead>
                    <tr style="background-color: #f5f5f5;">
                        <th colspan="5" class="text-center"><strong>SERVICE CONTRACT</strong></th>
                    </tr>
                    <tr style="background-color: #f5f5f5;">
                        <th class="text-center" style="vertical-align: middle;">Frequency</th>
                        <th class="text-center" style="vertical-align: middle;">Duration</th>
                        <th class="text-center" style="vertical-align: middle;">Total Services</th>
                        <th class="text-center no-print" style="vertical-align: middle;">Contract</th>
                        <th class="text-center" style="vertical-align: middle;">Appointments</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($contracts as $contract)
                        <tr>
                            <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_type }}</td>
                            <td class="text-center" style="vertical-align: middle;">
                                @php
                                    // Force 2 decimal places so the fraction always represents 2-digit months
                                    $parts = explode('.', number_format((float) $contract->svcc_total_years, 2, '.', ''));
                                    $yrs = (int) $parts[0];
                                    $mos = (int) $parts[1];

                                    $label = '';
                                    if ($yrs > 0) {
                                        $label .= $yrs . ' Year' . ($yrs > 1 ? 's' : '');
                                    }
                                    if ($mos > 0) {
                                        $label .= ($label ? ' and ' : '') . $mos . ' Month' . ($mos > 1 ? 's' : '');
                                    }
                                    if (!$label) {
                                        $label = '0 Months';
                                    }
                                @endphp
                                {{ $label }}
                            </td>
                            <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_total_services }}</td>
                            <td class="text-center no-print" style="vertical-align: middle;">
                                @if ($contract->svcc_contract)
                                    <a href="{{ asset('images/contracts/' . $contract->svcc_contract) }}"
                                        class="badge badge-info p-2" style="font-size: 0.85rem;"
                                        download target="_blank">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                @else
                                    <span class="text-muted">No file.</span>
                                @endif
                            </td>
                            <td>
                                @if ($contract->generated_services->isEmpty())
                                    <span class="text-muted">No appointments generated.</span>
                                @else
                                    <div class="d-flex flex-wrap" style="gap: 6px;">
                                        @foreach ($contract->generated_services as $svc)
                                            @php
                                                $statusRouteMap = [
                                                    'CONFIRM ASSESSMENT' => 'service/order/appointments/requested/',
                                                    'ASSESSED' => 'service/order/appointments/assessed/',
                                                    'SCHEDULED' => 'service/order/appointments/scheduled/',
                                                    'ONGOING' => 'service/order/appointments/ongoing/',
                                                    'DONE REPORT' => 'service/order/appointments/finished/',
                                                    'COMPLETED' => 'service/order/appointments/completed/',
                                                ];
                                                $routePrefix = $statusRouteMap[$svc->svc_status] ?? null;
                                                $saNumber = 'SA-' . str_pad($svc->svc_sa_number, 6, '0', STR_PAD_LEFT);
                                            @endphp

                                            @if ($routePrefix)
                                                <a href="{{ url($routePrefix . $svc->svc_id) }}" target="_blank"
                                                    class="badge badge-primary sa-badge p-2" style="font-size: 0.85rem;">
                                                    {{ $saNumber }}
                                                </a>
                                            @else
                                                <span class="badge badge-secondary sa-badge p-2" style="font-size: 0.85rem;">
                                                    {{ $saNumber }} ({{ $svc->svc_status }})
                                                </span>
                                            @endif
                                        @endforeach
                                    </div>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>