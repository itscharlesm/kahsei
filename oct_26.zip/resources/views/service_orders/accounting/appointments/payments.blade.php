<style>
    @media print {
        body {
            zoom: 100%;
        }

        .no-print {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }

        .print-hide {
            display: none !important;
        }
    }

    .table-responsive {
        overflow: visible !important;
    }

    #sectionB {
        overflow: visible !important;
    }
</style>

@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header no-print">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Service Order Payment History</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Service Order</li>
                        <li class="breadcrumb-item">Payments</li>
                        <li class="breadcrumb-item active">History</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">

                    <div class="text-center mb-2">
                        <h5 style="margin: 0; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
                        <p style="margin: 0;">{{ $display->branch_name }}</p>
                    </div>

                    <div class="mb-4 position-relative text-center">
                        <strong style="color: red;">SERVICE ORDER PAYMENT</strong>
                        <strong style="position: absolute; right: 0; top: 0;">
                            SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </strong>
                    </div>

                    {{-- Client Info --}}
                    <div class="table-responsive overflow-auto" id="sectionA">
                        <table class="table table-bordered text-left align-middle">
                            <tbody>
                                <tr>
                                    <th colspan="4" class="text-center table-light">CLIENT INFORMATION</th>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold;">CLIENT NAME</td>
                                    <td>{{ $display->usr_first_name }} {{ $display->usr_last_name }}</td>
                                    <td style="font-weight: bold;">PAYMENT STATUS</td>
                                    <td>{{ $display->svc_payment_status }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    {{-- Service Order Items --}}
                    <div class="table-responsive" id="sectionB">
                        @if (!$display->svc_is_termite)
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="2"><strong>PEST TYPE</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Pest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($pestTypes as $index => $type)
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $type->svcp_pest_type }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="2" class="text-center text-muted">No pest types
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="3"><strong>SERVICE ORDER</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Service</th>
                                                <th>Cost</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $itemsTotal = 0; @endphp
                                            @forelse ($serviceAreas as $index => $area)
                                                @php $itemsTotal += $area->svcpa_cost; @endphp
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $area->svcpa_area }}</td>
                                                    <td>₱{{ number_format($area->svcpa_cost, 2) }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="3" class="text-center text-muted">No service areas
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                            @if ($serviceAreas->count() > 0)
                                                <tr style="font-weight: bold; background-color: #f5f5f5;">
                                                    <td colspan="2" class="text-right">TOTAL:</td>
                                                    <td>₱{{ number_format($itemsTotal, 2) }}</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @else
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="2"><strong>PEST TYPE</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Pest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($pestTypes as $index => $type)
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $type->svcp_pest_type }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="2" class="text-center text-muted">No pest types
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="{{ $display->svc_with_device ? 5 : 3 }}">
                                                    <strong>TERMITE DETAILS</strong>
                                                    @if ($display->svc_type_treatment == 'STANDARD TREATMENT')
                                                        (<strong>STANDARD TREATMENT</strong>: sqm × cost)
                                                    @elseif ($display->svc_type_treatment == 'HYBRID TREATMENT')
                                                        (<strong>HYBRID TREATMENT</strong>: sqm × cost + device)
                                                    @endif
                                                </th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>SQM Details</th>
                                                <th>Cost</th>
                                                @if ($display->svc_with_device)
                                                    <th>Device Count</th>
                                                    <th>Device Price</th>
                                                @endif
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $itemsTotal = 0; @endphp
                                            @forelse ($termiteAreas as $index => $area)
                                                @php $itemsTotal += $area->svcpat_cost; @endphp
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $area->svcpat_sqm_details }}</td>
                                                    <td>₱{{ number_format($area->svcpat_cost, 2) }}</td>
                                                    @if ($display->svc_with_device)
                                                        <td>{{ $index == 0 ? $display->svc_device_count : '' }}</td>
                                                        <td>{{ $index == 0 ? '₱' . number_format($display->svc_device_price, 2) : '' }}</td>
                                                    @endif
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="{{ $display->svc_with_device ? 5 : 3 }}" class="text-center text-muted">
                                                        No termite areas added.
                                                    </td>
                                                </tr>
                                            @endforelse
                                            @if ($termiteAreas->count() > 0)
                                                @php
                                                    $grandTotal = $display->svc_with_device
                                                        ? $itemsTotal + $display->svc_device_price
                                                        : $itemsTotal;
                                                @endphp
                                                <tr style="font-weight: bold; background-color: #f5f5f5;">
                                                    <td colspan="{{ $display->svc_with_device ? 4 : 2 }}" class="text-right">TOTAL:</td>
                                                    <td>₱{{ number_format($grandTotal, 2) }}</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif
                    </div>

                    {{-- Pricing Summary --}}
                    <div class="d-flex mb-4 mt-3" style="gap: 15px;">
                        <div style="flex: 1;">
                            <label class="form-label fw-bold">Fixed Price:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_fixed_price, 2) }}">
                        </div>
                        <div style="flex: 1;">
                            <label class="form-label fw-bold">Final Price:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_final_price, 2) }}">
                        </div>
                        <div style="flex: 1;">
                            <label class="form-label fw-bold">Balance:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_balance, 2) }}">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mb-3 no-print">
                        @if ($display->svc_balance > 0)
                            <button type="button" class="btn btn-success mr-2" data-toggle="modal" data-target="#addPaymentModal">
                                <span class="fa fa-plus"></span> Add Payment
                            </button>
                        @endif
                        <button type="button" class="btn btn-primary mr-2" onclick="printDefault()">
                            <span class="fa fa-print"></span> Print
                        </button>
                    </div>

                    <hr>

                    {{-- Payment History --}}
                    <div class="row mt-4">
                        <div class="col-md-12">

                            {{-- For Approval --}}
                            @if ($paymentsForApproval->count() > 0)
                                <h4 class="mb-2">For Approval</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsForApproval as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                                        data-target="#approvePaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-check"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            {{-- List of Payments --}}
                            @if ($paymentsApproved->count() > 0)
                                <h4 class="mb-2">List of Payments</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th style="vertical-align: middle; text-align: center">Vatable</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsApproved as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_final_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_vatable_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                                        data-target="#voidPaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-ban"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            {{-- Voided Payments --}}
                            @if ($paymentsVoided->count() > 0)
                                <h4 class="mb-2">Voided Payments</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th style="vertical-align: middle; text-align: center">Vatable</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsVoided as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_final_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_vatable_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                        data-target="#voidedPaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-eye"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            @if ($paymentsForApproval->count() == 0 && $paymentsApproved->count() == 0 && $paymentsVoided->count() == 0)
                                <h4 class="mb-2">List of Payments</h4>
                                <p class="text-center text-muted">No payment history found.</p>
                            @endif

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    {{-- Add Payment Modal --}}
    <div class="modal fade" id="addPaymentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <form method="POST" id="addPaymentForm"
                    action="{{ url('service/order/payment/view/add/payment/' . $svc_id) }}">
                    @csrf

                    <div class="modal-header">
                        <h5 class="modal-title">
                            Add Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Type <span class="text-danger">*</span></label>
                                <select class="form-control" name="typ_id" required>
                                    <option value="" disabled selected>Select Payment Type</option>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}">{{ $type->typ_name }}</option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="spay_date" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Receipt Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="spay_receipt_number" required>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Reference Number <span class="text-muted">(blank if cash)</span></label>
                                <input type="text" class="form-control" name="spay_reference_number">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                <input type="number" step="0.1" class="form-control" name="spay_amount" id="spay_amount"
                                    max="{{ $display->svc_balance }}" min="0.1" required>
                                <small class="form-text text-muted">Balance: ₱{{ number_format($display->svc_balance, 2) }}</small>
                            </div>
                        </div>

                        {{-- VAT Section --}}
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="svc_is_vatable" name="svc_is_vatable" value="1">
                                    <label class="custom-control-label font-weight-bold" for="svc_is_vatable">This payment is VATable</label>
                                </div>
                            </div>
                        </div>

                        <div class="row" id="vatFieldsWrapper" style="display: none;">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">VAT Type <span class="text-danger">*</span></label>
                                <select class="form-control" name="svc_vatable_type" id="svc_vatable_type">
                                    <option value="" disabled selected>Select VAT Type</option>
                                    <option value="WHOLE AMOUNT">WHOLE AMOUNT</option>
                                    <option value="PERCENTAGE">PERCENTAGE</option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3" id="vatPercentageWrapper" style="display: none;">
                                <label class="font-weight-bold">VAT Percentage <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" min="0.01" max="100" class="form-control"
                                    name="spay_vatable_percentage" id="spay_vatable_percentage" placeholder="e.g. 5, 0.5, 20">
                            </div>

                            <div class="col-md-4 mb-3" id="vatAmountWrapper" style="display: none;">
                                <label class="font-weight-bold">
                                    VAT Amount <span class="text-danger" id="vatAmountRequiredMark">*</span>
                                </label>
                                <input type="number" step="0.01" min="0" class="form-control"
                                    name="svc_vatable_amount" id="svc_vatable_amount" placeholder="0.00">
                                <small class="form-text text-muted" id="vatAmountHint"></small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="font-weight-bold">Payment Details <span class="text-muted">(optional)</span></label>
                                <textarea class="form-control text-uppercase" name="spay_admin_details" rows="3" style="text-transform: uppercase;"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                        <button type="submit" class="btn btn-success">
                            <span class="fa fa-save"></span> Save Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @foreach ($paymentsForApproval as $payment)
        {{-- Approve Payment Modal --}}
        <div class="modal fade" id="approvePaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <form method="POST"
                        action="{{ url('service/order/payment/view/approve/' . $payment->spay_id) }}">
                        @csrf

                        <div class="modal-header">
                            <h5 class="modal-title">
                                Approve Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                            </h5>
                            <button type="button" class="close" data-dismiss="modal">
                                <span>&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Receipt Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="spay_receipt_number"
                                        value="{{ $payment->spay_receipt_number }}" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Payment Date</label>
                                    <input type="text" class="form-control"
                                        value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Payment Type <span class="text-danger">*</span></label>
                                    <select class="form-control" name="typ_id" required>
                                        @forelse ($paymentTypes as $type)
                                            <option value="{{ $type->typ_id }}"
                                                {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                                {{ $type->typ_name }}
                                            </option>
                                        @empty
                                            <option value="">No payment types available</option>
                                        @endforelse
                                    </select>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Reference Number</label>
                                    <input type="text" class="form-control" name="spay_reference_number"
                                        value="{{ $payment->spay_reference_number }}">
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" class="form-control" name="spay_final_amount"
                                        value="{{ $payment->spay_amount }}" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input approve-is-vatable"
                                            id="approve_is_vatable_{{ $payment->spay_id }}" name="spay_is_vatable" value="1"
                                            {{ $payment->spay_is_vatable ? 'checked' : '' }}>
                                        <label class="custom-control-label font-weight-bold" for="approve_is_vatable_{{ $payment->spay_id }}">
                                            This payment is VATable
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="row approve-vat-fields-wrapper" style="display: {{ $payment->spay_is_vatable ? 'flex' : 'none' }};">
                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">VAT Type <span class="text-danger">*</span></label>
                                    <select class="form-control approve-vat-type" name="spay_vatable_type">
                                        <option value="" disabled {{ !$payment->spay_vatable_type ? 'selected' : '' }}>Select VAT Type</option>
                                        <option value="WHOLE AMOUNT" {{ $payment->spay_vatable_type == 'WHOLE AMOUNT' ? 'selected' : '' }}>WHOLE AMOUNT</option>
                                        <option value="PERCENTAGE" {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'selected' : '' }}>PERCENTAGE</option>
                                    </select>
                                </div>

                                <div class="col-md-4 mb-3 approve-vat-percentage-wrapper"
                                    style="display: {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'block' : 'none' }};">
                                    <label class="font-weight-bold">VAT Percentage <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" min="0.01" max="100" class="form-control approve-vat-percentage"
                                        name="spay_vatable_percentage" value="{{ $payment->spay_vatable_percentage }}" placeholder="e.g. 5, 0.5, 20">
                                </div>

                                <div class="col-md-4 mb-3 approve-vat-amount-wrapper"
                                    style="display: {{ $payment->spay_vatable_type ? 'block' : 'none' }};">
                                    <label class="font-weight-bold">
                                        VAT Amount
                                        <span class="text-danger approve-vat-required-mark"
                                            style="display: {{ $payment->spay_vatable_type == 'WHOLE AMOUNT' ? 'inline' : 'none' }};">*</span>
                                    </label>
                                    <input type="number" step="0.01" min="0" class="form-control approve-vat-amount"
                                        name="svc_vatable_amount" value="{{ $payment->spay_vatable_amount }}"
                                        {{ $payment->spay_vatable_type == 'PERCENTAGE' ? 'readonly' : '' }} placeholder="0.00">
                                    <small class="form-text text-muted approve-vat-amount-hint"></small>
                                </div>
                            </div>

                            {{-- Proof of Payment --}}
                            @if (!empty($payment->spay_image_proof))
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="font-weight-bold">Proof of Payment</label>
                                        <div>
                                            <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                target="_blank"
                                                style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                                <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                    alt="Proof of Payment"
                                                    style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            @endif

                            @if(!empty($payment->spay_details))
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="font-weight-bold">Client Details</label>
                                        <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                    </div>
                                </div>
                            @endif

                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Approve Details <span class="text-muted">(optional)</span></label>
                                    <textarea class="form-control" name="spay_admin_details" rows="3">{{ $payment->spay_admin_details ?? '' }}</textarea>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-success">
                                <span class="fa fa-save"></span> Approve
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    @foreach ($paymentsApproved as $payment)
        {{-- Void Payment Modal --}}
        <div class="modal fade" id="voidPaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <form method="POST"
                        action="{{ url('service/order/payment/view/void/' . $payment->spay_id) }}">
                        @csrf

                        <div class="modal-header">
                            <h5 class="modal-title">
                                Void Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                            </h5>
                            <button type="button" class="close" data-dismiss="modal">
                                <span>&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Receipt Number</label>
                                    <input type="text" class="form-control" value="{{ $payment->spay_receipt_number }}" readonly>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Payment Date</label>
                                    <input type="text" class="form-control"
                                        value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Payment Type</label>
                                    <select class="form-control" readonly>
                                        @forelse ($paymentTypes as $type)
                                            <option value="{{ $type->typ_id }}"
                                                {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                                {{ $type->typ_name }}
                                            </option>
                                        @empty
                                            <option value="">No payment types available</option>
                                        @endforelse
                                    </select>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Reference Number</label>
                                    <input type="text" class="form-control" value="{{ $payment->spay_reference_number }}" readonly>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" class="form-control"
                                        value="{{ $payment->spay_final_amount }}" readonly>
                                </div>
                            </div>

                            @if ($payment->spay_is_vatable)
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="font-weight-bold">VAT Type</label>
                                        <input type="text" class="form-control" value="{{ $payment->spay_vatable_type }}" readonly>
                                    </div>

                                    @if ($payment->spay_vatable_type == 'PERCENTAGE')
                                        <div class="col-md-4 mb-3">
                                            <label class="font-weight-bold">VAT Percentage</label>
                                            <input type="text" class="form-control" value="{{ $payment->spay_vatable_percentage }}%" readonly>
                                        </div>
                                    @endif

                                    <div class="col-md-4 mb-3">
                                        <label class="font-weight-bold">VAT Amount</label>
                                        <input type="text" class="form-control" value="₱{{ number_format($payment->spay_vatable_amount, 2) }}" readonly>
                                    </div>
                                </div>
                            @endif

                            {{-- Proof of Payment --}}
                            @if (!empty($payment->spay_image_proof))
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="font-weight-bold">Proof of Payment</label>
                                        <div>
                                            <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                target="_blank"
                                                style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                                <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                    alt="Proof of Payment"
                                                    style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            @endif

                            @if(!empty($payment->spay_details))
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="font-weight-bold">Client Details</label>
                                        <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                    </div>
                                </div>
                            @endif

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Approved By</label>
                                    <input type="text" class="form-control" value="{{ $payment->approved_first_name }} {{ $payment->approved_last_name }}" readonly>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="font-weight-bold">Date Approved</label>
                                    <input type="text" class="form-control"
                                        value="{{ \Carbon\Carbon::parse($payment->spay_date_approved)->format('m/d/Y') }}" readonly>
                                </div>
                            </div>

                            @if(!empty($payment->spay_admin_details))
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="font-weight-bold">Approve Details</label>
                                        <textarea class="form-control" rows="3" readonly>{{ $payment->spay_admin_details ?? '' }}</textarea>
                                    </div>
                                </div>
                            @endif

                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Void Details <span class="text-muted">(optional)</span></label>
                                    <textarea class="form-control" name="spay_void_details" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('ACCOUNTING OFFICER') == '1')
                                <button type="submit" class="btn btn-danger">
                                    <span class="fa fa-ban"></span> Void
                                </button>
                            @endif
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    @foreach ($paymentsVoided as $payment)
        {{-- Voided Payment Modal --}}
        <div class="modal fade" id="voidedPaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Voided Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Receipt Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_receipt_number }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Payment Type</label>
                                <select class="form-control" readonly>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}"
                                            {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                            {{ $type->typ_name }}
                                        </option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Reference Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_reference_number }}" readonly>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control"
                                    value="{{ $payment->spay_final_amount }}" readonly>
                            </div>
                        </div>

                        {{-- Proof of Payment --}}
                        @if (!empty($payment->spay_image_proof))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Proof of Payment</label>
                                    <div>
                                        <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                            target="_blank"
                                            style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                alt="Proof of Payment"
                                                style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if(!empty($payment->spay_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Client Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Approved By</label>
                                <input type="text" class="form-control" value="{{ $payment->approved_first_name }} {{ $payment->approved_last_name }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Date Approved</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date_approved)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        @if(!empty($payment->spay_admin_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Approve Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_admin_details ?? '' }}</textarea>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Voided By</label>
                                <input type="text" class="form-control" value="{{ $payment->voided_first_name }} {{ $payment->voided_last_name }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Date Voided</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date_voided)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        @if(!empty($payment->spay_void_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Void Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_void_details ?? '' }}</textarea>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    <script>
        function printDefault() {
            window.print();
        }
    </script>

    <script>
        (function () {
            const isVatableCheckbox = document.getElementById('svc_is_vatable');
            const vatFieldsWrapper = document.getElementById('vatFieldsWrapper');
            const vatTypeSelect = document.getElementById('svc_vatable_type');
            const vatPercentageWrapper = document.getElementById('vatPercentageWrapper');
            const vatAmountWrapper = document.getElementById('vatAmountWrapper');
            const vatPercentageInput = document.getElementById('spay_vatable_percentage');
            const vatAmountInput = document.getElementById('svc_vatable_amount');
            const vatAmountHint = document.getElementById('vatAmountHint');
            const spayAmountInput = document.getElementById('spay_amount');

            function clearVatFields() {
                vatTypeSelect.value = '';
                vatPercentageInput.value = '';
                vatAmountInput.value = '';
                vatPercentageWrapper.style.display = 'none';
                vatAmountWrapper.style.display = 'none';
                vatAmountHint.textContent = '';
                vatTypeSelect.required = false;
                vatPercentageInput.required = false;
                vatAmountInput.required = false;
            }

            function computePercentageAmount() {
                const amount = parseFloat(spayAmountInput.value) || 0;
                const pct = parseFloat(vatPercentageInput.value) || 0;
                const computed = amount * (pct / 100);
                vatAmountInput.value = computed.toFixed(2);
                vatAmountHint.textContent = 'Auto-computed from ' + pct + '% of ₱' + amount.toFixed(2);
            }

            isVatableCheckbox.addEventListener('change', function () {
                if (this.checked) {
                    vatFieldsWrapper.style.display = 'flex';
                    vatTypeSelect.required = true;
                } else {
                    // Wipe anything already typed so it never gets submitted
                    clearVatFields();
                    vatFieldsWrapper.style.display = 'none';
                }
            });

            vatTypeSelect.addEventListener('change', function () {
                vatPercentageInput.value = '';
                vatAmountInput.value = '';
                vatAmountHint.textContent = '';

                if (this.value === 'PERCENTAGE') {
                    vatPercentageWrapper.style.display = 'block';
                    vatAmountWrapper.style.display = 'block';
                    vatPercentageInput.required = true;
                    vatAmountInput.required = false;
                    vatAmountInput.readOnly = true;
                    document.getElementById('vatAmountRequiredMark').style.display = 'none';
                } else if (this.value === 'WHOLE AMOUNT') {
                    vatPercentageWrapper.style.display = 'none';
                    vatAmountWrapper.style.display = 'block';
                    vatPercentageInput.required = false;
                    vatAmountInput.required = true;
                    vatAmountInput.readOnly = false;
                    document.getElementById('vatAmountRequiredMark').style.display = 'inline';
                } else {
                    vatPercentageWrapper.style.display = 'none';
                    vatAmountWrapper.style.display = 'none';
                }
            });

            vatPercentageInput.addEventListener('input', function () {
                if (vatTypeSelect.value === 'PERCENTAGE') {
                    computePercentageAmount();
                }
            });

            spayAmountInput.addEventListener('input', function () {
                if (vatTypeSelect.value === 'PERCENTAGE' && vatPercentageInput.value) {
                    computePercentageAmount();
                }
            });

            // Reset everything whenever the modal is reopened
            document.getElementById('addPaymentModal').addEventListener('hidden.bs.modal', function () {
                isVatableCheckbox.checked = false;
                clearVatFields();
            });
        })();
    </script>

    <script>
        (function () {
            function computePercentageAmount(modal) {
                const amount = parseFloat(modal.querySelector('.approve-final-amount').value) || 0;
                const pct = parseFloat(modal.querySelector('.approve-vat-percentage').value) || 0;
                const amtInput = modal.querySelector('.approve-vat-amount');
                amtInput.value = (amount * (pct / 100)).toFixed(2);
                modal.querySelector('.approve-vat-amount-hint').textContent =
                    'Auto-computed from ' + pct + '% of ₱' + amount.toFixed(2);
            }

            function clearVatFields(modal) {
                modal.querySelector('.approve-vat-type').value = '';
                modal.querySelector('.approve-vat-percentage').value = '';
                modal.querySelector('.approve-vat-amount').value = '';
                modal.querySelector('.approve-vat-percentage-wrapper').style.display = 'none';
                modal.querySelector('.approve-vat-amount-wrapper').style.display = 'none';
                modal.querySelector('.approve-vat-amount-hint').textContent = '';
            }

            document.addEventListener('change', function (e) {
                const modal = e.target.closest('.modal');
                if (!modal) return;

                if (e.target.classList.contains('approve-is-vatable')) {
                    const wrapper = modal.querySelector('.approve-vat-fields-wrapper');
                    if (e.target.checked) {
                        wrapper.style.display = 'flex';
                    } else {
                        clearVatFields(modal);
                        wrapper.style.display = 'none';
                    }
                }

                if (e.target.classList.contains('approve-vat-type')) {
                    const pctWrap = modal.querySelector('.approve-vat-percentage-wrapper');
                    const amtWrap = modal.querySelector('.approve-vat-amount-wrapper');
                    const pctInput = modal.querySelector('.approve-vat-percentage');
                    const amtInput = modal.querySelector('.approve-vat-amount');
                    const requiredMark = modal.querySelector('.approve-vat-required-mark');

                    pctInput.value = '';
                    amtInput.value = '';
                    modal.querySelector('.approve-vat-amount-hint').textContent = '';

                    if (e.target.value === 'PERCENTAGE') {
                        pctWrap.style.display = 'block';
                        amtWrap.style.display = 'block';
                        amtInput.readOnly = true;
                        requiredMark.style.display = 'none';
                    } else if (e.target.value === 'WHOLE AMOUNT') {
                        pctWrap.style.display = 'none';
                        amtWrap.style.display = 'block';
                        amtInput.readOnly = false;
                        requiredMark.style.display = 'inline';
                    } else {
                        pctWrap.style.display = 'none';
                        amtWrap.style.display = 'none';
                    }
                }
            });

            document.addEventListener('input', function (e) {
                const modal = e.target.closest('.modal');
                if (!modal) return;

                if (e.target.classList.contains('approve-vat-percentage') || e.target.classList.contains('approve-final-amount')) {
                    const vatType = modal.querySelector('.approve-vat-type');
                    if (vatType && vatType.value === 'PERCENTAGE' && modal.querySelector('.approve-vat-percentage').value) {
                        computePercentageAmount(modal);
                    }
                }
            });
        })();
    </script>
@endsection