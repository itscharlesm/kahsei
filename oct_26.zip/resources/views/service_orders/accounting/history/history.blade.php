@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Payment History</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Accounting</li>
                        <li class="breadcrumb-item active">Payment History</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <div class="col-lg-12 col-md-7">
                            <form method="GET" action="{{ url('accounting/history/payments') }}" class="mb-3">
                                <div class="input-group">
                                    <input type="text" name="search" id="searchInput" class="form-control"
                                        placeholder="Search client..." value="{{ request('search') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <span class="fa fa-search"></span> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="paymentsTable">
                            <thead>
                                <tr style="background-color: #f5f5f5;">
                                    <th class="text-center">Receipt Number</th>
                                    <th class="text-center">Payment Date</th>
                                    <th class="text-center">SA Number</th>
                                    <th class="text-center">Client Name</th>
                                    <th class="text-center">Payment Type</th>
                                    <th class="text-center">Reference Number</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Vatable</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($payments as $payment)
                                    <tr>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '-' }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}</td>
                                        <td style="vertical-align: middle; text-align: center">SA-{{ str_pad($payment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->usr_first_name }} {{ $payment->usr_last_name }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name ?? '-' }}</td>
                                        <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '-' }}</td>
                                        <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_final_amount ?? 0, 2) }}</td>
                                        <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_vatable_amount ?? 0, 2) }}</td>
                                        <td style="vertical-align: middle; text-align: center">
                                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                data-target="#paymentDetailsModal"
                                                onclick="loadPaymentDetails({{ $payment->spay_id }})">
                                                <span class="fa fa-ban"></span>
                                            </button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="10" class="text-center text-muted">No payments for approval.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    {{ $payments->links() }}
                </div>
            </div>
        </div>
    </section>

    {{-- Payment Details Modal --}}
    <div class="modal fade" id="paymentDetailsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Service Order Details</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="paymentDetailsBody">
                    <div class="text-center py-5">
                        <span class="fa fa-spinner fa-spin"></span> Loading...
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <span class="fa fa-close"></span> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- Dynamic Search While Typing --}}
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let value = this.value.toLowerCase();
            let table = document.getElementById("paymentsTable");
            let rows = table.querySelectorAll("tbody tr");

            rows.forEach(function (row) {
                let text = row.innerText.toLowerCase();
                row.style.display = text.includes(value) ? "" : "none";
            });
        });

        function loadPaymentDetails(spayId) {
            const body = document.getElementById('paymentDetailsBody');
            body.innerHTML = '<div class="text-center py-5"><span class="fa fa-spinner fa-spin"></span> Loading...</div>';

            fetch(`/accounting/history/${spayId}/details`)
                .then(response => response.text())
                .then(html => {
                    body.innerHTML = html;
                })
                .catch(() => {
                    body.innerHTML = '<p class="text-center text-danger py-4">Failed to load details.</p>';
                });
        }
    </script>
@endsection