<style>
    @media print {
        body {
            zoom: 100%;
        }

        .no-print {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }

        .print-hide {
            display: none !important;
        }
    }

    .table-responsive {
        overflow: visible !important;
    }

    #sectionB {
        overflow: visible !important;
    }

    #timelineTabs .nav-link {
        color: #28a745;
    }

    #timelineTabs .nav-link.active {
        color: #28a745;
        border-color: #28a745 #28a745 #fff;
    }

    #timelineTabs .nav-link:hover {
        color: #1e7e34;
        border-color: #1e7e34 #1e7e34 transparent;
    }

    body.layout-fixed .content-wrapper {
        height: auto !important;
        min-height: auto !important;
        overflow-y: visible !important;
    }
</style>

@php
    // Safely format a date/time value. Returns $default if the value is null, empty, or unparsable.
    function safeDate($value, $format, $default = 'N/A')
    {
        if (empty($value)) {
            return $default;
        }

        try {
            return \Carbon\Carbon::parse($value)->format($format);
        } catch (\Throwable $e) {
            return $default;
        }
    }

    function formatDuration($time)
    {
        if (empty($time)) {
            return '-';
        }

        [$h, $m] = explode(':', $time ?? '00:00:00');
        $h = (int) $h;
        $m = (int) $m;

        if ($h == 0 && $m == 0) return '-';

        if ($h > 0 && $m > 0) {
            return "{$h} hr" . ($h > 1 ? 's' : '') . " {$m} min" . ($m > 1 ? 's' : '');
        }

        if ($h > 0) {
            return "{$h} hr" . ($h > 1 ? 's' : '');
        }

        return "{$m} min" . ($m > 1 ? 's' : '');
    }
@endphp

@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Deleted Appointment</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointment</li>
                        <li class="breadcrumb-item">Deleted</li>
                        <li class="breadcrumb-item active">View</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="text-center mb-2">
                        <h5 style="margin: 0; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
                        <p style="margin: 0;">{{ $display->branch_name ?? 'N/A' }}</p>
                    </div>

                    <div class="mb-4 position-relative text-center">
                        <strong style="color: red;">SERVICE ORDER</strong>

                        <strong style="position: absolute; right: 0; top: 0;">
                            SA-{{ str_pad($display->svc_sa_number ?? 0, 6, '0', STR_PAD_LEFT) }}
                        </strong>
                    </div>
                    <div class="row">

                        {{-- Appointment Information Display --}}
                        <div class="table-responsive overflow-auto" id="sectionA">
                            <table class="table table-bordered text-left align-middle">
                                <tbody>
                                    <tr>
                                        <th colspan="6" class="text-center table-light">CLIENT INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">CLIENT NAME</td>
                                        <td>{{ trim(($display->usr_first_name ?? '') . ' ' . ($display->usr_last_name ?? '')) ?: 'N/A' }}</td>
                                        <td style="font-weight: bold;">EMAIL</td>
                                        <td>{{ $display->usr_email ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">MOBILE</td>
                                        <td>{{ $display->usr_mobile ?? 'N/A' }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">ADDRESS</td>
                                        <td colspan="3">
                                            {{ implode(
                                                ', ',
                                                array_filter([
                                                    $display->uadd_street ?? null,
                                                    $display->uadd_barangay ?? null,
                                                    $display->uadd_city ?? null,
                                                    $display->uadd_province ?? null,
                                                    $display->uadd_region ?? null,
                                                ]),
                                            ) ?: 'N/A' }}
                                        </td>
                                        <td style="font-weight: bold;">ADDRESS TYPE</td>
                                        <td>{{ $display->add_name ?? 'N/A' }}</td>
                                    </tr>

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SERVICE INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">BRANCH</td>
                                        <td>{{ $display->branch_name ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">STATUS</td>
                                        <td>{{ $display->svc_status ?? 'N/A' }} (DELETED)</td>
                                        <td style="font-weight: bold;">PAYMENT STATUS</td>
                                        <td>{{ $display->svc_payment_status ?? 'N/A' }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">PROPERTY TYPE</td>
                                        <td>{{ $display->svc_property_type ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">INFESTATION</td>
                                        <td>{{ $display->svc_infestation ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">DISTANCE</td>
                                        <td>{{ $display->svc_km_distance ?? 0 }} KM</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">IS TERMITE</td>
                                        <td>{{ ($display->svc_is_termite ?? 0) ? 'YES' : 'NO' }}</td>
                                        <td style="font-weight: bold;">IS PACKAGE</td>
                                        <td colspan="3">{{ ($display->svc_is_package ?? 0) ? 'YES' : 'NO' }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">INITIAL SQM</td>
                                        <td>{{ $display->svc_sqm_initial ?? 'N/A' }}</td>
                                        <td style="font-weight: bold;">FINAL SQM</td>
                                        <td colspan="3">{{ $display->svc_sqm_final ?? 'N/A' }}</td>
                                    </tr>

                                    @if (!empty($display->svc_problem_description))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">PROBLEM DESCRIPTION / CLIENT REQUEST</th>
                                        </tr>

                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_problem_description }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">PRICING</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">INITIAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_initial_price ?? 0, 2) }}</td>
                                        <td style="font-weight: bold;">LOCATION PRICE</td>
                                        <td>₱{{ number_format($display->svc_location_price ?? 0, 2) }}</td>
                                        <td style="font-weight: bold;">FIXED PRICE</td>
                                        <td>₱{{ number_format($display->svc_fixed_price ?? 0, 2) }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">FINAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_final_price ?? 0, 2) }}</td>
                                        <td style="font-weight: bold;">BALANCE</td>
                                        <td colspan="3">₱{{ number_format($display->svc_balance ?? 0, 2) }}</td>
                                    </tr>

                                    @if ($display->svc_is_termite ?? false)
                                        <tr>
                                            <th colspan="6" class="text-center table-light">TERMITE CASE</th>
                                        </tr>

                                        <tr>
                                            <td style="font-weight: bold;">TREATMENT TYPE</td>
                                            <td>{{ $display->svc_type_treatment ?? 'N/A' }}</td>
                                            <td style="font-weight: bold;">INITIAL SQM</td>
                                            <td>{{ $display->svc_sqm_initial ?? 'N/A' }}</td>
                                            <td style="font-weight: bold;">FINAL SQM</td>
                                            <td>{{ $display->svc_sqm_final ?? 'N/A' }}</td>
                                        </tr>

                                        <tr>
                                            <td style="font-weight: bold;">WITH DEVICE</td>
                                            <td>{{ ($display->svc_with_device ?? 0) ? 'YES' : 'NO' }}</td>
                                            <td style="font-weight: bold;">DEVICE COUNT</td>
                                            <td colspan="3">{{ $display->svc_device_count ?? 'N/A' }}</td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">CHEMICAL</th>
                                    </tr>

                                    @forelse ($serviceChemicals as $chem)
                                        <tr>
                                            <td style="font-weight: bold;">CHEMICAL</td>
                                            <td>{{ $chem->chem_name }}</td>
                                            <td style="font-weight: bold;">EXPECTED QUANTITY</td>
                                            <td>{{ $chem->svcch_expected_quantity }}</td>
                                            <td style="font-weight: bold;">METRIC</td>
                                            <td>{{ $chem->svcch_unit }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No chemicals recorded.</td>
                                        </tr>
                                    @endforelse

                                    @if (!empty($display->svc_assessment_recommendation))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">ASSESSMENT RECOMMENDATION
                                            </th>
                                        </tr>
                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_assessment_recommendation }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SCHEDULE</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE REQUESTED</td>
                                        <td>{{ safeDate($display->svca_client_date ?? null, 'm/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME REQUESTED</td>
                                        <td colspan="3">{{ safeDate($display->svca_client_time ?? null, 'h:i A') }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE APPROVED</td>
                                        <td>{{ safeDate($display->svca_date_approved ?? null, 'm/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME APPROVED</td>
                                        <td>
                                            @if (!empty($display->svca_approved_time_from) && !empty($display->svca_approved_time_to))
                                                {{ safeDate($display->svca_approved_time_from, 'h:i A') }} - {{ safeDate($display->svca_approved_time_to, 'h:i A') }}
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td style="font-weight: bold;">APPROVED BY</td>
                                        <td>{{ trim(($display->approved_first_name ?? '') . ' ' . ($display->approved_last_name ?? '')) ?: 'N/A' }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE ASSIGNED</td>
                                        <td>{{ safeDate($display->svcas_date_assigned ?? null, 'm/d/Y | h:i A') }}</td>
                                        <td style="font-weight: bold;">ASSIGNED TO</td>
                                        <td colspan="3">
                                            {{ $display->assigned_to_label ?? 'N/A' }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE STARTED</td>
                                        <td>{{ safeDate($display->svcas_start_date ?? null, 'm/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME</td>
                                        <td>
                                            @if (!empty($display->svcas_start_time) && !empty($display->svcas_end_time))
                                                {{ safeDate($display->svcas_start_time, 'h:i A') }} - {{ safeDate($display->svcas_end_time, 'h:i A') }}
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td style="font-weight: bold;">TRAVEL TIME / ELAPSED TIME</td>
                                        <td>
                                            {{ formatDuration($display->svcas_time_travel ?? null) }}
                                            /
                                            {{ formatDuration($display->svcas_time_finished ?? null) }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <th colspan="6" class="text-center table-light">COMPLETION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE COMPLETED</td>
                                        <td>
                                            {{ safeDate($display->svc_date_completed ?? null, 'm/d/Y | h:i A') }}
                                        </td>
                                        <td style="font-weight: bold;">COMPLETED BY</td>
                                        <td colspan="3">
                                            {{ trim(($display->completed_first_name ?? '') . ' ' . ($display->completed_last_name ?? '')) ?: 'N/A' }}
                                        </td>
                                    </tr>

                                    @if (!empty($display->svc_rating))
                                        <tr>
                                            <td colspan="6" class="text-center" style="padding: 20px 0;">
                                                <div>
                                                    <strong>CUSTOMER SATISFACTION</strong>
                                                </div>

                                                <div style="margin-top: 5px;">
                                                    @for ($i = 1; $i <= 5; $i++)
                                                        <i class="fa fa-star" style="font-size: 24px; color: {{ $i <= $display->svc_rating ? '#ffc107' : '#d3d3d3' }};"></i>
                                                    @endfor
                                                </div>

                                                <div style="margin-top: 5px; font-weight: bold;">
                                                    {{ $display->svc_rating }}/5
                                                </div>

                                                @if (!empty($display->svc_date_rated))
                                                    <div style="margin-top: 3px; color: #6c757d;">
                                                        {{ \Carbon\Carbon::parse($display->svc_date_rated)->format('h:i A - m/d/Y') }}
                                                    </div>
                                                @endif
                                            </td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-end flex-wrap mb-3 no-print">
                            @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1' || session('ACCOUNTING OFFICER') == '1' || session('BILLING OFFICER'))
                                <a class="btn btn-info mr-2 mb-2" href="{{ url('service/order/payment/view/' . $display->svc_id) }}">
                                    <span class="fa {{ ($display->svc_payment_status ?? '') == 'PAID' ? 'fa-history' : 'fa-money-bill' }}"></span> {{ ($display->svc_payment_status ?? '') == 'PAID' ? 'Payment History' : 'Payments' }}
                                </a>
                            @endif
                            <button type="button" class="btn btn-dark mr-2 mb-2" onclick="printDefault()">
                                <span class="fa fa-print"></span> Print
                            </button>
                            <div class="btn-group mr-2 mb-2">
                                <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <span class="fa fa-print"></span> Print Options
                                </button>
                                <div class="dropdown-menu p-3" style="min-width: 200px;">
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionA">
                                        Appointment Information
                                    </label>
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionB"> Service
                                        Orders
                                    </label>
                                    @if ($appointmentImages->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionC">
                                            Client Appointment Images
                                        </label>
                                    @endif
                                    @if ($contracts->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionF"> Client
                                            Service Contract
                                        </label>
                                    @endif
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionD"> Technician Report
                                    </label>
                                    <div class="dropdown-item text-center">
                                        <button class="btn btn-primary btn-sm mt-2" onclick="handlePrint()">Confirm &
                                            Print</button>
                                    </div>
                                    <div class="dropdown-item">
                                        <p id="warning" style="color:red; display:none;" class="mt-1">Select at least
                                            one section.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Service Order Display --}}
                        <div class="table-responsive" id="sectionB">
                            <hr class="no-print">
                            @if (($display->svc_is_termite ?? 0) == 0)
                                <div class="row">
                                    {{-- PEST TYPE TABLE --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="3"><strong>PEST TYPE</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Pest</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($pestTypes as $index => $type)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $type->svcp_pest_type ?? 'N/A' }}</td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="2" class="text-center text-muted">No pest types added.</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>

                                    {{-- SERVICE ORDER TABLE --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="4"><strong>SERVICE ORDER</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Service</th>
                                                    <th>Cost</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($serviceAreas as $index => $area)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $area->svcpa_area ?? 'N/A' }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            ₱{{ number_format($area->svcpa_cost ?? 0, 2) }}</td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="3" class="text-center text-muted">No service areas added.</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            @elseif (($display->svc_is_termite ?? 0) == 1)
                                <div class="col-md-12">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="5"><strong>TERMITE DETAILS</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>SQM Details</th>
                                                <th>Cost</th>
                                                <th>Computation</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($termiteAreas as $index => $area)
                                                <tr>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $index + 1 }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $area->svcpat_sqm_details ?? 'N/A' }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        ₱{{ number_format($area->svcpat_cost ?? 0, 2) }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        @if (($display->svc_type_treatment ?? '') == 'STANDARD TREATMENT')
                                                            <p>STANDARD TREATMENT: sqm × cost</p>
                                                        @elseif (($display->svc_type_treatment ?? '') == 'HYBRID TREATMENT')
                                                            <p>HYBRID TREATMENT: sqm × cost + device</p>
                                                        @else
                                                            <p>{{ $display->svc_type_treatment ?? 'N/A' }}: sqm × cost</p>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted">No termite areas
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            @endif
                        </div>

                        {{-- Client Appointment Images --}}
                        @if ($appointmentImages->count() > 0)
                            <div class="table-responsive" id="sectionC">
                                <table class="table table-bordered text-center mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5">
                                                <strong>CLIENT APPOINTMENT IMAGES</strong>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($appointmentImages->chunk(5) as $chunk)
                                            <tr>
                                                @foreach ($chunk as $img)
                                                    <td style="width:20%; padding:10px; vertical-align:middle;">
                                                        @if (!empty($img->svcap_image))
                                                            <a href="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                target="_blank"
                                                                style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden;">
                                                                <img src="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                    alt="Appointment Image"
                                                                    style="width:100%; height:100%; object-fit:cover; display:block;">
                                                            </a>
                                                        @else
                                                            <span class="text-muted">No image</span>
                                                        @endif
                                                    </td>
                                                @endforeach
                                                @for ($i = $chunk->count(); $i < 5; $i++)
                                                    <td style="vertical-align: middle;"></td>
                                                @endfor
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Technician Report --}}
                        <div class="table-responsive" id="sectionD">
                            <table class="table table-bordered mb-2">
                                <thead>
                                    <tr style="background-color: #f5f5f5;">
                                        <th class="text-center">
                                            <strong>TECHNICIAN REPORT</strong>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{-- Recommendation --}}
                                    <tr>
                                        <td>
                                            <div class="mb-2" style="font-weight: bold; color: #495057;">
                                                RECOMMENDATION / FINDINGS
                                            </div>
                                            <p style="text-align: justify; margin-bottom: 0;">
                                                {{ $display->svc_technician_recommendation ?? 'No recommendation provided.' }}
                                            </p>
                                        </td>
                                    </tr>

                                    {{-- Chemical Used --}}
                                    <tr>
                                        <td>
                                            <div class="mb-2" style="font-weight: bold; color: #495057;">
                                                CHEMICAL USED
                                            </div>

                                            @forelse ($serviceChemicals as $chem)
                                                <p class="mb-1">
                                                    {{ $chem->svcch_actual_quantity ?? 'N/A' }} {{ $chem->svcch_unit }} - {{ $chem->chem_name }} 
                                                    (EXPECTED: {{ $chem->svcch_expected_quantity }} {{ $chem->svcch_unit }})
                                                </p>
                                            @empty
                                                <p class="mb-0 text-muted">No chemicals recorded.</p>
                                            @endforelse
                                        </td>
                                    </tr>

                                    {{-- Captured Animals --}}
                                    <tr>
                                        <td>
                                            <div class="mb-2" style="font-weight: bold; color: #495057;">
                                                CAPTURED PESTS
                                            </div>

                                            <div class="row text-center">
                                                <div class="col">
                                                    <div><strong>Rats</strong></div>
                                                    <div>{{ $display->svc_rat_captured ?? 0 }}</div>
                                                </div>

                                                <div class="col">
                                                    <div><strong>Snakes</strong></div>
                                                    <div>{{ $display->svc_snake_captured ?? 0 }}</div>
                                                </div>

                                                <div class="col">
                                                    <div><strong>Lizards</strong></div>
                                                    <div>{{ $display->svc_lizard_captured ?? 0 }}</div>
                                                </div>

                                                <div class="col">
                                                    <div><strong>Kittens</strong></div>
                                                    <div>{{ $display->svc_kitten_captured ?? 0 }}</div>
                                                </div>

                                                <div class="col">
                                                    <div><strong>Others</strong></div>
                                                    <div>{{ $display->svc_other_captured ?? 0 }}</div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    {{-- Site Documentation --}}
                                    @if ($technicianImages->count() > 0)
                                        <tr>
                                            <td style="padding-top: 20px;">
                                                <div class="mb-2" style="font-weight: bold; color: #495057;">
                                                    SITE DOCUMENTATION
                                                    ({{ $technicianImages->count() }}
                                                    {{ $technicianImages->count() == 1 ? 'photo' : 'photos' }})
                                                </div>

                                                <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                                    @foreach ($technicianImages as $img)
                                                        <div class="col-6 p-2">
                                                            @if (!empty($img->svcasp_image))
                                                                <a href="{{ asset('images/technician_images/' . $img->svcasp_image) }}"
                                                                    target="_blank"
                                                                    style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                                                    <img src="{{ asset('images/technician_images/' . $img->svcasp_image) }}"
                                                                        alt="Technician Report Image"
                                                                        style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                                                </a>
                                                            @else
                                                                <span class="text-muted">No image</span>
                                                            @endif
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </td>
                                        </tr>
                                    @else
                                        <tr>
                                            <td style="padding-top: 10px;">
                                                <div class="mb-2" style="font-weight: bold; color: #495057;">
                                                    SITE DOCUMENTATION
                                                </div>
                                                <p class="text-muted text-center mb-0" style="padding: 10px 0;">
                                                    No images attached.
                                                </p>
                                            </td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>

                        {{-- Service Contracts --}}
                        @if ($contracts->count() > 0)
                            <div class="table-responsive" id="sectionF">
                                <table class="table table-bordered mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5" class="text-center"><strong>SERVICE CONTRACT</strong></th>
                                        </tr>
                                        <tr style="background-color: #f5f5f5;">
                                            <th class="text-center" style="vertical-align: middle;">Frequency</th>
                                            <th class="text-center" style="vertical-align: middle;">Duration</th>
                                            <th class="text-center" style="vertical-align: middle;">Total Services</th>
                                            <th class="text-center no-print" style="vertical-align: middle;">Contract</th>
                                            <th class="text-center" style="vertical-align: middle;">Appointments</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($contracts as $contract)
                                            <tr>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_type }}</td>
                                                <td class="text-center" style="vertical-align: middle;">
                                                    @php
                                                        // Force 2 decimal places so the fraction always represents 2-digit months
                                                        $parts = explode('.', number_format((float) $contract->svcc_total_years, 2, '.', ''));
                                                        $yrs = (int) $parts[0];
                                                        $mos = (int) $parts[1];

                                                        $label = '';
                                                        if ($yrs > 0) {
                                                            $label .= $yrs . ' Year' . ($yrs > 1 ? 's' : '');
                                                        }
                                                        if ($mos > 0) {
                                                            $label .= ($label ? ' and ' : '') . $mos . ' Month' . ($mos > 1 ? 's' : '');
                                                        }
                                                        if (!$label) {
                                                            $label = '0 Months';
                                                        }
                                                    @endphp
                                                    {{ $label }}
                                                </td>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_total_services }}</td>
                                                <td class="text-center no-print" style="vertical-align: middle;">
                                                    @if ($contract->svcc_contract)
                                                        <a href="{{ asset('images/contracts/' . $contract->svcc_contract) }}"
                                                            class="badge badge-info p-2" style="font-size: 0.85rem;"
                                                            download target="_blank">
                                                            <i class="fas fa-download"></i> Download
                                                        </a>
                                                    @else
                                                        <span class="text-muted">No file.</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($contract->generated_services->isEmpty())
                                                        <span class="text-muted">No appointments generated.</span>
                                                    @else
                                                        <div class="d-flex flex-wrap" style="gap: 6px;">
                                                            @foreach ($contract->generated_services as $svc)
                                                                @php
                                                                    $statusRouteMap = [
                                                                        'CONFIRM ASSESSMENT' => 'service/order/appointments/requested/',
                                                                        'ASSESSED' => 'service/order/appointments/assessed/',
                                                                        'SCHEDULED' => 'service/order/appointments/scheduled/',
                                                                        'ONGOING' => 'service/order/appointments/ongoing/',
                                                                        'DONE REPORT' => 'service/order/appointments/finished/',
                                                                        'COMPLETED' => 'service/order/appointments/completed/',
                                                                    ];
                                                                    $routePrefix = $statusRouteMap[$svc->svc_status] ?? null;
                                                                    $saNumber = 'SA-' . str_pad($svc->svc_sa_number, 6, '0', STR_PAD_LEFT);
                                                                @endphp

                                                                @if ($routePrefix)
                                                                    <a href="{{ url($routePrefix . $svc->svc_id) }}" target="_blank"
                                                                        class="badge badge-primary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }}
                                                                    </a>
                                                                @else
                                                                    <span class="badge badge-secondary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }} ({{ $svc->svc_status }})
                                                                    </span>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function printDefault() {
            window.print();
        }

        function handlePrint() {
            const checkboxes = document.querySelectorAll('.print-toggle');
            const warning = document.getElementById('warning');
            let anyChecked = false;

            const sectionIds = ['sectionA', 'sectionB', 'sectionC', 'sectionD', 'sectionF'];

            sectionIds.forEach(sectionId => {
                const section = document.getElementById(sectionId);
                if (section) {
                    section.classList.remove('print-hide');
                }
            });

            checkboxes.forEach(checkbox => {
                const targetId = checkbox.dataset.target;
                const targetDiv = document.getElementById(targetId);

                if (targetDiv) {
                    if (checkbox.checked) {
                        anyChecked = true;
                        targetDiv.classList.remove('print-hide');
                    } else {
                        targetDiv.classList.add('print-hide');
                    }
                }
            });

            if (!anyChecked) {
                warning.style.display = 'block';
                return;
            }

            warning.style.display = 'none';

            setTimeout(() => {
                window.print();
            }, 500);

            setTimeout(() => {
                sectionIds.forEach(sectionId => {
                    const section = document.getElementById(sectionId);
                    if (section) {
                        section.classList.remove('print-hide');
                    }
                });
            }, 1000);
        }
    </script>
@endsection