@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Finished Appointments</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item active">Finished</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <!-- Table Column -->
                        <div class="col-lg-12 col-md-7">
                            <form method="GET" action="{{ url('service/order/appointments/finished') }}" class="mb-3">
                                <div class="input-group">
                                    <input type="text" name="search" id="searchInput" class="form-control"
                                        placeholder="Search client..." value="{{ request('search') }}">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <span class="fa fa-search"></span> Search
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <table id="profilingTable" class="table table-hover table-bordered table-sm responsive">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">SA Number</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Client</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Mobile Number</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Branch</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Is Termite</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Is Package</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Date Scheduled</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Actual Schedule</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Travel Time</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Service Time</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Total Time</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Payment Status</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($appointments as $appointment)
                                        <tr>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                SA-{{ str_pad($appointment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->usr_last_name }}, {{ $appointment->usr_first_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->usr_mobile }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->branch_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svc_is_termite == 1)
                                                    YES
                                                @else
                                                    NO
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svc_is_package == 1)
                                                    YES
                                                @else
                                                    NO
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svca_approved_date)
                                                    {{ \Carbon\Carbon::parse($appointment->svca_approved_date)->format('m/d/Y') }}
                                                    <br>
                                                    {{ \Carbon\Carbon::parse($appointment->svca_approved_time_from)->format('h:i A') }}
                                                    -
                                                    {{ \Carbon\Carbon::parse($appointment->svca_approved_time_to)->format('h:i A') }}
                                                @else
                                                    -
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svcas_start_date)
                                                    {{ \Carbon\Carbon::parse($appointment->svcas_start_date)->format('m/d/Y') }}
                                                    <br>
                                                    {{ \Carbon\Carbon::parse($appointment->svcas_start_time)->format('h:i A') }}
                                                    -
                                                    {{ \Carbon\Carbon::parse($appointment->svcas_end_time)->format('h:i A') }}
                                                @else
                                                    -
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @php
                                                    [$hours, $minutes] = explode(':', $appointment->svcas_time_travel ?? '00:00:00');
                                                    $hours = (int) $hours;
                                                    $minutes = (int) $minutes;
                                                @endphp

                                                @if ($hours == 0 && $minutes == 0)
                                                    -
                                                @elseif ($hours > 0 && $minutes > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }} and {{ $minutes }}
                                                    min{{ $minutes > 1 ? 's' : '' }}
                                                @elseif ($hours > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }}
                                                @else
                                                    {{ $minutes }} min{{ $minutes > 1 ? 's' : '' }}
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @php
                                                    $totalSeconds = strtotime($appointment->svcas_time_finished ?? '00:00:00') - strtotime('00:00:00');
                                                    $travelSeconds = strtotime($appointment->svcas_time_travel ?? '00:00:00') - strtotime('00:00:00');

                                                    $serviceSeconds = max(0, $totalSeconds - $travelSeconds);

                                                    $hours = floor($serviceSeconds / 3600);
                                                    $minutes = floor(($serviceSeconds % 3600) / 60);
                                                @endphp

                                                @if ($hours == 0 && $minutes == 0)
                                                    -
                                                @elseif ($hours > 0 && $minutes > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }} and {{ $minutes }} min{{ $minutes > 1 ? 's' : '' }}
                                                @elseif ($hours > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }}
                                                @else
                                                    {{ $minutes }} min{{ $minutes > 1 ? 's' : '' }}
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @php
                                                    [$hours, $minutes] = explode(':', $appointment->svcas_time_finished ?? '00:00:00');
                                                    $hours = (int) $hours;
                                                    $minutes = (int) $minutes;
                                                @endphp

                                                @if ($hours == 0 && $minutes == 0)
                                                    -
                                                @elseif ($hours > 0 && $minutes > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }} and {{ $minutes }}
                                                    min{{ $minutes > 1 ? 's' : '' }}
                                                @elseif ($hours > 0)
                                                    {{ $hours }} hr{{ $hours > 1 ? 's' : '' }}
                                                @else
                                                    {{ $minutes }} min{{ $minutes > 1 ? 's' : '' }}
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->svc_payment_status }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                <a class="btn btn-primary btn-sm mb-1"
                                                    href="{{ url('service/order/appointments/finished/' . $appointment->svc_id) }}">
                                                    <span class="fa fa-eye"></span>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Dynamic Search While Typing --}}
    <script>
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let value = this.value.toLowerCase();

            // Select all tables with ID containing "Table"
            let tables = document.querySelectorAll('table[id*="Table"]');

            tables.forEach(function (table) {
                let rows = table.querySelectorAll("tbody tr");

                rows.forEach(function (row) {
                    let text = row.innerText.toLowerCase();
                    row.style.display = text.includes(value) ? "" : "none";
                });
            });
        });
    </script>
@endsection