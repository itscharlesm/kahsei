@extends('layouts.themes.main')

@section('content')

    {{-- Leaflet CSS --}}
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Live Technician Tracking</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item">
                            <a href="{{ url('service/order/appointments/ongoing') }}">Ongoing</a>
                        </li>
                        <li class="breadcrumb-item active">Track Technician</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">

                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0 float-none">
                            <i class="fas fa-map-marker-alt mr-1"></i>
                            Live Tracking
                        </h3>

                        <a href="{{ url('service/order/appointments/ongoing') }}"
                            class="btn btn-info btn-sm">
                            <i class="fas fa-spinner mr-1"></i>
                            Ongoing Schedules
                        </a>
                    </div>
                </div>

                <div class="card-body">

                    {{-- Filter Form --}}
                    <form method="GET" action="{{ url('service/order/appointments/ongoing/tracking') }}"
                          class="d-flex flex-wrap align-items-end mb-3" style="gap:10px;">

                        {{-- Branch dropdown — only for branch 1 (admin) --}}
                        @if ($sessionBranchId == 1)
                            <div>
                                <label class="d-block mb-1" style="font-size:12px;font-weight:600;color:#555;">Branch</label>
                                <select name="filter_branch" class="form-control form-control-sm" style="min-width:160px;">
                                    <option value="">All Branches</option>
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->branch_id }}"
                                            {{ $filterBranch == $branch->branch_id ? 'selected' : '' }}>
                                            {{ $branch->branch_name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        @endif

                        {{-- Technician name search --}}
                        <div>
                            <label class="d-block mb-1" style="font-size:12px;font-weight:600;color:#555;">Technician Name</label>
                            <input type="text" name="search_name" value="{{ $searchName }}"
                                   class="form-control form-control-sm" style="min-width:200px;"
                                   placeholder="Search by name (blank = all)">
                        </div>

                        <div>
                            <button type="submit" class="btn btn-sm btn-info">
                                <i class="fas fa-location-arrow mr-1"></i> Track
                            </button>
                            @if ($searchName || $filterBranch)
                                <a href="{{ url('service/order/appointments/ongoing/tracking') }}"
                                   class="btn btn-sm btn-outline-secondary ml-1">
                                    <i class="fas fa-times mr-1"></i> Clear
                                </a>
                            @endif
                        </div>
                    </form>

                    {{-- Legend --}}
                    <div class="d-flex flex-wrap mb-2" style="gap:16px; font-size:12px; color:#666;">
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span style="width:12px;height:12px;border-radius:50%;background:#dc3545;display:inline-block;"></span>
                            ONGOING — En route
                        </span>
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span style="width:12px;height:12px;border-radius:50%;background:#fd7e14;display:inline-block;"></span>
                            ARRIVED — On-site
                        </span>
                    </div>

                    {{-- No results message --}}
                    @if ($techLocations->isEmpty())
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-circle mr-1"></i>
                            No active technician locations found
                            @if ($searchName)
                                for <strong>{{ $searchName }}</strong>
                            @endif
                            @if ($sessionBranchId != 1)
                                in your branch.
                            @elseif ($filterBranch)
                                in the selected branch.
                            @else
                                .
                            @endif
                        </div>
                    @endif

                    {{-- Map --}}
                    <div id="trackingMap"
                         style="width:100%; height:500px; border:1px solid #ddd; border-radius:6px;
                                {{ $techLocations->isEmpty() ? 'display:none;' : '' }}">
                    </div>

                    {{-- Technician list below map --}}
                    @if ($techLocations->isNotEmpty())
                        <div class="mt-3">
                            <table class="table table-sm table-bordered table-hover" style="font-size:13px;">
                                <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Technician</th>
                                        <th>Branch</th>
                                        <th>Status</th>
                                        <th>Coordinates</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($techLocations as $i => $loc)
                                        <tr>
                                            <td>{{ $i + 1 }}</td>
                                            <td>{{ $loc->tech_last_name }}, {{ $loc->tech_first_name }}</td>
                                            <td>{{ $loc->branch_name }}</td>
                                            <td>
                                                @if ($loc->svca_status === 'ONGOING')
                                                    <span class="badge badge-danger">ONGOING</span>
                                                @elseif ($loc->svca_status === 'ARRIVED')
                                                    <span class="badge badge-warning">ARRIVED</span>
                                                @else
                                                    <span class="badge badge-secondary">{{ $loc->svca_status }}</span>
                                                @endif
                                            </td>
                                            <td style="font-size:11px; color:#888;">
                                                {{ number_format($loc->svcal_latitude, 6) }},
                                                {{ number_format($loc->svcal_longitude, 6) }}
                                            </td>
                                            <td>
                                                <a href="{{ url('service/order/appointments/ongoing/' . $loc->svc_id) }}"
                                                   class="btn btn-xs btn-outline-info">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif

                </div>{{-- /card-body --}}
            </div>
        </div>
    </section>

    {{-- Leaflet JS --}}
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
    (function () {
        const locations = @json($techLocations);

        if (!locations.length) return;

        // SVG markers — reusing exact same SVGs from your existing view_ongoing
        function motorSVG() {
            return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 56" width="48" height="56">
                <circle cx="24" cy="22" r="20" fill="#dc3545" stroke="#fff" stroke-width="2"/>
                <rect x="13" y="19" width="22" height="7" rx="2" fill="#fff" opacity="0.9"/>
                <rect x="28" y="14" width="2" height="7" rx="1" fill="#fff" opacity="0.9"/>
                <ellipse cx="24" cy="19" rx="7" ry="3" fill="#fff" opacity="0.8"/>
                <line x1="33" y1="19" x2="35" y2="26" stroke="#fff" stroke-width="1.5" opacity="0.9"/>
                <circle cx="14" cy="28" r="5" fill="none" stroke="#fff" stroke-width="2.5"/>
                <circle cx="14" cy="28" r="2" fill="#fff"/>
                <circle cx="35" cy="28" r="5" fill="none" stroke="#fff" stroke-width="2.5"/>
                <circle cx="35" cy="28" r="2" fill="#fff"/>
                <polygon points="24,44 19,36 29,36" fill="#dc3545" stroke="#fff" stroke-width="1"/>
            </svg>`;
        }

        function houseSVG() {
            return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 56" width="48" height="56">
                <circle cx="24" cy="22" r="20" fill="#fd7e14" stroke="#fff" stroke-width="2"/>
                <polygon points="24,8 11,20 37,20" fill="#fff"/>
                <rect x="14" y="20" width="20" height="14" rx="1" fill="#fff"/>
                <rect x="20" y="26" width="8" height="8" rx="1" fill="#fd7e14" opacity="0.4"/>
                <g transform="translate(20,21) rotate(-35,4,5)">
                    <rect x="3" y="1" width="3" height="9" rx="1" fill="#fd7e14"/>
                    <rect x="1" y="1" width="7" height="3" rx="1.5" fill="#fd7e14"/>
                    <rect x="1" y="7" width="7" height="3" rx="1.5" fill="#fd7e14"/>
                </g>
                <polygon points="24,44 19,36 29,36" fill="#fd7e14" stroke="#fff" stroke-width="1"/>
            </svg>`;
        }

        // Init map centered on first location
        const firstLat = parseFloat(locations[0].svcal_latitude);
        const firstLng = parseFloat(locations[0].svcal_longitude);

        const map = L.map('trackingMap').setView([firstLat, firstLng], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap'
        }).addTo(map);

        // Bounds to fit all markers
        const bounds = [];

        locations.forEach(function (loc) {
            const lat = parseFloat(loc.svcal_latitude);
            const lng = parseFloat(loc.svcal_longitude);

            const iconHtml = loc.svca_status === 'ARRIVED' ? houseSVG() : motorSVG();

            const icon = L.divIcon({
                html: iconHtml,
                className: '',
                iconSize: [48, 56],
                iconAnchor: [24, 56],
                popupAnchor: [0, -56]
            });

            const statusLabel = loc.svca_status === 'ONGOING'
                ? '<span style="color:#dc3545;font-weight:700;">● ONGOING</span> — En route'
                : '<span style="color:#fd7e14;font-weight:700;">● ARRIVED</span> — On-site';

            const popupHtml = `
                <div style="font-size:12px;line-height:1.7;min-width:160px;">
                    <strong>${loc.tech_last_name}, ${loc.tech_first_name}</strong><br>
                    <hr style="margin:4px 0;border-color:#eee;">
                    <span style="color:#666;">Branch:</span> ${loc.branch_name}<br>
                    <span style="color:#666;">Status:</span> ${statusLabel}<br>
                    <a href="/service/order/appointments/ongoing/${loc.svc_id}"
                       style="font-size:11px;">View appointment →</a>
                </div>`;

            const marker = L.marker([lat, lng], { icon }).addTo(map);
            marker.bindPopup(popupHtml);

            bounds.push([lat, lng]);
        });

        // Fit map to all markers if more than one
        if (bounds.length > 1) {
            map.fitBounds(bounds, { padding: [40, 40] });
        }
    })();
    </script>

@endsection