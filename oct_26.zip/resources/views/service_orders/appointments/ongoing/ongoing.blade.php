@extends('layouts.themes.main')

@section('content')
    {{-- Flatpickr CSS --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.css">
    <style>
        .flatpickr-calendar {
            font-size: 13px;
            border-radius: 6px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, .12);
        }

        .flatpickr-day.disabled,
        .flatpickr-day.disabled:hover {
            color: #ccc !important;
            background: transparent !important;
            cursor: not-allowed !important;
            text-decoration: line-through;
        }

        .flatpickr-day.selected,
        .flatpickr-day.selected:hover {
            background: #e53e3e !important;
            border-color: #e53e3e !important;
        }
    </style>

    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Ongoing Appointments</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item active">Ongoing</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">

                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0 float-none">
                            <i class="fas fa-spinner mr-1"></i>
                            Ongoing Timeline View
                        </h3>

                        <a href="{{ url('service/order/appointments/ongoing/tracking') }}"
                            class="btn btn-info btn-sm">
                            <i class="fas fa-map-marker-alt mr-1"></i>
                            Track Technician
                        </a>
                    </div>
                </div>

                <div class="card-body p-0">

                    {{-- Day navigation bar --}}
                    <div class="d-flex align-items-center justify-content-between flex-wrap p-3 border-bottom"
                        style="gap:10px;">

                        {{-- Previous day --}}
                        @if ($prevDate)
                            <a href="{{ url('service/order/appointments/ongoing') }}?tl_date={{ $prevDate }}"
                                class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-chevron-left mr-1"></i> Previous day
                            </a>
                        @else
                            <button class="btn btn-sm btn-outline-secondary" disabled>
                                <i class="fas fa-chevron-left mr-1"></i> Previous day
                            </button>
                        @endif

                        {{-- Date label + Flatpickr --}}
                        <div class="d-flex align-items-center" style="gap:10px; flex-wrap:wrap;">
                            <span class="font-weight-bold" style="font-size:15px;">
                                {{ \Carbon\Carbon::parse($tlDate)->format('l, F d, Y') }}
                            </span>

                            <form method="GET" action="{{ url('service/order/appointments/ongoing') }}" id="tlDateForm"
                                class="d-flex align-items-center" style="gap:6px;">
                                <input type="text" name="tl_date" id="tlDatePicker" value="{{ $tlDate }}"
                                    class="form-control form-control-sm" style="width:150px;" placeholder="Pick a date"
                                    readonly>
                            </form>
                        </div>

                        {{-- Next day --}}
                        @if ($nextDate)
                            <a href="{{ url('service/order/appointments/ongoing') }}?tl_date={{ $nextDate }}"
                                class="btn btn-sm btn-outline-secondary">
                                Next day <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        @else
                            <button class="btn btn-sm btn-outline-secondary" disabled>
                                Next day <i class="fas fa-chevron-right ml-1"></i>
                            </button>
                        @endif
                    </div>

                    {{-- Legend --}}
                    <div class="px-3 pt-2 pb-1 d-flex flex-wrap" style="gap:16px; font-size:12px; color:#666;">
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span
                                style="width:12px;height:12px;border-radius:3px;background:#F4BBBB;border:0.5px solid #E07070;display:inline-block;"></span>
                            Scheduled
                        </span>
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span
                                style="width:12px;height:12px;border-radius:3px;background:#C0DD97;border:1px solid #97C459;display:inline-block;"></span>
                            Done Service
                        </span>
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span
                                style="width:12px;height:12px;border-radius:3px;background:#FFD49A;border:1px solid #FFA940;display:inline-block;"></span>
                            In Progress / Overdue
                        </span>
                        <span class="d-flex align-items-center" style="gap:5px;">
                            <span
                                style="width:12px;height:12px;border-radius:3px;background:#e53e3e;display:inline-block;border-radius:50%;"></span>
                            Current time
                        </span>
                    </div>

                    {{-- Timeline container --}}
                    <div class="p-3" style="overflow-x:auto;" id="tlOuter">
                        @if (empty($timelineByTech))
                            <p class="text-muted text-center py-4">No ongoing appointments for this day.</p>
                        @else
                            <div id="tlContainer" style="min-width:900px;"></div>
                        @endif
                    </div>

                    {{-- Pass PHP data to JS --}}
                    @php
                        $tlDataForJs = [];
                        foreach ($timelineByTech as $techName => $rows) {
                            foreach ($rows as $row) {
                                $tlDataForJs[] = [
                                    'tech' => $techName,
                                    'client' => $row->usr_last_name . ', ' . $row->usr_first_name,
                                    'email' => $row->usr_email,
                                    'mobile' => $row->usr_mobile,
                                    'branch' => $row->branch_name,
                                    'from' => $row->svca_approved_time_from,
                                    'to' => $row->svca_approved_time_to,
                                    'payment' => $row->svc_payment_status,
                                    'termite' => (bool) $row->svc_is_termite,
                                    'package' => (bool) $row->svc_is_package,
                                    'sa_number' => 'SA-' . str_pad($row->svc_sa_number, 6, '0', STR_PAD_LEFT),
                                    'svc_id' => $row->svc_id,
                                    'svcas_start_date' => $row->svcas_start_date ?? null, // e.g. "2025-06-04"
                                    'svcas_start_time' => $row->svcas_start_time ?? null, // e.g. "08:30:00"
                                    'svcas_end_date' => $row->svcas_end_date ?? null,
                                    'svcas_end_time' => $row->svcas_end_time ?? null,
                                    'svcas_time_finished' => $row->svcas_time_finished ?? null,
                                ];
                            }
                        }
                    @endphp

                    {{-- Flatpickr JS --}}
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.js"></script>
                    <script>
                        (function() {
                            const availableDates = @json($availableDates);

                            document.addEventListener('DOMContentLoaded', function() {
                                flatpickr('#tlDatePicker', {
                                    enable: availableDates,
                                    dateFormat: 'Y-m-d',
                                    defaultDate: '{{ $tlDate }}',
                                    disableMobile: true,
                                    onChange: function(selectedDates, dateStr) {
                                        if (dateStr) {
                                            document.getElementById('tlDateForm').submit();
                                        }
                                    },
                                });
                            });
                        })();
                    </script>

                    {{-- Timeline JS --}}
                    <script>
                        (function() {
                            const HOURS_S = 0;
                            const HOURS_E = 23;
                            const TOTAL = HOURS_E - HOURS_S;
                            const ROW_H = 40;
                            const LABEL_W = 130;
                            const BASE_URL = '{{ url('service/order/appointments/ongoing') }}';

                            const DATA = @json($tlDataForJs);
                            const TL_DATE = '{{ $tlDate }}';
                            const TODAY = new Date().toISOString().slice(0, 10);
                            const IS_TODAY = TL_DATE === TODAY;

                            const NOW_H = (function() {
                                const n = new Date();
                                return n.getHours() + n.getMinutes() / 60;
                            })();

                            function parseTm(s) {
                                if (!s) return null;
                                const p = s.split(':');
                                return +p[0] + +p[1] / 60;
                            }

                            function pct(h) {
                                return ((h - HOURS_S) / TOTAL * 100).toFixed(4) + '%';
                            }

                            function fmt12(s) {
                                if (!s) return '';
                                const h = parseInt(s);
                                const m = s.split(':')[1] ?? '00';
                                const ampm = h < 12 ? 'AM' : 'PM';
                                const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
                                return h12 + (m !== '00' ? ':' + m : '') + ' ' + ampm;
                            }

                            function fmtDateTime(timeStr, dateStr) {
                                if (!timeStr || !dateStr) return null;
                                const [y, mo, d] = dateStr.split('-');
                                return fmt12(timeStr) + ' ' + mo + '/' + d + '/' + y;
                            }

                            /* Tooltip */
                            let tt = null;

                            function ensureTT() {
                                if (tt) return;
                                tt = document.createElement('div');
                                tt.style.cssText = [
                                    'position:fixed;background:#fff;border:1px solid #ddd;',
                                    'border-radius:8px;padding:8px 12px;font-size:12px;',
                                    'pointer-events:none;z-index:9999;display:none;',
                                    'box-shadow:0 4px 12px rgba(0,0,0,.1);',
                                    'max-width:260px;line-height:1.6;color:#333;',
                                ].join('');
                                document.body.appendChild(tt);
                            }

                            function showTip(e, html) {
                                ensureTT();
                                tt.innerHTML = html;
                                tt.style.display = 'block';
                                moveTip(e);
                            }

                            function moveTip(e) {
                                if (!tt) return;
                                let x = e.clientX + 14,
                                    y = e.clientY + 14;
                                if (x + 260 > window.innerWidth) x = e.clientX - 260 - 14;
                                if (y + 200 > window.innerHeight) y = e.clientY - 200 - 14;
                                tt.style.left = x + 'px';
                                tt.style.top = y + 'px';
                            }

                            function hideTip() {
                                if (tt) tt.style.display = 'none';
                            }

                            /* Red appointment block */
                            function makeBlock(row) {
                                const frm = parseTm(row.from);
                                const to_ = parseTm(row.to);
                                if (frm === null || to_ === null) return null;

                                const df = Math.max(frm, HOURS_S);
                                const dt = Math.min(to_, HOURS_E);
                                if (df >= dt) return null;

                                const blk = document.createElement('div');
                                blk.style.cssText = [
                                    'position:absolute;top:4px;bottom:4px;',
                                    'left:' + pct(df) + ';',
                                    'width:' + ((dt - df) / TOTAL * 100).toFixed(4) + '%;',
                                    'background:#F4BBBB;color:#7A1010;',
                                    'border:0.5px solid #E07070;',
                                    'border-radius:5px;',
                                    'display:flex;flex-direction:column;',
                                    'align-items:center;justify-content:center;',
                                    'overflow:hidden;padding:0 4px;cursor:pointer;',
                                    'z-index:1;',
                                ].join('');

                                const nameEl = document.createElement('span');
                                nameEl.style.cssText =
                                    'font-size:10px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;';
                                nameEl.textContent = row.client;

                                const saEl = document.createElement('span');
                                saEl.style.cssText =
                                    'font-size:9px;opacity:0.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;';
                                saEl.textContent = row.sa_number;

                                blk.appendChild(nameEl);
                                blk.appendChild(saEl);

                                const tipHtml = [
                                    '<strong>' + row.sa_number + ' &mdash; ' + row.client + '</strong>',
                                    '<hr style="margin:4px 0;border-color:#eee;">',
                                    '<span style="color:#666;">Tech:</span> ' + row.tech,
                                    '<span style="color:#666;">Branch:</span> ' + row.branch,
                                    '<span style="color:#666;">Mobile:</span> ' + (row.mobile || '—'),
                                    '<span style="color:#666;">Email:</span> ' + (row.email || '—'),
                                    '<span style="color:#666;">Time:</span> ' + fmt12(row.from) + ' – ' + fmt12(row.to),
                                    '<span style="color:#666;">Payment:</span> ' + row.payment,
                                    '<span style="color:#666;">Termite:</span> ' + (row.termite ? 'Yes' : 'No') +
                                    '&nbsp;&nbsp;<span style="color:#666;">Package:</span> ' + (row.package ? 'Yes' : 'No'),
                                ].join('<br>');

                                blk.addEventListener('mouseenter', e => showTip(e, tipHtml));
                                blk.addEventListener('mousemove', moveTip);
                                blk.addEventListener('mouseleave', hideTip);
                                blk.addEventListener('click', () => {
                                    hideTip();
                                    window.location.href = BASE_URL + '/' + row.svc_id;
                                });

                                return blk;
                            }

                            function formatElapsedTime(timeStr) {
                                if (!timeStr) return '—';

                                const parts = timeStr.split(':');

                                const hours = parseInt(parts[0] || 0);
                                const minutes = parseInt(parts[1] || 0);
                                const seconds = parseInt(parts[2] || 0);

                                const result = [];

                                if (hours > 0) {
                                    result.push(hours + ' hour' + (hours > 1 ? 's' : ''));
                                }

                                if (minutes > 0) {
                                    result.push(minutes + ' minute' + (minutes > 1 ? 's' : ''));
                                }

                                if (seconds > 0 && hours === 0) {
                                    result.push(seconds + ' second' + (seconds > 1 ? 's' : ''));
                                }

                                return result.length ? result.join(' and ') : '0 minute';
                            }

                            /* Green/Orange schedule overlay block */
                            function makeScheduleBlock(row) {
                                if (!row.svcas_start_time || !row.svcas_start_date) return null;

                                const startH = parseTm(row.svcas_start_time);
                                if (startH === null) return null;

                                let endH;
                                let bg, color, border;

                                const hasEnd = !!row.svcas_end_time && !!row.svcas_end_date;
                                const endSameDay = hasEnd && row.svcas_end_date === TL_DATE;

                                if (hasEnd) {
                                    endH = parseTm(row.svcas_end_time);
                                    bg = '#C0DD97';
                                    color = '#27500A';
                                    border = '#97C459';
                                } else if (IS_TODAY) {
                                    endH = NOW_H;
                                    bg = '#FFD49A';
                                    color = '#7A3B00';
                                    border = '#FFA940';
                                } else {
                                    endH = parseTm(row.to);
                                    bg = '#FFD49A';
                                    color = '#7A3B00';
                                    border = '#FFA940';
                                }

                                if (endH === null || endH <= startH) return null;

                                const df = Math.max(startH, HOURS_S);
                                const dt = Math.min(endH, HOURS_E);
                                if (df >= dt) return null;

                                const blk = document.createElement('div');
                                blk.style.cssText = [
                                    'position:absolute;top:2px;bottom:2px;',
                                    'left:' + pct(df) + ';',
                                    'width:' + ((dt - df) / TOTAL * 100).toFixed(4) + '%;',
                                    'background:' + bg + ';color:' + color + ';',
                                    'border:1px solid ' + border + ';',
                                    'border-radius:5px;',
                                    'display:flex;flex-direction:column;',
                                    'align-items:center;justify-content:center;',
                                    'overflow:hidden;padding:0 4px;cursor:pointer;',
                                    'pointer-events:auto;',
                                    'z-index:2;',
                                ].join('');

                                // Same labels as the red block
                                const nameEl = document.createElement('span');
                                nameEl.style.cssText =
                                    'font-size:10px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;';
                                nameEl.textContent = row.client;

                                const saEl = document.createElement('span');
                                saEl.style.cssText =
                                    'font-size:9px;opacity:0.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;';
                                saEl.textContent = row.sa_number;

                                blk.appendChild(nameEl);
                                blk.appendChild(saEl);

                                // Tooltip: same as red block + START / END lines
                                const startLabel = fmtDateTime(row.svcas_start_time, row.svcas_start_date);
                                const endLabel = hasEnd ? fmtDateTime(row.svcas_end_time, row.svcas_end_date) : null;

                                const tipHtml = [
                                    '<strong>' + row.sa_number + ' &mdash; ' + row.client + '</strong>',
                                    '<hr style="margin:4px 0;border-color:#eee;">',
                                    '<span style="color:#666;">Tech:</span> ' + row.tech,
                                    '<span style="color:#666;">Branch:</span> ' + row.branch,
                                    '<span style="color:#666;">Mobile:</span> ' + (row.mobile || '—'),
                                    '<span style="color:#666;">Email:</span> ' + (row.email || '—'),
                                    '<span style="color:#666;">Time:</span> ' + fmt12(row.from) + ' – ' + fmt12(row.to),
                                    '<span style="color:#666;">Payment:</span> ' + row.payment,
                                    '<span style="color:#666;">Termite:</span> ' + (row.termite ? 'Yes' : 'No') +
                                    '&nbsp;&nbsp;<span style="color:#666;">Package:</span> ' + (row.package ? 'Yes' : 'No'),
                                    '<hr style="margin:4px 0;border-color:#eee;">',
                                    '<span style="color:#666;">Start:</span> ' + startLabel,
                                    endLabel ?
                                    '<span style="color:#666;">End:</span> ' + endLabel :
                                    '',
                                    row.svcas_time_finished
                                    ? '<span style="color:#666;">Elapsed Time:</span> ' + formatElapsedTime(row.svcas_time_finished)
                                    : '',
                                ].filter(Boolean).join('<br>');

                                blk.addEventListener('mouseenter', e => showTip(e, tipHtml));
                                blk.addEventListener('mousemove', moveTip);
                                blk.addEventListener('mouseleave', hideTip);
                                blk.addEventListener('click', () => {
                                    hideTip();
                                    window.location.href = BASE_URL + '/' + row.svc_id;
                                });

                                return blk;
                            }

                            /* buildTimeline */
                            function buildTimeline() {
                                const container = document.getElementById('tlContainer');
                                if (!container) return;
                                container.innerHTML = '';
                                container.style.position = 'relative'; // needed for the now-line overlay

                                /* ── Hour axis ── */
                                const axisRow = document.createElement('div');
                                axisRow.style.cssText = 'display:flex;margin-bottom:6px;';

                                const axisLabel = document.createElement('div');
                                axisLabel.style.cssText = `flex:none;width:${LABEL_W}px;`;
                                axisRow.appendChild(axisLabel);

                                const axisTrack = document.createElement('div');
                                axisTrack.style.cssText = 'flex:1;position:relative;height:20px;';

                                for (let h = HOURS_S; h <= HOURS_E; h++) {
                                    const span = document.createElement('span');
                                    span.style.cssText = [
                                        'position:absolute;',
                                        'left:' + pct(h) + ';',
                                        'transform:translateX(-50%);',
                                        'font-size:10px;color:#999;white-space:nowrap;',
                                    ].join('');
                                    const h12 = h === 0 || h === 24 ? 12 : h > 12 ? h - 12 : h;
                                    const ampm = h < 12 ? 'am' : 'pm';
                                    span.textContent = h12 + ampm;
                                    axisTrack.appendChild(span);
                                }

                                /* "Now" label on axis (today only) */
                                if (IS_TODAY && NOW_H >= HOURS_S && NOW_H <= HOURS_E) {
                                    const nowLabel = document.createElement('div');
                                    nowLabel.style.cssText = [
                                        'position:absolute;',
                                        'left:' + pct(NOW_H) + ';',
                                        'transform:translateX(-50%);',
                                        'font-size:9px;font-weight:700;color:#e53e3e;',
                                        'white-space:nowrap;',
                                        'top:-14px;', // sits above the axis line
                                        'z-index:6;',
                                    ].join('');
                                    const nowHr = new Date().getHours();
                                    const nowMin = String(new Date().getMinutes()).padStart(2, '0');
                                    const a = nowHr < 12 ? 'AM' : 'PM';
                                    const h12 = nowHr === 0 ? 12 : nowHr > 12 ? nowHr - 12 : nowHr;
                                    nowLabel.textContent = h12 + ':' + nowMin + ' ' + a;
                                    axisTrack.appendChild(nowLabel);
                                }

                                axisRow.appendChild(axisTrack);
                                container.appendChild(axisRow);

                                if (!DATA.length) return;

                                /* ── One row per technician ── */
                                const techs = [...new Set(DATA.map(r => r.tech))].sort();

                                techs.forEach(tech => {
                                    const rows = DATA.filter(r => r.tech === tech);

                                    const rowWrap = document.createElement('div');
                                    rowWrap.style.cssText = 'display:flex;align-items:center;margin-bottom:4px;';

                                    const label = document.createElement('div');
                                    label.style.cssText = [
                                        `flex:none;width:${LABEL_W}px;`,
                                        'font-size:11px;color:#555;padding-right:8px;',
                                        'text-align:right;overflow:hidden;',
                                        'text-overflow:ellipsis;white-space:nowrap;',
                                    ].join('');
                                    label.title = tech;
                                    label.textContent = tech;
                                    rowWrap.appendChild(label);

                                    const track = document.createElement('div');
                                    track.style.cssText = [
                                        'flex:1;position:relative;',
                                        `height:${ROW_H}px;`,
                                        'background:#f7f7f7;',
                                        'border:0.5px solid #ddd;',
                                        'border-radius:6px;overflow:visible;',
                                    ].join('');

                                    // Grid lines
                                    for (let h = HOURS_S; h <= HOURS_E; h++) {
                                        const line = document.createElement('div');
                                        line.style.cssText = [
                                            'position:absolute;top:0;bottom:0;',
                                            'left:' + pct(h) + ';',
                                            'width:0.5px;background:#e0e0e0;',
                                        ].join('');
                                        track.appendChild(line);
                                    }

                                    // Red appointment bars
                                    rows.forEach(row => {
                                        const blk = makeBlock(row);
                                        if (blk) track.appendChild(blk);
                                    });

                                    // Green/Orange schedule overlay bars
                                    rows.forEach(row => {
                                        const blk = makeScheduleBlock(row);
                                        if (blk) track.appendChild(blk);
                                    });

                                    rowWrap.appendChild(track);
                                    container.appendChild(rowWrap);
                                });

                                /* Single continuous "Now" line over all rows (today only) */
                                if (IS_TODAY && NOW_H >= HOURS_S && NOW_H <= HOURS_E) {
                                    const nowLine = document.createElement('div');
                                    nowLine.style.cssText = [
                                        'position:absolute;',
                                        'top:0;',
                                        // Extend downward enough to cover all rows; 44px per row (ROW_H + 4px margin)
                                        `height:${(techs.length * (ROW_H + 4)) + 30}px;`,
                                        'left:' + pct(NOW_H) + ';',
                                        'width:2px;',
                                        'background:#e53e3e;',
                                        'z-index:10;',
                                        'pointer-events:none;',
                                        'transform:translateX(-50%);',
                                    ].join('');

                                    axisTrack.appendChild(nowLine);
                                }
                            }

                            document.addEventListener('DOMContentLoaded', buildTimeline);
                            if (document.readyState !== 'loading') buildTimeline();
                        })();
                    </script>

                </div>
            </div>
        </div>
    </section>
@endsection