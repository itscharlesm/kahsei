<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
    <title>Sign Up | Go Forward Pest Control</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="CQA Review Center">
    <meta name="author" content="Infinit Soloutions">
    <link rel="shortcut icon" href="{{ asset('images/logos/logo.jpg') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ asset('login/css/style.css') }}">
</head>

<body>
    @include('sweetalert::alert')
    @include('layouts.partials.alerts')
    @include('layouts.partials.onclick')
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="wrap d-md-flex">
                        <div class="img" style="background-image: url({{ asset('images/logos/logo_red.png') }});">
                        </div>
                        <div class="login-wrap p-4 p-md-4">
                            <div class="d-flex justify-content-center">
                                <img src="{{ asset('images/logos/logo.jpg') }}" class="img-circle elevation-2"
                                    style="width:80px;height:80px;" alt="">
                            </div>

                            <div class="d-flex justify-content-center">
                                <h5 class="text-center" style="color:gray;">Create Account</h5>
                            </div>
                            
                            <p class="text-center"><small>Sign up to get started</small></p>

                            @if(session('errorMessage'))
                                <p style="color:red;"><small>{{ session('errorMessage') }}</small></p>
                            @endif

                            <form method="POST"
                                action="{{ action('App\Http\Controllers\ClientController@registration_store') }}">
                                {{ csrf_field() }}
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="branch_id">Branch <span class="text-danger">*</span></label>
                                        <select class="form-control" name="branch_id" required>
                                            @foreach ($branches as $branch)
                                                <option value="{{ $branch->branch_id }}" {{ old('branch_id') == $branch->branch_id ? 'selected' : '' }}>
                                                    {{ $branch->branch_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="usr_first_name">First Name <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="usr_first_name"
                                            value="{{ old('usr_first_name') }}" required />
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_middle_name">Middle Name <span class="text-secondary">(Optional)</span></label>
                                        <input class="form-control" type="text" name="usr_middle_name"
                                            value="{{ old('usr_middle_name') }}" />
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_last_name">Last Name <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="usr_last_name"
                                            value="{{ old('usr_last_name') }}" required />
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_mobile">Mobile Number <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">+63</span>
                                            </div>
                                            <input class="form-control" type="text" name="usr_mobile"
                                                value="{{ old('usr_mobile') }}" maxlength="10" pattern="9[0-9]{9}"
                                                placeholder="9123456789"
                                                title="Enter a valid mobile number starting with 9 (10 digits)"
                                                required />
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_email">Email Address <span class="text-danger">*</span></label>
                                        <input class="form-control" type="email" name="usr_email"
                                            value="{{ old('usr_email') }}" required />
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_password">Password <span class="text-danger">*</span></label>
                                        <input class="form-control" type="password" name="usr_password" required />
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label for="usr_password_confirmation">Confirm Password <span class="text-danger">*</span></label>
                                        <input class="form-control" type="password" name="usr_password_confirmation"
                                            required />
                                    </div>
                                    <div class="col-md-12 col-sm-12 mb-2 mt-3">
                                        <button class="btn btn-secondary btn-block"
                                            style="background-color:#313131;color:white;" type="submit"><span
                                                class="fa fa-user-plus"></span> Sign Up</button>
                                    </div>
                                </div>
                            </form>

                            <div class="d-flex justify-content-center mt-2">
                                <small class="text-secondary">
                                    Already have an account?
                                    <a href="{{ url('/') }}" class="text-danger">Login</a>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="{{ asset('login/js/jquery.min.js') }}"></script>
    <script src="{{ asset('login/js/popper.js') }}"></script>
    <script src="{{ asset('login/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('login/js/main.js') }}"></script>
</body>

</html>