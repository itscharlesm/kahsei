<style>
    @media print {
        body {
            zoom: 100%;
        }

        .no-print {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }

        .print-hide {
            display: none !important;
        }
    }

    .table-responsive {
        overflow: visible !important;
    }

    #sectionB {
        overflow: visible !important;
    }
</style>

@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header no-print">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Service Order Payment History</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Service Order</li>
                        <li class="breadcrumb-item">Payments</li>
                        <li class="breadcrumb-item active">History</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">

                    <div class="text-center mb-2">
                        <h5 style="margin: 0; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
                        <p style="margin: 0;">{{ $display->branch_name }}</p>
                    </div>

                    <div class="mb-4 position-relative text-center">
                        <strong style="color: red;">SERVICE ORDER PAYMENT</strong>
                        <strong style="position: absolute; right: 0; top: 0;">
                            SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </strong>
                    </div>

                    {{-- Client Info --}}
                    <div class="table-responsive overflow-auto" id="sectionA">
                        <table class="table table-bordered text-left align-middle">
                            <tbody>
                                <tr>
                                    <th colspan="4" class="text-center table-light">CLIENT INFORMATION</th>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold;">CLIENT NAME</td>
                                    <td>{{ $display->usr_first_name }} {{ $display->usr_last_name }}</td>
                                    <td style="font-weight: bold;">PAYMENT STATUS</td>
                                    <td>{{ $display->svc_payment_status }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    {{-- Service Order Items --}}
                    <div class="table-responsive" id="sectionB">
                        @if (!$display->svc_is_termite)
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="2"><strong>PEST TYPE</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Pest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($pestTypes as $index => $type)
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $type->svcp_pest_type }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="2" class="text-center text-muted">No pest types
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="3"><strong>SERVICE ORDER</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Service</th>
                                                <th>Cost</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $itemsTotal = 0; @endphp
                                            @forelse ($serviceAreas as $index => $area)
                                                @php $itemsTotal += $area->svcpa_cost; @endphp
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $area->svcpa_area }}</td>
                                                    <td>₱{{ number_format($area->svcpa_cost, 2) }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="3" class="text-center text-muted">No service areas
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                            @if ($serviceAreas->count() > 0)
                                                <tr style="font-weight: bold; background-color: #f5f5f5;">
                                                    <td colspan="2" class="text-right">TOTAL:</td>
                                                    <td>₱{{ number_format($itemsTotal, 2) }}</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @else
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="2"><strong>PEST TYPE</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>Pest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($pestTypes as $index => $type)
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $type->svcp_pest_type }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="2" class="text-center text-muted">No pest types
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="{{ $display->svc_with_device ? 5 : 3 }}">
                                                    <strong>TERMITE DETAILS</strong>
                                                    @if ($display->svc_type_treatment == 'STANDARD TREATMENT')
                                                        (<strong>STANDARD TREATMENT</strong>: sqm × cost)
                                                    @elseif ($display->svc_type_treatment == 'HYBRID TREATMENT')
                                                        (<strong>HYBRID TREATMENT</strong>: sqm × cost + device)
                                                    @endif
                                                </th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>SQM Details</th>
                                                <th>Cost</th>
                                                @if ($display->svc_with_device)
                                                    <th>Device Count</th>
                                                    <th>Device Price</th>
                                                @endif
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $itemsTotal = 0; @endphp
                                            @forelse ($termiteAreas as $index => $area)
                                                @php $itemsTotal += $area->svcpat_cost; @endphp
                                                <tr>
                                                    <td>{{ $index + 1 }}</td>
                                                    <td>{{ $area->svcpat_sqm_details }}</td>
                                                    <td>₱{{ number_format($area->svcpat_cost, 2) }}</td>
                                                    @if ($display->svc_with_device)
                                                        <td>{{ $index == 0 ? $display->svc_device_count : '' }}</td>
                                                        <td>{{ $index == 0 ? '₱' . number_format($display->svc_device_price, 2) : '' }}</td>
                                                    @endif
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="{{ $display->svc_with_device ? 5 : 3 }}" class="text-center text-muted">
                                                        No termite areas added.
                                                    </td>
                                                </tr>
                                            @endforelse
                                            @if ($termiteAreas->count() > 0)
                                                @php
                                                    $grandTotal = $display->svc_with_device
                                                        ? $itemsTotal + $display->svc_device_price
                                                        : $itemsTotal;
                                                @endphp
                                                <tr style="font-weight: bold; background-color: #f5f5f5;">
                                                    <td colspan="{{ $display->svc_with_device ? 4 : 2 }}" class="text-right">TOTAL:</td>
                                                    <td>₱{{ number_format($grandTotal, 2) }}</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif
                    </div>

                    {{-- Pricing Summary --}}
                    <div class="d-flex mb-4 mt-3" style="gap: 15px;">
                        {{-- <div style="flex: 1;">
                            <label class="form-label fw-bold">Fixed Price:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_fixed_price, 2) }}">
                        </div> --}}
                        <div style="flex: 1;">
                            <label class="form-label fw-bold">Final Price:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_final_price, 2) }}">
                        </div>
                        <div style="flex: 1;">
                            <label class="form-label fw-bold">Balance:</label>
                            <input type="text" class="form-control bg-light" readonly
                                value="₱{{ number_format($display->svc_balance, 2) }}">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mb-3 no-print">
                        @if ($display->svc_balance > 0)
                            <button type="button" class="btn btn-success mr-2" data-toggle="modal" data-target="#addPaymentModal">
                                <span class="fa fa-plus"></span> Add Payment
                            </button>
                        @endif
                        <button type="button" class="btn btn-primary mr-2" onclick="printDefault()">
                            <span class="fa fa-print"></span> Print
                        </button>
                    </div>

                    <hr>

                    {{-- Payment History --}}
                    <div class="row mt-4">
                        <div class="col-md-12">

                            {{-- For Approval --}}
                            @if ($paymentsForApproval->count() > 0)
                                <h4 class="mb-2">For Approval</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsForApproval as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                        data-target="#forApprovalPaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-eye"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            {{-- List of Payments --}}
                            @if ($paymentsApproved->count() > 0)
                                <h4 class="mb-2">List of Payments</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th style="vertical-align: middle; text-align: center">Vatable</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsApproved as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_final_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_vatable_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                        data-target="#viewPaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-eye"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            {{-- Voided Payments --}}
                            @if ($paymentsVoided->count() > 0)
                                <h4 class="mb-2">Voided Payments</h4>
                                <table class="table table-bordered table-striped mb-4">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align: middle; text-align: center">Receipt No.</th>
                                            <th style="vertical-align: middle; text-align: center">Reference No.</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Date</th>
                                            <th style="vertical-align: middle; text-align: center">Amount Paid</th>
                                            <th style="vertical-align: middle; text-align: center">Payment Type</th>
                                            <th style="vertical-align: middle; text-align: center">Vatable</th>
                                            <th class="text-center no-print">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($paymentsVoided as $payment)
                                            <tr>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_receipt_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->spay_reference_number ?? '—' }}</td>
                                                <td style="vertical-align: middle; text-align: center">
                                                    {{ \Carbon\Carbon::parse($payment->spay_date)->format('F d, Y') }}
                                                </td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_final_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center">{{ $payment->typ_name }}</td>
                                                <td style="vertical-align: middle; text-align: center">₱{{ number_format($payment->spay_vatable_amount, 2) }}</td>
                                                <td style="vertical-align: middle; text-align: center" class="no-print">
                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                        data-target="#voidedPaymentModal-{{ $payment->spay_id }}">
                                                        <span class="fa fa-eye"></span>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            @endif

                            @if ($paymentsForApproval->count() == 0 && $paymentsApproved->count() == 0 && $paymentsVoided->count() == 0)
                                <h4 class="mb-2">List of Payments</h4>
                                <p class="text-center text-muted">No payment history found.</p>
                            @endif

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    {{-- Add Payment Modal (Client) --}}
    <div class="modal fade" id="addPaymentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <form method="POST" id="addPaymentForm" enctype="multipart/form-data"
                    action="{{ url('client/service/order/payment/view/add/payment/' . $svc_id) }}">
                    @csrf

                    <div class="modal-header">
                        <h5 class="modal-title">
                            Add Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Type <span class="text-danger">*</span></label>
                                <select class="form-control" name="typ_id" required>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}">{{ $type->typ_name }}</option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="spay_date" value="{{ date('Y-m-d') }}" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Reference Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="spay_reference_number" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                <input type="number" step="0.1" class="form-control" name="spay_amount" id="spay_amount"
                                    max="{{ $display->svc_balance }}" min="0.1" required>
                                <small class="form-text text-muted">Balance: ₱{{ number_format($display->svc_balance, 2) }}</small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="font-weight-bold">Proof of Payment <span class="text-danger">*</span></label>
                                <input type="file" class="form-control" name="spay_image_proof"
                                    accept=".jpg,.jpeg,.png,.webp" required>
                                <small class="form-text text-muted">JPG, PNG, or WEBP. Max 8MB.</small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="font-weight-bold">Payment Details <span class="text-muted">(optional)</span></label>
                                <textarea class="form-control text-uppercase" name="spay_details" rows="3" style="text-transform: uppercase;"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                        <button type="submit" class="btn btn-success">
                            <span class="fa fa-save"></span> Submit Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @foreach ($paymentsForApproval as $payment)
        {{-- For Approval Payment Modal --}}
        <div class="modal fade" id="forApprovalPaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            For Approval Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="font-weight-bold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Payment Type</label>
                                <select class="form-control" name="typ_id" readonly>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}"
                                            {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                            {{ $type->typ_name }}
                                        </option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Reference Number</label>
                                <input type="text" class="form-control" name="spay_reference_number"
                                    value="{{ $payment->spay_reference_number }}" readonly>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Amount</label>
                                <input type="number" step="0.01" class="form-control" name="spay_final_amount"
                                    value="{{ $payment->spay_amount }}" readonly>
                            </div>
                        </div>

                        {{-- Proof of Payment --}}
                        @if (!empty($payment->spay_image_proof))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Proof of Payment</label>
                                    <div>
                                        <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                            target="_blank"
                                            style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                alt="Proof of Payment"
                                                style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if(!empty($payment->spay_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Client Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                </div>
                            </div>
                        @endif
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    @foreach ($paymentsApproved as $payment)
        {{-- View Payment Modal --}}
        <div class="modal fade" id="viewPaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            View Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Receipt Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_receipt_number }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Payment Type</label>
                                <select class="form-control" readonly>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}"
                                            {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                            {{ $type->typ_name }}
                                        </option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Reference Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_reference_number }}" readonly>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control"
                                    value="{{ $payment->spay_final_amount }}" readonly>
                            </div>
                        </div>

                        @if ($payment->spay_is_vatable)
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">VAT Type</label>
                                    <input type="text" class="form-control" value="{{ $payment->spay_vatable_type }}" readonly>
                                </div>

                                @if ($payment->spay_vatable_type == 'PERCENTAGE')
                                    <div class="col-md-4 mb-3">
                                        <label class="font-weight-bold">VAT Percentage</label>
                                        <input type="text" class="form-control" value="{{ $payment->spay_vatable_percentage }}%" readonly>
                                    </div>
                                @endif

                                <div class="col-md-4 mb-3">
                                    <label class="font-weight-bold">VAT Amount</label>
                                    <input type="text" class="form-control" value="₱{{ number_format($payment->spay_vatable_amount, 2) }}" readonly>
                                </div>
                            </div>
                        @endif

                        {{-- Proof of Payment --}}
                        @if (!empty($payment->spay_image_proof))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Proof of Payment</label>
                                    <div>
                                        <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                            target="_blank"
                                            style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                alt="Proof of Payment"
                                                style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if(!empty($payment->spay_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Client Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Approved By</label>
                                <input type="text" class="form-control" value="{{ $payment->approved_first_name }} {{ $payment->approved_last_name }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Date Approved</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date_approved)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        @if(!empty($payment->spay_admin_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Approve Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_admin_details ?? '' }}</textarea>
                                </div>
                            </div>
                        @endif
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    @foreach ($paymentsVoided as $payment)
        {{-- Voided Payment Modal --}}
        <div class="modal fade" id="voidedPaymentModal-{{ $payment->spay_id }}" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            Voided Payment - SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Receipt Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_receipt_number }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Payment Date</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Payment Type</label>
                                <select class="form-control" readonly>
                                    @forelse ($paymentTypes as $type)
                                        <option value="{{ $type->typ_id }}"
                                            {{ $payment->typ_id == $type->typ_id ? 'selected' : '' }}>
                                            {{ $type->typ_name }}
                                        </option>
                                    @empty
                                        <option value="">No payment types available</option>
                                    @endforelse
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Reference Number</label>
                                <input type="text" class="form-control" value="{{ $payment->spay_reference_number }}" readonly>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="font-weight-bold">Amount <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control"
                                    value="{{ $payment->spay_final_amount }}" readonly>
                            </div>
                        </div>

                        {{-- Proof of Payment --}}
                        @if (!empty($payment->spay_image_proof))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Proof of Payment</label>
                                    <div>
                                        <a href="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                            target="_blank"
                                            style="display:block; width:100%; padding-top:60%; position:relative; border:1px solid #dee2e6; border-radius:4px;">
                                            <img src="{{ asset('images/proof_payment_images/' . $payment->spay_image_proof) }}"
                                                alt="Proof of Payment"
                                                style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover;">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if(!empty($payment->spay_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Client Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_details ?? '-' }}</textarea>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Approved By</label>
                                <input type="text" class="form-control" value="{{ $payment->approved_first_name }} {{ $payment->approved_last_name }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Date Approved</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date_approved)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        @if(!empty($payment->spay_admin_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Approve Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_admin_details ?? '' }}</textarea>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Voided By</label>
                                <input type="text" class="form-control" value="{{ $payment->voided_first_name }} {{ $payment->voided_last_name }}" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Date Voided</label>
                                <input type="text" class="form-control"
                                    value="{{ \Carbon\Carbon::parse($payment->spay_date_voided)->format('m/d/Y') }}" readonly>
                            </div>
                        </div>

                        @if(!empty($payment->spay_void_details))
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="font-weight-bold">Void Details</label>
                                    <textarea class="form-control" rows="3" readonly>{{ $payment->spay_void_details ?? '' }}</textarea>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    <script>
        function printDefault() {
            window.print();
        }
    </script>
@endsection