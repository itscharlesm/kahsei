@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">My Service Orders Report</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\ClientController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Reports</li>
                        <li class="breadcrumb-item active">Service Orders</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">

                    {{-- Filter Form --}}
                    <form id="clientFilterForm" action="{{ url('client/reports/client/filter') }}" method="POST">
                        @csrf
                        <div class="row align-items-end no-print">

                            <div class="col-md-2 form-group">
                                <label>Filter Type</label>
                                <select name="filter_type" id="filter_type" class="form-control"
                                    onchange="toggleFilterInputs()">
                                    <option value="daily" {{ $filter_type == 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="date_range" {{ $filter_type == 'date_range' ? 'selected' : '' }}>Date Range
                                    </option>
                                    <option value="weekly" {{ $filter_type == 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ $filter_type == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ $filter_type == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-daily">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" value="{{ $date }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>From</label>
                                <input type="date" name="date_from" class="form-control" value="{{ $date_from }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>To</label>
                                <input type="date" name="date_to" class="form-control" value="{{ $date_to }}">
                            </div>

                            <div class="col-md-2 form-group filter-weekly" style="display:none;">
                                <label>Week</label>
                                <input type="week" name="week" class="form-control" value="{{ $week }}">
                            </div>

                            <div class="col-md-2 form-group filter-monthly" style="display:none;">
                                <label>Month</label>
                                <select name="month" class="form-control">
                                    @for ($m = 1; $m <= 12; $m++)
                                        <option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>
                                            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                                        </option>
                                    @endfor
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-monthly filter-yearly" style="display:none;">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" value="{{ $year }}">
                            </div>

                            <div class="col-md-2 form-group">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter"></i> Apply Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="row mb-2 no-print">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm" onclick="exportToExcel('searchTable')">
                                <i class="fa fa-file-excel"></i> Export Excel
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="printReport()">
                                <i class="fa fa-print"></i> Print
                            </button>
                        </div>
                    </div>

                    <hr>

                    <div class="card printable-area">
                        <div class="card-body overflow-auto">

                            {{-- Print Header --}}
                            <div class="row mb-3">
                                <div class="col-md-12 text-center">
                                    <h4><strong>My Service Orders Report</strong></h4>

                                    @if ($filtered)
                                    <div class="row mb-2">
                                        <div class="col-md-4 text-center summary-filter">
                                            <strong>Filter Used:</strong>
                                            @if ($filter_type == 'daily')
                                                Daily ({{ \Carbon\Carbon::parse($date)->format('F d, Y') }})
                                            @elseif ($filter_type == 'date_range')
                                                Date Range ({{ \Carbon\Carbon::parse($date_from)->format('F d, Y') }} -
                                                {{ \Carbon\Carbon::parse($date_to)->format('F d, Y') }})
                                            @elseif ($filter_type == 'weekly')
                                                @php
                                                    [$year, $weekNumber] = explode('-W', $week);

                                                    $startOfWeek = \Carbon\Carbon::now()
                                                        ->setISODate($year, $weekNumber)
                                                        ->startOfWeek();

                                                    $endOfWeek = (clone $startOfWeek)
                                                        ->endOfWeek();
                                                @endphp

                                                Weekly ({{ $startOfWeek->format('F d, Y') }} - {{ $endOfWeek->format('F d, Y') }})
                                            @elseif ($filter_type == 'monthly')
                                                Monthly ({{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }})
                                            @elseif ($filter_type == 'yearly')
                                                Yearly ({{ $year }})
                                            @endif
                                        </div>

                                        <div class="col-md-4 text-center summary-total-orders">
                                            <strong>Total Service Orders:</strong> {{ $totalServiceOrders }}
                                        </div>

                                        <div class="col-md-4 text-center summary-active-orders">
                                            <strong>Active Service Orders:</strong> {{ $totalActiveOrders }}
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-md-4 text-center summary-deleted-orders">
                                            <strong>Deleted Service Orders:</strong> {{ $totalDeletedOrders }}
                                        </div>
                                        <div class="col-md-4 text-center summary-total-pests">
                                            <strong>Total Pests Captured:</strong> {{ $totalPestsCaptured }}
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-md-2 text-center summary-total-rats">
                                            <strong>Rats:</strong> {{ $totalRats }}
                                        </div>
                                        <div class="col-md-2 text-center summary-total-snakes">
                                            <strong>Snakes:</strong> {{ $totalSnakes }}
                                        </div>
                                        <div class="col-md-2 text-center summary-total-lizard">
                                            <strong>Lizard:</strong> {{ $totalLizard }}
                                        </div>
                                        <div class="col-md-2 text-center summary-total-kittens">
                                            <strong>Kittens:</strong> {{ $totalKittens }}
                                        </div>
                                        <div class="col-md-2 text-center summary-total-others">
                                            <strong>Others:</strong> {{ $totalOthers }}
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="searchTable" class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">No.</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Appointment Date</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">SA Number</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Rats</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Snakes</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Lizard</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Kittens</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Others</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 12px">Appointment Status</th>
                                                <th style="text-align: center; width: 80px" class="no-print">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($services as $index => $service)
                                                <tr>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">
                                                        {{ $index + 1 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">
                                                        {{ $service->svca_approved_date ? \Carbon\Carbon::parse($service->svca_approved_date)->format('m-d-Y') : '-' }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">
                                                        SA-{{ str_pad($service->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">{{ $service->svc_rat_captured ?? 0 }}</td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">{{ $service->svc_snake_captured ?? 0 }}</td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">{{ $service->svc_lizard_captured ?? 0 }}</td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">{{ $service->svc_kitten_captured ?? 0 }}</td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">{{ $service->svc_other_captured ?? 0 }}</td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px">
                                                        {{ strtoupper($service->svc_status ?? '-') }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 12px" class="no-print">
                                                        <a class="btn btn-dark btn-sm"
                                                            href="{{ url('client/service/order/payment/view', $service->svc_id) }}">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="10" style="text-align: center;">No service order records found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection

<script>
    function toggleFilterInputs() {
        let type = document.getElementById('filter_type').value;
        document.querySelectorAll('.filter-daily, .filter-date_range, .filter-weekly, .filter-monthly, .filter-yearly')
            .forEach(el => el.style.display = 'none');

        if (type === 'daily') document.querySelectorAll('.filter-daily').forEach(el => el.style.display = 'block');
        if (type === 'date_range') document.querySelectorAll('.filter-date_range').forEach(el => el.style.display = 'block');
        if (type === 'weekly') document.querySelectorAll('.filter-weekly').forEach(el => el.style.display = 'block');
        if (type === 'monthly') document.querySelectorAll('.filter-monthly').forEach(el => el.style.display = 'block');
        if (type === 'yearly') document.querySelectorAll('.filter-yearly').forEach(el => el.style.display = 'block');
    }
    toggleFilterInputs(); // on page load
</script>

<script>
    function printReport() {
        window.print();
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    function exportToExcel(tableId) {
        let table = document.getElementById(tableId);
        if (!table) {
            console.error('exportToExcel: table not found:', tableId);
            return;
        }

        let filterUsed = document.querySelector('.printable-area .summary-filter')?.innerText.trim() || '';
        let totalOrders = document.querySelector('.printable-area .summary-total-orders')?.innerText.trim() || '';
        let activeOrders = document.querySelector('.printable-area .summary-active-orders')?.innerText.trim() || '';
        let deletedOrders = document.querySelector('.printable-area .summary-deleted-orders')?.innerText.trim() || '';
        let totalPests = document.querySelector('.printable-area .summary-total-pests')?.innerText.trim() || '';
        let totalRats = document.querySelector('.printable-area .summary-total-rats')?.innerText.trim() || '';
        let totalSnakes = document.querySelector('.printable-area .summary-total-snakes')?.innerText.trim() || '';
        let totalLizard = document.querySelector('.printable-area .summary-total-lizard')?.innerText.trim() || '';
        let totalKittens = document.querySelector('.printable-area .summary-total-kittens')?.innerText.trim() || '';
        let totalOthers = document.querySelector('.printable-area .summary-total-others')?.innerText.trim() || '';

        let tableData = [];

        let headerCells = table.querySelectorAll('thead tr th');
        let headers = [];
        headerCells.forEach((th, i) => {
            if (i < headerCells.length - 1) headers.push(th.innerText.trim());
        });
        tableData.push(headers);

        let bodyRows = table.querySelectorAll('tbody tr');
        bodyRows.forEach(row => {
            let cells = row.querySelectorAll('td');
            if (cells.length <= 1) return;
            let rowData = [];
            cells.forEach((td, i) => {
                if (i < cells.length - 1) rowData.push(td.innerText.trim());
            });
            tableData.push(rowData);
        });

        let sheetData = [
            [],
            ['My Service Orders Report'],
            [filterUsed, totalOrders, activeOrders, deletedOrders],
            [totalPests, totalRats, totalSnakes, totalLizard, totalKittens, totalOthers],
            [],
            ...tableData
        ];

        let ws = XLSX.utils.aoa_to_sheet(sheetData);
        let wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Service Orders');

        XLSX.writeFile(wb, 'My_Service_Orders_Report_' + new Date().toISOString().slice(0,10) + '.xlsx');
    }
</script>