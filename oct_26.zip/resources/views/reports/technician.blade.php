@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Technician Report</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Reports</li>
                        <li class="breadcrumb-item active">Technician</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">

                    {{-- Filter Form --}}
                    <form id="technicianFilterForm" action="{{ url('reports/technician/filter') }}" method="POST">
                        @csrf
                        <div class="row align-items-end no-print">

                            <div class="col-md-2 form-group">
                                <label>Filter Type</label>
                                <select name="filter_type" id="filter_type" class="form-control"
                                    onchange="toggleFilterInputs()">
                                    <option value="daily" {{ $filter_type == 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="date_range" {{ $filter_type == 'date_range' ? 'selected' : '' }}>Date Range
                                    </option>
                                    <option value="weekly" {{ $filter_type == 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ $filter_type == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ $filter_type == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-daily">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" value="{{ $date }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>From</label>
                                <input type="date" name="date_from" class="form-control" value="{{ $date_from }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>To</label>
                                <input type="date" name="date_to" class="form-control" value="{{ $date_to }}">
                            </div>

                            <div class="col-md-2 form-group filter-weekly" style="display:none;">
                                <label>Week</label>
                                <input type="week" name="week" class="form-control" value="{{ $week }}">
                            </div>

                            <div class="col-md-2 form-group filter-monthly" style="display:none;">
                                <label>Month</label>
                                <select name="month" class="form-control">
                                    @for ($m = 1; $m <= 12; $m++)
                                        <option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>
                                            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                                        </option>
                                    @endfor
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-monthly filter-yearly" style="display:none;">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" value="{{ $year }}">
                            </div>

                            @if (session('branch_id') == 1)
                                <div class="col-md-2 form-group">
                                    <label>Branch</label>
                                    <select name="branch_id" class="form-control">
                                        <option value="">All Branches</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->branch_id }}" {{ request('branch_id') == $branch->branch_id ? 'selected' : '' }}>
                                                {{ strtoupper($branch->branch_name) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif

                            <div class="col-md-2 form-group">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter"></i> Apply Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="row mb-2 no-print">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm" onclick="exportToExcel('searchTable')">
                                <i class="fa fa-file-excel"></i> Export Excel
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="printReport()">
                                <i class="fa fa-print"></i> Print
                            </button>
                        </div>
                    </div>

                    <hr>

                    <div class="card printable-area">
                        <div class="card-body overflow-auto">

                            {{-- Print Header --}}
                            <div class="row mb-3">
                                <div class="col-md-12 text-center">
                                    <h4><strong>Technician Report</strong></h4>

                                    @if ($filtered)
                                        <div class="row mb-2">
                                            <div class="col-md-6 text-center">
                                                <strong>Filter Used:</strong>
                                                <span id="filterUsedText">
                                                @if ($filter_type == 'daily')
                                                    Daily ({{ \Carbon\Carbon::parse($date)->format('F d, Y') }})
                                                @elseif ($filter_type == 'date_range')
                                                    Date Range ({{ \Carbon\Carbon::parse($date_from)->format('F d, Y') }} -
                                                    {{ \Carbon\Carbon::parse($date_to)->format('F d, Y') }})
                                                @elseif ($filter_type == 'weekly')
                                                    @php
                                                        [$year, $weekNumber] = explode('-W', $week);

                                                        $startOfWeek = \Carbon\Carbon::now()
                                                            ->setISODate($year, $weekNumber)
                                                            ->startOfWeek();

                                                        $endOfWeek = (clone $startOfWeek)->endOfWeek();
                                                    @endphp

                                                    Weekly ({{ $startOfWeek->format('F d, Y') }} - {{ $endOfWeek->format('F d, Y') }})
                                                @elseif ($filter_type == 'monthly')
                                                    Monthly ({{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }})
                                                @elseif ($filter_type == 'yearly')
                                                    Yearly ({{ $year }})
                                                @endif
                                                </span>
                                            </div>

                                            <div class="col-md-6 text-center">
                                                <strong>Branch:</strong>
                                                <span id="branchText">{{ $selectedBranch ? strtoupper($selectedBranch->branch_name) : 'All Branches' }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-2 text-center">
                                                <strong>1 (Lowest):</strong> <span id="totalRating1">{{ $totalRating1 }}</span>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <strong>2:</strong> <span id="totalRating2">{{ $totalRating2 }}</span>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <strong>3 (Middle):</strong> <span id="totalRating3">{{ $totalRating3 }}</span>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <strong>4:</strong> <span id="totalRating4">{{ $totalRating4 }}</span>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <strong>5 (Highest):</strong> <span id="totalRating5">{{ $totalRating5 }}</span>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <strong>Avg. Satisfaction:</strong> <span id="overallAvgRating">{{ $overallAvgRating !== null ? number_format($overallAvgRating, 2) : 'N/A' }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-4 text-center">
                                                <strong>Total Completed Jobs:</strong> <span id="totalCompleted">{{ $totalCompleted }}</span>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <strong>Total Assigned Jobs:</strong> <span id="totalAssigned">{{ $totalAssigned }}</span>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <strong>Total Jobs:</strong> <span id="totalJobs">{{ $totalJobs }}</span>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="searchTable" class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center">No.</th>
                                                <th style="text-align: center">Technician</th>
                                                <th style="text-align: center">Assigned Jobs</th>
                                                <th style="text-align: center">Completed Jobs</th>
                                                <th style="text-align: center">Total Jobs</th>
                                                <th style="text-align: center">1</th>
                                                <th style="text-align: center">2</th>
                                                <th style="text-align: center">3</th>
                                                <th style="text-align: center">4</th>
                                                <th style="text-align: center">5</th>
                                                <th style="text-align: center">Average Customer Satisfaction</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($technicians as $index => $technician)
                                                <tr>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $index + 1 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->usr_last_name }}, {{ $technician->usr_first_name }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->assigned_jobs }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->completed_jobs }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->completed_jobs + $technician->assigned_jobs }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->rating_1 ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->rating_2 ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->rating_3 ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->rating_4 ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->rating_5 ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $technician->avg_rating !== null ? number_format($technician->avg_rating, 2) : 'N/A' }}
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="11" style="text-align: center;">No technician job records found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection

<script>
    function toggleFilterInputs() {
        let type = document.getElementById('filter_type').value;
        document.querySelectorAll('.filter-daily, .filter-date_range, .filter-weekly, .filter-monthly, .filter-yearly')
            .forEach(el => el.style.display = 'none');

        if (type === 'daily') document.querySelectorAll('.filter-daily').forEach(el => el.style.display = 'block');
        if (type === 'date_range') document.querySelectorAll('.filter-date_range').forEach(el => el.style.display = 'block');
        if (type === 'weekly') document.querySelectorAll('.filter-weekly').forEach(el => el.style.display = 'block');
        if (type === 'monthly') document.querySelectorAll('.filter-monthly').forEach(el => el.style.display = 'block');
        if (type === 'yearly') document.querySelectorAll('.filter-yearly').forEach(el => el.style.display = 'block');
    }
    toggleFilterInputs(); // on page load
</script>

<script>
    function printReport() {
        window.print();
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    function exportToExcel(tableId) {
        let table = document.getElementById(tableId);
        if (!table) return;

        let filterUsed = document.getElementById('filterUsedText')?.innerText.trim() || '';
        let branch = document.getElementById('branchText')?.innerText.trim() || '';

        let totalCompleted = document.getElementById('totalCompleted')?.innerText.trim() || '0';
        let totalAssigned = document.getElementById('totalAssigned')?.innerText.trim() || '0';
        let totalJobs = document.getElementById('totalJobs')?.innerText.trim() || '0';

        let totalRating1 = document.getElementById('totalRating1')?.innerText.trim() || '0';
        let totalRating2 = document.getElementById('totalRating2')?.innerText.trim() || '0';
        let totalRating3 = document.getElementById('totalRating3')?.innerText.trim() || '0';
        let totalRating4 = document.getElementById('totalRating4')?.innerText.trim() || '0';
        let totalRating5 = document.getElementById('totalRating5')?.innerText.trim() || '0';
        let overallAvgRating = document.getElementById('overallAvgRating')?.innerText.trim() || 'N/A';

        let tableData = [];

        let headerCells = table.querySelectorAll('thead tr th');
        let headers = [];
        headerCells.forEach((th) => headers.push(th.innerText.trim()));
        tableData.push(headers);

        let bodyRows = table.querySelectorAll('tbody tr');
        bodyRows.forEach(row => {
            let cells = row.querySelectorAll('td');
            if (cells.length <= 1) return; // skip "No records found" row
            let rowData = [];
            cells.forEach((td) => rowData.push(td.innerText.trim()));
            tableData.push(rowData);
        });

        let sheetData = [
            [], // Row 1 - blank
            ['Technician Report'], // Row 2 - title
            ['Filter Used:', filterUsed, 'Branch:', branch], // Row 3 - filter/branch
            ['1 (Lowest):', totalRating1, '2:', totalRating2, '3 (Middle):', totalRating3, '4:', totalRating4, '5 (Highest):', totalRating5, 'Avg. Satisfaction:', overallAvgRating], // Row 4 - rating tally
            ['Total Completed Jobs:', totalCompleted, 'Total Assigned Jobs:', totalAssigned, 'Total Jobs:', totalJobs], // Row 5
            [], // Row 6 - blank
            ...tableData // Row 6+ - table
        ];

        let ws = XLSX.utils.aoa_to_sheet(sheetData);
        let wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Technician Report');

        XLSX.writeFile(wb, 'Technician_Report_' + new Date().toISOString().slice(0,10) + '.xlsx');
    }
</script>