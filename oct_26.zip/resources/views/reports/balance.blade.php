@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Balance Report</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Reports</li>
                        <li class="breadcrumb-item active">Balance</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">

                    {{-- Filter Form --}}
                    <form id="balanceFilterForm" action="{{ url('reports/balance/filter') }}" method="POST">
                        @csrf
                        <div class="row align-items-end no-print">

                            <div class="col-md-2 form-group">
                                <label>Filter Type</label>
                                <select name="filter_type" id="filter_type" class="form-control"
                                    onchange="toggleFilterInputs()">
                                    <option value="daily" {{ $filter_type == 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="date_range" {{ $filter_type == 'date_range' ? 'selected' : '' }}>Date Range
                                    </option>
                                    <option value="weekly" {{ $filter_type == 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ $filter_type == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ $filter_type == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-daily">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" value="{{ $date }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>From</label>
                                <input type="date" name="date_from" class="form-control" value="{{ $date_from }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>To</label>
                                <input type="date" name="date_to" class="form-control" value="{{ $date_to }}">
                            </div>

                            <div class="col-md-2 form-group filter-weekly" style="display:none;">
                                <label>Week</label>
                                <input type="week" name="week" class="form-control" value="{{ $week }}">
                            </div>

                            <div class="col-md-2 form-group filter-monthly" style="display:none;">
                                <label>Month</label>
                                <select name="month" class="form-control">
                                    @for ($m = 1; $m <= 12; $m++)
                                        <option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>
                                            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                                        </option>
                                    @endfor
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-monthly filter-yearly" style="display:none;">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" value="{{ $year }}">
                            </div>

                            @if (session('branch_id') == 1)
                                <div class="col-md-2 form-group">
                                    <label>Branch</label>
                                    <select name="branch_id" class="form-control">
                                        <option value="">All Branches</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->branch_id }}" {{ request('branch_id') == $branch->branch_id ? 'selected' : '' }}>
                                                {{ strtoupper($branch->branch_name) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif

                            <div class="col-md-2 form-group">
                                <label>Payment Status</label>
                                <select name="svc_payment_status" class="form-control">
                                    <option value="">All Statuses</option>
                                    @foreach ($paymentStatuses as $status)
                                        <option value="{{ $status }}" {{ request('svc_payment_status') == $status ? 'selected' : '' }}>
                                            {{ strtoupper($status) }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-2 form-group">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter"></i> Apply Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="row mb-2 no-print">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm" onclick="exportToExcel('searchTable')">
                                <i class="fa fa-file-excel"></i> Export Excel
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="printReport()">
                                <i class="fa fa-print"></i> Print
                            </button>
                        </div>
                    </div>

                    <hr>

                    <div class="card printable-area">
                        <div class="card-body overflow-auto">

                            {{-- Print Header --}}
                            <div class="row mb-3">
                                <div class="col-md-12 text-center">
                                    <h4><strong>Balance Report</strong></h4>

                                    @if ($filtered)
                                    <div class="row mb-2">
                                        <div class="col-md-3 text-center summary-filter">
                                            <strong>Filter Used:</strong>
                                            @if ($filter_type == 'daily')
                                                Daily ({{ \Carbon\Carbon::parse($date)->format('F d, Y') }})
                                            @elseif ($filter_type == 'date_range')
                                                Date Range ({{ \Carbon\Carbon::parse($date_from)->format('F d, Y') }} -
                                                {{ \Carbon\Carbon::parse($date_to)->format('F d, Y') }})
                                            @elseif ($filter_type == 'weekly')
                                                @php
                                                    [$year, $weekNumber] = explode('-W', $week);

                                                    $startOfWeek = \Carbon\Carbon::now()
                                                        ->setISODate($year, $weekNumber)
                                                        ->startOfWeek();

                                                    $endOfWeek = (clone $startOfWeek)
                                                        ->endOfWeek();
                                                @endphp

                                                Weekly ({{ $startOfWeek->format('F d, Y') }} - {{ $endOfWeek->format('F d, Y') }})
                                            @elseif ($filter_type == 'monthly')
                                                Monthly ({{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }})
                                            @elseif ($filter_type == 'yearly')
                                                Yearly ({{ $year }})
                                            @endif
                                        </div>

                                        <div class="col-md-3 text-center summary-branch">
                                            <strong>Branch:</strong> {{ $selectedBranch ? strtoupper($selectedBranch->branch_name) : 'All Branches' }}
                                        </div>

                                        <div class="col-md-3 text-center summary-status">
                                            <strong>Payment Status:</strong>
                                            {{ request('svc_payment_status') ? strtoupper(request('svc_payment_status')) : 'All Statuses' }}
                                        </div>

                                        <div class="col-md-3 text-center summary-total-balance">
                                            <strong>Total Balance:</strong> ₱{{ number_format($totalBalance, 2) }}
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-md-3 text-center summary-total-fixed">
                                            <strong>Total Fixed Price:</strong> ₱{{ number_format($totalFixedPrice, 2) }}
                                        </div>
                                        <div class="col-md-3 text-center summary-total-final">
                                            <strong>Total Final Price:</strong> ₱{{ number_format($totalFinalPrice, 2) }}
                                        </div>
                                        <div class="col-md-3 text-center summary-total-collected">
                                            <strong>Total Amount Collected:</strong> ₱{{ number_format($totalCollected, 2) }}
                                        </div>
                                        <div class="col-md-3 text-center summary-total-discount">
                                            <strong>Total Discount Given:</strong> ₱{{ number_format($totalDiscount, 2) }}
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                        <div class="col-md-3 text-center summary-collection-rate">
                                            <strong>Collection Rate:</strong> {{ number_format($collectionRate, 2) }}%
                                        </div>
                                        <div class="col-md-3 text-center summary-record-count">
                                            <strong>Total Records:</strong> {{ $recordCount }}
                                        </div>
                                        <div class="col-md-3 text-center summary-outstanding-count">
                                            <strong>Accounts With Balance:</strong> {{ $outstandingCount }}
                                        </div>
                                        <div class="col-md-3 text-center summary-fullypaid-count">
                                            <strong>Fully Paid Accounts:</strong> {{ $fullyPaidCount }}
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="searchTable" class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">No.</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Appointment Date</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">SA Number</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Client Name</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Payment Status</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Fixed Price</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Final Price</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Balance</th>
                                                <th style="text-align: center; vertical-align: middle; font-size: 13px">Appointment Status</th>
                                                <th style="text-align: center; width: 80px" class="no-print">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($services as $index => $service)
                                                <tr>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        {{ $index + 1 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        {{ $service->svca_approved_date ? \Carbon\Carbon::parse($service->svca_approved_date)->format('m-d-Y') : '-' }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        SA-{{ str_pad($service->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        {{ strtoupper(trim(($service->usr_first_name ?? '') . ' ' . ($service->usr_last_name ?? ''))) ?: '-' }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        {{ strtoupper($service->svc_payment_status ?? '-') }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        ₱{{ number_format($service->svc_fixed_price ?? 0, 2) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        ₱{{ number_format($service->svc_final_price ?? 0, 2) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        ₱{{ number_format($service->svc_balance ?? 0, 2) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px">
                                                        {{ strtoupper($service->svc_status ?? '-') }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle; font-size: 13px" class="no-print">
                                                        <a class="btn btn-dark btn-sm"
                                                            href="{{ url('service/order/payment/view', $service->svc_id) }}">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="10" style="text-align: center;">No balance records found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection

<script>
    function toggleFilterInputs() {
        let type = document.getElementById('filter_type').value;
        document.querySelectorAll('.filter-daily, .filter-date_range, .filter-weekly, .filter-monthly, .filter-yearly')
            .forEach(el => el.style.display = 'none');

        if (type === 'daily') document.querySelectorAll('.filter-daily').forEach(el => el.style.display = 'block');
        if (type === 'date_range') document.querySelectorAll('.filter-date_range').forEach(el => el.style.display = 'block');
        if (type === 'weekly') document.querySelectorAll('.filter-weekly').forEach(el => el.style.display = 'block');
        if (type === 'monthly') document.querySelectorAll('.filter-monthly').forEach(el => el.style.display = 'block');
        if (type === 'yearly') document.querySelectorAll('.filter-yearly').forEach(el => el.style.display = 'block');
    }
    toggleFilterInputs(); // on page load
</script>

<script>
    function printReport() {
        window.print();
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    function exportToExcel(tableId) {
        let table = document.getElementById(tableId);
        if (!table) return;

        let filterUsed = document.querySelector('.printable-area .summary-filter')?.innerText.trim() || '';
        let branch = document.querySelector('.printable-area .summary-branch')?.innerText.trim() || '';
        let status = document.querySelector('.printable-area .summary-status')?.innerText.trim() || '';
        let totalBalance = document.querySelector('.printable-area .summary-total-balance')?.innerText.trim() || '';
        let totalFixed = document.querySelector('.printable-area .summary-total-fixed')?.innerText.trim() || '';
        let totalFinal = document.querySelector('.printable-area .summary-total-final')?.innerText.trim() || '';
        let totalCollected = document.querySelector('.printable-area .summary-total-collected')?.innerText.trim() || '';
        let totalDiscount = document.querySelector('.printable-area .summary-total-discount')?.innerText.trim() || '';
        let collectionRate = document.querySelector('.printable-area .summary-collection-rate')?.innerText.trim() || '';
        let recordCount = document.querySelector('.printable-area .summary-record-count')?.innerText.trim() || '';
        let outstandingCount = document.querySelector('.printable-area .summary-outstanding-count')?.innerText.trim() || '';
        let fullyPaidCount = document.querySelector('.printable-area .summary-fullypaid-count')?.innerText.trim() || '';

        let tableData = [];

        let headerCells = table.querySelectorAll('thead tr th');
        let headers = [];
        headerCells.forEach((th, i) => {
            if (i < headerCells.length - 1) headers.push(th.innerText.trim());
        });
        tableData.push(headers);

        let bodyRows = table.querySelectorAll('tbody tr');
        bodyRows.forEach(row => {
            let cells = row.querySelectorAll('td');
            if (cells.length <= 1) return;
            let rowData = [];
            cells.forEach((td, i) => {
                if (i < cells.length - 1) rowData.push(td.innerText.trim());
            });
            tableData.push(rowData);
        });

        let sheetData = [
            [],
            ['Balance Report'],
            [filterUsed, branch, status, totalBalance],
            [totalFixed, totalFinal, totalCollected, totalDiscount],
            [collectionRate, recordCount, outstandingCount, fullyPaidCount],
            [],
            ...tableData
        ];

        let ws = XLSX.utils.aoa_to_sheet(sheetData);
        let wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Balance Report');

        XLSX.writeFile(wb, 'Balance_Report_' + new Date().toISOString().slice(0,10) + '.xlsx');
    }
</script>