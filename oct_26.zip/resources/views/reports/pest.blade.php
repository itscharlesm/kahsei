@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Pest Captured Report</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Reports</li>
                        <li class="breadcrumb-item active">Pest Captured</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">

                    {{-- Filter Form --}}
                    <form id="pestFilterForm" action="{{ url('reports/pest/captured/filter') }}" method="POST">
                        @csrf
                        <div class="row align-items-end no-print">

                            <div class="col-md-2 form-group">
                                <label>Filter Type</label>
                                <select name="filter_type" id="filter_type" class="form-control"
                                    onchange="toggleFilterInputs()">
                                    <option value="daily" {{ $filter_type == 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="date_range" {{ $filter_type == 'date_range' ? 'selected' : '' }}>Date Range
                                    </option>
                                    <option value="weekly" {{ $filter_type == 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ $filter_type == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ $filter_type == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-daily">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" value="{{ $date }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>From</label>
                                <input type="date" name="date_from" class="form-control" value="{{ $date_from }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>To</label>
                                <input type="date" name="date_to" class="form-control" value="{{ $date_to }}">
                            </div>

                            <div class="col-md-2 form-group filter-weekly" style="display:none;">
                                <label>Week</label>
                                <input type="week" name="week" class="form-control" value="{{ $week }}">
                            </div>

                            <div class="col-md-2 form-group filter-monthly" style="display:none;">
                                <label>Month</label>
                                <select name="month" class="form-control">
                                    @for ($m = 1; $m <= 12; $m++)
                                        <option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>
                                            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                                        </option>
                                    @endfor
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-monthly filter-yearly" style="display:none;">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" value="{{ $year }}">
                            </div>

                            @if (session('branch_id') == 1)
                                <div class="col-md-2 form-group">
                                    <label>Branch</label>
                                    <select name="branch_id" class="form-control">
                                        <option value="">All Branches</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->branch_id }}" {{ request('branch_id') == $branch->branch_id ? 'selected' : '' }}>
                                                {{ strtoupper($branch->branch_name) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif

                            <div class="col-md-2 form-group">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter"></i> Apply Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="row mb-2 no-print">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm" onclick="exportToExcel('searchTable')">
                                <i class="fa fa-file-excel"></i> Export Excel
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="printReport()">
                                <i class="fa fa-print"></i> Print
                            </button>
                        </div>
                    </div>

                    <hr>

                    <div class="card printable-area">
                        <div class="card-body overflow-auto">

                            {{-- Print Header --}}
                            <div class="row mb-3">
                                <div class="col-md-12 text-center">
                                    <h4><strong>Pest Captured Report</strong></h4>

                                    @if ($filtered)
                                        <div class="row mb-2">
                                            <div class="col-md-6 text-center">
                                                <strong>Filter Used:</strong>
                                                <span id="filterUsedText">
                                                @if ($filter_type == 'daily')
                                                    Daily ({{ \Carbon\Carbon::parse($date)->format('F d, Y') }})
                                                @elseif ($filter_type == 'date_range')
                                                    Date Range ({{ \Carbon\Carbon::parse($date_from)->format('F d, Y') }} -
                                                    {{ \Carbon\Carbon::parse($date_to)->format('F d, Y') }})
                                                @elseif ($filter_type == 'weekly')
                                                    @php
                                                        [$year, $weekNumber] = explode('-W', $week);

                                                        $startOfWeek = \Carbon\Carbon::now()
                                                            ->setISODate($year, $weekNumber)
                                                            ->startOfWeek();

                                                        $endOfWeek = (clone $startOfWeek)->endOfWeek();
                                                    @endphp

                                                    Weekly ({{ $startOfWeek->format('F d, Y') }} - {{ $endOfWeek->format('F d, Y') }})
                                                @elseif ($filter_type == 'monthly')
                                                    Monthly ({{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }})
                                                @elseif ($filter_type == 'yearly')
                                                    Yearly ({{ $year }})
                                                @endif
                                                </span>
                                            </div>

                                            <div class="col-md-6 text-center">
                                                <strong>Branch:</strong>
                                                <span id="branchText">{{ $selectedBranch ? strtoupper($selectedBranch->branch_name) : 'All Branches' }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-4 text-center">
                                                <strong>Total Rats:</strong> <span id="totalRats">{{ $totalRats }}</span>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <strong>Total Snakes:</strong> <span id="totalSnakes">{{ $totalSnakes }}</span>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <strong>Total Lizard:</strong> <span id="totalLizard">{{ $totalLizard }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-6 text-center">
                                                <strong>Total Kittens:</strong> <span id="totalKittens">{{ $totalKittens }}</span>
                                            </div>
                                            <div class="col-md-6 text-center">
                                                <strong>Total Others:</strong> <span id="totalOthers">{{ $totalOthers }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-12 text-center">
                                                <strong>Total Pests:</strong> <span id="totalPests">{{ $totalPests }}</span>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="searchTable" class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center">No.</th>
                                                <th style="text-align: center">SA Number</th>
                                                <th style="text-align: center">Rats Captured</th>
                                                <th style="text-align: center">Snakes Captured</th>
                                                <th style="text-align: center">Lizard Captured</th>
                                                <th style="text-align: center">Kittens Captured</th>
                                                <th style="text-align: center">Others Captured</th>
                                                <th style="text-align: center; width: 80px" class="no-print">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($captures as $index => $capture)
                                                <tr>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $index + 1 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        SA-{{ str_pad($capture->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $capture->svc_rat_captured ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $capture->svc_snake_captured ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $capture->svc_lizard_captured ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $capture->svc_kitten_captured ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $capture->svc_other_captured ?? 0 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;" class="no-print">
                                                        <a class="btn btn-dark btn-sm"
                                                            href="{{ url('service/order/payment/view', $capture->svc_id) }}">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="8" style="text-align: center;">No pest capture records found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection

<script>
    function toggleFilterInputs() {
        let type = document.getElementById('filter_type').value;
        document.querySelectorAll('.filter-daily, .filter-date_range, .filter-weekly, .filter-monthly, .filter-yearly')
            .forEach(el => el.style.display = 'none');

        if (type === 'daily') document.querySelectorAll('.filter-daily').forEach(el => el.style.display = 'block');
        if (type === 'date_range') document.querySelectorAll('.filter-date_range').forEach(el => el.style.display = 'block');
        if (type === 'weekly') document.querySelectorAll('.filter-weekly').forEach(el => el.style.display = 'block');
        if (type === 'monthly') document.querySelectorAll('.filter-monthly').forEach(el => el.style.display = 'block');
        if (type === 'yearly') document.querySelectorAll('.filter-yearly').forEach(el => el.style.display = 'block');
    }
    toggleFilterInputs(); // on page load
</script>

<script>
    function printReport() {
        window.print();
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    function exportToExcel(tableId) {
        let table = document.getElementById(tableId);
        if (!table) return;

        let filterUsed = document.getElementById('filterUsedText')?.innerText.trim() || '';
        let branch = document.getElementById('branchText')?.innerText.trim() || '';

        let totalRats = document.getElementById('totalRats')?.innerText.trim() || '0';
        let totalSnakes = document.getElementById('totalSnakes')?.innerText.trim() || '0';
        let totalLizard = document.getElementById('totalLizard')?.innerText.trim() || '0';
        let totalKittens = document.getElementById('totalKittens')?.innerText.trim() || '0';
        let totalOthers = document.getElementById('totalOthers')?.innerText.trim() || '0';
        let totalPests = document.getElementById('totalPests')?.innerText.trim() || '0';

        // Build table data (skip "Action" column - last column)
        let tableData = [];

        let headerCells = table.querySelectorAll('thead tr th');
        let headers = [];
        headerCells.forEach((th, i) => {
            if (i < headerCells.length - 1) { // skip last (Action)
                headers.push(th.innerText.trim());
            }
        });
        tableData.push(headers);

        let bodyRows = table.querySelectorAll('tbody tr');
        bodyRows.forEach(row => {
            let cells = row.querySelectorAll('td');
            if (cells.length <= 1) return; // skip "No records found" row
            let rowData = [];
            cells.forEach((td, i) => {
                if (i < cells.length - 1) { // skip last (Action)
                    rowData.push(td.innerText.trim());
                }
            });
            tableData.push(rowData);
        });

        // Assemble full sheet with required blank rows
        let sheetData = [
            [], // Row 1 - blank
            ['Pest Captured Report'], // Row 2 - title
            ['Filter Used:', filterUsed, 'Branch:', branch], // Row 3 - filter/branch
            ['Total Rats:', totalRats, 'Total Snakes:', totalSnakes, 'Total Lizard:', totalLizard], // Row 4
            ['Total Kittens:', totalKittens, 'Total Others:', totalOthers, 'Total Pests:', totalPests], // Row 5
            [], // Row 6 - blank
            ...tableData // Row 7+ - table
        ];

        let ws = XLSX.utils.aoa_to_sheet(sheetData);
        let wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Pest Captured Report');

        XLSX.writeFile(wb, 'Pest_Captured_Report_' + new Date().toISOString().slice(0,10) + '.xlsx');
    }
</script>