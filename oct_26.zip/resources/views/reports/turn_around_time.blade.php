@extends('layouts.themes.main')

@php
    if (!function_exists('hmsToSeconds')) {
        function hmsToSeconds($value)
        {
            if (empty($value)) {
                return 0;
            }

            $parts = explode(':', $value);
            $hours = (int) ($parts[0] ?? 0);
            $minutes = (int) ($parts[1] ?? 0);
            $seconds = (int) ($parts[2] ?? 0);

            return ($hours * 3600) + ($minutes * 60) + $seconds;
        }
    }

    if (!function_exists('tat_format_duration')) {
        function tat_format_duration($seconds)
        {
            if ($seconds === null) {
                return 'N/A';
            }

            $seconds = abs($seconds);
            $hours = floor($seconds / 3600);
            $minutes = floor(($seconds % 3600) / 60);

            if ($hours == 0 && $minutes == 0) {
                return '0 min';
            } elseif ($hours > 0 && $minutes > 0) {
                return $hours . ' hr' . ($hours > 1 ? 's' : '') . ' and ' . $minutes . ' min' . ($minutes > 1 ? 's' : '');
            } elseif ($hours > 0) {
                return $hours . ' hr' . ($hours > 1 ? 's' : '');
            } else {
                return $minutes . ' min' . ($minutes > 1 ? 's' : '');
            }
        }
    }

    // Compute per-record seconds/variance/status, and build technician performance stats
    $techStats = [];

    foreach ($records as $row) {
        $travelSeconds = hmsToSeconds($row->svcas_time_travel);
        $totalSeconds = hmsToSeconds($row->svcas_time_finished);
        $serviceSeconds = max(0, $totalSeconds - $travelSeconds);

        $approvedFromSeconds = $row->svca_approved_time_from ? hmsToSeconds($row->svca_approved_time_from) : null;
        $approvedToSeconds = $row->svca_approved_time_to ? hmsToSeconds($row->svca_approved_time_to) : null;
        $approvedDurationSeconds = ($approvedFromSeconds !== null && $approvedToSeconds !== null)
            ? max(0, $approvedToSeconds - $approvedFromSeconds)
            : null;

        $row->travel_seconds = $travelSeconds;
        $row->service_seconds = $serviceSeconds;
        $row->total_seconds = $totalSeconds;
        $row->approved_duration_seconds = $approvedDurationSeconds;

        if ($approvedDurationSeconds !== null) {
            $row->variance_seconds = $totalSeconds - $approvedDurationSeconds;
            $row->tat_status = $row->variance_seconds <= 0 ? 'ON TIME' : 'DELAYED';
        } else {
            $row->variance_seconds = null;
            $row->tat_status = 'N/A';
        }

        foreach ($row->technicians as $t) {
            $key = $t->usr_id;

            if (!isset($techStats[$key])) {
                $techStats[$key] = [
                    'usr_id' => $t->usr_id,
                    'name' => $t->usr_last_name . ', ' . $t->usr_first_name,
                    'total' => 0,
                    'on_time' => 0,
                    'delayed' => 0,
                    'variance_sum' => 0,
                    'variance_count' => 0,
                ];
            }

            $techStats[$key]['total']++;
            if ($row->tat_status === 'ON TIME') {
                $techStats[$key]['on_time']++;
            } elseif ($row->tat_status === 'DELAYED') {
                $techStats[$key]['delayed']++;
            }

            if ($row->variance_seconds !== null) {
                $techStats[$key]['variance_sum'] += $row->variance_seconds;
                $techStats[$key]['variance_count']++;
            }
        }
    }

    $totalRecords = $records->count();
    $onTimeCount = $records->where('tat_status', 'ON TIME')->count();
    $delayedCount = $records->where('tat_status', 'DELAYED')->count();
    $onTimeRate = $totalRecords > 0 ? round(($onTimeCount / $totalRecords) * 100, 2) : 0;

    $varianceValues = $records->pluck('variance_seconds')->filter(fn($v) => $v !== null);
    $avgVarianceMinutes = $varianceValues->isNotEmpty() ? round(($varianceValues->avg()) / 60, 1) : null;

    $technicianPerformance = collect($techStats)->map(function ($t) {
        $t['on_time_rate'] = $t['total'] > 0 ? round(($t['on_time'] / $t['total']) * 100, 2) : 0;
        $t['avg_variance_minutes'] = $t['variance_count'] > 0
            ? round(($t['variance_sum'] / $t['variance_count']) / 60, 1)
            : null;
        return (object) $t;
    })->sortByDesc('on_time_rate')->values();
@endphp

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Turn Around Time Report</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Reports</li>
                        <li class="breadcrumb-item active">Turn Around Time</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">

                    {{-- Filter Form --}}
                    <form id="tatFilterForm" action="{{ url('reports/turn-around-time/filter') }}" method="POST">
                        @csrf
                        <div class="row align-items-end no-print">

                            <div class="col-md-2 form-group">
                                <label>Filter Type</label>
                                <select name="filter_type" id="filter_type" class="form-control"
                                    onchange="toggleFilterInputs()">
                                    <option value="daily" {{ $filter_type == 'daily' ? 'selected' : '' }}>Daily</option>
                                    <option value="date_range" {{ $filter_type == 'date_range' ? 'selected' : '' }}>Date Range
                                    </option>
                                    <option value="weekly" {{ $filter_type == 'weekly' ? 'selected' : '' }}>Weekly</option>
                                    <option value="monthly" {{ $filter_type == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="yearly" {{ $filter_type == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-daily">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" value="{{ $date }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>From</label>
                                <input type="date" name="date_from" class="form-control" value="{{ $date_from }}">
                            </div>

                            <div class="col-md-2 form-group filter-date_range" style="display:none;">
                                <label>To</label>
                                <input type="date" name="date_to" class="form-control" value="{{ $date_to }}">
                            </div>

                            <div class="col-md-2 form-group filter-weekly" style="display:none;">
                                <label>Week</label>
                                <input type="week" name="week" class="form-control" value="{{ $week }}">
                            </div>

                            <div class="col-md-2 form-group filter-monthly" style="display:none;">
                                <label>Month</label>
                                <select name="month" class="form-control">
                                    @for ($m = 1; $m <= 12; $m++)
                                        <option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>
                                            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                                        </option>
                                    @endfor
                                </select>
                            </div>

                            <div class="col-md-2 form-group filter-monthly filter-yearly" style="display:none;">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" value="{{ $year }}">
                            </div>

                            @if (session('branch_id') == 1)
                                <div class="col-md-2 form-group">
                                    <label>Branch</label>
                                    <select name="branch_id" class="form-control">
                                        <option value="">All Branches</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->branch_id }}" {{ request('branch_id') == $branch->branch_id ? 'selected' : '' }}>
                                                {{ strtoupper($branch->branch_name) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif

                            <div class="col-md-2 form-group">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter"></i> Apply Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="row mb-2 no-print">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm" onclick="exportToExcel('searchTable')">
                                <i class="fa fa-file-excel"></i> Export Excel
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="printReport()">
                                <i class="fa fa-print"></i> Print
                            </button>
                        </div>
                    </div>

                    <hr>

                    <div class="card printable-area">
                        <div class="card-body overflow-auto">

                            {{-- Print Header --}}
                            <div class="row mb-3">
                                <div class="col-md-12 text-center">
                                    <h4><strong>Turn Around Time Report</strong></h4>

                                    @if ($filtered)
                                        <div class="row mb-2">
                                            <div class="col-md-6 text-center">
                                                <strong>Filter Used:</strong>
                                                <span id="filterUsedText">
                                                @if ($filter_type == 'daily')
                                                    Daily ({{ \Carbon\Carbon::parse($date)->format('F d, Y') }})
                                                @elseif ($filter_type == 'date_range')
                                                    Date Range ({{ \Carbon\Carbon::parse($date_from)->format('F d, Y') }} -
                                                    {{ \Carbon\Carbon::parse($date_to)->format('F d, Y') }})
                                                @elseif ($filter_type == 'weekly')
                                                    @php
                                                        [$wYear, $weekNumber] = explode('-W', $week);

                                                        $startOfWeek = \Carbon\Carbon::now()
                                                            ->setISODate($wYear, $weekNumber)
                                                            ->startOfWeek();

                                                        $endOfWeek = (clone $startOfWeek)->endOfWeek();
                                                    @endphp

                                                    Weekly ({{ $startOfWeek->format('F d, Y') }} - {{ $endOfWeek->format('F d, Y') }})
                                                @elseif ($filter_type == 'monthly')
                                                    Monthly ({{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }})
                                                @elseif ($filter_type == 'yearly')
                                                    Yearly ({{ $year }})
                                                @endif
                                                </span>
                                            </div>

                                            <div class="col-md-6 text-center">
                                                <strong>Branch:</strong>
                                                <span id="branchText">{{ $selectedBranch ? strtoupper($selectedBranch->branch_name) : 'All Branches' }}</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-3 text-center">
                                                <strong>Total Jobs:</strong> <span id="totalRecords">{{ $totalRecords }}</span>
                                            </div>
                                            <div class="col-md-3 text-center">
                                                <strong>On Time:</strong>
                                                <span id="onTimeCount" class="text-success">{{ $onTimeCount }}</span>
                                            </div>
                                            <div class="col-md-3 text-center">
                                                <strong>Delayed:</strong>
                                                <span id="delayedCount" class="text-danger">{{ $delayedCount }}</span>
                                            </div>
                                            <div class="col-md-3 text-center">
                                                <strong>On-Time Rate:</strong> <span id="onTimeRate">{{ $onTimeRate }}%</span>
                                            </div>
                                        </div>

                                        <div class="row mb-2">
                                            <div class="col-md-12 text-center">
                                                <strong>Average Variance vs. Approved Window:</strong>
                                                <span id="avgVarianceMinutes">
                                                    @if ($avgVarianceMinutes === null)
                                                        N/A
                                                    @else
                                                        {{ $avgVarianceMinutes > 0 ? '+' : '' }}{{ $avgVarianceMinutes }} min
                                                        ({{ $avgVarianceMinutes > 0 ? 'running late on average' : 'ahead of schedule on average' }})
                                                    @endif
                                                </span>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="searchTable" class="table table-bordered table-sm">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center">No.</th>
                                                <th style="text-align: center">SA Number</th>
                                                <th style="text-align: center">Technician(s)</th>
                                                <th style="text-align: center">Approved Window</th>
                                                <th style="text-align: center">Approved Duration</th>
                                                <th style="text-align: center">Travel Time</th>
                                                <th style="text-align: center">Service Time</th>
                                                <th style="text-align: center">Total Time</th>
                                                <th style="text-align: center">Variance</th>
                                                <th style="text-align: center">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($records as $index => $record)
                                                <tr>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $index + 1 }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        SA-{{ str_pad($record->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ $record->technician_label }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        @if ($record->svca_approved_time_from && $record->svca_approved_time_to)
                                                            {{ \Carbon\Carbon::parse($record->svca_approved_time_from)->format('g:i A') }}
                                                            -
                                                            {{ \Carbon\Carbon::parse($record->svca_approved_time_to)->format('g:i A') }}
                                                        @else
                                                            N/A
                                                        @endif
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ tat_format_duration($record->approved_duration_seconds) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ tat_format_duration($record->travel_seconds) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ tat_format_duration($record->service_seconds) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        {{ tat_format_duration($record->total_seconds) }}
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        @if ($record->variance_seconds === null)
                                                            N/A
                                                        @else
                                                            {{ $record->variance_seconds > 0 ? '+' : '-' }}{{ tat_format_duration($record->variance_seconds) }}
                                                        @endif
                                                    </td>
                                                    <td style="text-align: center; vertical-align: middle;">
                                                        @if ($record->tat_status == 'ON TIME')
                                                            <span class="badge badge-success">ON TIME</span>
                                                        @elseif ($record->tat_status == 'DELAYED')
                                                            <span class="badge badge-danger">DELAYED</span>
                                                        @else
                                                            <span class="badge badge-secondary">N/A</span>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="10" style="text-align: center;">No turn around time records found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            @if ($filtered && $technicianPerformance->isNotEmpty())
                                <hr>
                                <div class="row mt-3">
                                    <div class="col-md-12 text-center mb-2">
                                        <h5><strong>Technician Performance</strong></h5>
                                    </div>
                                    <div class="col-md-12">
                                        <table id="techPerformanceTable" class="table table-bordered table-sm">
                                            <thead>
                                                <tr>
                                                    <th style="text-align: center">No.</th>
                                                    <th style="text-align: center">Technician</th>
                                                    <th style="text-align: center">Total Jobs</th>
                                                    <th style="text-align: center">On Time</th>
                                                    <th style="text-align: center">Delayed</th>
                                                    <th style="text-align: center">On-Time Rate</th>
                                                    <th style="text-align: center">Avg. Variance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($technicianPerformance as $index => $tech)
                                                    <tr>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            {{ $index + 1 }}
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            {{ $tech->name }}
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            {{ $tech->total }}
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            {{ $tech->on_time }}
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            {{ $tech->delayed }}
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            @if ($tech->on_time_rate >= 80)
                                                                <span class="badge badge-success">{{ $tech->on_time_rate }}%</span>
                                                            @elseif ($tech->on_time_rate >= 50)
                                                                <span class="badge badge-warning">{{ $tech->on_time_rate }}%</span>
                                                            @else
                                                                <span class="badge badge-danger">{{ $tech->on_time_rate }}%</span>
                                                            @endif
                                                        </td>
                                                        <td style="text-align: center; vertical-align: middle;">
                                                            @if ($tech->avg_variance_minutes === null)
                                                                N/A
                                                            @else
                                                                {{ $tech->avg_variance_minutes > 0 ? '+' : '' }}{{ $tech->avg_variance_minutes }} min
                                                            @endif
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection

@php
    // Formats a raw seconds value into "X hr(s) and Y min(s)" style, matching the completed_appointments_view pattern.
    if (!function_exists('tat_format_duration')) {
        function tat_format_duration($seconds)
        {
            if ($seconds === null) {
                return 'N/A';
            }

            $seconds = abs($seconds);
            $hours = floor($seconds / 3600);
            $minutes = floor(($seconds % 3600) / 60);

            if ($hours == 0 && $minutes == 0) {
                return '0 min';
            } elseif ($hours > 0 && $minutes > 0) {
                return $hours . ' hr' . ($hours > 1 ? 's' : '') . ' and ' . $minutes . ' min' . ($minutes > 1 ? 's' : '');
            } elseif ($hours > 0) {
                return $hours . ' hr' . ($hours > 1 ? 's' : '');
            } else {
                return $minutes . ' min' . ($minutes > 1 ? 's' : '');
            }
        }
    }
@endphp

<script>
    function toggleFilterInputs() {
        let type = document.getElementById('filter_type').value;
        document.querySelectorAll('.filter-daily, .filter-date_range, .filter-weekly, .filter-monthly, .filter-yearly')
            .forEach(el => el.style.display = 'none');

        if (type === 'daily') document.querySelectorAll('.filter-daily').forEach(el => el.style.display = 'block');
        if (type === 'date_range') document.querySelectorAll('.filter-date_range').forEach(el => el.style.display = 'block');
        if (type === 'weekly') document.querySelectorAll('.filter-weekly').forEach(el => el.style.display = 'block');
        if (type === 'monthly') document.querySelectorAll('.filter-monthly').forEach(el => el.style.display = 'block');
        if (type === 'yearly') document.querySelectorAll('.filter-yearly').forEach(el => el.style.display = 'block');
    }
    toggleFilterInputs(); // on page load
</script>

<script>
    function printReport() {
        window.print();
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    function exportToExcel(tableId) {
        let table = document.getElementById(tableId);
        if (!table) return;

        let filterUsed = document.getElementById('filterUsedText')?.innerText.trim() || '';
        let branch = document.getElementById('branchText')?.innerText.trim() || '';

        let totalRecords = document.getElementById('totalRecords')?.innerText.trim() || '0';
        let onTimeCount = document.getElementById('onTimeCount')?.innerText.trim() || '0';
        let delayedCount = document.getElementById('delayedCount')?.innerText.trim() || '0';
        let onTimeRate = document.getElementById('onTimeRate')?.innerText.trim() || '0%';
        let avgVarianceMinutes = document.getElementById('avgVarianceMinutes')?.innerText.trim() || 'N/A';

        let tableData = [];

        let headerCells = table.querySelectorAll('thead tr th');
        let headers = [];
        headerCells.forEach((th) => headers.push(th.innerText.trim()));
        tableData.push(headers);

        let bodyRows = table.querySelectorAll('tbody tr');
        bodyRows.forEach(row => {
            let cells = row.querySelectorAll('td');
            if (cells.length <= 1) return; // skip "No records found" row
            let rowData = [];
            cells.forEach((td) => rowData.push(td.innerText.trim()));
            tableData.push(rowData);
        });

        let sheetData = [
            [], // Row 1 - blank
            ['Turn Around Time Report'], // Row 2 - title
            ['Filter Used:', filterUsed, 'Branch:', branch], // Row 3
            ['Total Jobs:', totalRecords, 'On Time:', onTimeCount, 'Delayed:', delayedCount, 'On-Time Rate:', onTimeRate], // Row 4
            ['Average Variance:', avgVarianceMinutes], // Row 5
            [], // Row 6 - blank
            ...tableData // Row 7+ - main table
        ];

        // Append technician performance table, if present
        let techTable = document.getElementById('techPerformanceTable');
        if (techTable) {
            sheetData.push([], ['Technician Performance']);

            let techHeaders = [];
            techTable.querySelectorAll('thead tr th').forEach((th) => techHeaders.push(th.innerText.trim()));
            sheetData.push(techHeaders);

            techTable.querySelectorAll('tbody tr').forEach(row => {
                let cells = row.querySelectorAll('td');
                if (cells.length <= 1) return;
                let rowData = [];
                cells.forEach((td) => rowData.push(td.innerText.trim()));
                sheetData.push(rowData);
            });
        }

        let ws = XLSX.utils.aoa_to_sheet(sheetData);
        let wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Turn Around Time Report');

        XLSX.writeFile(wb, 'Turn_Around_Time_Report_' + new Date().toISOString().slice(0,10) + '.xlsx');
    }
</script>