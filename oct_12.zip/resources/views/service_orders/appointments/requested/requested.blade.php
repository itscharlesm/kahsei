@extends('layouts.themes.main')

<style>
    #requestedTable_filter { display: none; }
</style>

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Requested Appointments</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\AdminController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointments</li>
                        <li class="breadcrumb-item active">Requested</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="row">
                        <!-- Table Column -->
                        <div class="col-lg-12 col-md-7">

                            {{-- Search + Batch Delete --}}
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <form method="GET" action="{{ url('service/order/appointments/requested') }}"
                                    class="flex-grow-1 mr-2">
                                    <div class="input-group">
                                        <input type="text" name="search" id="searchInput" class="form-control"
                                            placeholder="Search client..." value="{{ request('search') }}">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-primary">
                                                <span class="fa fa-search"></span> Search
                                            </button>
                                        </div>
                                    </div>
                                </form>

                                @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1')
                                    <div class="text-nowrap">
                                        <button type="button" id="batchDeleteBtn" class="btn btn-danger">
                                            <span class="fa fa-trash"></span> Batch Delete
                                        </button>

                                        <span id="batchActions" class="d-none">
                                            <button type="button" id="batchConfirmBtn" class="btn btn-danger" disabled
                                                data-toggle="modal" data-target="#batchDeleteModal">
                                                <span class="fa fa-trash"></span> Delete Selected
                                                (<span id="selectedCount">0</span>)
                                            </button>
                                            <button type="button" id="batchCancelBtn" class="btn btn-secondary">
                                                <span class="fa fa-times"></span> Cancel
                                            </button>
                                        </span>
                                    </div>
                                @endif
                            </div>

                            {{-- Date filter (moved next to "Show entries" by the script) --}}
                            <div id="dateFilterWrap" class="d-none align-items-center ml-3">
                                <label class="mb-0 mr-1 font-weight-normal">Date Requested:</label>
                                <input type="date" id="dateFilter" class="form-control form-control-sm mr-1"
                                    style="width: 150px;">
                                <button type="button" id="dateClear" class="btn btn-secondary btn-sm">
                                    <span class="fa fa-times"></span> Clear
                                </button>
                            </div>

                            <table id="requestedTable" class="table table-hover table-bordered table-sm responsive">
                                <thead>
                                    <tr>
                                        <th class="batch-col d-none text-center"
                                            style="vertical-align: middle; width: 30px;">
                                            <input type="checkbox" id="checkAllRows" title="Select all shown rows">
                                        </th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">SA Number</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Client</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Mobile Number</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Branch</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Is Termite</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Is Package</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Payment Status</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Date Requested</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Status</th>
                                        <th class="text-center" style="vertical-align: middle; text-align: center; font-size: 12px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($appointments as $appointment)
                                        <tr data-date="{{ \Carbon\Carbon::parse($appointment->svca_client_date)->format('Y-m-d') }}">
                                            <td class="batch-col d-none text-center" style="vertical-align: middle;">
                                                <input type="checkbox" class="row-checkbox"
                                                    value="{{ $appointment->svc_id }}">
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                SA-{{ str_pad($appointment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->usr_last_name }}, {{ $appointment->usr_first_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->usr_mobile }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->branch_name }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svc_is_termite == 1)
                                                    YES
                                                @else
                                                    NO
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                @if ($appointment->svc_is_package == 1)
                                                    YES
                                                @else
                                                    NO
                                                @endif
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->svc_payment_status }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ \Carbon\Carbon::parse($appointment->svca_client_date)->format('m/d/Y') }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                {{ $appointment->svc_status }}
                                            </td>
                                            <td style="vertical-align: middle; text-align: center; font-size: 12px">
                                                <a class="btn btn-primary btn-sm mb-1"
                                                    href="{{ url('service/order/appointments/requested/' . $appointment->svc_id) }}">
                                                    <span class="fa fa-eye"></span>
                                                </a>

                                                @if (session('SUPERADMIN') == '1' || session('ADMIN') == '1' || session('MANAGER') == '1')
                                                    <a class="btn btn-danger btn-sm mb-1" href="javascript:void(0)"
                                                        data-toggle="modal"
                                                        data-target="#deleteModal-{{ $appointment->svc_id }}">
                                                        <span class="fa fa-trash"></span>
                                                    </a>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Batch Delete Modal --}}
    <div class="modal fade" id="batchDeleteModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form method="POST" action="{{ url('service/order/appointments/batch/delete') }}">
                    @csrf
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title text-white">Please Confirm</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to <strong>DELETE</strong>
                            <strong id="batchModalCount">0</strong> selected appointment(s)?
                            This action cannot be undone.
                        </p>
                        <div id="batchIdsContainer"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <span class="fa fa-close"></span> Close
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <span class="fa fa-trash"></span> Confirm Delete
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @foreach ($appointments as $appointment)
        {{-- Delete Modal --}}
        <div class="modal fade" id="deleteModal-{{ $appointment->svc_id }}" tabindex="-1" role="dialog"
            aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form method="POST"
                        action="{{ action('App\Http\Controllers\AppointmentController@delete_appointment', [$appointment->svc_id]) }}">
                        @csrf
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title text-white" id="deleteModalLabel">
                                Please Confirm
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to <strong>DELETE</strong> the
                                appointment of <strong>{{ $appointment->usr_first_name }}
                                    {{ $appointment->usr_last_name }}</strong>? This action cannot be undone.
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                <span class="fa fa-close"></span> Close
                            </button>
                            <button type="submit" class="btn btn-danger">
                                <span class="fa fa-trash"></span> Confirm Delete
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    {{-- Batch Delete + Dynamic Search Script --}}
    <script>
        const searchInput  = document.getElementById("searchInput");
        const batchBtn     = document.getElementById("batchDeleteBtn");
        const batchActions = document.getElementById("batchActions");
        const confirmBtn   = document.getElementById("batchConfirmBtn");
        const cancelBtn    = document.getElementById("batchCancelBtn");
        const checkAll     = document.getElementById("checkAllRows");
        const countEl      = document.getElementById("selectedCount");

        const allRowChecks  = () => document.querySelectorAll("#requestedTable .row-checkbox");
        const visibleChecks = () => Array.from(allRowChecks()).filter(cb => cb.closest("tr").style.display !== "none");

        function updateBatchState() {
            if (!confirmBtn) return;
            const selected = Array.from(allRowChecks()).filter(cb => cb.checked).length;
            const visible  = visibleChecks();

            countEl.textContent = selected;
            confirmBtn.disabled = selected === 0;
            checkAll.checked = visible.length > 0 && visible.every(cb => cb.checked);
        }

        function setBatchMode(on) {
            document.querySelectorAll(".batch-col").forEach(el => el.classList.toggle("d-none", !on));
            batchBtn.classList.toggle("d-none", on);
            batchActions.classList.toggle("d-none", !on);

            if (!on) {
                allRowChecks().forEach(cb => cb.checked = false);
                checkAll.checked = false;
            }
            updateBatchState();
        }

        if (batchBtn) {
            batchBtn.addEventListener("click", () => setBatchMode(true));
            cancelBtn.addEventListener("click", () => setBatchMode(false));

            // Select all = only rows currently shown (respects the search/date filter and paging)
            checkAll.addEventListener("change", function() {
                visibleChecks().forEach(cb => cb.checked = this.checked);
                updateBatchState();
            });

            allRowChecks().forEach(cb => cb.addEventListener("change", updateBatchState));

            // Fill hidden inputs before the modal opens
            confirmBtn.addEventListener("click", function() {
                const container = document.getElementById("batchIdsContainer");
                container.innerHTML = "";
                let n = 0;
                allRowChecks().forEach(cb => {
                    if (cb.checked) {
                        const input = document.createElement("input");
                        input.type = "hidden";
                        input.name = "svc_ids[]";
                        input.value = cb.value;
                        container.appendChild(input);
                        n++;
                    }
                });
                document.getElementById("batchModalCount").textContent = n;
            });
        }

        // Dynamic search while typing
        searchInput.addEventListener("keyup", function() {
            let value = this.value.toLowerCase();

            document.querySelectorAll('table[id*="Table"]').forEach(function(table) {
                table.querySelectorAll("tbody tr").forEach(function(row) {
                    let text = row.innerText.toLowerCase();
                    row.style.display = text.includes(value) ? "" : "none";

                    // Rows hidden by the filter get unchecked so they can't be deleted by accident
                    if (row.style.display === "none") {
                        const cb = row.querySelector(".row-checkbox");
                        if (cb) cb.checked = false;
                    }
                });
            });

            updateBatchState();
        });
    </script>

    {{-- DataTable + Date Filter --}}
    <script>
    $(document).ready(function() {
        if (!$('#requestedTable').length) return;

        // Date filter: show only rows whose svca_client_date falls on the selected day
        $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
            if (settings.nTable.id !== 'requestedTable') return true;

            const selected = $('#dateFilter').val();
            if (!selected) return true;

            const rowDate = $(settings.aoData[dataIndex].nTr).data('date');
            return rowDate === selected;
        });

        const table = $('#requestedTable').DataTable({
            "searching": true,
            "order": [],
            "columnDefs": [{ "orderable": false, "targets": [0, -1] }],
            "lengthMenu": [
                [25, 50, 100],
                [25, 50, 100]
            ],
            dom: '<"top"lf>rt<"bottom"ip><"clear">'
        });

        $('#requestedTable_length')
            .addClass('d-flex align-items-center')
            .append($('#dateFilterWrap').removeClass('d-none').addClass('d-flex'));

        $('#dateFilter').on('change', function() {
            table.draw();
        });

        $('#dateClear').on('click', function() {
            $('#dateFilter').val('');
            table.draw();
        });

        table.on('draw', function() {
            table.rows().nodes().to$().find('.row-checkbox').prop('checked', false);
            if (typeof updateBatchState === 'function') updateBatchState();
        });
    });
</script>
@endsection