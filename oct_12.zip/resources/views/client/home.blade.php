@extends('layouts.themes.main')

@section('title', 'Home - Dashboard')

@section('page_styles')
    <style>
        .client-dashboard .range-btn-group .btn {
            min-width: 95px;
        }

        .client-dashboard .range-btn-group .btn.active {
            font-weight: 600;
        }

        .client-dashboard .stat-card .inner h3 {
            font-size: 1.45rem;
            line-height: 1.2;
            overflow-wrap: anywhere;
        }

        .client-dashboard .stat-card .inner p {
            font-size: .88rem;
            min-height: 42px;
        }

        .client-dashboard .stat-card .icon {
            top: 8px;
        }

        .client-dashboard .stat-card .icon > i {
            font-size: 58px;
        }

        .client-dashboard .dashboard-table {
            overflow-x: auto !important;
        }

        .client-dashboard .dashboard-table table {
            margin-bottom: 0;
            min-width: 650px;
        }

        .client-dashboard .payment-table table {
            min-width: 460px;
        }

        .client-dashboard .dashboard-table th {
            border-top: 0;
            color: #6c757d;
            font-size: .72rem;
            letter-spacing: .03em;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .client-dashboard .dashboard-table td {
            vertical-align: middle;
        }

        .client-dashboard .service-label {
            display: block;
            max-width: 220px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .client-dashboard .pending-summary {
            background: #fff8e1;
            border: 1px solid #ffe69c;
            border-radius: .25rem;
            color: #725400;
            margin-bottom: 1rem;
            padding: .75rem;
        }

        .client-dashboard .empty-state {
            color: #8a939b;
            padding: 2.8rem 1rem;
            text-align: center;
        }

        .client-dashboard .empty-state i {
            display: block;
            font-size: 2rem;
            margin-bottom: .65rem;
            opacity: .55;
        }

        @media (max-width: 575.98px) {
            .client-dashboard .range-btn-group {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                width: 100%;
            }

            .client-dashboard .range-btn-group .btn {
                min-width: 0;
            }

            .client-dashboard .stat-card .inner h3 {
                font-size: 1.12rem;
            }

            .client-dashboard .stat-card .inner p {
                font-size: .76rem;
                min-height: 38px;
            }

            .client-dashboard .stat-card .icon > i {
                font-size: 48px;
            }
        }
    </style>
@endsection

@section('content')
    @php
        $metrics = [
            [
                'label' => 'Services Availed',
                'value' => number_format($servicesAvailed),
                'icon' => 'fas fa-briefcase',
                'class' => 'bg-primary',
            ],
            [
                'label' => 'Total Fixed Price',
                'value' => '₱' . number_format($financialSummary->total_fixed_price ?? 0, 2),
                'icon' => 'fas fa-tag',
                'class' => 'bg-purple',
            ],
            [
                'label' => 'Total Final Price',
                'value' => '₱' . number_format($financialSummary->total_final_price ?? 0, 2),
                'icon' => 'fas fa-receipt',
                'class' => 'bg-info',
            ],
            [
                'label' => 'Amount Paid',
                'value' => '₱' . number_format($financialSummary->amount_paid ?? 0, 2),
                'icon' => 'fas fa-circle-check',
                'class' => 'bg-success',
            ],
            [
                'label' => 'Outstanding Balance',
                'value' => '₱' . number_format($financialSummary->outstanding_balance ?? 0, 2),
                'icon' => 'fas fa-wallet',
                'class' => 'bg-danger',
            ],
            [
                'label' => 'Discounted',
                'value' => '₱' . number_format($financialSummary->client_credit ?? 0, 2),
                'icon' => 'fas fa-coins',
                'class' => 'bg-warning',
            ],
        ];

        $pipeline = [
            [
                'label' => 'Requested',
                'count' => $counts['requested'],
                'icon' => 'fas fa-inbox',
                'class' => 'bg-warning',
                'url' => action('App\Http\Controllers\ClientController@requested_appointments'),
            ],
            [
                'label' => 'Assessed',
                'count' => $counts['assessed'],
                'icon' => 'fas fa-user-clock',
                'class' => 'bg-secondary',
                'url' => action('App\Http\Controllers\ClientController@assessed_appointments'),
            ],
            [
                'label' => 'Scheduled',
                'count' => $counts['scheduled'],
                'icon' => 'fas fa-calendar-check',
                'class' => 'bg-info',
                'url' => action('App\Http\Controllers\ClientController@scheduled_appointments'),
            ],
            [
                'label' => 'Ongoing',
                'count' => $counts['ongoing'],
                'icon' => 'fas fa-route',
                'class' => 'bg-primary',
                'url' => action('App\Http\Controllers\ClientController@ongoing_appointments'),
            ],
            [
                'label' => 'Finished',
                'count' => $counts['finished'],
                'icon' => 'fas fa-file-alt',
                'class' => 'bg-teal',
                'url' => action('App\Http\Controllers\ClientController@finished_appointments'),
            ],
            [
                'label' => 'Completed',
                'count' => $counts['completed'],
                'icon' => 'fas fa-check-circle',
                'class' => 'bg-success',
                'url' => action('App\Http\Controllers\ClientController@completed_appointments'),
            ],
        ];
    @endphp

    <div class="client-dashboard">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Home</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="{{ action('App\Http\Controllers\ClientController@home') }}">Home</a>
                            </li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <section class="content pb-3">
            <div class="container-fluid">
                <section id="client-dashboard-filters">
                    <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
                        <div class="btn-group range-btn-group mb-2" role="group" aria-label="Dashboard period">
                            @foreach ($periodLabels as $periodValue => $periodLabel)
                                <a href="{{ url('client/home') }}?period={{ $periodValue }}"
                                   class="btn btn-outline-primary {{ $period === $periodValue ? 'active' : '' }}"
                                   @if ($period === $periodValue) aria-current="page" @endif>
                                    {{ $periodLabel }}
                                </a>
                            @endforeach
                        </div>
                    </div>
                </section>

                <section id="financial-summary">
                    <div class="d-flex align-items-center mb-2">
                        <h5 class="mb-0" style="font-weight: 600;">
                            <i class="fas fa-wallet mr-2"></i>Financial Summary
                        </h5>
                        <span class="badge bg-green ml-2">{{ $periodLabels[$period] }}</span>
                    </div>

                    <div class="row">
                        @foreach ($metrics as $metric)
                            <div class="col-md-2 col-6">
                                <div class="small-box {{ $metric['class'] }} stat-card">
                                    <div class="inner">
                                        <h3 class="mb-1">{{ $metric['value'] }}</h3>
                                        <p>{{ $metric['label'] }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="{{ $metric['icon'] }}" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </section>

                <section id="appointment-pipeline">
                    <div class="d-flex align-items-center mb-2">
                        <h5 class="mb-0" style="font-weight: 600;">
                            <i class="fas fa-route mr-2"></i>Service Orders Pipeline
                        </h5>
                    </div>

                    <div class="row">
                        @foreach ($pipeline as $item)
                            <div class="col-md-2 col-6">
                                <div class="small-box {{ $item['class'] }} stat-card">
                                    <div class="inner">
                                        <h3 class="mb-0">{{ number_format($item['count']) }}</h3>
                                        <p>{{ $item['label'] }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="{{ $item['icon'] }}" aria-hidden="true"></i>
                                    </div>
                                    <a href="{{ $item['url'] }}" class="small-box-footer">
                                        View <i class="fas fa-arrow-circle-right" aria-hidden="true"></i>
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </section>

                <section id="client-financial-details">
                    <div class="row align-items-stretch">
                        <div class="col-xl-7 d-flex">
                            <div class="card card-outline card-danger w-100">
                                <div class="card-header">
                                    <h3 class="card-title" style="font-weight: 600;">
                                        <i class="fas fa-file-invoice-dollar mr-2"></i>Outstanding Balances
                                    </h3>
                                </div>
                                <div class="card-body p-0">
                                    <p class="text-muted px-3 pt-3 mb-2">
                                        Up to five services with the highest remaining balance.
                                    </p>

                                    @if ($outstandingServices->isEmpty())
                                        <div class="empty-state">
                                            <i class="fas fa-check-circle text-success" aria-hidden="true"></i>
                                            <strong>No outstanding balances</strong>
                                            <div class="small mt-1">
                                                You have no final-priced services with a balance for this period.
                                            </div>
                                        </div>
                                    @else
                                        <div class="dashboard-table">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Service</th>
                                                        <th>Final Price</th>
                                                        <th>Paid</th>
                                                        <th>Balance</th>
                                                        <th>Status</th>
                                                        <th class="text-right">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($outstandingServices as $service)
                                                        @php
                                                            $servicePaymentBadge = match ($service->svc_payment_status) {
                                                                'PAID' => 'badge-success',
                                                                'INCOMPLETE PAYMENT' => 'badge-warning',
                                                                'EXCESS PAYMENT' => 'badge-info',
                                                                default => 'badge-secondary',
                                                            };
                                                        @endphp
                                                        <tr>
                                                            <td>
                                                                <strong>
                                                                    SA-{{ str_pad($service->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                                </strong>
                                                                <span class="service-label small text-muted"
                                                                      title="{{ $service->service_label }}">
                                                                    {{ $service->service_label }}
                                                                </span>
                                                            </td>
                                                            <td>₱{{ number_format($service->svc_final_price, 2) }}</td>
                                                            <td class="text-success">
                                                                ₱{{ number_format($service->paid_amount, 2) }}
                                                            </td>
                                                            <td class="font-weight-bold text-danger">
                                                                ₱{{ number_format($service->svc_balance, 2) }}
                                                            </td>
                                                            <td>
                                                                <span class="badge {{ $servicePaymentBadge }}">
                                                                    {{ $service->svc_payment_status ?: 'NO PAYMENT' }}
                                                                </span>
                                                            </td>
                                                            <td class="text-right">
                                                                <a href="{{ url('client/service/order/payment/view/' . $service->svc_id) }}"
                                                                   class="btn btn-sm btn-outline-primary"
                                                                   aria-label="View payment details for service SA-{{ str_pad($service->svc_sa_number, 6, '0', STR_PAD_LEFT) }}">
                                                                    <i class="fas fa-credit-card mr-1"
                                                                       aria-hidden="true"></i>Pay
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-5 d-flex">
                            <div class="card card-outline card-primary w-100">
                                <div class="card-header">
                                    <h3 class="card-title" style="font-weight: 600;">
                                        <i class="fas fa-clock-rotate-left mr-2"></i>Payment Activity
                                    </h3>
                                </div>
                                <div class="card-body p-0">
                                    <p class="text-muted px-3 pt-3 mb-2">
                                        Your five most recent payment submissions.
                                    </p>

                                    @if (($pendingPayments->total_count ?? 0) > 0)
                                        <div class="pending-summary mx-3">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span>
                                                    <i class="fas fa-hourglass-half mr-1" aria-hidden="true"></i>
                                                    <strong>{{ number_format($pendingPayments->total_count) }}</strong>
                                                    awaiting verification
                                                </span>
                                                <strong>
                                                    ₱{{ number_format($pendingPayments->total_amount ?? 0, 2) }}
                                                </strong>
                                            </div>
                                        </div>
                                    @endif

                                    @if ($paymentActivity->isEmpty())
                                        <div class="empty-state">
                                            <i class="fas fa-receipt" aria-hidden="true"></i>
                                            <strong>No payment activity</strong>
                                            <div class="small mt-1">
                                                Payment submissions for this period will appear here.
                                            </div>
                                        </div>
                                    @else
                                        <div class="dashboard-table payment-table">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Payment</th>
                                                        <th>Method</th>
                                                        <th>Amount</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($paymentActivity as $payment)
                                                        @php
                                                            $paymentBadge = match ($payment->spay_status) {
                                                                'APPROVED' => 'badge-success',
                                                                'FOR APPROVAL' => 'badge-warning',
                                                                'VOIDED' => 'badge-danger',
                                                                default => 'badge-secondary',
                                                            };
                                                        @endphp
                                                        <tr>
                                                            <td>
                                                                <a href="{{ url('client/service/order/payment/view/' . $payment->svc_id) }}"
                                                                   class="text-nowrap"
                                                                   aria-label="View payment activity for service SA-{{ str_pad($payment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}">
                                                                    <strong>
                                                                        SA-{{ str_pad($payment->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                                                                    </strong>
                                                                    <i class="fas fa-chevron-right small ml-1"
                                                                       aria-hidden="true"></i>
                                                                </a>
                                                                <span class="d-block small text-muted text-nowrap">
                                                                    {{ $payment->spay_date ? \Carbon\Carbon::parse($payment->spay_date)->format('M d, Y') : 'No date' }}
                                                                </span>
                                                            </td>
                                                            <td>{{ $payment->typ_name ?: '—' }}</td>
                                                            <td class="font-weight-bold">
                                                                ₱{{ number_format($payment->display_amount ?? 0, 2) }}
                                                            </td>
                                                            <td>
                                                                <span class="badge {{ $paymentBadge }}">
                                                                    {{ $payment->spay_status ?: 'UNKNOWN' }}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>
@endsection