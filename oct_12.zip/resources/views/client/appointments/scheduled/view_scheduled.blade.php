<style>
    @media print {
        body {
            zoom: 100%;
        }

        .no-print {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }

        .print-hide {
            display: none !important;
        }
    }

    .table-responsive {
        overflow: visible !important;
    }

    #sectionB {
        overflow: visible !important;
    }

    #timelineTabs .nav-link {
        color: #28a745;
    }

    #timelineTabs .nav-link.active {
        color: #28a745;
        border-color: #28a745 #28a745 #fff;
    }

    #timelineTabs .nav-link:hover {
        color: #1e7e34;
        border-color: #1e7e34 #1e7e34 transparent;
    }

    body.layout-fixed .content-wrapper {
        height: auto !important;
        min-height: auto !important;
        overflow-y: visible !important;
    }
</style>

@extends('layouts.themes.main')

@section('content')
    {{-- Content Header --}}
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Scheduled Appointment</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="{{ action('App\Http\Controllers\ClientController@home') }}">Home</a>
                        </li>
                        <li class="breadcrumb-item">Appointment</li>
                        <li class="breadcrumb-item">Scheduled</li>
                        <li class="breadcrumb-item active">View</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content --}}
    <section class="content">
        @include('layouts.partials.onclick')
        @include('layouts.partials.alerts')
        @include('layouts.partials.modal_style')
        <div class="container-fluid">
            <div class="card">
                <div class="card-body overflow-auto">
                    <div class="text-center mb-2">
                        <h5 style="margin: 0; font-weight: bold;">GO FORWARD PEST CONTROL</h5>
                        <p style="margin: 0;">{{ $display->branch_name }}</p>
                    </div>

                    <div class="mb-4 position-relative text-center">
                        <strong style="color: red;">SERVICE ORDER</strong>

                        <strong style="position: absolute; right: 0; top: 0;">
                            SA-{{ str_pad($display->svc_sa_number, 6, '0', STR_PAD_LEFT) }}
                        </strong>
                    </div>
                    <div class="row">

                        {{-- Appointment Information Display --}}
                        <div class="table-responsive overflow-auto" id="sectionA">
                            <table class="table table-bordered text-left align-middle">
                                <tbody>
                                    <tr>
                                        <th colspan="6" class="text-center table-light">CLIENT INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">CLIENT NAME</td>
                                        <td>{{ $display->usr_first_name }} {{ $display->usr_last_name }}</td>
                                        <td style="font-weight: bold;">EMAIL</td>
                                        <td>{{ $display->usr_email }}</td>
                                        <td style="font-weight: bold;">MOBILE</td>
                                        <td>{{ $display->usr_mobile }}</td> 
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">ADDRESS</td>
                                        <td colspan="3">
                                            {{ implode(
                                                ', ',
                                                array_filter([
                                                    $display->uadd_street,
                                                    $display->uadd_barangay,
                                                    $display->uadd_city,
                                                    $display->uadd_province,
                                                    $display->uadd_region,
                                                ]),
                                            ) }}
                                        </td>
                                        <td style="font-weight: bold;">ADDRESS TYPE</td>
                                        <td>{{ $display->add_name }}</td>
                                    </tr>

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SERVICE INFORMATION</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">BRANCH</td>
                                        <td>{{ $display->branch_name }}</td>
                                        <td style="font-weight: bold;">STATUS</td>
                                        <td>{{ $display->svc_status }}</td>
                                        <td style="font-weight: bold;">PAYMENT STATUS</td>
                                        <td>{{ $display->svc_payment_status }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">PROPERTY TYPE</td>
                                        <td>{{ $display->svc_property_type }}</td>
                                        <td style="font-weight: bold;">INFESTATION</td>
                                        <td>{{ $display->svc_infestation }}</td>
                                        <td style="font-weight: bold;">DISTANCE</td>
                                        <td>{{ $display->svc_km_distance }} KM</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">IS TERMITE</td>
                                        <td>{{ $display->svc_is_termite ? 'YES' : 'NO' }}</td>
                                        <td style="font-weight: bold;">IS PACKAGE</td>
                                        <td colspan="3">{{ $display->svc_is_package ? 'YES' : 'NO' }}</td>
                                    </tr>

                                    @if (!empty($display->svc_problem_description))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">PROBLEM DESCRIPTION / CLIENT REQUEST</th>
                                        </tr>
                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_problem_description }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">PRICING</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">INITIAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_initial_price, 2) }}</td>
                                        <td style="font-weight: bold;">LOCATION PRICE</td>
                                        <td>₱{{ number_format($display->svc_location_price, 2) }}</td>
                                        <td style="font-weight: bold;">FIXED PRICE</td>
                                        <td>₱{{ number_format($display->svc_fixed_price, 2) }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">FINAL PRICE</td>
                                        <td>₱{{ number_format($display->svc_final_price, 2) }}</td>
                                        <td style="font-weight: bold;">BALANCE</td>
                                        <td colspan="3">₱{{ number_format($display->svc_balance, 2) }}</td>
                                    </tr>

                                    @if ($display->svc_is_termite)
                                        <tr>
                                            <th colspan="6" class="text-center table-light">TERMITE CASE</th>
                                        </tr>
                                        <tr>
                                            <td style="font-weight: bold;">TREATMENT TYPE</td>
                                            <td>{{ $display->svc_type_treatment }}</td>
                                            <td style="font-weight: bold;">INITIAL SQM</td>
                                            <td>{{ $display->svc_sqm_initial }}</td>
                                            <td style="font-weight: bold;">FINAL SQM</td>
                                            <td>{{ $display->svc_sqm_final }}</td>
                                        </tr>
                                        <tr>
                                            <td style="font-weight: bold;">WITH DEVICE</td>
                                            <td>{{ $display->svc_with_device ? 'YES' : 'NO' }}</td>
                                            <td style="font-weight: bold;">DEVICE COUNT</td>
                                            <td colspan="3">{{ $display->svc_device_count ?? 'N/A' }}</td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">CHEMICAL</th>
                                    </tr>

                                    @forelse ($serviceChemicals as $chem)
                                        <tr>
                                            <td style="font-weight: bold;">CHEMICAL</td>
                                            <td>{{ $chem->chem_name }}</td>
                                            <td style="font-weight: bold;">EXPECTED QUANTITY</td>
                                            <td>{{ $chem->svcch_expected_quantity }}</td>
                                            <td style="font-weight: bold;">METRIC</td>
                                            <td>{{ $chem->svcch_unit }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No chemicals recorded.</td>
                                        </tr>
                                    @endforelse

                                    @if (!empty($display->svc_assessment_recommendation))
                                        <tr>
                                            <th colspan="6" class="text-center table-light">ASSESSMENT RECOMMENDATION
                                            </th>
                                        </tr>
                                        <tr>
                                            <td colspan="6" style="text-align: justify">
                                                {{ $display->svc_assessment_recommendation }}
                                            </td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th colspan="6" class="text-center table-light">SCHEDULE</th>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE REQUESTED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_client_date)->format('m/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME REQUESTED</td>
                                        <td colspan="3">{{ \Carbon\Carbon::parse($display->svca_client_time)->format('h:i A') }}</td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE APPROVED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_date_approved)->format('m/d/Y') }}</td>
                                        <td style="font-weight: bold;">TIME APPROVED</td>
                                        <td>{{ \Carbon\Carbon::parse($display->svca_approved_time_from)->format('h:i A') }} - {{ \Carbon\Carbon::parse($display->svca_approved_time_to)->format('h:i A') }}
                                        </td>
                                        <td style="font-weight: bold;">APPROVED BY</td>
                                        <td>{{ $display->approved_first_name }} {{ $display->approved_last_name }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight: bold;">DATE ASSIGNED</td>
                                        <td>
                                            {{ \Carbon\Carbon::parse($display->svcas_date_assigned)->format('m/d/Y | h:i A') }}
                                        </td>

                                        <td style="font-weight: bold;">ASSIGNED TO</td>
                                        <td colspan="3">
                                            {{ $display->assigned_to_label ?? 'N/A' }}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-end flex-wrap mb-3 no-print">
                            <a class="btn btn-info mr-2 mb-2" href="{{ url('client/service/order/payment/view/' . $display->svc_id) }}">
                                <span class="fa {{ $display->svc_payment_status == 'PAID' ? 'fa-history' : 'fa-money-bill' }}"></span> {{ $display->svc_payment_status == 'PAID' ? 'Payment History' : 'Payments' }}
                            </a>
                            <button type="button" class="btn btn-dark mr-2 mb-2" onclick="printDefault()">
                                <span class="fa fa-print"></span> Print
                            </button>
                            <div class="btn-group mr-2 mb-2">
                                <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <span class="fa fa-print"></span> Print Options
                                </button>
                                <div class="dropdown-menu p-3" style="min-width: 200px;">
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionA">
                                        Appointment Information
                                    </label>
                                    <label class="dropdown-item">
                                        <input type="checkbox" class="print-toggle mr-1" data-target="sectionB"> Service
                                        Orders
                                    </label>
                                    @if ($appointmentImages->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionC">
                                            Client Appointment Images
                                        </label>
                                    @endif
                                    @if ($mappingImages->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionD">
                                            Mapping Images
                                        </label>
                                    @endif
                                    @if ($contracts->count() > 0)
                                        <label class="dropdown-item">
                                            <input type="checkbox" class="print-toggle mr-1" data-target="sectionF"> Client
                                            Service Contract
                                        </label>
                                    @endif
                                    <div class="dropdown-item text-center">
                                        <button class="btn btn-primary btn-sm mt-2" onclick="handlePrint()">Confirm &
                                            Print</button>
                                    </div>
                                    <div class="dropdown-item">
                                        <p id="warning" style="color:red; display:none;" class="mt-1">Select at least
                                            one section.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Service Order Display --}}
                        <div class="table-responsive" id="sectionB">
                            <hr class="no-print">
                            @if ($display->svc_is_termite == 0)
                                {{-- NON-TERMITE: Two columns - Pest Type & Service Order --}}
                                <div class="row">
                                    {{-- PEST TYPE TABLE --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="3"><strong>PEST TYPE</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Pest</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($pestTypes as $index => $type)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $type->svcp_pest_type }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>

                                    {{-- SERVICE ORDER TABLE (non-termite areas) --}}
                                    <div class="col-md-6">
                                        <table class="table table-bordered text-center mb-2">
                                            <thead>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th colspan="4"><strong>SERVICE ORDER</strong></th>
                                                </tr>
                                                <tr style="background-color: #f5f5f5;">
                                                    <th style="width: 50px;">No.</th>
                                                    <th>Service</th>
                                                    <th>Cost</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($serviceAreas as $index => $area)
                                                    <tr>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $index + 1 }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            {{ $area->svcpa_area }}</td>
                                                        <td style="vertical-align: middle; text-align: center">
                                                            ₱{{ number_format($area->svcpa_cost, 2) }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            @elseif ($display->svc_is_termite == 1)
                                {{-- TERMITE: Full width - Termite Details --}}
                                <div class="col-md-12">
                                    <table class="table table-bordered text-center mb-2">
                                        <thead>
                                            <tr style="background-color: #f5f5f5;">
                                                <th colspan="5"><strong>TERMITE DETAILS</strong></th>
                                            </tr>
                                            <tr style="background-color: #f5f5f5;">
                                                <th style="width: 50px;">No.</th>
                                                <th>SQM Details</th>
                                                <th>Cost</th>
                                                <th>Computation</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($termiteAreas as $index => $area)
                                                <tr>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $index + 1 }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        {{ $area->svcpat_sqm_details }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        ₱{{ number_format($area->svcpat_cost, 2) }}</td>
                                                    <td style="vertical-align: middle; text-align: center">
                                                        @if ($display->svc_type_treatment == 'STANDARD TREATMENT')
                                                            <p>STANDARD TREATMENT: sqm × cost</p>
                                                        @elseif ($display->svc_type_treatment == 'HYBRID TREATMENT')
                                                            <p>HYBRID TREATMENT: sqm × cost + device</p>
                                                        @else
                                                            <p>{{ $display->svc_type_treatment }}: sqm × cost</p>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted">No termite areas
                                                        added.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            @endif
                        </div>

                        {{-- Client Appointment Images --}}
                        @if ($appointmentImages->count() > 0)
                            <div class="table-responsive" id="sectionC">
                                <table class="table table-bordered text-center mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5">
                                                <strong>CLIENT APPOINTMENT IMAGES</strong>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" style="padding: 10px;">
                                                <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                                    @foreach ($appointmentImages as $img)
                                                        <div class="p-2" style="width:20%;">
                                                            <a href="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                target="_blank"
                                                                style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                                                <img src="{{ asset('images/client_images/' . $img->svcap_image) }}"
                                                                    alt="Mapping Image"
                                                                    style="width:100%; height:100%; object-fit:cover; display:block;">
                                                            </a>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Mapping Appointment Images --}}
                        @if ($mappingImages->count() > 0)
                            <div class="table-responsive" id="sectionD">
                                <table class="table table-bordered text-center mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5">
                                                <strong>MAPPING IMAGES</strong>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" style="padding: 10px;">
                                                <div class="row no-gutters justify-content-center" style="--bs-gutter-x: 0;">
                                                    @foreach ($mappingImages as $img)
                                                        <div class="p-2" style="width:20%;">
                                                            <a href="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                                                target="_blank"
                                                                style="display:block; width:100%; aspect-ratio:1/1; overflow:hidden; border:1px solid #dee2e6; border-radius:4px;">
                                                                <img src="{{ asset('images/mappings/' . $img->svcmp_image) }}"
                                                                    alt="Mapping Image"
                                                                    style="width:100%; height:100%; object-fit:cover; display:block;">
                                                            </a>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Service Contracts --}}
                        @if ($contracts->count() > 0)
                            <div class="table-responsive" id="sectionF">
                                <table class="table table-bordered mb-2">
                                    <thead>
                                        <tr style="background-color: #f5f5f5;">
                                            <th colspan="5" class="text-center"><strong>SERVICE CONTRACT</strong></th>
                                        </tr>
                                        <tr style="background-color: #f5f5f5;">
                                            <th class="text-center" style="vertical-align: middle;">Frequency</th>
                                            <th class="text-center" style="vertical-align: middle;">Duration</th>
                                            <th class="text-center" style="vertical-align: middle;">Total Services</th>
                                            <th class="text-center no-print" style="vertical-align: middle;">Contract</th>
                                            <th class="text-center" style="vertical-align: middle;">Appointments</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($contracts as $contract)
                                            <tr>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_type }}</td>
                                                <td class="text-center" style="vertical-align: middle;">
                                                    @php
                                                        // Force 2 decimal places so the fraction always represents 2-digit months
                                                        $parts = explode('.', number_format((float) $contract->svcc_total_years, 2, '.', ''));
                                                        $yrs = (int) $parts[0];
                                                        $mos = (int) $parts[1];

                                                        $label = '';
                                                        if ($yrs > 0) {
                                                            $label .= $yrs . ' Year' . ($yrs > 1 ? 's' : '');
                                                        }
                                                        if ($mos > 0) {
                                                            $label .= ($label ? ' and ' : '') . $mos . ' Month' . ($mos > 1 ? 's' : '');
                                                        }
                                                        if (!$label) {
                                                            $label = '0 Months';
                                                        }
                                                    @endphp
                                                    {{ $label }}
                                                </td>
                                                <td class="text-center" style="vertical-align: middle;">{{ $contract->svcc_total_services }}</td>
                                                <td class="text-center no-print" style="vertical-align: middle;">
                                                    @if ($contract->svcc_contract)
                                                        <a href="{{ asset('images/contracts/' . $contract->svcc_contract) }}"
                                                            class="badge badge-info p-2" style="font-size: 0.85rem;"
                                                            download target="_blank">
                                                            <i class="fas fa-download"></i> Download
                                                        </a>
                                                    @else
                                                        <span class="text-muted">No file.</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($contract->generated_services->isEmpty())
                                                        <span class="text-muted">No appointments generated.</span>
                                                    @else
                                                        <div class="d-flex flex-wrap" style="gap: 6px;">
                                                            @foreach ($contract->generated_services as $svc)
                                                                @php
                                                                    $statusRouteMap = [
                                                                        'CONFIRM ASSESSMENT' => 'client/service/order/appointments/requested/',
                                                                        'ASSESSED' => 'client/service/order/appointments/assessed/',
                                                                        'SCHEDULED' => 'client/service/order/appointments/scheduled/',
                                                                        'ONGOING' => 'client/service/order/appointments/ongoing/',
                                                                        'DONE REPORT' => 'client/service/order/appointments/finished/',
                                                                        'COMPLETED' => 'client/service/order/appointments/completed/',
                                                                    ];
                                                                    $routePrefix = $statusRouteMap[$svc->svc_status] ?? null;
                                                                    $saNumber = 'SA-' . str_pad($svc->svc_sa_number, 6, '0', STR_PAD_LEFT);
                                                                @endphp

                                                                @if ($routePrefix)
                                                                    <a href="{{ url($routePrefix . $svc->svc_id) }}" target="_blank"
                                                                        class="badge badge-primary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }}
                                                                    </a>
                                                                @else
                                                                    <span class="badge badge-secondary sa-badge p-2" style="font-size: 0.85rem;">
                                                                        {{ $saNumber }} ({{ $svc->svc_status }})
                                                                    </span>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function printDefault() {
            window.print();
        }

        function handlePrint() {
            console.log("Print button clicked!");

            const checkboxes = document.querySelectorAll('.print-toggle');
            const warning = document.getElementById('warning');
            let anyChecked = false;

            const sectionIds = ['sectionA', 'sectionB', 'sectionC', 'sectionD', 'sectionF'];

            sectionIds.forEach(sectionId => {
                const section = document.getElementById(sectionId);
                if (section) {
                    section.classList.remove('print-hide');
                }
            });

            checkboxes.forEach(checkbox => {
                const targetId = checkbox.dataset.target;
                const targetDiv = document.getElementById(targetId);

                if (targetDiv) {
                    if (checkbox.checked) {
                        anyChecked = true;
                        targetDiv.classList.remove('print-hide');
                    } else {
                        targetDiv.classList.add('print-hide');
                    }
                } else {
                    console.error(`Element with ID ${targetId} not found!`);
                }
            });

            if (!anyChecked) {
                warning.style.display = 'block';
                return;
            }

            warning.style.display = 'none';

            setTimeout(() => {
                console.log("Triggering print dialog...");
                window.print();
            }, 500);

            setTimeout(() => {
                sectionIds.forEach(sectionId => {
                    const section = document.getElementById(sectionId);
                    if (section) {
                        section.classList.remove('print-hide');
                    }
                });
            }, 1000);
        }
    </script>
@endsection